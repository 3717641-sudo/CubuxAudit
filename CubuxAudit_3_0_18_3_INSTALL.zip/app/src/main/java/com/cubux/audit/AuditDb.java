package com.cubux.audit;
import android.content.*; import android.database.*; import android.database.sqlite.*; import org.json.JSONObject; import java.util.*;
public class AuditDb extends SQLiteOpenHelper {
 public static final String DB_NAME="cubux_audit.db"; private static final int DB_VERSION=10; private final Context appContext;
 public AuditDb(Context c){super(c,DB_NAME,null,DB_VERSION);appContext=c.getApplicationContext();} public void onCreate(SQLiteDatabase db){create(db);} public void onUpgrade(SQLiteDatabase db,int o,int n){String[] pre={"ALTER TABLE app_events ADD COLUMN seen INTEGER NOT NULL DEFAULT 0","ALTER TABLE app_events ADD COLUMN category TEXT NOT NULL DEFAULT 'SYSTEM'","ALTER TABLE app_events ADD COLUMN action TEXT NOT NULL DEFAULT 'EVENTS'"};for(String x:pre)try{db.execSQL(x);}catch(Exception ignored){}create(db);String[] a={"ALTER TABLE transactions ADD COLUMN operation_date TEXT","ALTER TABLE changes ADD COLUMN operation_date TEXT","ALTER TABLE changes ADD COLUMN closed_period INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN duration_ms INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN current_stage TEXT","ALTER TABLE audit_runs ADD COLUMN last_successful_page INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN page_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN received_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN checked_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN speed REAL NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN error TEXT","ALTER TABLE audit_runs ADD COLUMN retry_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN recovery INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN last_activity TEXT","ALTER TABLE audit_runs ADD COLUMN closed_changed_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN multi_changed_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE daily_closures ADD COLUMN currency_totals TEXT NOT NULL DEFAULT '{}'","ALTER TABLE daily_closures ADD COLUMN baseline_data TEXT NOT NULL DEFAULT '[]'","ALTER TABLE changes ADD COLUMN resolution_status TEXT NOT NULL DEFAULT 'OPEN'","ALTER TABLE changes ADD COLUMN resolved_at TEXT","ALTER TABLE changes ADD COLUMN resolution_note TEXT","ALTER TABLE audit_runs ADD COLUMN mode TEXT NOT NULL DEFAULT ''","ALTER TABLE app_events ADD COLUMN seen INTEGER NOT NULL DEFAULT 0","ALTER TABLE app_events ADD COLUMN category TEXT NOT NULL DEFAULT 'SYSTEM'","ALTER TABLE app_events ADD COLUMN action TEXT NOT NULL DEFAULT 'EVENTS'"};for(String s:a)try{db.execSQL(s);}catch(Exception ignored){} if(o<9)try{db.execSQL("UPDATE app_events SET seen=1");}catch(Exception ignored){}}
 private void create(SQLiteDatabase db){db.execSQL("CREATE TABLE IF NOT EXISTS transactions(transaction_id TEXT PRIMARY KEY,operation_date TEXT,data TEXT NOT NULL,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY AUTOINCREMENT,detected_at TEXT NOT NULL,transaction_id TEXT NOT NULL,operation_date TEXT,change_type TEXT NOT NULL,old_data TEXT,new_data TEXT,closed_period INTEGER NOT NULL DEFAULT 0,resolution_status TEXT NOT NULL DEFAULT 'OPEN',resolved_at TEXT,resolution_note TEXT)");db.execSQL("CREATE TABLE IF NOT EXISTS audit_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,started_at TEXT NOT NULL,finished_at TEXT,duration_ms INTEGER NOT NULL DEFAULT 0,total_records INTEGER NOT NULL DEFAULT 0,new_count INTEGER NOT NULL DEFAULT 0,changed_count INTEGER NOT NULL DEFAULT 0,deleted_count INTEGER NOT NULL DEFAULT 0,closed_changed_count INTEGER NOT NULL DEFAULT 0,multi_changed_count INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL,current_stage TEXT,last_successful_page INTEGER NOT NULL DEFAULT 0,page_count INTEGER NOT NULL DEFAULT 0,received_count INTEGER NOT NULL DEFAULT 0,checked_count INTEGER NOT NULL DEFAULT 0,speed REAL NOT NULL DEFAULT 0,error TEXT,retry_count INTEGER NOT NULL DEFAULT 0,recovery INTEGER NOT NULL DEFAULT 0,last_activity TEXT,mode TEXT NOT NULL DEFAULT '')");db.execSQL("CREATE TABLE IF NOT EXISTS daily_closures(date_key TEXT PRIMARY KEY,closed_at TEXT NOT NULL,record_count INTEGER NOT NULL,income_total REAL NOT NULL,expense_total REAL NOT NULL,currency_totals TEXT NOT NULL,control_hash TEXT NOT NULL,baseline_data TEXT NOT NULL,status TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS bank_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,bank_uid TEXT,operation_date TEXT NOT NULL,amount REAL NOT NULL,currency TEXT,description TEXT,counterparty TEXT,raw_data TEXT NOT NULL,imported_at TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS bank_matches(id INTEGER PRIMARY KEY AUTOINCREMENT,bank_transaction_id INTEGER NOT NULL,cubux_transaction_id TEXT,match_status TEXT NOT NULL,match_score REAL NOT NULL,checked_at TEXT NOT NULL,details TEXT)");db.execSQL("CREATE TABLE IF NOT EXISTS app_state(state_key TEXT PRIMARY KEY,state_value TEXT NOT NULL,updated_at TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS app_events(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,level TEXT NOT NULL,source TEXT NOT NULL,message TEXT NOT NULL,seen INTEGER NOT NULL DEFAULT 0,category TEXT NOT NULL DEFAULT 'SYSTEM',action TEXT NOT NULL DEFAULT 'EVENTS')");db.execSQL("CREATE INDEX IF NOT EXISTS idx_changes_tx ON changes(transaction_id)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_changes_date ON changes(operation_date)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_date ON transactions(operation_date)");db.execSQL("CREATE TABLE IF NOT EXISTS day_snapshot(day_key TEXT NOT NULL,transaction_id TEXT NOT NULL,data TEXT NOT NULL,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL,PRIMARY KEY(day_key,transaction_id))");db.execSQL("CREATE TABLE IF NOT EXISTS day_events(id INTEGER PRIMARY KEY AUTOINCREMENT,day_key TEXT NOT NULL,detected_at TEXT NOT NULL,transaction_id TEXT NOT NULL,operation_date TEXT,event_type TEXT NOT NULL,old_data TEXT,new_data TEXT)");db.execSQL("CREATE TABLE IF NOT EXISTS day_scans(id INTEGER PRIMARY KEY AUTOINCREMENT,day_key TEXT NOT NULL,scanned_at TEXT NOT NULL,total_records INTEGER NOT NULL,new_count INTEGER NOT NULL,changed_count INTEGER NOT NULL,deleted_count INTEGER NOT NULL,status TEXT NOT NULL,error TEXT)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_app_events_created ON app_events(created_at)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_app_events_seen ON app_events(seen,id)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_day_events_day ON day_events(day_key,id)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_day_snapshot_day ON day_snapshot(day_key)");}
 public long createRun(boolean recovery){ContentValues v=new ContentValues();v.put("started_at",TimeUtil.now());v.put("status","RUNNING");v.put("current_stage",recovery?"RECOVERY":"CONNECTING");v.put("recovery",recovery?1:0);v.put("last_activity",TimeUtil.now());return getWritableDatabase().insert("audit_runs",null,v);}
 public void setRunMode(long id,String mode){ContentValues v=new ContentValues();v.put("mode",mode==null?"":mode);getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}
 public void updateRunStage(long id,String s){ContentValues v=new ContentValues();v.put("current_stage",s);v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});} public void updateRunProgress(long id,int p,int ps,int r,int total,double speed,int retries){ContentValues v=new ContentValues();v.put("current_stage","READING_DATA");v.put("last_successful_page",p);v.put("page_count",ps);v.put("received_count",r);v.put("total_records",total);v.put("speed",speed);v.put("retry_count",retries);v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}
 public void finishRun(long id,long dur,int total,int n,int ch,int del,int closed,int multi){ContentValues v=new ContentValues();v.put("finished_at",TimeUtil.now());v.put("duration_ms",dur);v.put("total_records",total);v.put("checked_count",total);v.put("new_count",n);v.put("changed_count",ch);v.put("deleted_count",del);v.put("closed_changed_count",closed);v.put("multi_changed_count",multi);v.put("status","OK");v.put("current_stage","COMPLETED");v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});} public void failRun(long id,String e){ContentValues v=new ContentValues();v.put("finished_at",TimeUtil.now());v.put("status","ERROR");v.put("current_stage","ERROR");v.put("error",e);v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}

 public void updateRunDuration(long id,long durationMs){ContentValues v=new ContentValues();v.put("duration_ms",Math.max(0L,durationMs));v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}
 public Map<String,String> transactions(){Map<String,String> m=new HashMap<>();Cursor c=getReadableDatabase().rawQuery("SELECT transaction_id,data FROM transactions",null);try{while(c.moveToNext())m.put(c.getString(0),c.getString(1));}finally{c.close();}return m;}
 public void upsert(String id,String date,String data,String now,boolean exists){ContentValues v=new ContentValues();v.put("operation_date",date);v.put("data",data);v.put("last_seen",now);if(exists)getWritableDatabase().update("transactions",v,"transaction_id=?",new String[]{id});else{v.put("transaction_id",id);v.put("first_seen",now);getWritableDatabase().insertWithOnConflict("transactions",null,v,SQLiteDatabase.CONFLICT_REPLACE);}}
 public void deleteTx(String id){getWritableDatabase().delete("transactions","transaction_id=?",new String[]{id});}
 public void change(String id,String date,String type,String oldD,String newD,boolean closed){ContentValues v=new ContentValues();v.put("detected_at",TimeUtil.now());v.put("transaction_id",id);v.put("operation_date",date);v.put("change_type",type);if(oldD!=null)v.put("old_data",oldD);if(newD!=null)v.put("new_data",newD);v.put("closed_period",closed?1:0);getWritableDatabase().insert("changes",null,v);} public int changeCount(String id){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM changes WHERE transaction_id=?",new String[]{id});try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
 public SQLiteDatabase begin(){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();return d;} public void end(SQLiteDatabase d,boolean ok){if(ok)d.setTransactionSuccessful();d.endTransaction();}
 public void state(String k,String val){ContentValues v=new ContentValues();v.put("state_key",k);v.put("state_value",val);v.put("updated_at",TimeUtil.now());getWritableDatabase().insertWithOnConflict("app_state",null,v,SQLiteDatabase.CONFLICT_REPLACE);} public String state(String k){Cursor c=getReadableDatabase().rawQuery("SELECT state_value FROM app_state WHERE state_key=?",new String[]{k});try{return c.moveToFirst()?c.getString(0):null;}finally{c.close();}}
 public Closure closure(String date){Cursor c=getReadableDatabase().rawQuery("SELECT record_count,income_total,expense_total,currency_totals,control_hash,baseline_data,status FROM daily_closures WHERE date_key=?",new String[]{date});try{return c.moveToFirst()?new Closure(date,c.getInt(0),c.getDouble(1),c.getDouble(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6)):null;}finally{c.close();}}
 public void createClosure(String date,int count,double in,double out,String currencies,String hash,String baseline){if(closure(date)!=null)return;ContentValues v=new ContentValues();v.put("date_key",date);v.put("closed_at",TimeUtil.now());v.put("record_count",count);v.put("income_total",in);v.put("expense_total",out);v.put("currency_totals",currencies);v.put("control_hash",hash);v.put("baseline_data",baseline);v.put("status","CLOSED");getWritableDatabase().insert("daily_closures",null,v);} public void markClosureChanged(String date){ContentValues v=new ContentValues();v.put("status","CHANGED");getWritableDatabase().update("daily_closures",v,"date_key=?",new String[]{date});}
 public void upsertClosure(String date,int count,double in,double out,String currencies,String hash,String baseline,String status){ContentValues v=new ContentValues();v.put("date_key",date);v.put("closed_at",TimeUtil.now());v.put("record_count",count);v.put("income_total",in);v.put("expense_total",out);v.put("currency_totals",currencies);v.put("control_hash",hash);v.put("baseline_data",baseline);v.put("status",status==null?"CLOSED":status);getWritableDatabase().insertWithOnConflict("daily_closures",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
 public int purgeTransactionsAfter(String cutoff){return getWritableDatabase().delete("transactions","operation_date>?",new String[]{cutoff});}
 public int purgeClosuresAfter(String cutoff){return getWritableDatabase().delete("daily_closures","date_key>?",new String[]{cutoff});}

 public String runsText(){Cursor c=getReadableDatabase().rawQuery("SELECT id,started_at,duration_ms,total_records,new_count,changed_count,deleted_count,status,error,recovery FROM audit_runs ORDER BY id DESC LIMIT 30",null);StringBuilder s=new StringBuilder();try{while(c.moveToNext()){String started=c.getString(1),status=c.getString(7);long dur=c.getLong(2);if("RUNNING".equals(status)){long startMs=TimeUtil.parseDateTimeMillis(started);if(startMs>0)dur=Math.max(dur,System.currentTimeMillis()-startMs);}s.append("#").append(c.getLong(0)).append(" • ").append(TimeUtil.displayDateTime(started)).append("\n").append(runStatusRu(status));if(c.getInt(9)==1)s.append(" • Восстановительная проверка");s.append(" • ").append(TimeUtil.duration(dur)).append("\nНовые: ").append(c.getInt(4)).append(" • Изменённые: ").append(c.getInt(5)).append(" • Удалённые: ").append(c.getInt(6));if(c.getString(8)!=null)s.append("\nОшибка: ").append(c.getString(8));s.append("\n\n");}}finally{c.close();}return s.length()==0?"История пока пуста":s.toString();}
 public String journal(String filter,String q){
  Cursor c=getReadableDatabase().rawQuery("SELECT detected_at,transaction_id,operation_date,change_type,old_data,new_data,closed_period FROM changes ORDER BY id DESC LIMIT 500",null);
  StringBuilder s=new StringBuilder();String f=filter==null?"ALL":filter,search=q==null?"":q.toLowerCase().trim();
  try{
   while(c.moveToNext()){
    String detected=c.getString(0),id=c.getString(1),date=c.getString(2),type=c.getString(3),oldD=c.getString(4),newD=c.getString(5);
    boolean closed=c.getInt(6)==1;
    if(!"ALL".equals(f)){
     if("CLOSED".equals(f)&&!closed)continue;
     else if("MULTI".equals(f)&&changeCount(id)<2)continue;
     else if(!"CLOSED".equals(f)&&!"MULTI".equals(f)&&!type.equals(f))continue;
    }
    String blob=(id+" "+date+" "+type+" "+oldD+" "+newD).toLowerCase();
    if(!search.isEmpty()&&!blob.contains(search))continue;

    JSONObject oldJ=parseJson(oldD),newJ=parseJson(newD);
    JSONObject shown=newJ!=null?newJ:oldJ;
    String mark="NEW".equals(type)?"🟢":"DELETED".equals(type)?"🔴":closed?"🟣":"🟡";
    s.append(mark).append(" ").append(changeTypeRu(type));
    if(closed)s.append(" • Закрытый период");
    s.append("\n");

    appendDate(s,date,oldJ,newJ,"CHANGED".equals(type));
    appendOperationType(s,oldJ,newJ,shown,"CHANGED".equals(type));
    appendAmount(s,oldJ,newJ,shown,"CHANGED".equals(type));
    appendField(s,"Категория",oldJ,newJ,shown,"category","CHANGED".equals(type));
    appendAccount(s,oldJ,newJ,shown,"CHANGED".equals(type));
    appendField(s,"Комментарий",oldJ,newJ,shown,"description","CHANGED".equals(type));
    String user=shown==null?"":pretty(shown,"user_name");
    if(!user.isEmpty())appendField(s,"Пользователь операции",oldJ,newJ,shown,"user_name","CHANGED".equals(type));
    s.append("Обнаружено: ").append(TimeUtil.displayDateTime(detected)).append("\n\n");
   }
  }finally{c.close();}
  return s.length()==0?"Ничего не найдено":s.toString();
 }

 /** Technical view intentionally separated from the normal journal. */
 public String diagnosticJournal(){
  Cursor c=getReadableDatabase().rawQuery("SELECT id,detected_at,transaction_id,operation_date,change_type,old_data,new_data,closed_period FROM changes ORDER BY id DESC LIMIT 200",null);
  StringBuilder s=new StringBuilder("РАСШИРЕННАЯ ДИАГНОСТИКА ИЗМЕНЕНИЙ\n\n");
  try{
   while(c.moveToNext()){
    long rowId=c.getLong(0);String detected=c.getString(1),tx=c.getString(2),date=c.getString(3),type=c.getString(4),oldD=c.getString(5),newD=c.getString(6);boolean closed=c.getInt(7)==1;
    s.append("#").append(rowId).append(" • ").append(changeTypeRu(type)).append("\n");
    s.append("ID операции: ").append(tx).append("\n");
    s.append("Техническая причина: ").append(technicalReason(type)).append("\n");
    s.append("Дата операции: ").append(date==null?"—":TimeUtil.displayDateTime(date)).append("\n");
    s.append("Закрытый период: ").append(closed?"да":"нет").append("\n");
    s.append("Обнаружено: ").append(TimeUtil.displayDateTime(detected)).append("\n");
    s.append("Старое значение: ").append(oldD==null?"—":oldD).append("\n");
    s.append("Новое значение: ").append(newD==null?"—":newD).append("\n\n");
   }
  }finally{c.close();}
  if(s.toString().equals("РАСШИРЕННАЯ ДИАГНОСТИКА ИЗМЕНЕНИЙ\n\n"))s.append("Изменений пока нет.");
  return s.toString();
 }

 private String technicalReason(String type){
  if("NEW".equals(type))return "операция появилась в уже защищённом закрытом периоде";
  if("CHANGED".equals(type))return "контрольный отпечаток операции отличается от локального эталона";
  if("DELETED".equals(type))return "операция из локального эталона отсутствует в подтверждённых данных Cubux";
  return type==null?"неизвестно":type;
 }

 private void appendDate(StringBuilder s,String fallback,JSONObject oldJ,JSONObject newJ,boolean changed){
  String a=oldJ==null?"":dateOnly(pretty(oldJ,"date")),b=newJ==null?"":dateOnly(pretty(newJ,"date"));
  if(changed&&!a.equals(b)&&(!a.isEmpty()||!b.isEmpty()))s.append("Дата операции: ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else {String d=!b.isEmpty()?b:(!a.isEmpty()?a:fallback);if(d!=null&&!d.isEmpty())s.append("Дата операции: ").append(d).append("\n");}
 }

 private String dateOnly(String x){return x!=null&&x.length()>=10?x.substring(0,10):(x==null?"":x);}

 private void appendOperationType(StringBuilder s,JSONObject oldJ,JSONObject newJ,JSONObject shown,boolean changed){
  String a=operationType(oldJ),b=operationType(newJ),v=operationType(shown);
  if(changed&&!a.equals(b)&&(!a.isEmpty()||!b.isEmpty()))s.append("Тип операции: ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else if(!v.isEmpty())s.append("Тип операции: ").append(v).append("\n");
 }

 private String operationType(JSONObject o){
  return OperationTypeResolver.resolve(o,this);
 }

 private void appendAmount(StringBuilder s,JSONObject oldJ,JSONObject newJ,JSONObject shown,boolean changed){
  String a=amountWithCurrency(oldJ),b=amountWithCurrency(newJ),v=amountWithCurrency(shown);
  String rawA=oldJ==null?"":pretty(oldJ,"amount")+"|"+pretty(oldJ,"currency_code");
  String rawB=newJ==null?"":pretty(newJ,"amount")+"|"+pretty(newJ,"currency_code");
  if(changed&&!rawA.equals(rawB)&&(!a.isEmpty()||!b.isEmpty()))s.append("Сумма: ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else if(!v.isEmpty())s.append("Сумма: ").append(v).append("\n");
 }

 private String amountWithCurrency(JSONObject o){
  if(o==null)return "";String a=money(pretty(o,"amount"));if(a.isEmpty())return "";String c=currencySymbol(pretty(o,"currency_code"));return c.isEmpty()?a:(a+" "+c);
 }
 private String money(String x){
  if(x==null||x.trim().isEmpty())return "";
  try{return new java.math.BigDecimal(x.trim().replace(" ","").replace(",",".")).stripTrailingZeros().toPlainString();}
  catch(Exception e){return x.trim();}
 }

 private String currencySymbol(String code){
  if(code==null)return "";String c=code.trim().toUpperCase(Locale.ROOT);
  if(c.equals("RUB")||c.equals("RUR")||c.equals("643"))return "₽";
  if(c.equals("USD")||c.equals("840"))return "$";
  if(c.equals("EUR")||c.equals("978"))return "€";
  if(c.equals("GBP")||c.equals("826"))return "£";
  if(c.equals("CNY")||c.equals("RMB")||c.equals("156"))return "¥";
  if(c.equals("KZT")||c.equals("398"))return "₸";
  if(c.equals("BYN")||c.equals("933"))return "Br";
  if(c.equals("TRY")||c.equals("949"))return "₺";
  return code.trim();
 }


 private void appendAccount(StringBuilder s,JSONObject oldJ,JSONObject newJ,JSONObject shown,boolean changed){
  String a=accountDisplay(oldJ),b=accountDisplay(newJ),v=accountDisplay(shown);
  if(changed&&!a.equals(b))s.append("Счёт: ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else if(!v.isEmpty())s.append("Счёт: ").append(v).append("\n");
 }
 private String accountDisplay(JSONObject o){
  if(o==null)return "";
  String n=pretty(o,"account_name"); if(!n.isEmpty())return n;
  String raw=pretty(o,"account"); if(raw.isEmpty())return "";
  String cached=getState("account_name:"+raw); if(cached!=null&&!cached.trim().isEmpty())return cached.trim();
  if(raw.matches("\\d+"))return "Неизвестный счёт";
  return raw;
 }

 private void appendField(StringBuilder s,String label,JSONObject oldJ,JSONObject newJ,JSONObject shown,String key,boolean changed){
  String a=oldJ==null?"":pretty(oldJ,key),b=newJ==null?"":pretty(newJ,key),v=shown==null?"":pretty(shown,key);
  if(changed&&!a.equals(b))s.append(label).append(": ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else if(!v.isEmpty())s.append(label).append(": ").append(v).append("\n");
 }
 private JSONObject parseJson(String x){if(x==null||x.trim().isEmpty())return null;try{return new JSONObject(x);}catch(Exception e){return null;}}
 private String pretty(JSONObject o,String k){if(o==null)return "";Object v=o.opt(k);if(v==null||v==JSONObject.NULL)return "";String x=String.valueOf(v);return "null".equalsIgnoreCase(x)?"":x;}
 private void appendDiff(StringBuilder s,String label,JSONObject a,JSONObject b,String key){
  String av=pretty(a,key),bv=pretty(b,key);if(!av.equals(bv))s.append(label).append(": ").append(av.isEmpty()?"—":av).append(" → ").append(bv.isEmpty()?"—":bv).append("\n");
 }
 public List<JSONObject> currentJson(){List<JSONObject> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT data FROM transactions",null);try{while(c.moveToNext())try{a.add(new JSONObject(c.getString(0)));}catch(Exception ignored){}}finally{c.close();}return a;}
 public void clearBank(){SQLiteDatabase d=getWritableDatabase();d.delete("bank_matches",null,null);d.delete("bank_transactions",null,null);} public long bankInsert(String uid,String date,double amount,String cur,String desc,String cp,String raw){ContentValues v=new ContentValues();v.put("bank_uid",uid);v.put("operation_date",date);v.put("amount",amount);v.put("currency",cur);v.put("description",desc);v.put("counterparty",cp);v.put("raw_data",raw);v.put("imported_at",TimeUtil.now());return getWritableDatabase().insert("bank_transactions",null,v);}
 public List<BankRow> bankRows(){List<BankRow>a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,bank_uid,operation_date,amount,currency,description,counterparty FROM bank_transactions ORDER BY operation_date",null);try{while(c.moveToNext())a.add(new BankRow(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4),c.getString(5),c.getString(6)));}finally{c.close();}return a;}
 public void bankMatch(long bank,String cubux,String status,double score,String details){ContentValues v=new ContentValues();v.put("bank_transaction_id",bank);v.put("cubux_transaction_id",cubux);v.put("match_status",status);v.put("match_score",score);v.put("checked_at",TimeUtil.now());v.put("details",details);getWritableDatabase().insert("bank_matches",null,v);} public String bankSummary(){Cursor c=getReadableDatabase().rawQuery("SELECT match_status,COUNT(*) FROM bank_matches GROUP BY match_status",null);Map<String,Integer>m=new HashMap<>();try{while(c.moveToNext())m.put(c.getString(0),c.getInt(1));}finally{c.close();}return "БАНКОВСКАЯ СВЕРКА\n\n✅ Точное: "+m.getOrDefault("EXACT",0)+"\n🟡 Вероятное: "+m.getOrDefault("PROBABLE",0)+"\n🟠 Ручная проверка: "+m.getOrDefault("MANUAL",0)+"\n🔴 Нет в Cubux: "+m.getOrDefault("MISSING_CUBUX",0)+"\n\nВсе ли доходы банка отражены в Cubux?";}
 public static class Closure{public final String date,currencies,hash,baseline,status;public final int count;public final double income,expense;Closure(String d,int c,double i,double e,String cur,String h,String b,String s){date=d;count=c;income=i;expense=e;currencies=cur;hash=h;baseline=b;status=s;}}
 public static class BankRow{public final long id;public final String uid,date,currency,description,counterparty;public final double amount;BankRow(long i,String u,String d,double a,String c,String x,String p){id=i;uid=u;date=d;amount=a;currency=c;description=x;counterparty=p;}}
 public String resolvedOperationType(JSONObject o){return OperationTypeResolver.resolve(o,this);}

 public static class ChangeItem{
  public final long id; public final String detectedAt,transactionId,operationDate,changeType,oldData,newData,resolutionStatus,resolvedAt,resolutionNote; public final boolean closedPeriod;
  ChangeItem(long id,String detectedAt,String transactionId,String operationDate,String changeType,String oldData,String newData,boolean closedPeriod,String resolutionStatus,String resolvedAt,String resolutionNote){this.id=id;this.detectedAt=detectedAt;this.transactionId=transactionId;this.operationDate=operationDate;this.changeType=changeType;this.oldData=oldData;this.newData=newData;this.closedPeriod=closedPeriod;this.resolutionStatus=resolutionStatus==null?"OPEN":resolutionStatus;this.resolvedAt=resolvedAt;this.resolutionNote=resolutionNote;}
 }
 public java.util.List<ChangeItem> changeItems(String resolution,String type,String q,int limit,int offset){
  int safe=Math.max(1,Math.min(200,limit)), off=Math.max(0,offset); java.util.ArrayList<ChangeItem> out=new java.util.ArrayList<>();
  StringBuilder where=new StringBuilder("1=1"); java.util.ArrayList<String> args=new java.util.ArrayList<>();
  if(resolution!=null&&!resolution.equals("ALL")){where.append(" AND resolution_status=?");args.add(resolution);}
  if(type!=null&&!type.equals("ALL")){where.append(" AND change_type=?");args.add(type);}
  if(q!=null&&!q.trim().isEmpty()){String like="%"+q.trim()+"%";where.append(" AND (transaction_id LIKE ? OR operation_date LIKE ? OR old_data LIKE ? OR new_data LIKE ?)");for(int i=0;i<4;i++)args.add(like);}
  Cursor c=getReadableDatabase().rawQuery("SELECT id,detected_at,transaction_id,operation_date,change_type,old_data,new_data,closed_period,resolution_status,resolved_at,resolution_note FROM changes WHERE "+where+" ORDER BY id DESC LIMIT "+safe+" OFFSET "+off,args.toArray(new String[0]));
  try{while(c.moveToNext())out.add(new ChangeItem(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getInt(7)==1,c.getString(8),c.getString(9),c.getString(10)));}finally{c.close();}return out;
 }
 public int unresolvedChangeCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM changes WHERE resolution_status='OPEN'",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
 public void resolveChange(long id,String note){ContentValues v=new ContentValues();v.put("resolution_status","RESOLVED");v.put("resolved_at",TimeUtil.now());v.put("resolution_note",note==null?"":note.trim());getWritableDatabase().update("changes",v,"id=?",new String[]{String.valueOf(id)});}
 public void reopenChange(long id){ContentValues v=new ContentValues();v.put("resolution_status","OPEN");v.putNull("resolved_at");v.put("resolution_note","");getWritableDatabase().update("changes",v,"id=?",new String[]{String.valueOf(id)});}
 public String changeTitle(ChangeItem x){JSONObject o=parseJson(x.newData);if(o==null)o=parseJson(x.oldData);String d=pretty(o,"description");if(!d.isEmpty())return d;String cp=pretty(o,"counterparty");if(!cp.isEmpty())return cp;String cat=pretty(o,"category");if(!cat.isEmpty())return cat;return "Операция";}
 public String changeOperationType(ChangeItem x){JSONObject o=parseJson(x.newData);if(o==null)o=parseJson(x.oldData);String v=operationType(o);return v.isEmpty()?"—":v;}
 public String changeAmountSummary(ChangeItem x){JSONObject a=parseJson(x.oldData),b=parseJson(x.newData);String av=amountWithCurrency(a),bv=amountWithCurrency(b);if("CHANGED".equals(x.changeType)&&!av.equals(bv)&&(!av.isEmpty()||!bv.isEmpty()))return (av.isEmpty()?"—":av)+" → "+(bv.isEmpty()?"—":bv);String v=!bv.isEmpty()?bv:av;return v.isEmpty()?"—":v;}
 public String changeDetails(ChangeItem x){StringBuilder s=new StringBuilder();JSONObject oldJ=parseJson(x.oldData),newJ=parseJson(x.newData),shown=newJ!=null?newJ:oldJ;boolean changed="CHANGED".equals(x.changeType);appendDate(s,x.operationDate,oldJ,newJ,changed);appendOperationType(s,oldJ,newJ,shown,changed);appendAmount(s,oldJ,newJ,shown,changed);appendField(s,"Категория",oldJ,newJ,shown,"category",changed);appendAccount(s,oldJ,newJ,shown,changed);appendField(s,"Описание",oldJ,newJ,shown,"description",changed);appendField(s,"Пользователь операции",oldJ,newJ,shown,"user_name",changed);s.append("Обнаружено: ").append(TimeUtil.displayDateTime(x.detectedAt)).append("\n");if(x.closedPeriod)s.append("Период: закрытый\n");if("RESOLVED".equals(x.resolutionStatus)){s.append("Решено: ").append(TimeUtil.displayDateTime(x.resolvedAt)).append("\n");if(x.resolutionNote!=null&&!x.resolutionNote.trim().isEmpty())s.append("Комментарий: ").append(x.resolutionNote.trim()).append("\n");}return s.toString();}

 public static class ChangeStats{public final int total,newCount,changedCount,deletedCount,daysWithChanges,totalTransactions,peakCount;public final String lastDetected,peakLabel;ChangeStats(int total,int n,int ch,int del,int days,int tx,String last,String peak,int peakCount){this.total=total;this.newCount=n;this.changedCount=ch;this.deletedCount=del;this.daysWithChanges=days;this.totalTransactions=tx;this.lastDetected=last;this.peakLabel=peak;this.peakCount=peakCount;}}
 public ChangeStats changeStats(String from,String to){int total=0,n=0,ch=0,del=0,days=0,peak=0;String last="",peakDay="";String[] a={from,to};Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*),SUM(CASE WHEN change_type='NEW' THEN 1 ELSE 0 END),SUM(CASE WHEN change_type='CHANGED' THEN 1 ELSE 0 END),SUM(CASE WHEN change_type='DELETED' THEN 1 ELSE 0 END),MAX(detected_at) FROM changes WHERE substr(detected_at,1,10)>=? AND substr(detected_at,1,10)<=?",a);try{if(c.moveToFirst()){total=c.getInt(0);n=c.isNull(1)?0:c.getInt(1);ch=c.isNull(2)?0:c.getInt(2);del=c.isNull(3)?0:c.getInt(3);last=c.getString(4);}}finally{c.close();}Cursor d=getReadableDatabase().rawQuery("SELECT substr(detected_at,1,10),COUNT(*) FROM changes WHERE substr(detected_at,1,10)>=? AND substr(detected_at,1,10)<=? GROUP BY substr(detected_at,1,10) ORDER BY COUNT(*) DESC,1 DESC",a);try{boolean first=true;while(d.moveToNext()){days++;if(first){peakDay=d.getString(0);peak=d.getInt(1);first=false;}}}finally{d.close();}return new ChangeStats(total,n,ch,del,days,transactionCount(),last,peakDay,peak);}
 public static class ChangeBucket{public final String key,label;public final int newCount,changedCount,deletedCount;ChangeBucket(String key,String label,int n,int ch,int d){this.key=key;this.label=label;this.newCount=n;this.changedCount=ch;this.deletedCount=d;}public int total(){return newCount+changedCount+deletedCount;}}
 public java.util.List<ChangeBucket> changeBuckets(String from,String to,String mode){java.util.ArrayList<ChangeBucket> out=new java.util.ArrayList<>();String expr="YEAR".equals(mode)?"substr(detected_at,1,7)":"DAY".equals(mode)?"substr(detected_at,12,2)":"substr(detected_at,1,10)";Cursor c=getReadableDatabase().rawQuery("SELECT "+expr+",SUM(CASE WHEN change_type='NEW' THEN 1 ELSE 0 END),SUM(CASE WHEN change_type='CHANGED' THEN 1 ELSE 0 END),SUM(CASE WHEN change_type='DELETED' THEN 1 ELSE 0 END) FROM changes WHERE substr(detected_at,1,10)>=? AND substr(detected_at,1,10)<=? GROUP BY "+expr+" ORDER BY "+expr,new String[]{from,to});try{while(c.moveToNext()){String k=c.getString(0),label=k;if("YEAR".equals(mode)&&k!=null&&k.length()==7)label=k.substring(5);else if(!"DAY".equals(mode)&&k!=null&&k.length()>=10)label=k.substring(8,10)+"."+k.substring(5,7);else if("DAY".equals(mode))label=k+":00";out.add(new ChangeBucket(k,label,c.getInt(1),c.getInt(2),c.getInt(3)));}}finally{c.close();}return out;}

 public java.util.List<RunSummary> runsPage(String filter,String q,int limit,int offset){int safe=Math.max(1,Math.min(50,limit)),off=Math.max(0,offset);StringBuilder w=new StringBuilder("1=1");java.util.ArrayList<String>a=new java.util.ArrayList<>();if("CHANGES".equals(filter))w.append(" AND (new_count+changed_count+deleted_count)>0");else if("ERROR".equals(filter))w.append(" AND status='ERROR'");else if("STOPPED".equals(filter))w.append(" AND status='STOPPED'");if(q!=null&&!q.trim().isEmpty()){String like="%"+q.trim()+"%";w.append(" AND (CAST(id AS TEXT) LIKE ? OR started_at LIKE ?)");a.add(like);a.add(like);}java.util.ArrayList<RunSummary> out=new java.util.ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,started_at,finished_at,duration_ms,total_records,new_count,changed_count,deleted_count,status,recovery,error,mode FROM audit_runs WHERE "+w+" ORDER BY id DESC LIMIT "+safe+" OFFSET "+off,a.toArray(new String[0]));try{while(c.moveToNext()){String started=c.getString(1),finished=c.getString(2),status=c.getString(8);long dur=c.getLong(3),startMs=TimeUtil.parseDateTimeMillis(started);if("RUNNING".equals(status)&&startMs>0)dur=Math.max(dur,System.currentTimeMillis()-startMs);else if(dur<=0&&startMs>0){long end=TimeUtil.parseDateTimeMillis(finished);if(end>startMs)dur=end-startMs;}out.add(new RunSummary(c.getLong(0),started,dur,c.getInt(4),c.getInt(5),c.getInt(6),c.getInt(7),status,c.getInt(9)==1,c.getString(10),c.getString(11)));}}finally{c.close();}return out;}

 public String changeTypeRu(String type){if("NEW".equals(type))return "Новые";if("CHANGED".equals(type))return "Изменённые";if("DELETED".equals(type))return "Удалённые";return type;}
 public String runStatusRu(String status){if("OK".equals(status))return "Завершено";if("ERROR".equals(status))return "Ошибка";if("STOPPED".equals(status))return "Остановлено";if("RUNNING".equals(status))return "Выполняется";return status;}
 // Compatibility API used by 2.1 modules
 public void updateRunProgress(long id,String stage,int p,int ps,int r,int total,double speed,int retries){updateRunProgress(id,p,ps,r,total,speed,retries); if(stage!=null) updateRunStage(id,stage);}
 public void saveState(String k,String val){state(k,val);}
 public String getState(String k){return state(k);}

 public static class RunSummary{
  public final long id; public final String startedAt,status,error,mode; public final long durationMs; public final int total,newCount,changedCount,deletedCount; public final boolean recovery;
  RunSummary(long id,String startedAt,long durationMs,int total,int n,int ch,int del,String status,boolean recovery,String error,String mode){this.id=id;this.startedAt=startedAt;this.durationMs=durationMs;this.total=total;this.newCount=n;this.changedCount=ch;this.deletedCount=del;this.status=status;this.recovery=recovery;this.error=error;this.mode=mode==null?"":mode;}
 }
 public int transactionCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM transactions",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
 public java.util.List<RunSummary> recentRuns(int limit){
  int safe=Math.max(1,Math.min(30,limit)); java.util.ArrayList<RunSummary> out=new java.util.ArrayList<>();
  Cursor c=getReadableDatabase().rawQuery("SELECT id,started_at,finished_at,duration_ms,total_records,new_count,changed_count,deleted_count,status,recovery,error,mode FROM audit_runs ORDER BY id DESC LIMIT "+safe,null);
  try{while(c.moveToNext()){
   String started=c.getString(1),finished=c.getString(2),status=c.getString(8); long dur=c.getLong(3);
   long startMs=TimeUtil.parseDateTimeMillis(started);
   if("RUNNING".equals(status)){if(startMs>0)dur=Math.max(dur,System.currentTimeMillis()-startMs);}
   else if(dur<=0&&startMs>0){long endMs=TimeUtil.parseDateTimeMillis(finished);if(endMs>startMs)dur=endMs-startMs;}
   out.add(new RunSummary(c.getLong(0),started,dur,c.getInt(4),c.getInt(5),c.getInt(6),c.getInt(7),status,c.getInt(9)==1,c.getString(10),c.getString(11)));
  }}finally{c.close();}
  return out;
 }

 public String recentRunsText(){return runsText();}
 public String journalText(String filter,String q){return journal(filter,q);}
 public List<JSONObject> getCurrentTransactionsJson(){return currentJson();}



 public static class AppEvent{
  public final long id; public final String createdAt,level,source,message,category,action; public final boolean seen;
  AppEvent(long id,String createdAt,String level,String source,String message,boolean seen,String category,String action){this.id=id;this.createdAt=createdAt;this.level=level;this.source=source;this.message=message;this.seen=seen;this.category=category;this.action=action;}
 }
 private String inferEventCategory(String source){String x=source==null?"":source.toUpperCase(Locale.ROOT);if(x.contains("КОНТРОЛЬ ДНЯ"))return "TODAY";if(x.contains("ПРОВЕР"))return "CHECKS";return "SYSTEM";}
 private String inferEventAction(String category){if("TODAY".equals(category))return "TODAY";if("CHECKS".equals(category))return "CHECKS";return "EVENTS";}
 public void appEvent(String level,String source,String message){String cat=inferEventCategory(source);boolean attention=level!=null&&!"INFO".equals(level);appEvent(level,source,message,cat,inferEventAction(cat),attention);}
 public void appEvent(String level,String source,String message,String category,String action,boolean attention){
  if(message==null||message.trim().isEmpty())return;String lv=level==null?"INFO":level;String src=source==null?"APP":source;String cat=category==null?inferEventCategory(src):category;String act=action==null?inferEventAction(cat):action;
  ContentValues v=new ContentValues();v.put("created_at",TimeUtil.now());v.put("level",lv);v.put("source",src);v.put("message",message.trim());v.put("seen",attention?0:1);v.put("category",cat);v.put("action",act);getWritableDatabase().insert("app_events",null,v);
  try{getWritableDatabase().execSQL("DELETE FROM app_events WHERE id NOT IN (SELECT id FROM app_events ORDER BY id DESC LIMIT 3000)");}catch(Exception ignored){}
 }
 public int unreadEventCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM app_events WHERE seen=0",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
 public List<AppEvent> unreadEvents(int limit){int safe=Math.max(1,Math.min(100,limit));ArrayList<AppEvent> out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,created_at,level,source,message,seen,category,action FROM app_events WHERE seen=0 ORDER BY CASE level WHEN 'ALERT' THEN 4 WHEN 'ERROR' THEN 4 WHEN 'WARNING' THEN 3 WHEN 'INFO' THEN 2 WHEN 'OK' THEN 1 ELSE 0 END DESC,id ASC LIMIT "+safe,null);try{while(c.moveToNext())out.add(new AppEvent(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getInt(5)==1,c.getString(6),c.getString(7)));}finally{c.close();}return out;}
 public List<AppEvent> appEvents(String filter,int limit){int safe=Math.max(1,Math.min(500,limit));String where="1=1";ArrayList<String>a=new ArrayList<>();if("IMPORTANT".equals(filter))where+=" AND level IN ('ALERT','ERROR','WARNING')";else if("CHECKS".equals(filter)){where+=" AND category=?";a.add("CHECKS");}else if("TODAY".equals(filter)){where+=" AND category=?";a.add("TODAY");}else if("SYSTEM".equals(filter)){where+=" AND category=?";a.add("SYSTEM");}ArrayList<AppEvent>out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,created_at,level,source,message,seen,category,action FROM app_events WHERE "+where+" ORDER BY id DESC LIMIT "+safe,a.toArray(new String[0]));try{while(c.moveToNext())out.add(new AppEvent(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getInt(5)==1,c.getString(6),c.getString(7)));}finally{c.close();}return out;}
 public void markEventSeen(long id){ContentValues v=new ContentValues();v.put("seen",1);getWritableDatabase().update("app_events",v,"id=?",new String[]{String.valueOf(id)});}
 public void markAllEventsSeen(){ContentValues v=new ContentValues();v.put("seen",1);getWritableDatabase().update("app_events",v,"seen=0",null);}
 public String eventsText(){StringBuilder s=new StringBuilder();for(AppEvent e:appEvents("ALL",300)){String icon="INFO".equals(e.level)?"ℹ":"OK".equals(e.level)?"✓":"WARNING".equals(e.level)?"⚠":("ERROR".equals(e.level)||"ALERT".equals(e.level))?"✖":"•";s.append(icon).append(" ").append(TimeUtil.displayDateTime(e.createdAt)).append("  •  ").append(e.source).append("\n").append(e.message).append("\n\n");}return s.length()==0?"История событий пока пуста":s.toString();}

 public static class DayScanResult{public final String day;public final int total,newCount,changedCount,deletedCount;DayScanResult(String day,int total,int n,int c,int d){this.day=day;this.total=total;this.newCount=n;this.changedCount=c;this.deletedCount=d;}}
 public static class DaySummary{public final int total,newCount,changedCount,deletedCount;public final String lastScan,status;DaySummary(int total,int n,int c,int d,String lastScan,String status){this.total=total;this.newCount=n;this.changedCount=c;this.deletedCount=d;this.lastScan=lastScan;this.status=status;}}
 public static class DayEvent{public final long id;public final String day,detectedAt,transactionId,operationDate,eventType,oldData,newData;DayEvent(long id,String day,String detectedAt,String transactionId,String operationDate,String eventType,String oldData,String newData){this.id=id;this.day=day;this.detectedAt=detectedAt;this.transactionId=transactionId;this.operationDate=operationDate;this.eventType=eventType;this.oldData=oldData;this.newData=newData;}}
 public Map<String,String> daySnapshot(String day){Map<String,String>m=new LinkedHashMap<>();Cursor c=getReadableDatabase().rawQuery("SELECT transaction_id,data FROM day_snapshot WHERE day_key=?",new String[]{day});try{while(c.moveToNext())m.put(c.getString(0),c.getString(1));}finally{c.close();}return m;}
 private String dataDate(String data,String fallback){try{String d=AuditEngine.operationDate(new JSONObject(data));return d==null?fallback:d;}catch(Exception e){return fallback;}}
 private void insertDayEvent(SQLiteDatabase sql,String day,String now,String id,String type,String oldD,String newD){ContentValues v=new ContentValues();v.put("day_key",day);v.put("detected_at",now);v.put("transaction_id",id);v.put("operation_date",dataDate(newD!=null?newD:oldD,day));v.put("event_type",type);if(oldD!=null)v.put("old_data",oldD);if(newD!=null)v.put("new_data",newD);sql.insert("day_events",null,v);}
 public DayScanResult applyDayScan(String day,Map<String,String>current,String now) throws Exception{Map<String,String>old=daySnapshot(day);int n=0,ch=0,del=0;SQLiteDatabase sql=getWritableDatabase();sql.beginTransaction();try{for(Map.Entry<String,String>e:current.entrySet()){String id=e.getKey(),nd=e.getValue(),od=old.get(id);if(od==null){n++;insertDayEvent(sql,day,now,id,"NEW",null,nd);}else if(!HashUtil.sha256(od).equals(HashUtil.sha256(nd))){ch++;insertDayEvent(sql,day,now,id,"CHANGED",od,nd);}ContentValues v=new ContentValues();v.put("day_key",day);v.put("transaction_id",id);v.put("data",nd);v.put("last_seen",now);if(od==null)v.put("first_seen",now);else{Cursor fc=sql.rawQuery("SELECT first_seen FROM day_snapshot WHERE day_key=? AND transaction_id=?",new String[]{day,id});try{v.put("first_seen",fc.moveToFirst()?fc.getString(0):now);}finally{fc.close();}}sql.insertWithOnConflict("day_snapshot",null,v,SQLiteDatabase.CONFLICT_REPLACE);}for(Map.Entry<String,String>e:old.entrySet()){if(current.containsKey(e.getKey()))continue;del++;insertDayEvent(sql,day,now,e.getKey(),"DELETED",e.getValue(),null);sql.delete("day_snapshot","day_key=? AND transaction_id=?",new String[]{day,e.getKey()});}ContentValues r=new ContentValues();r.put("day_key",day);r.put("scanned_at",now);r.put("total_records",current.size());r.put("new_count",n);r.put("changed_count",ch);r.put("deleted_count",del);r.put("status","OK");sql.insert("day_scans",null,r);if(day!=null&&day.equals(TimeUtil.today()))sql.delete("day_snapshot","day_key<?",new String[]{day});sql.setTransactionSuccessful();}finally{sql.endTransaction();}return new DayScanResult(day,current.size(),n,ch,del);}
 public void recordDayScanError(String day,String error){ContentValues r=new ContentValues();r.put("day_key",day);r.put("scanned_at",TimeUtil.now());r.put("total_records",daySnapshot(day).size());r.put("new_count",0);r.put("changed_count",0);r.put("deleted_count",0);r.put("status","ERROR");r.put("error",error==null?"":error);getWritableDatabase().insert("day_scans",null,r);}
 public DaySummary daySummary(String day){int total=0,n=0,ch=0,del=0;String last="",status="";Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM day_snapshot WHERE day_key=?",new String[]{day});try{if(c.moveToFirst())total=c.getInt(0);}finally{c.close();}Cursor e=getReadableDatabase().rawQuery("SELECT SUM(CASE WHEN event_type='NEW' THEN 1 ELSE 0 END),SUM(CASE WHEN event_type='CHANGED' THEN 1 ELSE 0 END),SUM(CASE WHEN event_type='DELETED' THEN 1 ELSE 0 END) FROM day_events WHERE day_key=?",new String[]{day});try{if(e.moveToFirst()){n=e.isNull(0)?0:e.getInt(0);ch=e.isNull(1)?0:e.getInt(1);del=e.isNull(2)?0:e.getInt(2);}}finally{e.close();}Cursor r=getReadableDatabase().rawQuery("SELECT scanned_at,status,total_records FROM day_scans WHERE day_key=? ORDER BY id DESC LIMIT 1",new String[]{day});try{if(r.moveToFirst()){last=r.getString(0);status=r.getString(1);total=Math.max(total,r.getInt(2));}}finally{r.close();}return new DaySummary(total,n,ch,del,last,status);}
 public List<DayEvent> dayEvents(String day,String type,int limit){int safe=Math.max(1,Math.min(300,limit));ArrayList<DayEvent>out=new ArrayList<>();String where="day_key=?";ArrayList<String>a=new ArrayList<>();a.add(day);if(type!=null&&!"ALL".equals(type)){where+=" AND event_type=?";a.add(type);}Cursor c=getReadableDatabase().rawQuery("SELECT id,day_key,detected_at,transaction_id,operation_date,event_type,old_data,new_data FROM day_events WHERE "+where+" ORDER BY id DESC LIMIT "+safe,a.toArray(new String[0]));try{while(c.moveToNext())out.add(new DayEvent(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7)));}finally{c.close();}return out;}
 public String dayEventTitle(DayEvent x){JSONObject o=parseJson(x.newData);if(o==null)o=parseJson(x.oldData);String d=pretty(o,"description");if(!d.isEmpty())return d;String cat=pretty(o,"category");if(!cat.isEmpty())return cat;return "Операция";}
 public String dayEventOperationType(DayEvent x){JSONObject o=parseJson(x.newData);if(o==null)o=parseJson(x.oldData);String v=operationType(o);return v.isEmpty()?"—":v;}
 public String dayEventAmountSummary(DayEvent x){JSONObject a=parseJson(x.oldData),b=parseJson(x.newData);String av=amountWithCurrency(a),bv=amountWithCurrency(b);if("CHANGED".equals(x.eventType)&&!av.equals(bv)&&(!av.isEmpty()||!bv.isEmpty()))return (av.isEmpty()?"—":av)+" → "+(bv.isEmpty()?"—":bv);String v=!bv.isEmpty()?bv:av;return v.isEmpty()?"—":v;}
 public String dayEventDetails(DayEvent x){StringBuilder s=new StringBuilder();JSONObject oldJ=parseJson(x.oldData),newJ=parseJson(x.newData),shown=newJ!=null?newJ:oldJ;boolean changed="CHANGED".equals(x.eventType);appendDate(s,x.operationDate,oldJ,newJ,changed);appendOperationType(s,oldJ,newJ,shown,changed);appendAmount(s,oldJ,newJ,shown,changed);appendField(s,"Категория",oldJ,newJ,shown,"category",changed);appendAccount(s,oldJ,newJ,shown,changed);appendField(s,"Описание",oldJ,newJ,shown,"description",changed);appendField(s,"Пользователь операции",oldJ,newJ,shown,"user_name",changed);s.append("Обнаружено: ").append(TimeUtil.displayDateTime(x.detectedAt)).append("\n");s.append("Дневной контроль: только наблюдение, на основную проверку не влияет\n");return s.toString();}

 public void clearResolvedAttention(){saveState("missed_check_pending","0");}

 public int stopStaleRunningRuns(){ContentValues v=new ContentValues();v.put("finished_at",TimeUtil.now());v.put("status","STOPPED");v.put("current_stage","STOPPED");v.put("last_activity",TimeUtil.now());return getWritableDatabase().update("audit_runs",v,"status='RUNNING'",null);}
 public void stopRun(long id){ContentValues v=new ContentValues();v.put("finished_at",TimeUtil.now());v.put("status","STOPPED");v.put("current_stage","STOPPED");v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}
 public Set<String> closureDates(){Set<String>s=new HashSet<>();Cursor c=getReadableDatabase().rawQuery("SELECT date_key FROM daily_closures",null);try{while(c.moveToNext())s.add(c.getString(0));}finally{c.close();}return s;} public void cleanupLegacyBaselineNoise(){try{Cursor r=getReadableDatabase().rawQuery("SELECT started_at,finished_at,total_records,new_count FROM audit_runs ORDER BY id ASC LIMIT 1",null);try{if(r.moveToFirst()){String s=r.getString(0),f=r.getString(1);int total=r.getInt(2),n=r.getInt(3);if(f!=null&&total>0&&n>=Math.max(10,(int)(total*0.90))){getWritableDatabase().delete("changes","change_type='NEW' AND detected_at>=? AND detected_at<=?",new String[]{s,f});saveState("legacy_baseline_noise_cleaned","1");}}}finally{r.close();}}catch(Exception ignored){}}

}
