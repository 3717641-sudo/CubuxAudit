package com.cubux.audit;

import android.app.job.JobParameters;
import android.app.job.JobService;

public class ScheduledCheckJobService extends JobService {
    private volatile boolean cancelled=false;

    @Override public boolean onStartJob(JobParameters params){
        new Thread(()->runJob(params)).start();return true;
    }

    private void runJob(JobParameters params){
        String type=params.getExtras().getString("check_type",CheckSettings.TYPE_LIGHT);
        int previous=params.getExtras().getInt("attempt",0);
        int attempt=previous+1;
        int max=new CheckSettings(getApplicationContext()).retries();
        String mode=CheckSettings.TYPE_FULL.equals(type)?AuditCoordinator.MODE_FULL:AuditCoordinator.MODE_QUICK;
        String label=CheckSettings.TYPE_FULL.equals(type)?"Полная проверка":"Лёгкая проверка";
        boolean retry=false;
        try{
            CheckStatusStore.running(getApplicationContext(),label);
            DiagnosticLog.write(getApplicationContext(),"SCHEDULED",label+" запущена. Попытка="+attempt+"/"+max);
            AuditCoordinator c=new AuditCoordinator(getApplicationContext());
            AuditEngine.Result r=c.runStoredMode(c.isRecovery(),null,mode);
            String actual=new AuditDb(getApplicationContext()).getState("last_audit_mode");
            if("FULL_AFTER_LIGHT".equals(actual))label="Лёгкая → полная проверка";
            CheckStatusStore.success(getApplicationContext(),label,r);
        }catch(Exception e){
            String msg=e.getMessage()==null?e.toString():e.getMessage();
            boolean permanent=msg.contains("Логин/пароль Cubux не сохранены")||msg.contains("HTTP 401")||msg.contains("HTTP 403");
            retry=!permanent && attempt<max;
            CheckStatusStore.failure(getApplicationContext(),label,attempt,msg);
            DiagnosticLog.error(getApplicationContext(),"SCHEDULED_ERROR",e);
            if(!msg.contains("Другая проверка уже выполняется")){
                NotificationHelper.showAuditResult(getApplicationContext(),false,
                        retry?label+" не выполнена. Попытка "+attempt+" из "+max+"; повтор будет автоматически."
                                :label+" не выполнена после "+attempt+" попыток. Причина: "+msg);
            }
        }finally{
            if(!cancelled){
                jobFinished(params,false);
                if(retry)CheckScheduler.scheduleRetry(getApplicationContext(),type,attempt);
                else CheckScheduler.scheduleNext(getApplicationContext());
            }
        }
    }

    @Override public boolean onStopJob(JobParameters params){cancelled=true;return true;}
}
