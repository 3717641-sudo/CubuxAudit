package com.cubux.audit;

import java.util.Locale;

/** Rules for user-marked test records. Does not alter audit/security baselines. */
public final class TestRecordPolicy {
    private TestRecordPolicy() {}

    public static boolean isTestNote(String note) {
        if (note == null) return false;
        String normalized = note.trim().replaceAll("\\s+", " ").toLowerCase(new Locale("ru", "RU"));
        return "тест".equals(normalized);
    }

    public static boolean isTestResolved(String status, String note) {
        return "RESOLVED".equals(status) && isTestNote(note);
    }
}
