package com.cubux.audit;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class BackupManager {
    private static final int MAX_BACKUP_BYTES = 768 * 1024 * 1024;
    private final Context c;
    private final AuditDb db;

    public BackupManager(Context c, AuditDb d) {
        this.c = c.getApplicationContext();
        this.db = d;
    }

    public String exportTo(ContentResolver r, Uri u) throws Exception {
        SQLiteDatabase s = db.getWritableDatabase();
        checkpointOrThrow(s);
        File f = c.getDatabasePath(AuditDb.DB_NAME);
        byte[] data = read(new FileInputStream(f), MAX_BACKUP_BYTES);
        String h = HashUtil.sha256(data);

        JSONObject m = new JSONObject();
        m.put("format", "CubuxAuditBackup");
        m.put("version", 1);
        m.put("created_at", TimeUtil.now());
        m.put("sha256", h);

        OutputStream raw = r.openOutputStream(u, "wt");
        if (raw == null) throw new Exception("Не удалось создать резервную копию");
        try (ZipOutputStream z = new ZipOutputStream(raw)) {
            z.putNextEntry(new ZipEntry("cubux_audit.db"));
            z.write(data);
            z.closeEntry();
            z.putNextEntry(new ZipEntry("manifest.json"));
            z.write(m.toString(2).getBytes(StandardCharsets.UTF_8));
            z.closeEntry();
        }
        return h;
    }

    public void restoreFrom(ContentResolver r, Uri u) throws Exception {
        if (!BackupOperationGate.tryAcquireRestore()) {
            throw new BackupBusyException("Сейчас выполняется " + BackupOperationGate.currentOperationRu() + ". Дождитесь завершения.");
        }

        File temp = null;
        File previous = null;
        boolean swapped = false;
        try {
            ensureNoCheckRunningForRestore();

            byte[] data;
            String manifestText;
            try (InputStream raw = r.openInputStream(u)) {
                if (raw == null) throw new Exception("Не удалось открыть резервную копию");
                try (ZipInputStream z = new ZipInputStream(raw)) {
                    byte[] dbData = null;
                    String mt = null;
                    ZipEntry e;
                    while ((e = z.getNextEntry()) != null) {
                        if (e.isDirectory()) continue;
                        if ("cubux_audit.db".equals(e.getName())) {
                            dbData = read(z, MAX_BACKUP_BYTES);
                        } else if ("manifest.json".equals(e.getName())) {
                            mt = new String(read(z, 1024 * 1024), StandardCharsets.UTF_8);
                        }
                    }
                    data = dbData;
                    manifestText = mt;
                }
            }

            if (data == null || manifestText == null) throw new Exception("Резервная копия повреждена: отсутствуют обязательные файлы");
            JSONObject manifest = new JSONObject(manifestText);
            if (!"CubuxAuditBackup".equals(manifest.optString("format"))) {
                throw new Exception("Неподдерживаемый формат резервной копии");
            }
            String exp = manifest.getString("sha256");
            String act = HashUtil.sha256(data);
            if (!exp.equalsIgnoreCase(act)) throw new Exception("SHA-256 не совпадает");

            File f = c.getDatabasePath(AuditDb.DB_NAME);
            File parent = f.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new Exception("Не удалось подготовить папку базы");
            }
            temp = new File(f.getPath() + ".restore.tmp");
            previous = new File(f.getPath() + ".restore.previous");
            deleteQuietly(temp);
            deleteQuietly(previous);

            try (FileOutputStream o = new FileOutputStream(temp, false)) {
                o.write(data);
                o.flush();
                o.getFD().sync();
            }
            validateSqliteIntegrity(temp);

            // Recheck after validation. The restore gate prevents new checks from starting,
            // while the second check closes the small race with a check that started just before it.
            ensureNoCheckRunningForRestore();

            SQLiteDatabase live = db.getWritableDatabase();
            checkpointOrThrow(live);
            db.close();

            deleteSidecars(f);
            if (f.exists() && !f.renameTo(previous)) {
                throw new Exception("Не удалось подготовить текущую базу к восстановлению");
            }
            if (!temp.renameTo(f)) {
                if (previous.exists()) previous.renameTo(f);
                throw new Exception("Не удалось заменить базу восстановленной копией");
            }
            swapped = true;

            AuditDb fresh = new AuditDb(c);
            try {
                // Opening writable DB also applies safe schema upgrades when an older valid backup is restored.
                fresh.getWritableDatabase();
                fresh.saveState("restore_sync_pending", "1");
                fresh.saveState("restored_at", TimeUtil.now());
                fresh.saveState("restore_integrity_check", "OK");
            } catch (Throwable openError) {
                fresh.close();
                deleteSidecars(f);
                deleteQuietly(f);
                if (previous.exists() && !previous.renameTo(f)) {
                    throw new Exception("Восстановленная база не открылась, а возврат предыдущей базы не удался", openError);
                }
                swapped = false;
                throw new Exception("Восстановленная база не открылась. Предыдущая база возвращена.", openError);
            } finally {
                try { fresh.close(); } catch (Throwable ignored) {}
            }

            deleteQuietly(previous);
            DiagnosticLog.write(c, "RESTORE", "Backup восстановлен; SHA-256 и PRAGMA integrity_check — OK. Следующая проверка — синхронизационная.");
        } finally {
            if (!swapped) deleteQuietly(temp);
            BackupOperationGate.releaseRestore();
        }
    }

    private void ensureNoCheckRunningForRestore() throws BackupBusyException {
        if (AuditRunGate.isRunning() || DayControlService.isRunning()) {
            throw new BackupBusyException("Восстановление недоступно во время проверки. Дождитесь завершения проверки и повторите.");
        }
    }

    private void checkpointOrThrow(SQLiteDatabase s) throws Exception {
        Cursor cursor = s.rawQuery("PRAGMA wal_checkpoint(FULL)", null);
        try {
            if (!cursor.moveToFirst()) throw new Exception("Не удалось выполнить контрольную фиксацию базы");
            int busy = cursor.getInt(0);
            int logFrames = cursor.getColumnCount() > 1 ? cursor.getInt(1) : 0;
            int checkpointed = cursor.getColumnCount() > 2 ? cursor.getInt(2) : logFrames;
            if (busy != 0 || checkpointed < logFrames) {
                throw new BackupBusyException("База сейчас занята записью. Повторите резервное копирование после завершения проверки.");
            }
        } finally {
            cursor.close();
        }
    }

    private void validateSqliteIntegrity(File file) throws Exception {
        SQLiteDatabase check = null;
        Cursor cursor = null;
        try {
            check = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            cursor = check.rawQuery("PRAGMA integrity_check", null);
            boolean row = false;
            while (cursor.moveToNext()) {
                row = true;
                String result = cursor.getString(0);
                if (!"ok".equalsIgnoreCase(result == null ? "" : result.trim())) {
                    throw new Exception("SQLite integrity_check: " + result);
                }
            }
            if (!row) throw new Exception("SQLite integrity_check не вернул результат");
        } catch (Exception e) {
            throw new Exception("Резервная копия не прошла проверку целостности: " + safeMessage(e), e);
        } finally {
            if (cursor != null) cursor.close();
            if (check != null) check.close();
        }
    }

    private static void deleteSidecars(File f) {
        deleteQuietly(new File(f.getPath() + "-wal"));
        deleteQuietly(new File(f.getPath() + "-shm"));
        deleteQuietly(new File(f.getPath() + "-journal"));
    }

    private static void deleteQuietly(File f) {
        if (f != null && f.exists()) {
            try { f.delete(); } catch (Throwable ignored) {}
        }
    }

    private static String safeMessage(Throwable e) {
        if (e == null) return "неизвестная ошибка";
        String m = e.getMessage();
        return m == null || m.trim().isEmpty() ? e.toString() : m;
    }

    private byte[] read(InputStream in, int maxBytes) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        int total = 0;
        while ((n = in.read(b)) != -1) {
            total += n;
            if (total > maxBytes) throw new Exception("Резервная копия слишком большая или повреждена");
            o.write(b, 0, n);
        }
        return o.toByteArray();
    }
}
