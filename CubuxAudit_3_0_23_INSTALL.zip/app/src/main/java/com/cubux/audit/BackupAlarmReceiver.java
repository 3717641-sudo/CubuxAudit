package com.cubux.audit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BackupAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        final BroadcastReceiver.PendingResult pending=goAsync();
        final Context app=context.getApplicationContext();
        new Thread(()->{try{AutoBackupManager.scheduledBackupBlocking(app);}finally{pending.finish();}},"cubux-backup-alarm").start();
    }
}
