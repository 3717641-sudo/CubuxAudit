package com.cubux.audit;

import java.util.Calendar;

/** Pure calculation for "every N days at HH:mm" automatic backups. */
public final class BackupTimePolicy {
    private BackupTimePolicy() {}

    public static long nextMs(long nowMs, int intervalDays, String hhmm) {
        int[] hm = parse(hhmm);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(nowMs);
        c.add(Calendar.DAY_OF_MONTH, Math.max(1, intervalDays));
        c.set(Calendar.HOUR_OF_DAY, hm[0]);
        c.set(Calendar.MINUTE, hm[1]);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    public static boolean valid(String hhmm) {
        if (hhmm == null || !hhmm.matches("\\d{2}:\\d{2}")) return false;
        try {
            String[] p = hhmm.split(":", -1);
            int h = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            return h >= 0 && h <= 23 && m >= 0 && m <= 59;
        } catch (Exception e) {
            return false;
        }
    }

    public static int[] parse(String hhmm) {
        try {
            String[] p = hhmm.split(":", -1);
            int h = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            if (h < 0 || h > 23 || m < 0 || m > 59) throw new IllegalArgumentException("bad time");
            return new int[]{h, m};
        } catch (Exception e) {
            return new int[]{3, 0};
        }
    }

    public static String format(int hour, int minute) {
        int h = Math.max(0, Math.min(23, hour));
        int m = Math.max(0, Math.min(59, minute));
        return String.format(java.util.Locale.US, "%02d:%02d", h, m);
    }
}
