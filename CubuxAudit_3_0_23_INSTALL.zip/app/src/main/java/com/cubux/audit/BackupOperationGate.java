package com.cubux.audit;

import java.util.concurrent.atomic.AtomicReference;

/** Serializes backup/restore operations and exposes restore state to database writers. */
public final class BackupOperationGate {
    private static final String NONE = "";
    private static final String BACKUP = "BACKUP";
    private static final String RESTORE = "RESTORE";
    private static final AtomicReference<String> ACTIVE = new AtomicReference<>(NONE);

    private BackupOperationGate() {}

    public static boolean tryAcquireBackup() {
        return ACTIVE.compareAndSet(NONE, BACKUP);
    }

    public static boolean tryAcquireRestore() {
        return ACTIVE.compareAndSet(NONE, RESTORE);
    }

    public static void releaseBackup() {
        ACTIVE.compareAndSet(BACKUP, NONE);
    }

    public static void releaseRestore() {
        ACTIVE.compareAndSet(RESTORE, NONE);
    }

    public static boolean isBusy() {
        return !NONE.equals(ACTIVE.get());
    }

    public static boolean isRestoreActive() {
        return RESTORE.equals(ACTIVE.get());
    }

    public static String currentOperationRu() {
        String s = ACTIVE.get();
        if (RESTORE.equals(s)) return "восстановление базы";
        if (BACKUP.equals(s)) return "создание резервной копии";
        return "";
    }
}
