package com.cubux.audit;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Storage helper for user-visible Cubux Security backups. */
public final class BackupStorage {
    public static final String DEFAULT_RELATIVE_PATH = Environment.DIRECTORY_DOWNLOADS + "/Cubux Security/Backups/";
    public static final String PREFIX = "CubuxSecurity-backup-";
    public static final String LATEST = "CubuxSecurity-backup-latest.zip";
    public static final String LATEST_PREFIX = "CubuxSecurity-backup-latest-";

    private BackupStorage() {}

    public static final class Item {
        public final Uri uri;
        public final String name;
        public final long modifiedMs;
        public final long size;
        public Item(Uri uri,String name,long modifiedMs,long size){this.uri=uri;this.name=name;this.modifiedMs=modifiedMs;this.size=size;}
    }

    public static String folderLabel(AuditDb db) {
        String custom=db.getState("backup_tree_uri");
        if(custom==null||custom.trim().isEmpty()) return "Downloads/Cubux Security/Backups";
        String label=db.getState("backup_tree_label");
        return label==null||label.trim().isEmpty()?"Выбранная папка":label;
    }

    public static void setTree(Context context, AuditDb db, Uri treeUri, String label) throws Exception {
        if(treeUri==null)throw new Exception("Папка не выбрана");
        final int flags=android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION|android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        context.getContentResolver().takePersistableUriPermission(treeUri,flags);
        db.saveState("backup_tree_uri",treeUri.toString());
        db.saveState("backup_tree_label",label==null||label.trim().isEmpty()?"Выбранная папка":label.trim());
        db.saveState("auto_backup_uri","");
    }

    public static void resetToDefault(AuditDb db){
        db.saveState("backup_tree_uri","");
        db.saveState("backup_tree_label","");
        db.saveState("auto_backup_uri","");
    }

    public static Uri createBackupFile(Context context, AuditDb db, String displayName) throws Exception {
        String tree=db.getState("backup_tree_uri");
        if(tree!=null&&!tree.trim().isEmpty()){
            Uri treeUri=Uri.parse(tree.trim());
            String parentId=DocumentsContract.getTreeDocumentId(treeUri);
            Uri parent=DocumentsContract.buildDocumentUriUsingTree(treeUri,parentId);
            Uri created=DocumentsContract.createDocument(context.getContentResolver(),parent,"application/zip",displayName);
            if(created==null)throw new Exception("Не удалось создать файл в выбранной папке");
            return created;
        }
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.Q)throw new Exception("На Android ниже 10 выберите папку хранения");
        ContentValues v=new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME,displayName);
        v.put(MediaStore.Downloads.MIME_TYPE,"application/zip");
        v.put(MediaStore.Downloads.RELATIVE_PATH,DEFAULT_RELATIVE_PATH);
        v.put(MediaStore.Downloads.IS_PENDING,1);
        Uri uri=context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(uri==null)throw new Exception("Не удалось создать резервную копию");
        return uri;
    }

    public static void markReady(Context context, AuditDb db, Uri uri) {
        String tree=db.getState("backup_tree_uri");
        if(tree!=null&&!tree.trim().isEmpty())return;
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){
            try{ContentValues ready=new ContentValues();ready.put(MediaStore.Downloads.IS_PENDING,0);context.getContentResolver().update(uri,ready,null,null);}catch(Throwable ignored){}
        }
    }

    public static String timestampedName(){
        return PREFIX+new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss",Locale.US).format(new Date())+".zip";
    }

    public static String rollingName(){
        return LATEST_PREFIX+new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss-SSS",Locale.US).format(new Date())+".zip";
    }

    public static boolean isRollingName(String name){
        return LATEST.equals(name)||(name!=null&&name.startsWith(LATEST_PREFIX)&&name.endsWith(".zip"));
    }

    public static boolean isCurrentRolling(AuditDb db,Item item){
        if(item==null)return false;
        String current=db.getState("auto_backup_uri");
        if(current!=null&&!current.trim().isEmpty()&&current.equals(item.uri.toString()))return true;
        return (current==null||current.trim().isEmpty())&&LATEST.equals(item.name);
    }


    public static List<Item> list(Context context, AuditDb db) {
        List<Item> out=new ArrayList<>();
        String tree=db.getState("backup_tree_uri");
        if(tree!=null&&!tree.trim().isEmpty()) listTree(context,Uri.parse(tree.trim()),out); else listMedia(context,out);
        Collections.sort(out,(a,b)->Long.compare(b.modifiedMs,a.modifiedMs));
        return out;
    }

    private static void listTree(Context context,Uri treeUri,List<Item> out){
        Cursor c=null;
        try{
            String parentId=DocumentsContract.getTreeDocumentId(treeUri);
            Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,parentId);
            String[] p={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_LAST_MODIFIED,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_MIME_TYPE};
            c=context.getContentResolver().query(children,p,null,null,null);
            if(c==null)return;
            while(c.moveToNext()){
                String id=c.getString(0),name=c.getString(1),mime=c.getString(4);
                if(name==null||!name.startsWith(PREFIX)||!name.endsWith(".zip"))continue;
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime))continue;
                long modified=c.isNull(2)?0:c.getLong(2),size=c.isNull(3)?0:c.getLong(3);
                Uri doc=DocumentsContract.buildDocumentUriUsingTree(treeUri,id);
                out.add(new Item(doc,name,modified,size));
            }
        }catch(Throwable ignored){}finally{if(c!=null)c.close();}
    }

    private static void listMedia(Context context,List<Item> out){
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.Q)return;
        Cursor c=null;
        try{
            Uri base=MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String[] p={MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME,MediaStore.Downloads.DATE_MODIFIED,MediaStore.Downloads.SIZE};
            String sel=MediaStore.Downloads.RELATIVE_PATH+"=? AND "+MediaStore.Downloads.DISPLAY_NAME+" LIKE ?";
            String[] args={DEFAULT_RELATIVE_PATH,PREFIX+"%.zip"};
            c=context.getContentResolver().query(base,p,sel,args,MediaStore.Downloads.DATE_MODIFIED+" DESC");
            if(c==null)return;
            while(c.moveToNext()){
                long id=c.getLong(0);String name=c.getString(1);long modified=c.getLong(2)*1000L;long size=c.getLong(3);
                out.add(new Item(Uri.withAppendedPath(base,String.valueOf(id)),name,modified,size));
            }
        }catch(Throwable ignored){}finally{if(c!=null)c.close();}
    }

    public static boolean delete(Context context, Uri uri){
        try{return context.getContentResolver().delete(uri,null,null)>0;}catch(Throwable e){try{return DocumentsContract.deleteDocument(context.getContentResolver(),uri);}catch(Throwable ignored){return false;}}
    }

    public static void trim(Context context, AuditDb db, int keep){
        if(keep<1)return;
        List<Item> all=list(context,db);
        int archives=0;
        for(Item item:all){
            if(isRollingName(item.name))continue;
            archives++;
            if(archives>keep)delete(context,item.uri);
        }
    }


    public static void cleanupOldRollingCopies(Context context, AuditDb db, Uri keepUri){
        String keep=keepUri==null?"":keepUri.toString();
        for(Item item:list(context,db)){
            if(!isRollingName(item.name))continue;
            if(!keep.isEmpty()&&keep.equals(item.uri.toString()))continue;
            delete(context,item.uri);
        }
    }

    public static String displayName(Context context, Uri uri){
        Cursor c=null;
        try{c=context.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null);if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Throwable ignored){}finally{if(c!=null)c.close();}
        return "Резервная копия";
    }
}
