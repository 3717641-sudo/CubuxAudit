package com.cubux.audit;

import android.content.Context;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

/** Read-only current-day observer. Uses separate day_snapshot/day_events tables only. */
public final class DayControlEngine {
    public interface Progress {
        void onProgress(String note, int percent, int loaded, int total);
    }

    private final Context app;
    private final AuditDb db;

    public DayControlEngine(Context context) {
        app = context.getApplicationContext();
        db = new AuditDb(app);
    }

    public AuditDb.DayScanResult scan(String day) throws Exception {
        return scan(day, null);
    }

    public AuditDb.DayScanResult scan(String day, Progress progress) throws Exception {
        if (day == null || day.trim().isEmpty()) day = TimeUtil.today();
        final String scanDay = day.trim();
        emit(progress, "Подключение к Cubux", 5, 0, 0);

        SecureCredentialsStore credentials = new SecureCredentialsStore(app);
        String login = credentials.getLogin();
        String password = credentials.getPassword();
        if (login == null || login.trim().isEmpty() || password == null || password.isEmpty()) {
            throw new Exception("Логин/пароль Cubux не сохранены");
        }

        CheckSettings settings = new CheckSettings(app);
        CubuxAuthClient auth = new CubuxAuthClient(app, settings.requestDelayMs());
        emit(progress, "Вход в Cubux", 10, 0, 0);
        String token = auth.login(login, password);
        CubuxClient client = new CubuxClient(app, token,
                () -> new CubuxAuthClient(app, settings.requestDelayMs()).login(login, password),
                null, settings.requestDelayMs());
        String team = new CubuxTeamResolver(app, client).resolve();
        // Refresh semantic income/expense categories at most once per day so the
        // "Доход / Расход" daily totals use Cubux metadata, never the sign of amount.
        if (!scanDay.equals(db.getState("day_category_refresh_date"))) {
            try {
                new CategoryDirectory(db, client, team).refresh();
                db.saveState("day_category_refresh_date", scanDay);
            } catch (Throwable e) {
                DiagnosticLog.error(app, "DAY_CATEGORY_DIRECTORY", e);
            }
        }
        emit(progress, "Загрузка сегодняшних операций", 18, 0, 0);

        AuditProgressListener loaderProgress = new AuditProgressListener() {
            @Override public void onStage(String stage, String message) {
                String note = message == null ? "Загрузка сегодняшних операций" : message;
                emit(progress, note, 20, 0, 0);
            }
            @Override public void onMeta(int total, int pages) {
                emit(progress, "Найдено операций: " + total, 22, 0, total);
            }
            @Override public void onPage(int page, int pages, int loaded, int total) {
                int pct = pages <= 0 ? 25 : 22 + Math.min(58, (int)Math.round(58.0 * page / pages));
                emit(progress, total > 0 ? "Загрузка операций " + loaded + " из " + total : "Загрузка операций", pct, loaded, total);
            }
            @Override public void onRetry(int page, int attempt, int retrySeconds, String error) {
                emit(progress, "Повтор подключения к Cubux", 20, 0, 0);
            }
        };

        CubuxLoader.Result loaded = new CubuxLoader(client, team, scanDay, scanDay,
                loaderProgress, null, settings.retries()).loadAll();

        emit(progress, "Сравнение с предыдущим снимком", 82, loaded.items.size(), loaded.totalCount);
        Map<String,String> current = new LinkedHashMap<>();
        int processed = 0;
        for (JSONObject raw : loaded.items) {
            JSONObject normalized = AuditEngine.normalizeRecord(raw);
            Object idValue = normalized.opt("id");
            if (idValue == null || idValue == JSONObject.NULL) continue;
            String id = String.valueOf(idValue).trim();
            if (id.isEmpty()) continue;
            String operationDate = AuditEngine.operationDate(normalized);
            if (operationDate != null && !scanDay.equals(operationDate)) continue;
            current.put(id, normalized.toString());
            processed++;
            if (processed % 25 == 0) {
                int pct = 82 + Math.min(8, loaded.items.isEmpty() ? 0 : (int)Math.round(8.0 * processed / loaded.items.size()));
                emit(progress, "Сравнение операций", pct, processed, loaded.totalCount);
            }
        }

        emit(progress, "Сохранение результатов", 92, current.size(), loaded.totalCount);
        AuditDb.DayScanResult result = db.applyDayScan(scanDay, current, TimeUtil.now());
        emit(progress, "Готово", 100, result.total, result.total);
        return result;
    }

    private static void emit(Progress p, String note, int percent, int loaded, int total) {
        if (p != null) p.onProgress(note, Math.max(0, Math.min(100, percent)), Math.max(0, loaded), Math.max(0, total));
    }
}
