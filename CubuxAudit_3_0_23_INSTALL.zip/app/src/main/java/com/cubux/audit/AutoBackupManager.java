package com.cubux.audit;

import android.content.Context;
import android.net.Uri;

/** Central backup writer: rolling safety copy + timestamped manual/scheduled archives. */
public final class AutoBackupManager {
    private static final Object LOCK=new Object();
    private static volatile boolean running;
    private static volatile boolean pendingRolling;
    private AutoBackupManager(){}

    /** Existing audit-finalisation backup. Keeps one logical rolling file using atomic pointer swap. */
    public static void backupAsync(Context context){
        if(context==null)return;Context app=context.getApplicationContext();
        synchronized(LOCK){if(running){pendingRolling=true;return;}running=true;pendingRolling=false;}
        new Thread(()->{while(true){try{backupNowBlocking(app);}catch(Throwable e){saveError(app,e,"ROLLING_BACKUP");}
            synchronized(LOCK){if(pendingRolling){pendingRolling=false;continue;}running=false;break;}}
        },"cubux-rolling-backup").start();
    }

    /** Called by AuditCoordinator at the safe finalisation stage of a check. */
    public static void backupNowBlocking(Context context)throws Exception{
        if(context==null)return;
        if(!BackupOperationGate.tryAcquireBackup())throw new BackupBusyException(busyMessage());
        try{writeRollingUnlocked(context.getApplicationContext());}
        finally{BackupOperationGate.releaseBackup();}
    }

    /** User-requested timestamped copy. It never races an active audit/day-control write. */
    public static Uri createManualArchiveBlocking(Context context)throws Exception{
        Context app=context.getApplicationContext();
        ensureNoActiveCheckForArchive();
        if(!BackupOperationGate.tryAcquireBackup())throw new BackupBusyException(busyMessage());
        try{
            ensureNoActiveCheckForArchive();
            return writeArchiveUnlocked(app,"MANUAL");
        }finally{BackupOperationGate.releaseBackup();}
    }

    /** Scheduled archive; one catch-up copy only after missed days. */
    public static void scheduledBackupAsync(Context context){
        if(context==null)return;final Context app=context.getApplicationContext();
        new Thread(()->scheduledBackupBlocking(app),"cubux-scheduled-backup").start();
    }

    public static void scheduledBackupBlocking(Context context){
        if(context==null)return;final Context app=context.getApplicationContext();AuditDb db=new AuditDb(app);
        boolean acquired=false;
        try{
            if(!BackupScheduler.enabled(db))return;
            long next=BackupScheduler.nextMs(db);
            if(next>System.currentTimeMillis()+60000L){BackupScheduler.restore(app);return;}
            if(AuditRunGate.isRunning()||DayControlService.isRunning()){
                throw new BackupBusyException("Идёт проверка базы");
            }
            if(!BackupOperationGate.tryAcquireBackup())throw new BackupBusyException(busyMessage());
            acquired=true;
            if(AuditRunGate.isRunning()||DayControlService.isRunning()){
                throw new BackupBusyException("Идёт проверка базы");
            }
            writeArchiveUnlocked(app,"AUTO");
            BackupScheduler.afterSuccess(app,db);
            NotificationHelper.showBackupResult(app,true,"Автоматическая резервная копия создана");
        }catch(BackupBusyException e){
            db.saveState("backup_last_auto_status","WAITING: "+msg(e));
            BackupScheduler.retrySoon(app,db,15);
            DiagnosticLog.write(app,"SCHEDULED_BACKUP","Автокопия отложена на 15 минут: "+msg(e));
        }catch(Throwable e){
            db.saveState("backup_last_auto_status","ERROR: "+msg(e));
            DiagnosticLog.error(app,"SCHEDULED_BACKUP",e);
            BackupScheduler.retrySoon(app,db,60);
            NotificationHelper.showBackupResult(app,false,"Не удалось создать резервную копию: "+msg(e));
        }finally{
            if(acquired)BackupOperationGate.releaseBackup();
            db.close();
        }
    }

    private static void writeRollingUnlocked(Context context)throws Exception{
        AuditDb db=new AuditDb(context);
        Uri newUri=null;
        try{
            String oldUri=db.getState("auto_backup_uri");
            newUri=BackupStorage.createBackupFile(context,db,BackupStorage.rollingName());
            String hash=new BackupManager(context,db).exportTo(context.getContentResolver(),newUri);
            BackupStorage.markReady(context,db,newUri);

            // Pointer swap happens only after the new ZIP is fully written and closed.
            db.saveState("auto_backup_time",TimeUtil.now());
            db.saveState("auto_backup_sha256",hash);
            db.saveState("auto_backup_status","OK");
            db.saveState("auto_backup_uri",newUri.toString());

            // Old rolling copies are deleted only after the new copy became current.
            if(oldUri!=null&&!oldUri.trim().isEmpty()&&!oldUri.equals(newUri.toString())){
                try{BackupStorage.delete(context,Uri.parse(oldUri));}catch(Throwable ignored){}
            }
            BackupStorage.cleanupOldRollingCopies(context,db,newUri);
            DiagnosticLog.write(context,"AUTO_BACKUP","Защитная копия атомарно обновлена: "+BackupStorage.folderLabel(db));
        }catch(Exception e){
            if(newUri!=null)try{BackupStorage.delete(context,newUri);}catch(Throwable ignored){}
            throw e;
        }finally{db.close();}
    }

    private static Uri writeArchiveUnlocked(Context context,String source)throws Exception{
        AuditDb db=new AuditDb(context);Uri uri=null;
        try{
            uri=BackupStorage.createBackupFile(context,db,BackupStorage.timestampedName());
            String hash=new BackupManager(context,db).exportTo(context.getContentResolver(),uri);
            BackupStorage.markReady(context,db,uri);
            db.saveState("backup_last_archive_time",TimeUtil.now());
            db.saveState("backup_last_archive_sha256",hash);
            db.saveState("backup_last_archive_source",source);
            BackupStorage.trim(context,db,BackupScheduler.keepCount(db));
            DiagnosticLog.write(context,"BACKUP_ARCHIVE","Резервная копия создана: "+BackupStorage.displayName(context,uri));
            return uri;
        }catch(Exception e){if(uri!=null)try{BackupStorage.delete(context,uri);}catch(Throwable ignored){}throw e;}
        finally{db.close();}
    }

    private static void ensureNoActiveCheckForArchive()throws BackupBusyException{
        if(AuditRunGate.isRunning()||DayControlService.isRunning()){
            throw new BackupBusyException("Дождитесь завершения проверки. Резервная копия будет создана после освобождения базы.");
        }
    }

    private static String busyMessage(){
        String op=BackupOperationGate.currentOperationRu();
        return op.isEmpty()?"База занята другой операцией":"Сейчас выполняется "+op+". Дождитесь завершения.";
    }

    private static void saveError(Context c,Throwable e,String tag){
        DiagnosticLog.error(c,tag,e);AuditDb db=new AuditDb(c);try{db.saveState("auto_backup_status","ERROR: "+msg(e));}finally{db.close();}
    }
    private static String msg(Throwable e){return e==null?"неизвестная ошибка":(e.getMessage()==null?e.toString():e.getMessage());}
}
