package com.cubux.audit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        try {
            CheckScheduler.scheduleStartup(context);
            DayControlScheduler.scheduleNext(context);
            BackupScheduler.restore(context);
            DiagnosticLog.write(context,"BOOT","Расписание основных проверок, контроля дня и резервных копий восстановлено после запуска устройства");
        } catch (Throwable e) { DiagnosticLog.error(context,"BOOT",e); }
    }
}
