package com.cubux.audit;

/** Expected temporary conflict: retry later instead of treating it as a damaged backup. */
public class BackupBusyException extends Exception {
    public BackupBusyException(String message) {
        super(message);
    }
}
