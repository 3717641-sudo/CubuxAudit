package com.cubux.audit;

public class BackupOperationGateTest {
    public static void main(String[] args) {
        check(!BackupOperationGate.isBusy(), "gate starts free");
        check(BackupOperationGate.tryAcquireBackup(), "backup acquires gate");
        check(BackupOperationGate.isBusy(), "gate busy during backup");
        check(!BackupOperationGate.tryAcquireRestore(), "restore blocked during backup");
        BackupOperationGate.releaseBackup();
        check(!BackupOperationGate.isBusy(), "backup releases gate");
        check(BackupOperationGate.tryAcquireRestore(), "restore acquires gate");
        check(BackupOperationGate.isRestoreActive(), "restore state exposed to writers");
        check(!BackupOperationGate.tryAcquireBackup(), "backup blocked during restore");
        BackupOperationGate.releaseRestore();
        check(!BackupOperationGate.isBusy(), "restore releases gate");
        System.out.println("PASS BackupOperationGateTest");
    }

    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
