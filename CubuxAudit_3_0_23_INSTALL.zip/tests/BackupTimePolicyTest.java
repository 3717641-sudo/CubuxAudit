package com.cubux.audit;

import java.util.Calendar;
import java.util.TimeZone;

public final class BackupTimePolicyTest {
    private static void eq(int a,int b,String m){if(a!=b)throw new AssertionError(m+": "+a+" != "+b);}
    public static void main(String[] args){
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        Calendar c=Calendar.getInstance();c.set(2026,Calendar.SEPTEMBER,30,15,10,25);c.set(Calendar.MILLISECOND,0);
        long next=BackupTimePolicy.nextMs(c.getTimeInMillis(),7,"02:35");
        Calendar n=Calendar.getInstance();n.setTimeInMillis(next);
        eq(n.get(Calendar.YEAR),2026,"year");eq(n.get(Calendar.MONTH),Calendar.OCTOBER,"month");eq(n.get(Calendar.DAY_OF_MONTH),7,"day");eq(n.get(Calendar.HOUR_OF_DAY),2,"hour");eq(n.get(Calendar.MINUTE),35,"minute");eq(n.get(Calendar.SECOND),0,"second");
        if(!"03:00".equals(BackupTimePolicy.format(3,0)))throw new AssertionError("format");
        if(!BackupTimePolicy.valid("23:59")||BackupTimePolicy.valid("24:00"))throw new AssertionError("validation");
        System.out.println("PASS BackupTimePolicyTest");
    }
}
