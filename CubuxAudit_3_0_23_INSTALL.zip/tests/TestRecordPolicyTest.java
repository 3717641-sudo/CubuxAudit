package com.cubux.audit;

public final class TestRecordPolicyTest {
    private static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
    public static void main(String[] args){
        ok(TestRecordPolicy.isTestNote("тест"),"lowercase");
        ok(TestRecordPolicy.isTestNote(" ТЕСТ "),"case/spaces");
        ok(TestRecordPolicy.isTestNote("  ТеСт  "),"mixed case");
        ok(!TestRecordPolicy.isTestNote("не тест"),"must be exact word");
        ok(!TestRecordPolicy.isTestNote("тест 1"),"must be exact word");
        ok(!TestRecordPolicy.isTestResolved("OPEN","тест"),"open record is not test-excluded");
        ok(TestRecordPolicy.isTestResolved("RESOLVED"," тест "),"resolved test");
        System.out.println("PASS TestRecordPolicyTest");
    }
}
