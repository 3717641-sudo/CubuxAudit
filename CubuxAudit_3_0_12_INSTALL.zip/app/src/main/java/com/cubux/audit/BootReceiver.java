package com.cubux.audit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        try {
            CheckScheduler.scheduleStartup(context);
            DiagnosticLog.write(context,"BOOT","Расписание проверок восстановлено после запуска устройства");
        } catch (Throwable e) { DiagnosticLog.error(context,"BOOT",e); }
    }
}
