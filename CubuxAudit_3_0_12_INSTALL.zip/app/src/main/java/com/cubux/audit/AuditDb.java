package com.cubux.audit;
import android.content.*; import android.database.*; import android.database.sqlite.*; import org.json.JSONObject; import java.util.*;
public class AuditDb extends SQLiteOpenHelper {
 public static final String DB_NAME="cubux_audit.db"; private static final int DB_VERSION=7; private final Context appContext;
 public AuditDb(Context c){super(c,DB_NAME,null,DB_VERSION);appContext=c.getApplicationContext();} public void onCreate(SQLiteDatabase db){create(db);} public void onUpgrade(SQLiteDatabase db,int o,int n){create(db);String[] a={"ALTER TABLE transactions ADD COLUMN operation_date TEXT","ALTER TABLE changes ADD COLUMN operation_date TEXT","ALTER TABLE changes ADD COLUMN closed_period INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN duration_ms INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN current_stage TEXT","ALTER TABLE audit_runs ADD COLUMN last_successful_page INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN page_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN received_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN checked_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN speed REAL NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN error TEXT","ALTER TABLE audit_runs ADD COLUMN retry_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN recovery INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN last_activity TEXT","ALTER TABLE audit_runs ADD COLUMN closed_changed_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE audit_runs ADD COLUMN multi_changed_count INTEGER NOT NULL DEFAULT 0","ALTER TABLE daily_closures ADD COLUMN currency_totals TEXT NOT NULL DEFAULT '{}'","ALTER TABLE daily_closures ADD COLUMN baseline_data TEXT NOT NULL DEFAULT '[]'"};for(String s:a)try{db.execSQL(s);}catch(Exception ignored){}}
 private void create(SQLiteDatabase db){db.execSQL("CREATE TABLE IF NOT EXISTS transactions(transaction_id TEXT PRIMARY KEY,operation_date TEXT,data TEXT NOT NULL,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY AUTOINCREMENT,detected_at TEXT NOT NULL,transaction_id TEXT NOT NULL,operation_date TEXT,change_type TEXT NOT NULL,old_data TEXT,new_data TEXT,closed_period INTEGER NOT NULL DEFAULT 0)");db.execSQL("CREATE TABLE IF NOT EXISTS audit_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,started_at TEXT NOT NULL,finished_at TEXT,duration_ms INTEGER NOT NULL DEFAULT 0,total_records INTEGER NOT NULL DEFAULT 0,new_count INTEGER NOT NULL DEFAULT 0,changed_count INTEGER NOT NULL DEFAULT 0,deleted_count INTEGER NOT NULL DEFAULT 0,closed_changed_count INTEGER NOT NULL DEFAULT 0,multi_changed_count INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL,current_stage TEXT,last_successful_page INTEGER NOT NULL DEFAULT 0,page_count INTEGER NOT NULL DEFAULT 0,received_count INTEGER NOT NULL DEFAULT 0,checked_count INTEGER NOT NULL DEFAULT 0,speed REAL NOT NULL DEFAULT 0,error TEXT,retry_count INTEGER NOT NULL DEFAULT 0,recovery INTEGER NOT NULL DEFAULT 0,last_activity TEXT)");db.execSQL("CREATE TABLE IF NOT EXISTS daily_closures(date_key TEXT PRIMARY KEY,closed_at TEXT NOT NULL,record_count INTEGER NOT NULL,income_total REAL NOT NULL,expense_total REAL NOT NULL,currency_totals TEXT NOT NULL,control_hash TEXT NOT NULL,baseline_data TEXT NOT NULL,status TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS bank_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,bank_uid TEXT,operation_date TEXT NOT NULL,amount REAL NOT NULL,currency TEXT,description TEXT,counterparty TEXT,raw_data TEXT NOT NULL,imported_at TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS bank_matches(id INTEGER PRIMARY KEY AUTOINCREMENT,bank_transaction_id INTEGER NOT NULL,cubux_transaction_id TEXT,match_status TEXT NOT NULL,match_score REAL NOT NULL,checked_at TEXT NOT NULL,details TEXT)");db.execSQL("CREATE TABLE IF NOT EXISTS app_state(state_key TEXT PRIMARY KEY,state_value TEXT NOT NULL,updated_at TEXT NOT NULL)");db.execSQL("CREATE TABLE IF NOT EXISTS app_events(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,level TEXT NOT NULL,source TEXT NOT NULL,message TEXT NOT NULL)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_changes_tx ON changes(transaction_id)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_changes_date ON changes(operation_date)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_date ON transactions(operation_date)");db.execSQL("CREATE INDEX IF NOT EXISTS idx_app_events_created ON app_events(created_at)");}
 public long createRun(boolean recovery){ContentValues v=new ContentValues();v.put("started_at",TimeUtil.now());v.put("status","RUNNING");v.put("current_stage",recovery?"RECOVERY":"CONNECTING");v.put("recovery",recovery?1:0);v.put("last_activity",TimeUtil.now());return getWritableDatabase().insert("audit_runs",null,v);}
 public void updateRunStage(long id,String s){ContentValues v=new ContentValues();v.put("current_stage",s);v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});} public void updateRunProgress(long id,int p,int ps,int r,int total,double speed,int retries){ContentValues v=new ContentValues();v.put("current_stage","READING_DATA");v.put("last_successful_page",p);v.put("page_count",ps);v.put("received_count",r);v.put("total_records",total);v.put("speed",speed);v.put("retry_count",retries);v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}
 public void finishRun(long id,long dur,int total,int n,int ch,int del,int closed,int multi){ContentValues v=new ContentValues();v.put("finished_at",TimeUtil.now());v.put("duration_ms",dur);v.put("total_records",total);v.put("checked_count",total);v.put("new_count",n);v.put("changed_count",ch);v.put("deleted_count",del);v.put("closed_changed_count",closed);v.put("multi_changed_count",multi);v.put("status","OK");v.put("current_stage","COMPLETED");v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});} public void failRun(long id,String e){ContentValues v=new ContentValues();v.put("finished_at",TimeUtil.now());v.put("status","ERROR");v.put("current_stage","ERROR");v.put("error",e);v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}

 public void updateRunDuration(long id,long durationMs){ContentValues v=new ContentValues();v.put("duration_ms",Math.max(0L,durationMs));v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}
 public Map<String,String> transactions(){Map<String,String> m=new HashMap<>();Cursor c=getReadableDatabase().rawQuery("SELECT transaction_id,data FROM transactions",null);try{while(c.moveToNext())m.put(c.getString(0),c.getString(1));}finally{c.close();}return m;}
 public void upsert(String id,String date,String data,String now,boolean exists){ContentValues v=new ContentValues();v.put("operation_date",date);v.put("data",data);v.put("last_seen",now);if(exists)getWritableDatabase().update("transactions",v,"transaction_id=?",new String[]{id});else{v.put("transaction_id",id);v.put("first_seen",now);getWritableDatabase().insertWithOnConflict("transactions",null,v,SQLiteDatabase.CONFLICT_REPLACE);}}
 public void deleteTx(String id){getWritableDatabase().delete("transactions","transaction_id=?",new String[]{id});}
 public void change(String id,String date,String type,String oldD,String newD,boolean closed){ContentValues v=new ContentValues();v.put("detected_at",TimeUtil.now());v.put("transaction_id",id);v.put("operation_date",date);v.put("change_type",type);if(oldD!=null)v.put("old_data",oldD);if(newD!=null)v.put("new_data",newD);v.put("closed_period",closed?1:0);getWritableDatabase().insert("changes",null,v);} public int changeCount(String id){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM changes WHERE transaction_id=?",new String[]{id});try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
 public SQLiteDatabase begin(){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();return d;} public void end(SQLiteDatabase d,boolean ok){if(ok)d.setTransactionSuccessful();d.endTransaction();}
 public void state(String k,String val){ContentValues v=new ContentValues();v.put("state_key",k);v.put("state_value",val);v.put("updated_at",TimeUtil.now());getWritableDatabase().insertWithOnConflict("app_state",null,v,SQLiteDatabase.CONFLICT_REPLACE);} public String state(String k){Cursor c=getReadableDatabase().rawQuery("SELECT state_value FROM app_state WHERE state_key=?",new String[]{k});try{return c.moveToFirst()?c.getString(0):null;}finally{c.close();}}
 public Closure closure(String date){Cursor c=getReadableDatabase().rawQuery("SELECT record_count,income_total,expense_total,currency_totals,control_hash,baseline_data,status FROM daily_closures WHERE date_key=?",new String[]{date});try{return c.moveToFirst()?new Closure(date,c.getInt(0),c.getDouble(1),c.getDouble(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6)):null;}finally{c.close();}}
 public void createClosure(String date,int count,double in,double out,String currencies,String hash,String baseline){if(closure(date)!=null)return;ContentValues v=new ContentValues();v.put("date_key",date);v.put("closed_at",TimeUtil.now());v.put("record_count",count);v.put("income_total",in);v.put("expense_total",out);v.put("currency_totals",currencies);v.put("control_hash",hash);v.put("baseline_data",baseline);v.put("status","CLOSED");getWritableDatabase().insert("daily_closures",null,v);} public void markClosureChanged(String date){ContentValues v=new ContentValues();v.put("status","CHANGED");getWritableDatabase().update("daily_closures",v,"date_key=?",new String[]{date});}
 public void upsertClosure(String date,int count,double in,double out,String currencies,String hash,String baseline,String status){ContentValues v=new ContentValues();v.put("date_key",date);v.put("closed_at",TimeUtil.now());v.put("record_count",count);v.put("income_total",in);v.put("expense_total",out);v.put("currency_totals",currencies);v.put("control_hash",hash);v.put("baseline_data",baseline);v.put("status",status==null?"CLOSED":status);getWritableDatabase().insertWithOnConflict("daily_closures",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
 public int purgeTransactionsAfter(String cutoff){return getWritableDatabase().delete("transactions","operation_date>?",new String[]{cutoff});}
 public int purgeClosuresAfter(String cutoff){return getWritableDatabase().delete("daily_closures","date_key>?",new String[]{cutoff});}

 public String runsText(){Cursor c=getReadableDatabase().rawQuery("SELECT id,started_at,duration_ms,total_records,new_count,changed_count,deleted_count,status,error,recovery FROM audit_runs ORDER BY id DESC LIMIT 30",null);StringBuilder s=new StringBuilder();try{while(c.moveToNext()){String started=c.getString(1),status=c.getString(7);long dur=c.getLong(2);if("RUNNING".equals(status)){long startMs=TimeUtil.parseDateTimeMillis(started);if(startMs>0)dur=Math.max(dur,System.currentTimeMillis()-startMs);}s.append("#").append(c.getLong(0)).append(" • ").append(TimeUtil.displayDateTime(started)).append("\n").append(runStatusRu(status));if(c.getInt(9)==1)s.append(" • Восстановительная проверка");s.append(" • ").append(TimeUtil.duration(dur)).append("\nНовые: ").append(c.getInt(4)).append(" • Изменённые: ").append(c.getInt(5)).append(" • Удалённые: ").append(c.getInt(6));if(c.getString(8)!=null)s.append("\nОшибка: ").append(c.getString(8));s.append("\n\n");}}finally{c.close();}return s.length()==0?"История пока пуста":s.toString();}
 public String journal(String filter,String q){
  Cursor c=getReadableDatabase().rawQuery("SELECT detected_at,transaction_id,operation_date,change_type,old_data,new_data,closed_period FROM changes ORDER BY id DESC LIMIT 500",null);
  StringBuilder s=new StringBuilder();String f=filter==null?"ALL":filter,search=q==null?"":q.toLowerCase().trim();
  try{
   while(c.moveToNext()){
    String detected=c.getString(0),id=c.getString(1),date=c.getString(2),type=c.getString(3),oldD=c.getString(4),newD=c.getString(5);
    boolean closed=c.getInt(6)==1;
    if(!"ALL".equals(f)){
     if("CLOSED".equals(f)&&!closed)continue;
     else if("MULTI".equals(f)&&changeCount(id)<2)continue;
     else if(!"CLOSED".equals(f)&&!"MULTI".equals(f)&&!type.equals(f))continue;
    }
    String blob=(id+" "+date+" "+type+" "+oldD+" "+newD).toLowerCase();
    if(!search.isEmpty()&&!blob.contains(search))continue;

    JSONObject oldJ=parseJson(oldD),newJ=parseJson(newD);
    JSONObject shown=newJ!=null?newJ:oldJ;
    String mark="NEW".equals(type)?"🟢":"DELETED".equals(type)?"🔴":closed?"🟣":"🟡";
    s.append(mark).append(" ").append(changeTypeRu(type));
    if(closed)s.append(" • Закрытый период");
    s.append("\n");

    appendDate(s,date,oldJ,newJ,"CHANGED".equals(type));
    appendOperationType(s,oldJ,newJ,shown,"CHANGED".equals(type));
    appendAmount(s,oldJ,newJ,shown,"CHANGED".equals(type));
    appendField(s,"Категория",oldJ,newJ,shown,"category","CHANGED".equals(type));
    appendAccount(s,oldJ,newJ,shown,"CHANGED".equals(type));
    appendField(s,"Комментарий",oldJ,newJ,shown,"description","CHANGED".equals(type));
    String user=shown==null?"":pretty(shown,"user_name");
    if(!user.isEmpty())appendField(s,"Пользователь операции",oldJ,newJ,shown,"user_name","CHANGED".equals(type));
    s.append("Обнаружено: ").append(TimeUtil.displayDateTime(detected)).append("\n\n");
   }
  }finally{c.close();}
  return s.length()==0?"Ничего не найдено":s.toString();
 }

 /** Technical view intentionally separated from the normal journal. */
 public String diagnosticJournal(){
  Cursor c=getReadableDatabase().rawQuery("SELECT id,detected_at,transaction_id,operation_date,change_type,old_data,new_data,closed_period FROM changes ORDER BY id DESC LIMIT 200",null);
  StringBuilder s=new StringBuilder("РАСШИРЕННАЯ ДИАГНОСТИКА ИЗМЕНЕНИЙ\n\n");
  try{
   while(c.moveToNext()){
    long rowId=c.getLong(0);String detected=c.getString(1),tx=c.getString(2),date=c.getString(3),type=c.getString(4),oldD=c.getString(5),newD=c.getString(6);boolean closed=c.getInt(7)==1;
    s.append("#").append(rowId).append(" • ").append(changeTypeRu(type)).append("\n");
    s.append("ID операции: ").append(tx).append("\n");
    s.append("Техническая причина: ").append(technicalReason(type)).append("\n");
    s.append("Дата операции: ").append(date==null?"—":TimeUtil.displayDateTime(date)).append("\n");
    s.append("Закрытый период: ").append(closed?"да":"нет").append("\n");
    s.append("Обнаружено: ").append(TimeUtil.displayDateTime(detected)).append("\n");
    s.append("Старое значение: ").append(oldD==null?"—":oldD).append("\n");
    s.append("Новое значение: ").append(newD==null?"—":newD).append("\n\n");
   }
  }finally{c.close();}
  if(s.toString().equals("РАСШИРЕННАЯ ДИАГНОСТИКА ИЗМЕНЕНИЙ\n\n"))s.append("Изменений пока нет.");
  return s.toString();
 }

 private String technicalReason(String type){
  if("NEW".equals(type))return "операция появилась в уже защищённом закрытом периоде";
  if("CHANGED".equals(type))return "контрольный отпечаток операции отличается от локального эталона";
  if("DELETED".equals(type))return "операция из локального эталона отсутствует в подтверждённых данных Cubux";
  return type==null?"неизвестно":type;
 }

 private void appendDate(StringBuilder s,String fallback,JSONObject oldJ,JSONObject newJ,boolean changed){
  String a=oldJ==null?"":dateOnly(pretty(oldJ,"date")),b=newJ==null?"":dateOnly(pretty(newJ,"date"));
  if(changed&&!a.equals(b)&&(!a.isEmpty()||!b.isEmpty()))s.append("Дата операции: ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else {String d=!b.isEmpty()?b:(!a.isEmpty()?a:fallback);if(d!=null&&!d.isEmpty())s.append("Дата операции: ").append(d).append("\n");}
 }

 private String dateOnly(String x){return x!=null&&x.length()>=10?x.substring(0,10):(x==null?"":x);}

 private void appendOperationType(StringBuilder s,JSONObject oldJ,JSONObject newJ,JSONObject shown,boolean changed){
  String a=operationType(oldJ),b=operationType(newJ),v=operationType(shown);
  if(changed&&!a.equals(b)&&(!a.isEmpty()||!b.isEmpty()))s.append("Тип операции: ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else if(!v.isEmpty())s.append("Тип операции: ").append(v).append("\n");
 }

 private String operationType(JSONObject o){
  return OperationTypeResolver.resolve(o,this);
 }

 private void appendAmount(StringBuilder s,JSONObject oldJ,JSONObject newJ,JSONObject shown,boolean changed){
  String a=amountWithCurrency(oldJ),b=amountWithCurrency(newJ),v=amountWithCurrency(shown);
  String rawA=oldJ==null?"":pretty(oldJ,"amount")+"|"+pretty(oldJ,"currency_code");
  String rawB=newJ==null?"":pretty(newJ,"amount")+"|"+pretty(newJ,"currency_code");
  if(changed&&!rawA.equals(rawB)&&(!a.isEmpty()||!b.isEmpty()))s.append("Сумма: ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else if(!v.isEmpty())s.append("Сумма: ").append(v).append("\n");
 }

 private String amountWithCurrency(JSONObject o){
  if(o==null)return "";String a=money(pretty(o,"amount"));if(a.isEmpty())return "";String c=currencySymbol(pretty(o,"currency_code"));return c.isEmpty()?a:(a+" "+c);
 }
 private String money(String x){
  if(x==null||x.trim().isEmpty())return "";
  try{return new java.math.BigDecimal(x.trim().replace(" ","").replace(",",".")).stripTrailingZeros().toPlainString();}
  catch(Exception e){return x.trim();}
 }

 private String currencySymbol(String code){
  if(code==null)return "";String c=code.trim().toUpperCase(Locale.ROOT);
  if(c.equals("RUB")||c.equals("RUR")||c.equals("643"))return "₽";
  if(c.equals("USD")||c.equals("840"))return "$";
  if(c.equals("EUR")||c.equals("978"))return "€";
  if(c.equals("GBP")||c.equals("826"))return "£";
  if(c.equals("CNY")||c.equals("RMB")||c.equals("156"))return "¥";
  if(c.equals("KZT")||c.equals("398"))return "₸";
  if(c.equals("BYN")||c.equals("933"))return "Br";
  if(c.equals("TRY")||c.equals("949"))return "₺";
  return code.trim();
 }


 private void appendAccount(StringBuilder s,JSONObject oldJ,JSONObject newJ,JSONObject shown,boolean changed){
  String a=accountDisplay(oldJ),b=accountDisplay(newJ),v=accountDisplay(shown);
  if(changed&&!a.equals(b))s.append("Счёт: ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else if(!v.isEmpty())s.append("Счёт: ").append(v).append("\n");
 }
 private String accountDisplay(JSONObject o){
  if(o==null)return "";
  String n=pretty(o,"account_name"); if(!n.isEmpty())return n;
  String raw=pretty(o,"account"); if(raw.isEmpty())return "";
  String cached=getState("account_name:"+raw); if(cached!=null&&!cached.trim().isEmpty())return cached.trim();
  if(raw.matches("\\d+"))return "Неизвестный счёт";
  return raw;
 }

 private void appendField(StringBuilder s,String label,JSONObject oldJ,JSONObject newJ,JSONObject shown,String key,boolean changed){
  String a=oldJ==null?"":pretty(oldJ,key),b=newJ==null?"":pretty(newJ,key),v=shown==null?"":pretty(shown,key);
  if(changed&&!a.equals(b))s.append(label).append(": ").append(a.isEmpty()?"—":a).append(" → ").append(b.isEmpty()?"—":b).append("\n");
  else if(!v.isEmpty())s.append(label).append(": ").append(v).append("\n");
 }
 private JSONObject parseJson(String x){if(x==null||x.trim().isEmpty())return null;try{return new JSONObject(x);}catch(Exception e){return null;}}
 private String pretty(JSONObject o,String k){if(o==null)return "";Object v=o.opt(k);if(v==null||v==JSONObject.NULL)return "";String x=String.valueOf(v);return "null".equalsIgnoreCase(x)?"":x;}
 private void appendDiff(StringBuilder s,String label,JSONObject a,JSONObject b,String key){
  String av=pretty(a,key),bv=pretty(b,key);if(!av.equals(bv))s.append(label).append(": ").append(av.isEmpty()?"—":av).append(" → ").append(bv.isEmpty()?"—":bv).append("\n");
 }
 public List<JSONObject> currentJson(){List<JSONObject> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT data FROM transactions",null);try{while(c.moveToNext())try{a.add(new JSONObject(c.getString(0)));}catch(Exception ignored){}}finally{c.close();}return a;}
 public void clearBank(){SQLiteDatabase d=getWritableDatabase();d.delete("bank_matches",null,null);d.delete("bank_transactions",null,null);} public long bankInsert(String uid,String date,double amount,String cur,String desc,String cp,String raw){ContentValues v=new ContentValues();v.put("bank_uid",uid);v.put("operation_date",date);v.put("amount",amount);v.put("currency",cur);v.put("description",desc);v.put("counterparty",cp);v.put("raw_data",raw);v.put("imported_at",TimeUtil.now());return getWritableDatabase().insert("bank_transactions",null,v);}
 public List<BankRow> bankRows(){List<BankRow>a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,bank_uid,operation_date,amount,currency,description,counterparty FROM bank_transactions ORDER BY operation_date",null);try{while(c.moveToNext())a.add(new BankRow(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4),c.getString(5),c.getString(6)));}finally{c.close();}return a;}
 public void bankMatch(long bank,String cubux,String status,double score,String details){ContentValues v=new ContentValues();v.put("bank_transaction_id",bank);v.put("cubux_transaction_id",cubux);v.put("match_status",status);v.put("match_score",score);v.put("checked_at",TimeUtil.now());v.put("details",details);getWritableDatabase().insert("bank_matches",null,v);} public String bankSummary(){Cursor c=getReadableDatabase().rawQuery("SELECT match_status,COUNT(*) FROM bank_matches GROUP BY match_status",null);Map<String,Integer>m=new HashMap<>();try{while(c.moveToNext())m.put(c.getString(0),c.getInt(1));}finally{c.close();}return "БАНКОВСКАЯ СВЕРКА\n\n✅ Точное: "+m.getOrDefault("EXACT",0)+"\n🟡 Вероятное: "+m.getOrDefault("PROBABLE",0)+"\n🟠 Ручная проверка: "+m.getOrDefault("MANUAL",0)+"\n🔴 Нет в Cubux: "+m.getOrDefault("MISSING_CUBUX",0)+"\n\nВсе ли доходы банка отражены в Cubux?";}
 public static class Closure{public final String date,currencies,hash,baseline,status;public final int count;public final double income,expense;Closure(String d,int c,double i,double e,String cur,String h,String b,String s){date=d;count=c;income=i;expense=e;currencies=cur;hash=h;baseline=b;status=s;}}
 public static class BankRow{public final long id;public final String uid,date,currency,description,counterparty;public final double amount;BankRow(long i,String u,String d,double a,String c,String x,String p){id=i;uid=u;date=d;amount=a;currency=c;description=x;counterparty=p;}}
 public String resolvedOperationType(JSONObject o){return OperationTypeResolver.resolve(o,this);}

 public String changeTypeRu(String type){if("NEW".equals(type))return "Новые";if("CHANGED".equals(type))return "Изменённые";if("DELETED".equals(type))return "Удалённые";return type;}
 public String runStatusRu(String status){if("OK".equals(status))return "Завершено";if("ERROR".equals(status))return "Ошибка";if("STOPPED".equals(status))return "Остановлено";if("RUNNING".equals(status))return "Выполняется";return status;}
 // Compatibility API used by 2.1 modules
 public void updateRunProgress(long id,String stage,int p,int ps,int r,int total,double speed,int retries){updateRunProgress(id,p,ps,r,total,speed,retries); if(stage!=null) updateRunStage(id,stage);}
 public void saveState(String k,String val){state(k,val);}
 public String getState(String k){return state(k);}

 public static class RunSummary{
  public final long id; public final String startedAt,status; public final long durationMs; public final int total,newCount,changedCount,deletedCount; public final boolean recovery;
  RunSummary(long id,String startedAt,long durationMs,int total,int n,int ch,int del,String status,boolean recovery){this.id=id;this.startedAt=startedAt;this.durationMs=durationMs;this.total=total;this.newCount=n;this.changedCount=ch;this.deletedCount=del;this.status=status;this.recovery=recovery;}
 }
 public java.util.List<RunSummary> recentRuns(int limit){
  int safe=Math.max(1,Math.min(30,limit)); java.util.ArrayList<RunSummary> out=new java.util.ArrayList<>();
  Cursor c=getReadableDatabase().rawQuery("SELECT id,started_at,duration_ms,total_records,new_count,changed_count,deleted_count,status,recovery FROM audit_runs ORDER BY id DESC LIMIT "+safe,null);
  try{while(c.moveToNext()){String started=c.getString(1),status=c.getString(7);long dur=c.getLong(2);if("RUNNING".equals(status)){long ms=TimeUtil.parseDateTimeMillis(started);if(ms>0)dur=Math.max(dur,System.currentTimeMillis()-ms);}out.add(new RunSummary(c.getLong(0),started,dur,c.getInt(3),c.getInt(4),c.getInt(5),c.getInt(6),status,c.getInt(8)==1));}}finally{c.close();}
  return out;
 }

 public String recentRunsText(){return runsText();}
 public String journalText(String filter,String q){return journal(filter,q);}
 public List<JSONObject> getCurrentTransactionsJson(){return currentJson();}



 public void appEvent(String level,String source,String message){
  if(message==null||message.trim().isEmpty())return;
  ContentValues v=new ContentValues();v.put("created_at",TimeUtil.now());v.put("level",level==null?"INFO":level);v.put("source",source==null?"APP":source);v.put("message",message.trim());getWritableDatabase().insert("app_events",null,v);
  try{getWritableDatabase().execSQL("DELETE FROM app_events WHERE id NOT IN (SELECT id FROM app_events ORDER BY id DESC LIMIT 2000)");}catch(Exception ignored){}
 }
 public String eventsText(){
  Cursor c=getReadableDatabase().rawQuery("SELECT created_at,level,source,message FROM app_events ORDER BY id DESC LIMIT 300",null);StringBuilder s=new StringBuilder();
  try{while(c.moveToNext()){String level=c.getString(1);String icon="INFO".equals(level)?"ℹ":"OK".equals(level)?"✓":"WARNING".equals(level)?"⚠":"ERROR".equals(level)?"✖":"•";s.append(icon).append(" ").append(TimeUtil.displayDateTime(c.getString(0))).append("  •  ").append(c.getString(2)).append("\n").append(TimeUtil.displayDateTime(c.getString(3))).append("\n\n");}}finally{c.close();}
  return s.length()==0?"История событий пока пуста":s.toString();
 }
 public void clearResolvedAttention(){saveState("missed_check_pending","0");}

 public void stopRun(long id){ContentValues v=new ContentValues();v.put("finished_at",TimeUtil.now());v.put("status","STOPPED");v.put("current_stage","STOPPED");v.put("last_activity",TimeUtil.now());getWritableDatabase().update("audit_runs",v,"id=?",new String[]{String.valueOf(id)});}
 public Set<String> closureDates(){Set<String>s=new HashSet<>();Cursor c=getReadableDatabase().rawQuery("SELECT date_key FROM daily_closures",null);try{while(c.moveToNext())s.add(c.getString(0));}finally{c.close();}return s;} public void cleanupLegacyBaselineNoise(){try{Cursor r=getReadableDatabase().rawQuery("SELECT started_at,finished_at,total_records,new_count FROM audit_runs ORDER BY id ASC LIMIT 1",null);try{if(r.moveToFirst()){String s=r.getString(0),f=r.getString(1);int total=r.getInt(2),n=r.getInt(3);if(f!=null&&total>0&&n>=Math.max(10,(int)(total*0.90))){getWritableDatabase().delete("changes","change_type='NEW' AND detected_at>=? AND detected_at<=?",new String[]{s,f});saveState("legacy_baseline_noise_cleaned","1");}}}finally{r.close();}}catch(Exception ignored){}}

}
