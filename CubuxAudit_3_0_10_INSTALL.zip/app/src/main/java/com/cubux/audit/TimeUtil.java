package com.cubux.audit;
import java.text.SimpleDateFormat; import java.util.*;
public final class TimeUtil {
 private TimeUtil(){}
 public static String now(){return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date());}
 public static String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
 public static String yesterday(){Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,-1);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
 public static String clock(){return new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date());}
 public static String displayDateTime(String value){
  if(value==null)return "";
  return value.replaceAll("(\\d{4}-\\d{2}-\\d{2})T(?=\\d{2}:\\d{2})","$1 ");
 }
 public static String formatDuration(long ms){return duration(ms);}
 public static String duration(long ms){long s=Math.max(0,ms/1000),h=s/3600,m=(s%3600)/60,x=s%60; return h>0?String.format(Locale.US,"%02d:%02d:%02d",h,m,x):String.format(Locale.US,"%02d:%02d",m,x);}
}
