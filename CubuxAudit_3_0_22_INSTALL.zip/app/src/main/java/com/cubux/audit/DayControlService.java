package com.cubux.audit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import java.util.concurrent.atomic.AtomicBoolean;

/** Short foreground service for hourly current-day scans. */
public class DayControlService extends Service {
    public static final String ACTION = "com.cubux.audit.DAY_CONTROL_RUN";
    private static final String CHANNEL = "cubux_day_control";
    private static final int ID = 3181;
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    public static final class Snapshot {
        public final boolean running;
        public final String note;
        public final int percent;
        public final int loaded;
        public final int total;
        public final long startedMs;
        public final long lastActivityMs;
        public final String error;
        Snapshot(boolean running, String note, int percent, int loaded, int total,
                 long startedMs, long lastActivityMs, String error) {
            this.running = running;
            this.note = note == null ? "" : note;
            this.percent = percent;
            this.loaded = loaded;
            this.total = total;
            this.startedMs = startedMs;
            this.lastActivityMs = lastActivityMs;
            this.error = error == null ? "" : error;
        }
    }

    private static volatile Snapshot SNAPSHOT = new Snapshot(false, "", 0, 0, 0, 0L, 0L, "");

    public static Snapshot snapshot() { return SNAPSHOT; }
    public static boolean isRunning() { return RUNNING.get(); }

    private static void beginSnapshot() {
        long now = System.currentTimeMillis();
        SNAPSHOT = new Snapshot(true, "Подключение к Cubux", 2, 0, 0, now, now, "");
    }

    private static void updateSnapshot(String note, int percent, int loaded, int total) {
        Snapshot prev = SNAPSHOT;
        long started = prev.startedMs > 0 ? prev.startedMs : System.currentTimeMillis();
        SNAPSHOT = new Snapshot(true, note, percent, loaded, total, started, System.currentTimeMillis(), "");
    }

    private static void finishSnapshot(String note) {
        Snapshot prev = SNAPSHOT;
        SNAPSHOT = new Snapshot(false, note, 100, prev.loaded, prev.total,
                prev.startedMs, System.currentTimeMillis(), "");
    }

    private static void errorSnapshot(String error) {
        Snapshot prev = SNAPSHOT;
        SNAPSHOT = new Snapshot(false, "Ошибка", prev.percent, prev.loaded, prev.total,
                prev.startedMs, System.currentTimeMillis(), error);
    }

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    public static void startScheduled(Context c, String day, boolean finalScan, long scheduledFor) {
        Intent i = new Intent(c, DayControlService.class).setAction(ACTION)
                .putExtra("scan_day", day)
                .putExtra("final_scan", finalScan)
                .putExtra("scheduled_for", scheduledFor)
                .putExtra("manual", false);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    public static void startNow(Context c) {
        if (RUNNING.get()) return;
        Intent i = new Intent(c, DayControlService.class).setAction(ACTION)
                .putExtra("scan_day", TimeUtil.today())
                .putExtra("final_scan", false)
                .putExtra("scheduled_for", System.currentTimeMillis())
                .putExtra("manual", true);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(ID, notification("Проверяю сегодняшние записи…"));
        if (BackupOperationGate.isRestoreActive()) {
            DayControlScheduler.scheduleNext(this);
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (!RUNNING.compareAndSet(false, true)) {
            DayControlScheduler.scheduleNext(this);
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (BackupOperationGate.isRestoreActive()) {
            RUNNING.set(false);
            DayControlScheduler.scheduleNext(this);
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        beginSnapshot();
        final String day = intent == null ? TimeUtil.today() : intent.getStringExtra("scan_day");
        final boolean finalScan = intent != null && intent.getBooleanExtra("final_scan", false);
        final boolean manual = intent != null && intent.getBooleanExtra("manual", false);
        final Context app = getApplicationContext();

        new Thread(() -> {
            AuditDb db = new AuditDb(app);
            try {
                AuditDb.DayScanResult r = new DayControlEngine(app).scan(day,
                        (note, percent, loaded, total) -> {
                            updateSnapshot(note, percent, loaded, total);
                            try { updateNotification(note); } catch (Throwable ignored) {}
                        });
                db.saveState("day_control_last_scan_time", TimeUtil.now());
                db.saveState("day_control_last_scan_day", r.day);
                db.saveState("day_control_last_scan_total", String.valueOf(r.total));
                db.saveState("day_control_last_scan_status", "OK");
                db.saveState("day_control_last_scan_final", finalScan ? "1" : "0");
                db.saveState("day_control_last_error", "");

                if (r.newCount > 0) {
                    db.appEvent("INFO", "КОНТРОЛЬ ДНЯ",
                            "За сегодня добавлено новых записей: " + r.newCount,
                            "TODAY", "TODAY", false);
                }
                if (r.changedCount > 0) {
                    String msg=r.changedCount == 1 ? "За сегодня изменена 1 запись" : "За сегодня изменено записей: " + r.changedCount;
                    db.appEvent("WARNING", "КОНТРОЛЬ ДНЯ",msg,"TODAY", "TODAY", true);
                }
                if (r.deletedCount > 0) {
                    String msg=r.deletedCount == 1 ? "За сегодня удалена 1 запись" : "За сегодня удалено записей: " + r.deletedCount;
                    db.appEvent("ALERT", "КОНТРОЛЬ ДНЯ",msg,"TODAY", "TODAY", true);
                }
                if(r.changedCount>0||r.deletedCount>0){String alert=(r.changedCount>0?"Изменено: "+r.changedCount:"")+(r.changedCount>0&&r.deletedCount>0?" · ":"")+(r.deletedCount>0?"Удалено: "+r.deletedCount:"");NotificationHelper.showDayControlAlert(app,alert,r.deletedCount>0);}
                if (r.newCount + r.changedCount + r.deletedCount == 0) {
                    db.appEvent("INFO", "КОНТРОЛЬ ДНЯ",
                            "Дневной скан завершён. Изменений с прошлого скана нет.",
                            "TODAY", "TODAY", false);
                }
                finishSnapshot("Готово");
                if(r.changedCount==0&&r.deletedCount==0)NotificationHelper.clearDayControlWarning(app);
                DiagnosticLog.write(app, "DAY_CONTROL",
                        (manual ? "Ручной" : finalScan ? "Финальный" : "Почасовой") +
                                " скан " + r.day + ": всего " + r.total +
                                ", новых " + r.newCount + ", изменённых " + r.changedCount +
                                ", удалённых " + r.deletedCount);
            } catch (Throwable e) {
                String error = shortMessage(e);
                errorSnapshot(error);
                String previousStatus = db.getState("day_control_last_scan_status");
                String previousError = db.getState("day_control_last_error");
                db.saveState("day_control_last_scan_time", TimeUtil.now());
                db.saveState("day_control_last_scan_day", day == null ? TimeUtil.today() : day);
                db.saveState("day_control_last_scan_status", "ERROR");
                db.saveState("day_control_last_error", error);
                db.recordDayScanError(day == null ? TimeUtil.today() : day, error);
                if (!"ERROR".equals(previousStatus) || previousError == null || !previousError.equals(error)) {
                    db.appEvent("WARNING", "КОНТРОЛЬ ДНЯ","Дневной скан не выполнен: " + error,"TODAY", "TODAY", true);
                    NotificationHelper.showDayControlError(app,error);
                }
                DiagnosticLog.error(app, "DAY_CONTROL", e);
            } finally {
                RUNNING.set(false);
                DayControlScheduler.scheduleNext(app);
                stopSelf(startId);
            }
        }, "CubuxDayControl").start();
        return START_NOT_STICKY;
    }

    private void updateNotification(String text) {
        NotificationManager m = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (m != null) m.notify(ID, notification(text));
    }

    private static String shortMessage(Throwable e) {
        String s = e == null ? "неизвестная ошибка" : e.getMessage();
        if (s == null || s.trim().isEmpty()) s = String.valueOf(e);
        return s.length() > 120 ? s.substring(0, 120) : s;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager m = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (m != null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Контроль дня", NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Короткие почасовые проверки сегодняшних записей Cubux");
                m.createNotificationChannel(ch);
            }
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(MainActivity.EXTRA_NOTIFICATION_TARGET, MainActivity.TARGET_TODAY)
                .putExtra(MainActivity.EXTRA_NOTIFICATION_FILTER, "ALL");
        PendingIntent pi = PendingIntent.getActivity(this, 3181, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Snapshot s=SNAPSHOT;String title="Контроль дня"+(s.running?" · "+Math.max(0,s.percent)+"%":"");
        return b.setSmallIcon(R.drawable.ic_shield_check)
                .setColor(android.graphics.Color.rgb(0,169,190))
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setShowWhen(false)
                .setProgress(100,Math.max(0,Math.min(100,s.percent)),false)
                .build();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
