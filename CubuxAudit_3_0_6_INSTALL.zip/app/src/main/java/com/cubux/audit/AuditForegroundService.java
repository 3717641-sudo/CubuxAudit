package com.cubux.audit;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.os.IBinder;

public class AuditForegroundService extends Service {
    public static final String CHANNEL="cubux_audit_running";
    public static final int ID=2601;
    private static final String ACTION_SCHEDULED="com.cubux.audit.RUN_SCHEDULED";
    public static volatile int percent=0,page=0,pages=0,loaded=0,total=0;
    public static volatile String state="Подготовка проверки";
    public static volatile String stage="PREPARING";
    public static volatile String note="";
    private static volatile long updatedAt=0L,startedAtMs=0L;
    private static volatile boolean scheduledThreadRunning=false;

    public static final class Snapshot {
        public final int percent,page,pages,loaded,total; public final String state,stage,note; public final long updatedAt,elapsedMs;
        Snapshot(int percent,int page,int pages,int loaded,int total,String state,String stage,String note,long updatedAt,long elapsedMs){this.percent=percent;this.page=page;this.pages=pages;this.loaded=loaded;this.total=total;this.state=state;this.stage=stage;this.note=note;this.updatedAt=updatedAt;this.elapsedMs=elapsedMs;}
    }
    @Override public void onCreate(){super.onCreate();createChannel();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        startForeground(ID,buildNotification());
        if(intent!=null&&ACTION_SCHEDULED.equals(intent.getAction())){
            String type=intent.getStringExtra("check_type");int attempt=intent.getIntExtra("attempt",0);boolean retry=intent.getBooleanExtra("retry",false);
            launchScheduled(type==null?CheckSettings.TYPE_LIGHT:type,attempt,retry);
        }
        return START_STICKY;
    }
    public static void start(Context c){Intent i=new Intent(c,AuditForegroundService.class);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}
    public static void startScheduled(Context c,String type,int attempt,boolean retry){Intent i=new Intent(c,AuditForegroundService.class).setAction(ACTION_SCHEDULED).putExtra("check_type",type).putExtra("attempt",attempt).putExtra("retry",retry);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}
    public static void stop(Context c){try{c.stopService(new Intent(c,AuditForegroundService.class));}catch(Throwable ignored){}}

    private synchronized void launchScheduled(String type,int previousAttempt,boolean retry){
        if(scheduledThreadRunning||AuditRunGate.isRunning()){DiagnosticLog.write(this,"SCHEDULED","Проверка уже выполняется; новый автоматический запуск не создаю");return;}
        scheduledThreadRunning=true; final int attempt=previousAttempt+1; final Context app=getApplicationContext();
        new Thread(()->{
            AuditControl control=new AuditControl(); String mode=CheckSettings.TYPE_FULL.equals(type)?AuditCoordinator.MODE_FULL:AuditCoordinator.MODE_QUICK;String label=CheckSettings.TYPE_FULL.equals(type)?"Полная проверка":"Лёгкая проверка";
            boolean needRetry=false;
            try{
                reset(System.currentTimeMillis()); AuditControlRegistry.attach(control,mode); new AuditDb(app).saveState("last_scheduled_start_ms",String.valueOf(System.currentTimeMillis())); new AuditDb(app).saveState("yesterday_changed_during_scan","0");
                CheckStatusStore.running(app,label+" по расписанию");
                AuditProgressListener l=new AuditProgressListener(){
                    @Override public void onStage(String st,String msg){int pct=stagePercent(st);updateStage(app,st,msg,pct,page,pages,loaded,total);}
                    @Override public void onMeta(int t,int p){total=t;pages=p;updateStage(app,"LOADING_META","Получен объём данных Cubux",Math.max(percent,5),page,p,loaded,t);}
                    @Override public void onPage(int pg,int pgs,int ld,int ttl){int pct=ttl<=0?5:Math.min(85,(int)(5.0+80.0*ld/ttl));updateStage(app,"READING_DATA","Читаю операции из Cubux",pct,pg,pgs,ld,ttl);}
                    @Override public void onRetry(int pg,int a,int sec,String err){updateNote(app,"Повтор запроса: попытка "+a+" через "+sec+" сек • "+err);}
                };
                SecureCredentialsStore cr=new SecureCredentialsStore(app);String login=cr.getLogin(),password=cr.getPassword();if(login.isEmpty()||password.isEmpty())throw new Exception("Логин/пароль Cubux не сохранены");
                AuditCoordinator co=new AuditCoordinator(app);AuditEngine.Result r=co.runMode(login,password,co.isRecovery(),l,control,mode);
                CheckStatusStore.success(app,label,r);new AuditDb(app).saveState("last_scheduled_success_ms",String.valueOf(System.currentTimeMillis()));
                if("1".equals(new AuditDb(app).getState("yesterday_changed_during_scan"))){NotificationHelper.showWarning(app,"Внимание: данные за вчерашний день менялись во время ночной проверки. Визуально проверьте вчерашний день в Cubux.");}
                int found=r.newCount+r.changedCount+r.deletedCount;if(found>0)NotificationHelper.showAuditResult(app,true,label+" завершена. Найдены изменения — смотрите журнал.");
            }catch(Exception e){String msg=e.getMessage()==null?e.toString():e.getMessage();int max=new CheckSettings(app).retries();boolean permanent=msg.contains("Логин/пароль")||msg.contains("HTTP 401")||msg.contains("HTTP 403")||msg.contains("остановлена пользователем");needRetry=!permanent&&attempt<max;CheckStatusStore.failure(app,label,attempt,msg);DiagnosticLog.error(app,"SCHEDULED_ERROR",e);if(!msg.contains("остановлена пользователем"))NotificationHelper.showAuditResult(app,false,needRetry?label+" не выполнена. Повтор будет автоматически.":label+" не выполнена. Причина: "+msg);
            }finally{
                AuditControlRegistry.clear(control);scheduledThreadRunning=false;final boolean nr=needRetry;
                if(nr)CheckScheduler.scheduleRetry(app,type,attempt);else CheckScheduler.scheduleNext(app);
                if(!AuditRunGate.isRunning())stopSelf();
            }
        },"CubuxScheduledCheck").start();
    }
    private static int stagePercent(String st){if(st==null)return percent;if(st.startsWith("BACKUP"))return Math.max(percent,99);if("SAVING".equals(st))return Math.max(percent,97);if("COMPARING".equals(st)||"PROCESSING".equals(st))return Math.max(percent,90);if(st.startsWith("STABILITY")||st.startsWith("MONTHLY_CONTROL"))return Math.max(percent,86);if("COMPLETED".equals(st))return 100;return percent;}
    public static synchronized void update(Context c,String st,int pct,int pg,int pgs,int ld,int ttl){state=st==null?state:st;percent=Math.max(percent,pct);if(pg>=0)page=pg;if(pgs>=0)pages=pgs;if(ld>=0)loaded=ld;if(ttl>=0)total=ttl;updatedAt=System.currentTimeMillis();notifyNow(c);}
    public static synchronized void updateStage(Context c,String stageKey,String st,int pct,int pg,int pgs,int ld,int ttl){stage=stageKey==null?stage:stageKey;note="";update(c,st,pct,pg,pgs,ld,ttl);}
    public static synchronized void updateNote(Context c,String text){note=text==null?"":text;updatedAt=System.currentTimeMillis();notifyNow(c);}
    private static void notifyNow(Context c){try{NotificationManager m=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(m!=null)m.notify(ID,buildStatic(c));}catch(Throwable ignored){}}
    public static synchronized Snapshot snapshot(){long elapsed=startedAtMs<=0?0:AuditControlRegistry.activeElapsedMs(startedAtMs);return new Snapshot(percent,page,pages,loaded,total,state,stage,note,updatedAt,elapsed);}
    public static synchronized void reset(){reset(System.currentTimeMillis());}
    public static synchronized void reset(long startedAt){percent=page=pages=loaded=total=0;state="Подготовка проверки";stage="PREPARING";note="";startedAtMs=startedAt>0?startedAt:System.currentTimeMillis();updatedAt=System.currentTimeMillis();}
    public static synchronized void resetPageProgress(){page=0;pages=0;loaded=0;total=0;updatedAt=System.currentTimeMillis();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager m=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);if(m!=null){NotificationChannel ch=new NotificationChannel(CHANNEL,"Текущая проверка",NotificationManager.IMPORTANCE_LOW);ch.setDescription("Прогресс выполняющейся проверки Cubux");m.createNotificationChannel(ch);}}}
    private Notification buildNotification(){return buildStatic(this);}
    private static Notification buildStatic(Context c){Snapshot s=snapshot();Intent open=new Intent(c,MainActivity.class);PendingIntent content=PendingIntent.getActivity(c,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);PendingIntent pause=action(c,"PAUSE",2),resume=action(c,"RESUME",3),stop=action(c,"STOP",4);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);String progress=s.total>0?s.loaded+" из "+s.total+" • страница "+s.page+" из "+s.pages:"Текущий этап выполняется";String elapsed="Прошло: "+TimeUtil.formatDuration(s.elapsedMs);String delay="Запросы: "+DelayProfile.label(new CheckSettings(c).requestDelayMs());String extra=(s.note==null||s.note.trim().isEmpty())?"":"\n"+s.note.trim();b.setSmallIcon(android.R.drawable.ic_popup_sync).setContentTitle("Cubux Security — "+s.percent+"%").setContentText(s.state+" • "+elapsed).setStyle(new Notification.BigTextStyle().bigText(s.state+"\n"+progress+"\n"+delay+"\n"+elapsed+extra)).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(content).setProgress(100,Math.min(100,s.percent),false).addAction(new Notification.Action.Builder(null,"Пауза",pause).build()).addAction(new Notification.Action.Builder(null,"Продолжить",resume).build()).addAction(new Notification.Action.Builder(null,"Стоп",stop).build());return b.build();}
    private static PendingIntent action(Context c,String a,int code){Intent i=new Intent(c,AuditActionReceiver.class).setAction("com.cubux.audit."+a);return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    @Override public IBinder onBind(Intent intent){return null;}
}
