package com.cubux.audit;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

/** Exact scheduled checks. One next alarm only; full check wins the day. */
public final class CheckScheduler {
    public static final int ALARM_CODE=2801;
    private CheckScheduler(){}
    public static final class Next { public final long whenMs; public final String type; Next(long w,String t){whenMs=w;type=t;} }

    public static boolean canScheduleExact(Context c){
        try{AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);return am!=null&&(Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms());}
        catch(Throwable e){return false;}
    }
    public static boolean scheduleStartup(Context c){
        AuditDb db=new AuditDb(c); long last=0L; try{last=Long.parseLong(String.valueOf(db.getState("last_successful_audit_ms")));}catch(Exception ignored){}
        long now=System.currentTimeMillis();
        if(last>0L){String missed=missedType(c,last,now);if(missed!=null){db.saveState("missed_check_pending","1");return scheduleAt(c,now+5000L,missed,0,false);}}
        return scheduleNext(c);
    }
    private static String missedType(Context c,long fromMs,long toMs){
        CheckSettings s=new CheckSettings(c); Calendar day=Calendar.getInstance();day.setTimeInMillis(fromMs);day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);boolean light=false;
        for(int i=0;i<40&&day.getTimeInMillis()<=toMs;i++){
            int dow=day.get(Calendar.DAY_OF_WEEK);
            if(s.enabled(CheckSettings.TYPE_FULL,dow)){int[] hm=CheckSettings.parseTime(s.fullTime());Calendar x=(Calendar)day.clone();x.set(Calendar.HOUR_OF_DAY,hm[0]);x.set(Calendar.MINUTE,hm[1]);if(x.getTimeInMillis()>fromMs&&x.getTimeInMillis()<=toMs)return CheckSettings.TYPE_FULL;}
            else if(s.enabled(CheckSettings.TYPE_LIGHT,dow)){int[] hm=CheckSettings.parseTime(s.lightTime());Calendar x=(Calendar)day.clone();x.set(Calendar.HOUR_OF_DAY,hm[0]);x.set(Calendar.MINUTE,hm[1]);if(x.getTimeInMillis()>fromMs&&x.getTimeInMillis()<=toMs)light=true;}
            day.add(Calendar.DAY_OF_YEAR,1);day.set(Calendar.HOUR_OF_DAY,0);day.set(Calendar.MINUTE,0);
        }
        return light?CheckSettings.TYPE_LIGHT:null;
    }
    public static Next calculateNext(Context c,long nowMs){
        CheckSettings s=new CheckSettings(c); Calendar now=Calendar.getInstance();now.setTimeInMillis(nowMs);Next best=null;
        for(int add=0;add<15;add++){Calendar day=(Calendar)now.clone();day.add(Calendar.DAY_OF_YEAR,add);int dow=day.get(Calendar.DAY_OF_WEEK);String type=null,time=null;
            if(s.enabled(CheckSettings.TYPE_FULL,dow)){type=CheckSettings.TYPE_FULL;time=s.fullTime();} else if(s.enabled(CheckSettings.TYPE_LIGHT,dow)){type=CheckSettings.TYPE_LIGHT;time=s.lightTime();}
            if(type==null)continue;int[] hm=CheckSettings.parseTime(time);day.set(Calendar.HOUR_OF_DAY,hm[0]);day.set(Calendar.MINUTE,hm[1]);day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);if(day.getTimeInMillis()<=nowMs)continue;
            if(best==null||day.getTimeInMillis()<best.whenMs)best=new Next(day.getTimeInMillis(),type);
        }return best;
    }
    public static boolean scheduleNext(Context c){Next n=calculateNext(c,System.currentTimeMillis());if(n==null){cancel(c);return false;}return scheduleAt(c,n.whenMs,n.type,0,false);}
    public static boolean scheduleRetry(Context c,String type,int completedAttempts){long[] b=CheckSettings.retryBackoffSeconds();int idx=Math.max(0,Math.min(completedAttempts-1,b.length-1));return scheduleAt(c,System.currentTimeMillis()+b[idx]*1000L,type,completedAttempts,true);}
    private static PendingIntent pending(Context c,String type,int attempt,boolean retry){Intent i=new Intent(c,ScheduledAlarmReceiver.class).setAction("com.cubux.audit.SCHEDULED_CHECK");i.putExtra("check_type",type).putExtra("attempt",attempt).putExtra("retry",retry);return PendingIntent.getBroadcast(c,ALARM_CODE,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    private static boolean scheduleAt(Context c,long target,String type,int attempt,boolean retry){
        try{AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return false;PendingIntent pi=pending(c,type,attempt,retry);am.cancel(pi);
            if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,target,pi);new AuditDb(c).saveState("exact_alarm_status","LIMITED");}
            else {am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,target,pi);new AuditDb(c).saveState("exact_alarm_status","EXACT");}
            AuditDb db=new AuditDb(c);db.saveState("next_scheduled_check_ms",String.valueOf(target));db.saveState("next_scheduled_check_type",type);db.saveState("next_scheduled_check_retry",retry?"1":"0");DiagnosticLog.write(c,"SCHEDULE","Следующая проверка "+type+" запланирована на "+target);return true;
        }catch(Throwable e){DiagnosticLog.error(c,"CHECK_SCHEDULE",e);return false;}
    }
    public static void cancel(Context c){try{AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pending(c,CheckSettings.TYPE_LIGHT,0,false));}catch(Throwable ignored){}AuditDb db=new AuditDb(c);db.saveState("next_scheduled_check_ms","0");db.saveState("next_scheduled_check_type","");}
}
