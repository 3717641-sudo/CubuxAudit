package com.cubux.audit;
import android.content.*;

public class AuditActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if(intent==null)return;
        AuditSessionStore.Snapshot s=AuditSessionStore.snapshot(context);
        long requested=intent.getLongExtra(AuditForegroundService.EXTRA_RUN_ID,-1L);
        if(!AuditSessionPolicy.acceptsAction(s.active,s.runId,requested)){
            DiagnosticLog.write(context,"CONTROL","Игнорирую действие старого уведомления. current="+s.runId+", requested="+requested);
            return;
        }
        AuditControl c=AuditControlRegistry.current();
        if(c==null){
            DiagnosticLog.write(context,"CONTROL","Действие уведомления отклонено: контроллер проверки отсутствует");
            return;
        }
        String a=intent.getAction();
        if("com.cubux.audit.PAUSE".equals(a)){
            c.pause();AuditSessionStore.pause(context,s.runId);
            DiagnosticLog.write(context,"CONTROL","Пауза из уведомления");
            AuditForegroundService.update(context,"Проверка на паузе",s.percent,s.page,s.pages,s.loaded,s.total);
        } else if("com.cubux.audit.RESUME".equals(a)){
            c.resume();AuditSessionStore.resume(context,s.runId);
            DiagnosticLog.write(context,"CONTROL","Продолжить из уведомления");
            AuditForegroundService.update(context,"Проверка продолжается",s.percent,s.page,s.pages,s.loaded,s.total);
        } else if("com.cubux.audit.STOP".equals(a)){
            AuditSessionStore.stopping(context,s.runId);c.stop();
            DiagnosticLog.write(context,"CONTROL","Стоп из уведомления");
            AuditForegroundService.update(context,"Останавливаю проверку…",s.percent,s.page,s.pages,s.loaded,s.total);
        }
    }
}
