package com.cubux.audit;

/** Pure-Java policy for deciding whether one audit session is really active. */
public final class AuditSessionPolicy {
    private AuditSessionPolicy() {}

    public static boolean isActive(boolean persistedActive,
                                   boolean serviceRuntimeActive,
                                   boolean runGateActive,
                                   boolean hasControl) {
        return runGateActive || hasControl || (persistedActive && serviceRuntimeActive);
    }

    public static boolean shouldRecoverOrphan(boolean persistedActive,
                                              boolean serviceRuntimeActive,
                                              boolean runGateActive,
                                              boolean hasControl) {
        return persistedActive && !serviceRuntimeActive && !runGateActive && !hasControl;
    }

    public static boolean acceptsAction(boolean persistedActive, long currentRunId, long requestedRunId) {
        return persistedActive && currentRunId > 0L && requestedRunId == currentRunId;
    }
}
