package com.cubux.audit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.os.Bundle;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_BANK = 1001;
    private static final int REQ_BACKUP = 1002;
    private static final int REQ_RESTORE = 1003;
    private static final int REQ_LOG = 1004;
    private static final int REQ_BACKUP_FOLDER = 1005;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_CHECK = 1;
    private static final int PAGE_REPORTS = 2;
    private static final int PAGE_JOURNAL = 3;
    private static final int PAGE_SETTINGS = 4;
    private static final int PAGE_COUNT = 5;

    public static final String EXTRA_NOTIFICATION_TARGET = "notification_target";
    public static final String EXTRA_NOTIFICATION_FILTER = "notification_filter";
    public static final String TARGET_HOME = "HOME";
    public static final String TARGET_CHECK = "CHECK";
    public static final String TARGET_TODAY = "TODAY";
    public static final String TARGET_JOURNAL = "JOURNAL";
    public static final String TARGET_CHECK_HISTORY = "CHECK_HISTORY";
    public static final String TARGET_EVENTS = "EVENTS";
    public static final String TARGET_PERIODS = "PERIODS";
    public static final String TARGET_SCHEDULE = "SCHEDULE";
    public static final String TARGET_BACKUP = "BACKUP";
    public static final String TARGET_RESTORE = "RESTORE";

    private static final int ACCENT = Color.rgb(0, 169, 190);

    private final int GREEN = Color.rgb(0, 190, 113);
    private final int DARK = Color.rgb(18, 39, 67);
    private final int TEXT = Color.rgb(15, 31, 55);
    private final int MUTED = Color.rgb(104, 123, 153);
    private final int RED = Color.rgb(255, 75, 88);
    private final int YELLOW = Color.rgb(255, 184, 31);
    private final int PURPLE = Color.rgb(126, 79, 255);
    private final int BLUE = Color.rgb(24, 139, 232);

    private AuditDb db;
    private SecureCredentialsStore credentials;

    private LinearLayout pageHost;
    private LinearLayout bottomNav;
    private TextView informerText;
    private LinearLayout informerCard;
    private TextView informerIcon;
    private TextView informerNext;
    private TextView informerAll;
    private AuditDb.AppEvent currentInformerEvent;
    private TextView headerStatusPill;
    private int currentPage = PAGE_HOME;
    private boolean backupPageVisible = false;
    private float swipeDownX;
    private float swipeDownY;

    private EditText loginInput;
    private EditText passwordInput;

    private ProgressBar progressBar;
    private TextView percentText;
    private TextView statusText;
    private TextView detailsText;
    private TextView resultText;
    private TextView lastCheckText;

    private TextView connectStep;
    private TextView readStep;
    private TextView compareStep;
    private TextView reportStep;
    private final TextView[] stageRows = new TextView[8];
    private final TextView[] detailValues = new TextView[8];
    private TextView checkBannerTitle;
    private TextView checkBannerSubtitle;
    private TextView checkModePill;
    private TextView progressAmountText;
    private final TextView[] stageIconViews = new TextView[8];
    private final TextView[] stageStatusViews = new TextView[8];
    private TextView currentStageSummaryTitle;
    private TextView currentStageSummaryBody;
    private Button homeQuickButton;

    private TextView totalTop;
    private TextView newTop;
    private TextView changedTop;
    private TextView deletedTop;

    private TextView newCard;
    private TextView changedCard;
    private TextView deletedCard;
    private TextView closedCard;
    private TextView multiCard;

    private Button auditButton;
    private Button fullAuditButton;
    private Button pauseButton;
    private Button stopButton;
    private AuditControl auditControl;
    private long auditSessionCounter = 0L;
    private volatile long activeAuditSession = 0L;
    private volatile int maxPageShown = 0;
    private volatile int maxLoadedShown = 0;
    private volatile int maxPercentShown = 0;
    private volatile boolean auditRunning;
    private String activeCheckMode = AuditCoordinator.MODE_QUICK;
    private volatile String scanContext = "";
    private volatile String currentStageForUi = "IDLE";
    private volatile int maxStageIndexShown = 0;
    private volatile String currentWaitForUi = "";

    // 3.0.22 UI state
    private String reportMode = "MONTH";
    private String reportTypeFilter = "ALL";
    private final java.util.Calendar reportAnchor = java.util.Calendar.getInstance();
    private String journalResolutionFilter = "OPEN";
    private String journalTypeFilter = "ALL";
    private String journalQuery = "";
    private String historyFilter = "ALL";
    private String historyQuery = "";
    private int historyLimit = 20;
    private String dayEventTypeFilter = "ALL";
    private final java.util.Calendar dayAnchor = java.util.Calendar.getInstance();
    private String eventFilter = "ALL";
    private TextView dayScanLiveText;
    private ProgressBar dayScanProgressBar;
    private Button dayScanButton;
    private boolean dayScanWasRunning = false;
    private String dayLastRenderedScan = "";

    private long startedMs;
    private int retries;

    private final Handler progressSyncHandler = new Handler(Looper.getMainLooper());
    private boolean progressSyncActive = false;
    private final Runnable progressSyncTick = new Runnable() {
        @Override public void run() {
            if (!progressSyncActive) return;
            try { syncProgressFromService(); } catch (Throwable ignored) {}
            progressSyncHandler.postDelayed(this, 1000L);
        }
    };


    private boolean isAuditSessionActive() {
        AuditSessionStore.Snapshot live=AuditSessionStore.snapshot(this);
        return AuditSessionPolicy.isActive(live.active, AuditForegroundService.isRuntimeActive(),
                AuditRunGate.isRunning(), AuditControlRegistry.current()!=null);
    }

    private void recoverOrphanedAuditSession() {
        try {
            AuditSessionStore.Snapshot live=AuditSessionStore.snapshot(this);
            boolean gate=AuditRunGate.isRunning();
            boolean hasControl=AuditControlRegistry.current()!=null;
            if (AuditSessionPolicy.shouldRecoverOrphan(live.active, AuditForegroundService.isRuntimeActive(), gate, hasControl)) {
                AuditSessionStore.interruptOrphan(this,"Проверка прервана системой. Запустите её повторно.");
                int stopped=db.stopStaleRunningRuns();
                try {
                    android.app.NotificationManager m=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                    if(m!=null)m.cancel(AuditForegroundService.ID);
                } catch (Throwable ignored) {}
                db.appEvent("WARNING","ПРОВЕРКА","Незавершённая проверка после перезапуска приложения помечена как прерванная");
                DiagnosticLog.write(this,"STALE_RUN_RECOVERY","Прервана осиротевшая сессия runId="+live.runId+", строк запусков="+stopped);
            } else if (!gate && !hasControl && !live.active) {
                db.stopStaleRunningRuns();
            }
        } catch (Throwable e) { DiagnosticLog.error(this,"STALE_RUN_RECOVERY",e); }
    }

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);

        db = new AuditDb(this);
        // 3.0.25: reconcile the persistent live-session state before the UI is built.
        // A cold process cannot still own an audit thread; an orphaned session is marked
        // interrupted and its old foreground notification is removed. A live foreground
        // service, however, is never erased merely because this Activity was recreated.
        recoverOrphanedAuditSession();
        if (!"1".equals(db.getState("legacy_baseline_noise_cleaned"))) {
            db.cleanupLegacyBaselineNoise();
        }
        boolean backupStorageMigration=!"1".equals(db.getState("backup_storage_v2_ready"));
        if(backupStorageMigration){db.saveState("auto_backup_uri","");db.saveState("backup_storage_v2_ready","1");}
        String autoBackupTime = db.getState("auto_backup_time");
        String lastSuccessfulCheck = db.getState("last_successful_audit_ms");
        // Do not create an empty automatic backup on a fresh reinstall: an older
        // Downloads backup must remain easy to identify and restore first.
        if ((backupStorageMigration || autoBackupTime == null || autoBackupTime.trim().isEmpty())
                && lastSuccessfulCheck != null && !lastSuccessfulCheck.trim().isEmpty()) {
            AutoBackupManager.backupAsync(this);
        }

        credentials =
                new SecureCredentialsStore(
                        this
                );

        createUi();
        handleNotificationIntent(getIntent());

        try {
            NotificationHelper.ensureChannel(this);
            CheckScheduler.scheduleStartup(this);
            DiagnosticLog.write(this, "APP", "Приложение запущено");
            db.appEvent("INFO", "ПРИЛОЖЕНИЕ", "Cubux Security 3.0.25 запущен");
            DayControlScheduler.scheduleNext(this);
            BackupScheduler.restore(this);
            refreshAutoAuditStatus();
            refreshLastCheckStatus();
        } catch (Throwable e) {
            DiagnosticLog.error(this, "APP_START", e);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleNotificationIntent(intent);
    }

    private void handleNotificationIntent(Intent intent) {
        if (intent == null || pageHost == null) return;
        String target = intent.getStringExtra(EXTRA_NOTIFICATION_TARGET);
        if (target == null || target.trim().isEmpty()) return;
        String filter = intent.getStringExtra(EXTRA_NOTIFICATION_FILTER);
        try {
            if (TARGET_CHECK.equals(target)) {
                switchPage(PAGE_CHECK);
                // onNewIntent can be delivered while Activity is already RESUMED, so onResume
                // is not guaranteed to run. Synchronise immediately on notification taps.
                pageHost.post(() -> { try { syncProgressFromService(); } catch (Throwable ignored) {} });
            } else if (TARGET_TODAY.equals(target)) {
                dayAnchor.setTimeInMillis(System.currentTimeMillis());
                dayEventTypeFilter = (filter == null || filter.trim().isEmpty()) ? "ALL" : filter;
                switchPage(PAGE_REPORTS);
            } else if (TARGET_JOURNAL.equals(target)) {
                journalResolutionFilter = "OPEN";
                journalTypeFilter = (filter == null || filter.trim().isEmpty()) ? "ALL" : filter;
                switchPage(PAGE_JOURNAL);
            } else if (TARGET_CHECK_HISTORY.equals(target)) {
                showCheckHistoryPage();
            } else if (TARGET_EVENTS.equals(target)) {
                showEventCenterPage();
            } else if (TARGET_PERIODS.equals(target)) {
                switchPage(PAGE_HOME);
                showClosedPeriods();
            } else if (TARGET_SCHEDULE.equals(target)) {
                switchPage(PAGE_HOME);
                showAutoStartSettings();
            } else if (TARGET_BACKUP.equals(target)) {
                showBackupPage(false);
            } else if (TARGET_RESTORE.equals(target)) {
                showBackupPage(true);
            } else {
                switchPage(PAGE_HOME);
            }
        } catch (Throwable e) {
            DiagnosticLog.error(this, "NOTIFICATION_ROUTE", e);
            switchPage(PAGE_HOME);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startProgressSync();
        try {
            recoverOrphanedAuditSession();
            refreshAutoAuditStatus();
            refreshLastCheckStatus();
            refreshDashboardInformer();
            if (currentPage == PAGE_REPORTS) switchPage(PAGE_REPORTS);
            if (isAuditSessionActive()) {
                auditControl=AuditControlRegistry.current();
                auditRunning=true;
                if (currentPage == PAGE_CHECK) syncProgressFromService();
            } else {
                recoverStoppedAuditUi();
            }
        } catch (Throwable e) {
            DiagnosticLog.error(this, "RESUME", e);
        }
    }

    /** Return the check screen to idle only when no live service/session/gate/controller exists. */
    private void recoverStoppedAuditUi() {
        if (isAuditSessionActive()) return;
        AuditControl stale = AuditControlRegistry.current();
        if (stale != null) AuditControlRegistry.clear(stale);
        auditRunning = false;
        auditControl = null;
        if (auditButton != null) { auditButton.setEnabled(true); auditButton.setVisibility(View.VISIBLE); }
        if (fullAuditButton != null) { fullAuditButton.setEnabled(true); fullAuditButton.setVisibility(View.VISIBLE); }
        if (pauseButton != null) { pauseButton.setEnabled(false); pauseButton.setVisibility(View.GONE); pauseButton.setText("⏸  ПАУЗА"); }
        if (stopButton != null) { stopButton.setEnabled(false); stopButton.setVisibility(View.GONE); }
        if (statusText != null && (statusText.getText().toString().contains("Останавливаю") || statusText.getText().toString().contains("Выполняется"))) {
            statusText.setText("Проверка остановлена");
        }
        refreshCheckModeUi();
        refreshHomeQuickButton();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev != null) {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                swipeDownX = ev.getX();
                swipeDownY = ev.getY();
            } else if (ev.getAction() == MotionEvent.ACTION_UP) {
                float dx = ev.getX() - swipeDownX;
                float dy = ev.getY() - swipeDownY;
                if (Math.abs(dx) > dp(85) && Math.abs(dx) > Math.abs(dy) * 1.35f) {
                    if (dx < 0 && currentPage < PAGE_COUNT - 1) switchPage(currentPage + 1);
                    else if (dx > 0 && currentPage > 0) switchPage(currentPage - 1);
                    return true;
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        if (backupPageVisible) {
            switchPage(PAGE_HOME);
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopProgressSync();
    }

    private void startProgressSync() {
        if (progressSyncActive) return;
        progressSyncActive = true;
        progressSyncHandler.removeCallbacks(progressSyncTick);
        progressSyncHandler.post(progressSyncTick);
    }

    private void stopProgressSync() {
        progressSyncActive = false;
        progressSyncHandler.removeCallbacks(progressSyncTick);
    }

    /** Notification and the visible screen read the same persistent live-session snapshot. */
    private void syncProgressFromService() {
        if (currentPage == PAGE_REPORTS) {
            syncDayControlUi();
            refreshDashboardInformer();
            return;
        }
        if (!isAuditSessionActive()) {
            recoverStoppedAuditUi();
            refreshDashboardInformer();
            return;
        }
        if (currentPage != PAGE_CHECK) { refreshDashboardInformer(); return; }

        AuditForegroundService.Snapshot s = AuditForegroundService.snapshot(MainActivity.this);
        AuditControl running = AuditControlRegistry.current();
        auditRunning = true;
        auditControl = running;
        maxPercentShown = Math.max(maxPercentShown, s.percent);
        maxPageShown = Math.max(maxPageShown, s.page);
        maxLoadedShown = Math.max(maxLoadedShown, s.loaded);
        stableStageForUi(s.stage);
        currentWaitForUi = s.note == null ? "" : s.note;
        if (progressBar != null) progressBar.setProgress(Math.min(100, maxPercentShown));
        if (percentText != null) percentText.setText(percentLabel(maxPercentShown));
        if (progressAmountText != null) progressAmountText.setText(s.total > 0 ? (s.loaded + " из " + s.total + " операций") : progressFallbackText(s));
        boolean paused = AuditSessionStore.PAUSED.equals(s.status) || (running != null && running.isPaused());
        boolean stopping = AuditSessionStore.STOPPING.equals(s.status) || (running != null && running.isStopped());
        if (statusText != null) statusText.setText(paused ? "На паузе" : (stopping ? "Останавливаю проверку..." : s.state));
        refreshCheckModeUi();
        updateStageIndicators(currentStageForUi);
        if (detailsText != null) detailsText.setText(runningDetails(s));
        if (pauseButton != null) {
            pauseButton.setEnabled(running != null && !stopping);
            pauseButton.setVisibility(View.VISIBLE);
            pauseButton.setText(paused ? "▶  ПРОДОЛЖИТЬ" : "⏸  ПАУЗА");
        }
        if (stopButton != null) { stopButton.setEnabled(running != null && !stopping); stopButton.setVisibility(View.VISIBLE); }
        if (auditButton != null) { auditButton.setEnabled(false); auditButton.setVisibility(View.GONE); }
        if (fullAuditButton != null) { fullAuditButton.setEnabled(false); fullAuditButton.setVisibility(View.GONE); }
        refreshHomeQuickButton();
    }

    private void createUi() {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(Color.rgb(247, 250, 253));
        screen.addView(buildHeader(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        pageHost.setBackgroundColor(Color.rgb(247, 250, 253));
        screen.addView(pageHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        bottomNav = buildBottomNavigation();
        screen.addView(bottomNav, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(70)));
        setContentView(screen);
        switchPage(PAGE_HOME);
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(7), dp(3), dp(7), dp(3));
        GradientDrawable bg = rounded(Color.WHITE, 0);
        bg.setStroke(dp(1), Color.rgb(229, 235, 242));
        nav.setBackground(bg);
        nav.setElevation(dp(2));
        return nav;
    }

    private void rebuildBottomNavigation() {
        if (bottomNav == null) return;
        bottomNav.removeAllViews();
        int[] icons = {
                R.drawable.ic_home, R.drawable.ic_play, R.drawable.ic_chart,
                R.drawable.ic_journal, R.drawable.ic_settings
        };
        String[] names = {"Главная", "Проверка", "Сегодня", "Журнал", "Настройки"};
        for (int i = 0; i < PAGE_COUNT; i++) {
            final int page = i;
            boolean active = currentPage == i;
            View item = bottomNavItem(icons[i], names[i], active, v -> switchPage(page));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1);
            lp.setMargins(dp(2), dp(4), dp(2), dp(4));
            bottomNav.addView(item, lp);
        }
        if (headerStatusPill != null) headerStatusPill.setVisibility(currentPage == PAGE_HOME ? View.VISIBLE : View.GONE);
    }

    private View bottomNavItem(int iconRes, String caption, boolean active, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(2), dp(4), dp(2), dp(3));
        int color = active ? ACCENT : Color.rgb(92, 112, 145);
        if (active) {
            GradientDrawable activeBg = rounded(Color.rgb(229, 246, 252), 15);
            activeBg.setStroke(dp(1), Color.rgb(190, 229, 240));
            box.setBackground(activeBg);
            box.setElevation(dp(2));
            box.setScaleX(1.0f);
            box.setScaleY(1.0f);
        }
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(color);
        int iconSize = active ? dp(26) : dp(23);
        box.addView(icon, new LinearLayout.LayoutParams(iconSize, iconSize));
        TextView text = label(caption, 10, active, color);
        text.setGravity(Gravity.CENTER);
        text.setPadding(0, dp(3), 0, 0);
        box.addView(text, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.setOnClickListener(listener);
        return box;
    }

    private void switchPage(int page) {
        if (page < 0 || page >= PAGE_COUNT || pageHost == null) return;
        backupPageVisible = false;
        currentPage = page;
        pageHost.removeAllViews();

        View content;
        if (page == PAGE_HOME) content = buildHomePage();
        else if (page == PAGE_CHECK) content = buildCheckPage();
        else if (page == PAGE_REPORTS) content = buildReportsPage();
        else if (page == PAGE_JOURNAL) content = buildJournalPage();
        else content = buildSettingsPage();

        pageHost.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rebuildBottomNavigation();
        if (page == PAGE_HOME) refreshDashboardInformer();
        if (page == PAGE_CHECK && isAuditSessionActive()) {
            try { syncProgressFromService(); } catch (Throwable ignored) {}
        }
    }

    private ScrollView pageScroll(LinearLayout body) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(Color.rgb(247, 250, 253));
        scroll.addView(body);
        return scroll;
    }

    private LinearLayout pageBody() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(9), dp(7), dp(9), dp(14));
        body.setBackgroundColor(Color.rgb(247, 250, 253));
        return body;
    }

    private View pageTitle(String title, String subtitle) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(2), dp(2), dp(2), dp(7));
        TextView t = label(title, 15, true, DARK);
        wrap.addView(t);
        if (subtitle != null && !subtitle.trim().isEmpty()) {
            TextView st = label(subtitle, 10, false, MUTED);
            st.setPadding(0, dp(2), 0, 0);
            st.setLineSpacing(0, 0.96f);
            wrap.addView(st);
        }
        return wrap;
    }

    private View buildHomePage() {
        LinearLayout body = pageBody();
        body.setPadding(dp(10), dp(8), dp(10), dp(10));

        informerCard = new LinearLayout(this);
        informerCard.setOrientation(LinearLayout.HORIZONTAL);
        informerCard.setGravity(Gravity.CENTER_VERTICAL);
        informerCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        informerCard.setMinimumHeight(dp(100));
        informerCard.setElevation(dp(1));
        informerIcon = label("✓", 30, true, Color.WHITE);
        informerIcon.setGravity(Gravity.CENTER);
        informerIcon.setBackground(rounded(GREEN, 46));
        informerCard.addView(informerIcon, new LinearLayout.LayoutParams(dp(58), dp(58)));
        informerText = label("Проверяю состояние...", 13, false, TEXT);
        informerText.setPadding(dp(10), 0, dp(5), 0);
        informerText.setLineSpacing(dp(1), 1.02f);
        informerCard.addView(informerText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        LinearLayout eventActions=new LinearLayout(this);eventActions.setOrientation(LinearLayout.VERTICAL);eventActions.setGravity(Gravity.CENTER);
        informerAll=label("Все  ›",8,true,MUTED);informerAll.setGravity(Gravity.CENTER);informerAll.setPadding(dp(5),dp(4),dp(5),dp(4));informerAll.setOnClickListener(v->showEventCenterDialog());eventActions.addView(informerAll);
        informerNext=label("Далее  ›",8,true,ACCENT);informerNext.setGravity(Gravity.CENTER);informerNext.setPadding(dp(5),dp(4),dp(5),dp(4));informerNext.setOnClickListener(v->dismissCurrentInformerEvent());eventActions.addView(informerNext);
        informerCard.addView(eventActions,new LinearLayout.LayoutParams(dp(62),ViewGroup.LayoutParams.WRAP_CONTENT));
        informerCard.setOnClickListener(v -> openCurrentInformerEvent());
        informerText.setOnClickListener(v -> openCurrentInformerEvent());
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ip.setMargins(0, 0, 0, dp(7));
        body.addView(informerCard, ip);

        body.addView(buildHomeStatsRow());

        LinearLayout launch = new LinearLayout(this);
        launch.setOrientation(LinearLayout.HORIZONTAL);
        homeQuickButton = flatButton(isAuditSessionActive() ? "▶  Открыть проверку" : "▶  Быстрая проверка", Color.rgb(0, 169, 190), Color.WHITE);
        homeQuickButton.setTextSize(12);
        homeQuickButton.setOnClickListener(v -> {
            if (isAuditSessionActive()) switchPage(PAGE_CHECK);
            else { switchPage(PAGE_CHECK); runAudit(AuditCoordinator.MODE_QUICK); }
        });
        Button journal = flatButton("▤  Открыть журнал", Color.WHITE, DARK);
        journal.setTextSize(12);
        GradientDrawable jbg = rounded(Color.WHITE, 11);
        jbg.setStroke(dp(1), Color.rgb(208,220,234));
        journal.setBackground(jbg);
        journal.setOnClickListener(v -> switchPage(PAGE_JOURNAL));
        LinearLayout.LayoutParams qa=new LinearLayout.LayoutParams(0,dp(44),1.24f); qa.setMargins(0,0,dp(4),0);
        LinearLayout.LayoutParams ja=new LinearLayout.LayoutParams(0,dp(44),1f); ja.setMargins(dp(4),0,0,0);
        launch.addView(homeQuickButton,qa); launch.addView(journal,ja);
        body.addView(launch);

        LinearLayout quickGrid = new LinearLayout(this);
        quickGrid.setOrientation(LinearLayout.VERTICAL);
        quickGrid.setPadding(0,dp(7),0,0);
        quickGrid.addView(homeActionRow(
                homeStatusAction(R.drawable.ic_closed_periods, "Контроль периодов", "Прошлые данные", closedPeriodsHomeStatus(), Color.rgb(245,69,112), v -> showClosedPeriods()),
                homeStatusAction(R.drawable.ic_clock, "Расписание проверок", "Быстрая и полная", scheduleHomeStatus(), Color.rgb(133,69,210), v -> showAutoStartSettings())));
        quickGrid.addView(homeActionRow(
                homeStatusAction(R.drawable.ic_backup, "Резервные копии", "Сохранение базы", backupHomeStatus(), Color.rgb(21,163,198), v -> showBackupPage(false)),
                homeStatusAction(R.drawable.ic_restore, "Восстановление", "Из резервной копии", "Выбрать копию", Color.rgb(95,116,150), v -> showBackupPage(true))));
        body.addView(quickGrid);

        LinearLayout histHead = new LinearLayout(this);
        histHead.setOrientation(LinearLayout.HORIZONTAL);
        histHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView histTitle = label("История проверок", 16, true, DARK);
        histHead.addView(histTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView all = label("Все проверки  ›", 10, false, MUTED);
        all.setGravity(Gravity.RIGHT);
        all.setPadding(dp(8), dp(4), dp(3), dp(4));
        GradientDrawable allBg=rounded(Color.WHITE, 14); allBg.setStroke(dp(1),Color.rgb(220,230,241)); all.setBackground(allBg);
        all.setOnClickListener(v -> showCheckHistoryDialog());
        histHead.addView(all);
        histHead.setPadding(dp(2), dp(7), dp(2), dp(5));
        body.addView(histHead);
        addRecentRunCards(body);

        refreshDashboardInformer();
        return pageScroll(body);
    }

    private void addRecentRunCards(LinearLayout body) {
        java.util.List<AuditDb.RunSummary> runs = db.recentRuns(3);
        if (runs == null || runs.isEmpty()) {
            LinearLayout empty = card();
            empty.setPadding(dp(10), dp(9), dp(10), dp(9));
            empty.addView(label("История пока пуста", 9, false, MUTED));
            body.addView(empty);
            return;
        }
        for (int i=0;i<runs.size();i++) {
            body.addView(recentRunRow(runs.get(i)), historyRowParams(i > 0));
        }
    }

    private LinearLayout.LayoutParams historyRowParams(boolean withTopMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        if (withTopMargin) p.setMargins(0, dp(4), 0, 0);
        return p;
    }

    private View recentRunRow(AuditDb.RunSummary run) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(7), dp(8));
        GradientDrawable bg = rounded(Color.WHITE, 11);
        bg.setStroke(dp(1), Color.rgb(229,235,242));
        row.setBackground(bg);
        row.setElevation(dp(1));
        row.setOnClickListener(v -> showRunDetails(run));

        TextView number = label("#" + run.id, 16, true, ACCENT);
        number.setGravity(Gravity.CENTER);
        number.setBackground(rounded(Color.rgb(232,249,247), 12));
        row.addView(number, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(9), 0, dp(4), 0);
        TextView l1 = label(homeRunTime(run.startedAt), 13, true, DARK);
        String status = run.recovery ? "Проверка после прерывания" : runStatusShort(run.status);
        TextView l2 = label(runDurationLine(status, run.durationMs), 11, false, MUTED);
        l2.setPadding(0, dp(1), 0, dp(2));
        texts.addView(l1);
        texts.addView(l2);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.setGravity(Gravity.CENTER_VERTICAL);
        int shownTotal = run.total > 0 ? run.total : db.transactionCount();
        TextView total = label("Всего: " + spacedNumber(shownTotal), 11, false, MUTED);
        applyBoldTail(total, "Всего: ");
        metrics.addView(total);
        metrics.addView(historyMetric(run.newCount, GREEN));
        metrics.addView(historyMetric(run.changedCount, YELLOW));
        metrics.addView(historyMetric(run.deletedCount, RED));
        texts.addView(metrics);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        ImageView arrow = new ImageView(this);
        arrow.setImageResource(R.drawable.ic_chevron_right);
        arrow.setColorFilter(Color.rgb(93,112,145));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(18), dp(18)));
        return row;
    }

    private View historyMetric(int value, int accent) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setPadding(dp(7),0,0,0);
        TextView dot=label("●",13,true,accent);
        TextView valueView=label(String.valueOf(value),11,false,MUTED);
        valueView.setPadding(dp(2),0,0,0);
        chip.addView(dot); chip.addView(valueView);
        return chip;
    }

    private String runDurationLine(String status, long durationMs) {
        if (durationMs <= 0) return status;
        return status + "  •  " + TimeUtil.duration(durationMs);
    }

    private String homeRunTime(String iso) {
        long ms=TimeUtil.parseDateTimeMillis(iso);
        if(ms<=0)return TimeUtil.displayDateTime(iso);
        java.text.SimpleDateFormat dateFmt=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.getDefault());
        java.text.SimpleDateFormat timeFmt=new java.text.SimpleDateFormat("HH:mm",Locale.getDefault());
        String d=dateFmt.format(new java.util.Date(ms));
        java.util.Calendar cal=java.util.Calendar.getInstance();
        String today=dateFmt.format(cal.getTime());
        cal.add(java.util.Calendar.DAY_OF_YEAR,-1);
        String yesterday=dateFmt.format(cal.getTime());
        String prefix=d.equals(today)?"Сегодня":d.equals(yesterday)?"Вчера":new java.text.SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new java.util.Date(ms));
        return prefix+", "+timeFmt.format(new java.util.Date(ms));
    }

    private String runStatusShort(String status) {
        if("RUNNING".equals(status))return "Выполняется";
        if("STOPPED".equals(status))return "Остановлено";
        if("ERROR".equals(status))return "Ошибка";
        return "Завершено";
    }

    private String spacedNumber(int value) {
        return String.format(Locale.US,"%,d",Math.max(0,value)).replace(',', ' ');
    }

    private void applyBoldTail(TextView v,String prefix){
        CharSequence raw=v.getText();
        SpannableStringBuilder sp=new SpannableStringBuilder(raw);
        int start=Math.min(prefix.length(),sp.length());
        sp.setSpan(new StyleSpan(Typeface.BOLD),start,sp.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new ForegroundColorSpan(DARK),start,sp.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        v.setText(sp);
    }

    private View buildHomeStatsRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 0, 0, dp(7));
        newTop = statCard("●", String.valueOf(parseIntState("last_check_new")), "Новые", GREEN);
        changedTop = statCard("●", String.valueOf(parseIntState("last_check_changed")), "Изменённые", YELLOW);
        deletedTop = statCard("●", String.valueOf(parseIntState("last_check_deleted")), "Удалённые", RED);
        LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(0,dp(49),1); p1.setMargins(dp(1),0,dp(3),0);
        LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(0,dp(49),1); p2.setMargins(dp(3),0,dp(3),0);
        LinearLayout.LayoutParams p3=new LinearLayout.LayoutParams(0,dp(49),1); p3.setMargins(dp(3),0,dp(1),0);
        row.addView(newTop,p1); row.addView(changedTop,p2); row.addView(deletedTop,p3);
        return row;
    }

    private View buildHomeCheckActions() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button quick=flatButton("▶  Быстрая проверка", Color.rgb(0,169,190), Color.WHITE);
        quick.setOnClickListener(v->{switchPage(PAGE_CHECK); runAudit(AuditCoordinator.MODE_QUICK);});
        Button full=flatButton("Полная проверка", Color.WHITE, TEXT);
        GradientDrawable bg=rounded(Color.WHITE,12); bg.setStroke(dp(1),Color.rgb(216,225,235)); full.setBackground(bg);
        full.setOnClickListener(v->{switchPage(PAGE_CHECK); runAudit(AuditCoordinator.MODE_FULL);});
        row.addView(quick,new LinearLayout.LayoutParams(0,dp(48),1)); row.addView(full,new LinearLayout.LayoutParams(0,dp(48),1));
        return row;
    }

    private String currentCheckLabel() {
        String mode = isAuditSessionActive() ? AuditSessionStore.snapshot(this).mode : activeCheckMode;
        if ("FULL_AFTER_LIGHT".equals(mode)) return "Быстрая → полная проверка";
        return AuditCoordinator.MODE_FULL.equals(mode) ? "Полная проверка" : "Быстрая проверка";
    }

    private void refreshCheckModeUi() {
        String label = currentCheckLabel();
        boolean running = isAuditSessionActive();
        AuditControl c = AuditControlRegistry.current();
        AuditSessionStore.Snapshot liveState = AuditSessionStore.snapshot(this);
        boolean paused = AuditSessionStore.PAUSED.equals(liveState.status) || (c != null && c.isPaused());
        boolean finalizing = running && currentStageForUi != null &&
                (currentStageForUi.startsWith("BACKUP") || "SAVING".equals(currentStageForUi) || "CREATING_REPORT".equals(currentStageForUi));
        boolean completed = "COMPLETED".equals(currentStageForUi);
        if (checkBannerTitle != null) {
            if (running) checkBannerTitle.setText(paused ? "На паузе" : (finalizing ? "Завершение проверки" : (completed ? "Проверка завершена" : "Выполняется " + label.toLowerCase(Locale.ROOT))));
            else checkBannerTitle.setText(completed ? "Проверка завершена" : "Готово к проверке");
        }
        if (checkBannerSubtitle != null) {
            if (!running) checkBannerSubtitle.setText(completed ? "Результат сохранён • можно запустить новую проверку" : "Выберите быструю или полную проверку");
            else if (paused) checkBannerSubtitle.setText(label + " приостановлена • продолжение с текущего места");
            else if (finalizing) checkBannerSubtitle.setText("Сохраняю результат и резервную копию • дождитесь 100%");
            else if (completed) checkBannerSubtitle.setText("Результат проверки сохранён");
            else checkBannerSubtitle.setText("Режим: " + label + " • проверка завершённых периодов");
        }
        if (checkModePill != null) {
            boolean full = label.toLowerCase(Locale.ROOT).contains("полная");
            if (paused) {
                checkModePill.setText("ПАУЗА");
                checkModePill.setTextColor(Color.rgb(183,122,0));
                checkModePill.setBackground(rounded(Color.rgb(255,246,220), 10));
            } else {
                checkModePill.setText(full ? "ПОЛНАЯ" : "БЫСТРАЯ");
                checkModePill.setTextColor(full ? PURPLE : BLUE);
                checkModePill.setBackground(rounded(full ? Color.rgb(245,238,255) : Color.rgb(235,245,255), 10));
            }
            checkModePill.setVisibility(running ? View.VISIBLE : View.GONE);
        }
    }

    private String percentLabel(int percent) {
        AuditControl c = AuditControlRegistry.current();
        boolean paused = AuditSessionStore.PAUSED.equals(AuditSessionStore.snapshot(this).status) || (c != null && c.isPaused());
        return paused ? ("На паузе " + Math.max(0, percent) + "%") : (Math.max(0, percent) + "%");
    }

    private int stageIndexForUi(String stage) {
        String st = stage == null ? "" : stage;
        if (st.contains("COMPLETED")) return 8;
        if (st.contains("BACKUP") || st.contains("REPORT")) return 7;
        if (st.contains("SAVING")) return 6;
        if (st.contains("HISTORY") || st.contains("CONTROL") || st.contains("LIGHT")) return 5;
        if (st.contains("PROCESS") || st.contains("COMPAR")) return 4;
        if (st.contains("READ") || st.contains("LOAD") || st.contains("STABILITY") || st.contains("DEEP")) return 3;
        if (st.contains("RANGE") || st.contains("META")) return 2;
        if (st.contains("AUTH") || st.contains("TEAM") || st.contains("START") || st.contains("PREPAR")) return 1;
        return 0;
    }

    private String stableStageForUi(String candidate) {
        String st = candidate == null ? "" : candidate;
        if ((st.isEmpty() || "IDLE".equals(st)) && !isAuditSessionActive()) {
            maxStageIndexShown = 0;
            currentStageForUi = "IDLE";
            return currentStageForUi;
        }
        if (st.contains("ERROR") || st.contains("PERMANENT")) {
            currentStageForUi = st;
            return currentStageForUi;
        }
        int idx = stageIndexForUi(st);
        if (idx > 0 && idx >= maxStageIndexShown) {
            maxStageIndexShown = idx;
            currentStageForUi = st;
        }
        return currentStageForUi;
    }

    private String progressFallbackText(AuditForegroundService.Snapshot s) {
        String stage = s == null || s.stage == null ? "" : s.stage;
        if (stage.contains("CONNECT") || stage.contains("AUTH") || stage.contains("PREPAR")) return "Подключение к Cubux";
        if (stage.contains("PERIOD")) return "Получение списка периодов";
        if (stage.contains("READ") || stage.contains("LOAD")) return "Загрузка данных";
        return "Подготовка данных";
    }

    private void refreshHomeQuickButton() {
        if (homeQuickButton == null) return;
        boolean running = isAuditSessionActive();
        homeQuickButton.setText(running ? "▶  Открыть проверку" : "▶  Быстрая проверка");
    }

    private View buildCheckPage() {
        LinearLayout body = pageBody();
        body.setPadding(dp(8), dp(5), dp(8), dp(5));
        body.addView(buildCheckBanner());
        body.addView(buildAuditPanel(), topMargin(5));
        // Keep the legacy result target for internal messages, but the visible result
        // is now shown in the compact "Текущий этап" card inside the audit panel.
        resultText = label(db.getState("last_check_message") == null ? "" : db.getState("last_check_message"), 1, false, MUTED);
        resultText.setVisibility(View.GONE);
        body.addView(resultText, new LinearLayout.LayoutParams(1,1));
        return body;
    }

    private LinearLayout.LayoutParams topMargin(int marginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(marginDp), 0, 0);
        return p;
    }

    private View buildCheckBanner() {
        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.HORIZONTAL);
        banner.setGravity(Gravity.CENTER_VERTICAL);
        banner.setPadding(dp(7), dp(5), dp(7), dp(5));
        GradientDrawable bg = rounded(Color.WHITE, 11);
        bg.setStroke(dp(1), Color.rgb(229,235,242));
        banner.setBackground(bg);

        TextView icon = label("◎", 15, true, Color.WHITE);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(rounded(Color.rgb(45,145,245), 18));
        banner.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));

        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setPadding(dp(8), 0, 0, 0);
        checkBannerTitle = label("Готово к проверке", 13, true, DARK);
        checkBannerSubtitle = label("Выберите быструю или полную проверку", 10, false, MUTED);
        checkBannerSubtitle.setPadding(0, dp(1), 0, 0);
        text.addView(checkBannerTitle);
        text.addView(checkBannerSubtitle);
        banner.addView(text, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        checkModePill = label("БЫСТРАЯ", 8, true, BLUE);
        checkModePill.setGravity(Gravity.CENTER);
        checkModePill.setPadding(dp(6), dp(3), dp(6), dp(3));
        checkModePill.setBackground(rounded(Color.rgb(235, 245, 255), 10));
        banner.addView(checkModePill);
        refreshCheckModeUi();
        return banner;
    }

    private View buildStageCard() {
        LinearLayout c = card();
        c.setPadding(dp(10), dp(8), dp(10), dp(8));
        TextView stagesTitle = label("Текущий этап проверки", 9, true, DARK);
        c.addView(stagesTitle);
        c.addView(buildStageChecklist());
        updateStageIndicators(currentStageForUi);
        return c;
    }

    private View buildBankPage() {
        LinearLayout body = pageBody();
        body.addView(pageTitle("Проверка банковской выписки",
                "Загрузите файл выписки из банка. Система найдёт операции и сравнит их с Cubux"));
        LinearLayout c=card();
        c.setPadding(dp(10),dp(8),dp(10),dp(8));
        c.addView(processRow("1", "Выберите файл выписки", "Загрузите файл из банка в одном из поддерживаемых форматов"));
        c.addView(processRow("2", "Сканирование операций", "Система прочитает дату, сумму и описание"));
        c.addView(processRow("3", "Сравнение с Cubux", "Найдём совпадения, расхождения и спорные операции"));
        Button choose=flatButton("▣  Выбрать файл выписки", Color.rgb(22,126,235), Color.WHITE);
        choose.setOnClickListener(v->showBankDialog());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(42));
        cp.setMargins(0,dp(7),0,0); c.addView(choose,cp);
        TextView formats=label("Поддерживаемые форматы:  PDF, CSV, XLS, XLSX, OFX",8,false,MUTED);
        formats.setPadding(0,dp(5),0,0); c.addView(formats);
        body.addView(c);

        TextView lt=label("Последняя сверка",13,true,DARK);
        lt.setPadding(dp(2),dp(8),dp(2),dp(5)); body.addView(lt);
        LinearLayout sum=card();
        sum.setPadding(dp(10),dp(9),dp(10),dp(9));
        TextView summary=label(db.bankSummary(),9,false,TEXT);
        summary.setLineSpacing(dp(1),0.95f); sum.addView(summary);
        sum.setOnClickListener(v->showBankDialog()); body.addView(sum);
        return pageScroll(body);
    }

    private static final class ReportPeriod {
        final String from,to,label;
        ReportPeriod(String from,String to,String label){this.from=from;this.to=to;this.label=label;}
    }

    private String iso(java.util.Calendar c){return new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    private ReportPeriod reportPeriod(){
        java.util.Calendar a=(java.util.Calendar)reportAnchor.clone();
        java.text.SimpleDateFormat monthName=new java.text.SimpleDateFormat("LLLL yyyy",Locale.getDefault());
        if("DAY".equals(reportMode)){
            String d=iso(a); return new ReportPeriod(d,d,new java.text.SimpleDateFormat("dd MMMM yyyy",Locale.getDefault()).format(a.getTime()));
        }
        if("WEEK".equals(reportMode)){
            int dow=a.get(java.util.Calendar.DAY_OF_WEEK);int delta=dow==java.util.Calendar.SUNDAY?-6:java.util.Calendar.MONDAY-dow;
            a.add(java.util.Calendar.DAY_OF_MONTH,delta);java.util.Calendar b=(java.util.Calendar)a.clone();b.add(java.util.Calendar.DAY_OF_MONTH,6);
            String label=new java.text.SimpleDateFormat("dd.MM",Locale.getDefault()).format(a.getTime())+" — "+new java.text.SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(b.getTime());
            return new ReportPeriod(iso(a),iso(b),label);
        }
        if("YEAR".equals(reportMode)){
            int y=a.get(java.util.Calendar.YEAR);return new ReportPeriod(y+"-01-01",y+"-12-31",String.valueOf(y));
        }
        a.set(java.util.Calendar.DAY_OF_MONTH,1);java.util.Calendar b=(java.util.Calendar)a.clone();b.add(java.util.Calendar.MONTH,1);b.add(java.util.Calendar.DAY_OF_MONTH,-1);
        return new ReportPeriod(iso(a),iso(b),monthName.format(a.getTime()));
    }
    private void setReportMode(String mode){reportMode=mode;reportTypeFilter="ALL";reportAnchor.setTimeInMillis(System.currentTimeMillis());switchPage(PAGE_REPORTS);}
    private void shiftReportPeriod(int dir){if("DAY".equals(reportMode))reportAnchor.add(java.util.Calendar.DAY_OF_MONTH,dir);else if("WEEK".equals(reportMode))reportAnchor.add(java.util.Calendar.DAY_OF_MONTH,7*dir);else if("YEAR".equals(reportMode))reportAnchor.add(java.util.Calendar.YEAR,dir);else reportAnchor.add(java.util.Calendar.MONTH,dir);switchPage(PAGE_REPORTS);}

    private View buildReportsPage() {
        dayScanLiveText=null;
        dayScanProgressBar=null;
        dayScanButton=null;
        LinearLayout body=pageBody();
        body.addView(pageTitle("Контроль дня", "Наблюдение за сегодняшними записями Cubux"));

        LinearLayout note=card();note.setOrientation(LinearLayout.HORIZONTAL);note.setGravity(Gravity.CENTER_VERTICAL);note.setPadding(dp(9),dp(7),dp(9),dp(7));
        TextView ni=label("i",11,true,ACCENT);ni.setGravity(Gravity.CENTER);ni.setBackground(rounded(Color.rgb(229,246,252),20));note.addView(ni,new LinearLayout.LayoutParams(dp(28),dp(28)));
        TextView nt=label("Не влияет на основную проверку и эталонную базу",9,false,MUTED);nt.setPadding(dp(8),0,0,0);note.addView(nt,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));body.addView(note);

        String selected=iso(dayAnchor);boolean today=TimeUtil.today().equals(selected);
        LinearLayout dateRow=new LinearLayout(this);dateRow.setOrientation(LinearLayout.HORIZONTAL);dateRow.setGravity(Gravity.CENTER_VERTICAL);dateRow.setPadding(0,dp(7),0,dp(5));
        TextView prev=label("‹",20,true,Color.rgb(64,101,151));prev.setGravity(Gravity.CENTER);prev.setBackground(rounded(Color.WHITE,22));prev.setOnClickListener(v->shiftDayControl(-1));dateRow.addView(prev,new LinearLayout.LayoutParams(dp(38),dp(38)));
        String dateLabel=new java.text.SimpleDateFormat("dd MMMM yyyy",new Locale("ru","RU")).format(dayAnchor.getTime());
        TextView dt=label(dateLabel,14,true,DARK);dt.setGravity(Gravity.CENTER);dateRow.addView(dt,new LinearLayout.LayoutParams(0,dp(38),1));
        TextView next=label("›",20,true,today?Color.rgb(190,200,213):Color.rgb(64,101,151));next.setGravity(Gravity.CENTER);next.setBackground(rounded(Color.WHITE,22));next.setEnabled(!today);next.setOnClickListener(v->shiftDayControl(1));dateRow.addView(next,new LinearLayout.LayoutParams(dp(38),dp(38)));body.addView(dateRow);

        AuditDb.DaySummary summary=db.daySummary(selected);
        if(today) dayLastRenderedScan=summary.lastScan==null?"":summary.lastScan;
        LinearLayout scan=card();scan.setPadding(dp(11),dp(9),dp(11),dp(9));
        scan.addView(label(today?"Сегодняшний контроль":"Журнал за выбранный день",12,true,DARK));
        String last=(summary.lastScan==null||summary.lastScan.trim().isEmpty())?"Ещё не выполнялся":displayClock(summary.lastScan);
        StringBuilder scanText=new StringBuilder();scanText.append("Последний скан: ").append(last);
        if("ERROR".equals(summary.status))scanText.append("  •  ошибка");
        else if(summary.lastScan!=null&&!summary.lastScan.trim().isEmpty())scanText.append("  •  успешно");
        if(today){scanText.append("\nСледующий: ").append(nextDayControlTime());scanText.append("  •  Финальный: 23:59");}
        TextView scanInfo=label(scanText.toString(),10,false,MUTED);scanInfo.setLineSpacing(dp(2),1f);scanInfo.setPadding(0,dp(5),0,0);scan.addView(scanInfo);

        if(today){
            DayControlService.Snapshot ds=DayControlService.snapshot();
            dayScanWasRunning=ds.running;
            dayScanLiveText=label(dayControlStatusLine(ds,summary),10,true,ds.running?ACCENT:("ERROR".equals(summary.status)?RED:MUTED));
            dayScanLiveText.setPadding(0,dp(5),0,dp(3));
            scan.addView(dayScanLiveText);
            dayScanProgressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
            dayScanProgressBar.setMax(100);
            dayScanProgressBar.setProgress(ds.running?Math.max(2,ds.percent):0);
            dayScanProgressBar.setVisibility(ds.running?View.VISIBLE:View.GONE);
            scan.addView(dayScanProgressBar,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(4)));
            String buttonText=ds.running?"Сканирование…":("ERROR".equals(summary.status)?"Повторить":"Проверить сейчас");
            dayScanButton=flatButton(buttonText,Color.WHITE,ACCENT);
            GradientDrawable nbg=rounded(Color.WHITE,10);nbg.setStroke(dp(1),Color.rgb(190,229,240));dayScanButton.setBackground(nbg);
            dayScanButton.setEnabled(!ds.running);
            dayScanButton.setOnClickListener(v->{
                if(DayControlService.isRunning())return;
                DayControlService.startNow(this);
                if(dayScanButton!=null){dayScanButton.setText("Сканирование…");dayScanButton.setEnabled(false);}
                if(dayScanLiveText!=null){dayScanLiveText.setText("Сканирование… Подключение к Cubux");dayScanLiveText.setTextColor(ACCENT);}
                if(dayScanProgressBar!=null){dayScanProgressBar.setProgress(2);dayScanProgressBar.setVisibility(View.VISIBLE);}
            });
            LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38));np.setMargins(0,dp(6),0,0);scan.addView(dayScanButton,np);
        }
        body.addView(scan);

        LinearLayout metrics1=new LinearLayout(this);metrics1.setOrientation(LinearLayout.HORIZONTAL);metrics1.setPadding(0,dp(7),0,0);
        metrics1.addView(dayFinancialCard(summary),weightWithGap(false));
        metrics1.addView(dayMetricCard("+","Новые",summary.newCount,GREEN),weightWithGap(true));body.addView(metrics1);
        LinearLayout metrics2=new LinearLayout(this);metrics2.setOrientation(LinearLayout.HORIZONTAL);metrics2.setPadding(0,dp(6),0,0);
        metrics2.addView(dayMetricCard("!","Изменённые",summary.changedCount,YELLOW),weightWithGap(false));
        metrics2.addView(dayMetricCard("−","Удалённые",summary.deletedCount,RED),weightWithGap(true));body.addView(metrics2);

        TextView hist=label("История изменений",15,true,DARK);hist.setPadding(dp(2),dp(10),0,dp(4));body.addView(hist);
        LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);String[] fn={"Все","Новые","Изменённые","Удалённые"};String[] fv={"ALL","NEW","CHANGED","DELETED"};
        for(int i=0;i<fn.length;i++){final String f=fv[i];boolean active=f.equals(dayEventTypeFilter);TextView b=label(fn[i],9,active,active?Color.WHITE:MUTED);b.setGravity(Gravity.CENTER);GradientDrawable bg=rounded(active?ACCENT:Color.WHITE,10);bg.setStroke(dp(1),active?ACCENT:Color.rgb(222,231,241));b.setBackground(bg);b.setOnClickListener(v->{dayEventTypeFilter=f;switchPage(PAGE_REPORTS);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(31),1);lp.setMargins(i==0?0:dp(2),0,0,0);filters.addView(b,lp);}body.addView(filters);

        java.util.List<AuditDb.DayEvent> events=db.dayEvents(selected,dayEventTypeFilter,200);
        if(events.isEmpty()){LinearLayout empty=card();empty.setPadding(dp(12),dp(20),dp(12),dp(20));TextView e=label("За этот день изменений пока нет",11,false,MUTED);e.setGravity(Gravity.CENTER);empty.addView(e);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);ep.setMargins(0,dp(7),0,0);body.addView(empty,ep);}else{for(AuditDb.DayEvent e:events){View r=dayEventRow(e);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.setMargins(0,dp(5),0,0);body.addView(r,rp);}}
        return pageScroll(body);
    }

    private void syncDayControlUi(){
        if(dayScanLiveText==null||dayScanButton==null||dayScanProgressBar==null)return;
        DayControlService.Snapshot snap=DayControlService.snapshot();
        AuditDb.DaySummary summary=db.daySummary(TimeUtil.today());
        String last=summary.lastScan==null?"":summary.lastScan;
        boolean completedNow=dayScanWasRunning&&!snap.running;
        boolean resultChanged=!last.equals(dayLastRenderedScan);
        if(!snap.running&&(completedNow||resultChanged)&&currentPage==PAGE_REPORTS){
            dayScanWasRunning=false;
            dayLastRenderedScan=last;
            switchPage(PAGE_REPORTS);
            return;
        }
        dayScanWasRunning=snap.running;
        dayScanLiveText.setText(dayControlStatusLine(snap,summary));
        dayScanLiveText.setTextColor(snap.running?ACCENT:("ERROR".equals(summary.status)?RED:MUTED));
        dayScanProgressBar.setVisibility(snap.running?View.VISIBLE:View.GONE);
        if(snap.running)dayScanProgressBar.setProgress(Math.max(2,Math.min(100,snap.percent)));
        dayScanButton.setEnabled(!snap.running);
        dayScanButton.setText(snap.running?"Сканирование…":("ERROR".equals(summary.status)?"Повторить":"Проверить сейчас"));
    }
    private String dayControlStatusLine(DayControlService.Snapshot s,AuditDb.DaySummary summary){
        if(s!=null&&s.running){long sec=Math.max(0,(System.currentTimeMillis()-s.startedMs)/1000L);String note=s.note==null||s.note.trim().isEmpty()?"Подключение к Cubux":s.note;return "Сканирование…  "+note+"  •  "+sec+" сек";}
        if(summary!=null&&"ERROR".equals(summary.status)){String e=db.getState("day_control_last_error");return "● Не удалось загрузить данные"+(e==null||e.trim().isEmpty()?"":"  •  "+friendlyDayError(e));}
        if(summary!=null&&summary.lastScan!=null&&!summary.lastScan.trim().isEmpty())return "Готово  •  данные обновлены";
        return "Готов к сканированию";
    }
    private String friendlyDayError(String e){String x=e==null?"":e.trim();String l=x.toLowerCase(Locale.ROOT);if(l.contains("internet")||l.contains("интернет")||l.contains("network"))return "нет интернета";if(l.contains("401")||l.contains("авторизац")||l.contains("логин")||l.contains("парол"))return "ошибка входа в Cubux";if(l.contains("timeout")||l.contains("не отвечает")||l.contains("http 500")||l.contains("http 502")||l.contains("http 503")||l.contains("http 504"))return "Cubux не отвечает";if(x.length()>42)x=x.substring(0,42)+"…";return x;}

    private void shiftDayControl(int dir){dayAnchor.add(java.util.Calendar.DAY_OF_MONTH,dir);String today=TimeUtil.today();if(iso(dayAnchor).compareTo(today)>0){try{dayAnchor.setTime(new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(today));}catch(Exception ignored){dayAnchor.setTimeInMillis(System.currentTimeMillis());}}dayEventTypeFilter="ALL";switchPage(PAGE_REPORTS);}
    private String displayClock(String iso){String x=TimeUtil.displayDateTime(iso);int p=x.indexOf(' ');return p>=0&&x.length()>=p+6?x.substring(p+1,Math.min(x.length(),p+6)):x;}
    private String nextDayControlTime(){try{long ms=Long.parseLong(String.valueOf(db.getState("day_control_next_ms")));if(ms>0)return new java.text.SimpleDateFormat("HH:mm",Locale.US).format(new java.util.Date(ms));}catch(Exception ignored){}DayControlScheduler.Next n=DayControlScheduler.calculateNext(System.currentTimeMillis());return new java.text.SimpleDateFormat("HH:mm",Locale.US).format(new java.util.Date(n.whenMs));}
    private View dayFinancialCard(AuditDb.DaySummary summary){
        LinearLayout c=card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(dp(8),dp(7),dp(8),dp(7));
        TextView icon=label("▤",13,true,Color.WHITE);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(rounded(BLUE,30));
        c.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout tx=new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(dp(8),0,0,0);
        tx.addView(label("Доход:  "+moneyRub(summary.incomeTotal),10,true,GREEN));
        tx.addView(label("Расход:  "+moneyRub(summary.expenseTotal),10,true,RED));
        tx.addView(label("Записей:  "+summary.total,10,true,DARK));
        c.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        return c;
    }

    private String moneyRub(double value){
        java.text.DecimalFormat f=new java.text.DecimalFormat("#,##0.##");
        return f.format(Math.abs(value)).replace(',', ' ')+" ₽";
    }

    private View dayMetricCard(String icon,String title,int value,int accent){LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(dp(9),dp(8),dp(9),dp(8));TextView i=label(icon,15,true,Color.WHITE);i.setGravity(Gravity.CENTER);i.setBackground(rounded(accent,30));c.addView(i,new LinearLayout.LayoutParams(dp(38),dp(38)));LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.setPadding(dp(8),0,0,0);t.addView(label(title,10,false,MUTED));t.addView(label(String.valueOf(value),16,true,DARK));c.addView(t);return c;}
    private View dayEventRow(AuditDb.DayEvent x){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(7),dp(7));GradientDrawable bg=rounded(Color.WHITE,11);bg.setStroke(dp(1),Color.rgb(229,235,242));row.setBackground(bg);int accent=changeAccent(x.eventType);TextView time=label(displayClock(x.detectedAt),10,true,Color.rgb(37,104,157));time.setGravity(Gravity.CENTER);time.setBackground(rounded(Color.rgb(233,246,255),9));row.addView(time,new LinearLayout.LayoutParams(dp(54),dp(38)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(8),0,dp(5),0);tx.addView(label(db.dayEventOperationType(x)+"  •  "+db.dayEventAmountSummary(x),11,true,DARK));TextView title=label(db.dayEventTitle(x),9,false,MUTED);title.setMaxLines(1);tx.addView(title);row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));row.addView(tinyBadge(changeTypeLabel(x.eventType),accent,Color.argb(22,Color.red(accent),Color.green(accent),Color.blue(accent))));ImageView arrow=new ImageView(this);arrow.setImageResource(R.drawable.ic_chevron_right);arrow.setColorFilter(Color.rgb(93,112,145));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(16),dp(16));ap.setMargins(dp(5),0,0,0);row.addView(arrow,ap);row.setOnClickListener(v->showDayEventDetails(x));return row;}
    private void showDayEventDetails(AuditDb.DayEvent x){ScrollView scroll=new ScrollView(this);TextView text=label(db.dayEventDetails(x),12,false,TEXT);text.setPadding(dp(16),dp(10),dp(16),dp(18));text.setLineSpacing(dp(2),1f);scroll.addView(text);new AlertDialog.Builder(this).setTitle(changeTypeLabel(x.eventType)+" запись").setView(scroll).setPositiveButton("Закрыть",null).show();}

    private LinearLayout.LayoutParams weightWithGap(boolean leftGap){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);lp.setMargins(leftGap?dp(3):0,0,leftGap?0:dp(3),0);return lp;}
    private View reportMetricCard(String icon,String title,int value,int accent){LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(dp(9),dp(8),dp(9),dp(8));TextView i=label(icon,14,true,accent);i.setGravity(Gravity.CENTER);i.setBackground(rounded(Color.argb(22,Color.red(accent),Color.green(accent),Color.blue(accent)),10));c.addView(i,new LinearLayout.LayoutParams(dp(38),dp(38)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(8),0,0,0);tx.addView(label(title,11,true,DARK));tx.addView(label(String.valueOf(value)+"  за период",15,true,DARK));c.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));return c;}
    private View statInfoRow(String icon,String title,String value){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(0,dp(6),0,dp(6));TextView ic=label(icon,12,true,Color.rgb(88,112,150));ic.setGravity(Gravity.CENTER);r.addView(ic,new LinearLayout.LayoutParams(dp(30),dp(30)));TextView t=label(title,10,false,MUTED);t.setPadding(dp(5),0,0,0);r.addView(t,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));TextView v=label(value,10,true,DARK);v.setGravity(Gravity.RIGHT);r.addView(v);return r;}

    private View buildJournalPage() {
        LinearLayout body=pageBody();
        body.addView(pageTitle("Журнал изменений", "Что требует внимания и что уже решено"));
        int unresolved=db.unresolvedChangeCount();
        LinearLayout resolution=new LinearLayout(this);resolution.setOrientation(LinearLayout.HORIZONTAL);resolution.setPadding(dp(2),dp(2),dp(2),dp(2));resolution.setBackground(rounded(Color.WHITE,12));
        String[] rn={"Требует решения"+(unresolved>0?"  "+unresolved:""),"Решено"};String[] rv={"OPEN","RESOLVED"};
        for(int i=0;i<2;i++){final String f=rv[i];boolean active=f.equals(journalResolutionFilter);TextView b=label(rn[i],10,active,active?Color.WHITE:MUTED);b.setGravity(Gravity.CENTER);if(active)b.setBackground(rounded(ACCENT,10));b.setOnClickListener(v->{journalResolutionFilter=f;switchPage(PAGE_JOURNAL);});resolution.addView(b,new LinearLayout.LayoutParams(0,dp(34),1));}body.addView(resolution);

        LinearLayout types=new LinearLayout(this);types.setOrientation(LinearLayout.HORIZONTAL);types.setPadding(0,dp(6),0,0);String[] tn={"Все","Новые","Изменённые","Удалённые"};String[] tv={"ALL","NEW","CHANGED","DELETED"};
        for(int i=0;i<tn.length;i++){final String f=tv[i];boolean active=f.equals(journalTypeFilter);TextView b=label(tn[i],9,active,active?Color.WHITE:MUTED);b.setGravity(Gravity.CENTER);GradientDrawable bg=rounded(active?GREEN:Color.WHITE,10);bg.setStroke(dp(1),active?GREEN:Color.rgb(222,231,241));b.setBackground(bg);b.setOnClickListener(v->{journalTypeFilter=f;switchPage(PAGE_JOURNAL);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(30),1);lp.setMargins(i==0?0:dp(2),0,0,0);types.addView(b,lp);}body.addView(types);

        EditText search=new EditText(this);search.setHint("Поиск по описанию, сумме, дате...");search.setText(journalQuery);search.setTextSize(11);search.setSingleLine(true);search.setPadding(dp(10),0,dp(10),0);search.setBackground(rounded(Color.WHITE,11));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38));sp.setMargins(0,dp(6),0,dp(6));body.addView(search,sp);search.setOnEditorActionListener((v,a,e)->{journalQuery=search.getText().toString().trim();switchPage(PAGE_JOURNAL);return true;});

        java.util.List<AuditDb.ChangeItem> items=db.changeItems(journalResolutionFilter,journalTypeFilter,journalQuery,120,0);
        if(items.isEmpty()){LinearLayout empty=card();empty.setPadding(dp(12),dp(20),dp(12),dp(20));TextView t=label("Здесь пока ничего нет",12,true,DARK);t.setGravity(Gravity.CENTER);empty.addView(t);TextView sub=label("Новые найденные изменения появятся автоматически",10,false,MUTED);sub.setGravity(Gravity.CENTER);sub.setPadding(0,dp(3),0,0);empty.addView(sub);body.addView(empty);}else{for(AuditDb.ChangeItem item:items){body.addView(changeRow(item),historyRowParams(true));}}
        return pageScroll(body);
    }

    private String changeTypeLabel(String type){if("NEW".equals(type))return "Новая";if("CHANGED".equals(type))return "Изменённая";if("DELETED".equals(type))return "Удалённая";return type;}
    private int changeAccent(String type){if("NEW".equals(type))return GREEN;if("CHANGED".equals(type))return YELLOW;return RED;}
    private View tinyBadge(String text,int fg,int bg){TextView t=label(text,8,true,fg);t.setGravity(Gravity.CENTER);t.setPadding(dp(7),dp(3),dp(7),dp(3));t.setBackground(rounded(bg,12));return t;}
    private View changeRow(AuditDb.ChangeItem x){
        boolean test=db.isTestChange(x);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(7),dp(7));
        GradientDrawable bg=rounded(test?Color.rgb(235,249,242):Color.WHITE,11);bg.setStroke(dp(1),test?GREEN:Color.rgb(229,235,242));row.setBackground(bg);row.setElevation(dp(1));
        int accent=test?GREEN:changeAccent(x.changeType);TextView icon=label(test?"T":("DELETED".equals(x.changeType)?"−":"CHANGED".equals(x.changeType)?"!":"+"),13,true,Color.WHITE);icon.setGravity(Gravity.CENTER);icon.setBackground(rounded(accent,30));row.addView(icon,new LinearLayout.LayoutParams(dp(28),dp(28)));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(8),0,dp(5),0);String date=x.operationDate==null||x.operationDate.isEmpty()?TimeUtil.displayDateTime(x.detectedAt):x.operationDate;tx.addView(label(date,9,false,MUTED));tx.addView(label(db.changeTitle(x),11,true,DARK));TextView meta=label(db.changeOperationType(x)+"   •   "+db.changeAmountSummary(x),10,false,TEXT);meta.setPadding(0,dp(2),0,0);tx.addView(meta);row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setGravity(Gravity.RIGHT);right.addView(tinyBadge(test?"ТЕСТ":changeTypeLabel(x.changeType),test?GREEN:accent,test?Color.rgb(217,247,231):Color.argb(22,Color.red(accent),Color.green(accent),Color.blue(accent))));TextView res=(TextView)tinyBadge("RESOLVED".equals(x.resolutionStatus)?"✓ Решено":"Требует решения","RESOLVED".equals(x.resolutionStatus)?GREEN:RED,"RESOLVED".equals(x.resolutionStatus)?Color.rgb(235,249,242):Color.rgb(255,240,242));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.setMargins(0,dp(4),0,0);right.addView(res,rp);row.addView(right);
        ImageView arrow=new ImageView(this);arrow.setImageResource(R.drawable.ic_chevron_right);arrow.setColorFilter(Color.rgb(93,112,145));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(16),dp(16));ap.setMargins(dp(5),0,0,0);row.addView(arrow,ap);row.setOnClickListener(v->showChangeDetails(x));return row;
    }

    private void showChangeDetails(AuditDb.ChangeItem x){
        boolean test=db.isTestChange(x);
        LinearLayout body=pageBody();TextView back=label("‹  Детали изменения",15,true,DARK);back.setPadding(dp(1),dp(3),0,dp(8));back.setOnClickListener(v->switchPage(PAGE_JOURNAL));body.addView(back);
        int accent=test?GREEN:changeAccent(x.changeType);LinearLayout state=card();state.setOrientation(LinearLayout.HORIZONTAL);state.setGravity(Gravity.CENTER_VERTICAL);state.setPadding(dp(10),dp(9),dp(10),dp(9));if(test){GradientDrawable sb=rounded(Color.rgb(235,249,242),11);sb.setStroke(dp(1),GREEN);state.setBackground(sb);}TextView ic=label(test?"T":("DELETED".equals(x.changeType)?"−":"CHANGED".equals(x.changeType)?"!":"+"),16,true,Color.WHITE);ic.setGravity(Gravity.CENTER);ic.setBackground(rounded(accent,30));state.addView(ic,new LinearLayout.LayoutParams(dp(38),dp(38)));LinearLayout stx=new LinearLayout(this);stx.setOrientation(LinearLayout.VERTICAL);stx.setPadding(dp(9),0,0,0);stx.addView(label(test?"Тестовая запись":changeTypeLabel(x.changeType)+" запись",13,true,accent));stx.addView(label(test?"Исключена из отчётов и статистики":("RESOLVED".equals(x.resolutionStatus)?"✓ Решено":"Требует решения"),10,false,test?GREEN:("RESOLVED".equals(x.resolutionStatus)?GREEN:RED)));state.addView(stx);body.addView(state);
        LinearLayout details=card();details.setPadding(dp(11),dp(9),dp(11),dp(9));TextView dt=label(db.changeDetails(x),11,false,TEXT);dt.setLineSpacing(dp(2),1.0f);details.addView(dt);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);dlp.setMargins(0,dp(7),0,0);body.addView(details,dlp);
        EditText note=new EditText(this);note.setHint("Комментарий к решению (для тестовой записи: тест)");note.setText(x.resolutionNote==null?"":x.resolutionNote);note.setTextSize(11);note.setMinLines(2);note.setMaxLines(4);note.setPadding(dp(10),dp(7),dp(10),dp(7));note.setBackground(rounded(Color.WHITE,10));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);np.setMargins(0,dp(7),0,0);body.addView(note,np);
        boolean resolved="RESOLVED".equals(x.resolutionStatus);
        if(resolved){Button save=flatButton("Сохранить примечание",test?GREEN:ACCENT,Color.WHITE);save.setOnClickListener(v->{db.updateResolutionNote(x.id,note.getText().toString());NotificationHelper.refreshAfterTestPolicy(this,db);Toast.makeText(this,"Примечание сохранено",Toast.LENGTH_SHORT).show();switchPage(PAGE_JOURNAL);refreshDashboardInformer();});LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(42));slp.setMargins(0,dp(8),0,0);body.addView(save,slp);}
        Button action=flatButton(resolved?"Вернуть в «Требует решения»":"✓  Вопрос решён",resolved?Color.WHITE:ACCENT,resolved?RED:Color.WHITE);if(resolved){GradientDrawable ab=rounded(Color.WHITE,11);ab.setStroke(dp(1),RED);action.setBackground(ab);}action.setTextSize(13);action.setOnClickListener(v->{if(resolved)db.reopenChange(x.id);else db.resolveChange(x.id,note.getText().toString());NotificationHelper.refreshAfterTestPolicy(this,db);switchPage(PAGE_JOURNAL);refreshDashboardInformer();});LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(44));alp.setMargins(0,dp(8),0,0);body.addView(action,alp);
        pageHost.removeAllViews();pageHost.addView(pageScroll(body),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private View buildSettingsPage() {
        LinearLayout body=pageBody();
        body.addView(pageTitle("Настройки", "Только реальные параметры приложения"));
        CheckSettings cfg=new CheckSettings(this);

        String login=credentials==null?"":credentials.getLogin();
        String account=(login==null||login.trim().isEmpty())?"Не настроено":"Подключено: "+maskLogin(login.trim());
        body.addView(settingsSection("Cubux",
                settingRow("Учётная запись Cubux", account, "›", v->showLoginDialog(false)),
                settingRow("Удалить данные авторизации", "Логин, пароль и токен", "›", v->confirmClearCredentials())));

        body.addView(settingsSection("Расписание проверок",
                settingRow("Быстрая проверка", cfg.lightTime()+"  •  "+daysText(cfg.lightDays()), "›", v->scheduleSettingsDialog(CheckSettings.TYPE_LIGHT)),
                settingRow("Полная проверка", cfg.fullTime()+"  •  "+daysText(cfg.fullDays()), "›", v->scheduleSettingsDialog(CheckSettings.TYPE_FULL)),
                settingRow("Повторные попытки", String.valueOf(cfg.retries()), "›", v->retrySettingsDialog()),
                settingRow("Пауза между запросами", DelayProfile.label(cfg.requestDelayMs()), "›", v->delaySettingsDialog()),
                settingRow("Состояние автозапуска", scheduleSettingsStatus(cfg), "›", v->showAutoStartSettings())));

        body.addView(settingsSection("Уведомления",
                settingRow("Системные уведомления", "Настройки Android", "›", v->openAndroidNotificationSettings()),
                settingRow("Центр событий", eventCenterSettingsStatus(), "›", v->showEventCenterPage())));

        body.addView(settingsSection("Данные и безопасность",
                settingRow("Резервные копии", backupSettingsStatus(), "›", v->showBackupPage(false)),
                settingRow("Восстановление", "Выбрать сохранённую копию или файл", "›", v->showBackupPage(true)),
                settingRow("Контроль периодов", closedPeriodsSettingsStatus(), "›", v->showClosedPeriods()),
                settingRow("Диагностика", "Логи, HTTP-коды и экспорт", "›", v->showAdvancedDiagnosticsDialog())));

        body.addView(settingsSection("Контроль дня",
                settingRow("Сегодня", "Почасовой контроль 00:30–23:30 • финальный 23:59", "›", v->switchPage(PAGE_REPORTS))));

        TextView ver=label("Cubux Security 3.0.25",10,false,MUTED);
        ver.setGravity(Gravity.CENTER); ver.setPadding(0,dp(10),0,dp(3)); body.addView(ver);
        return pageScroll(body);
    }

    private String maskLogin(String login){
        if(login==null||login.isEmpty())return "";
        int at=login.indexOf('@');
        if(at>2)return login.substring(0,2)+"***"+login.substring(at);
        if(login.length()>4)return login.substring(0,2)+"***"+login.substring(login.length()-2);
        return "***";
    }

    private String scheduleSettingsStatus(CheckSettings cfg){
        boolean enabled=cfg.lightDays()!=0||cfg.fullDays()!=0;
        long next=parseLongState("next_scheduled_check_ms");
        if(!enabled)return "Автопроверка выключена";
        if(next<=0)return "Включена • запуск ещё не рассчитан";
        return "Следующая: "+new java.text.SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new java.util.Date(next));
    }

    private String eventCenterSettingsStatus(){
        int unread=db.unreadEventCount();
        return unread>0?"Непросмотренных: "+unread:"Новых событий нет";
    }

    private String backupSettingsStatus(){
        String t=db.getState("backup_last_archive_time");
        String auto=BackupScheduler.enabled(db)?" • авто каждые "+BackupScheduler.intervalDays(db)+" дн.":"";
        if(t==null||t.trim().isEmpty())return "Копий пока нет"+auto;
        return "Последняя: "+TimeUtil.displayDateTime(t)+auto;
    }

    private String closedPeriodsSettingsStatus(){
        int changed=db.closedPeriodChangedCount();
        return changed>0?"Есть изменения: "+changed:"Изменений нет";
    }

    private void openAndroidNotificationSettings(){
        try{
            Intent i=new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName());
            startActivity(i);
        }catch(Throwable e){
            try{startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Throwable ignored){}
        }
    }

    private void confirmClearCredentials(){
        new AlertDialog.Builder(this)
                .setTitle("Удалить данные авторизации?")
                .setMessage("Будут удалены сохранённые логин, пароль и токен Cubux. База проверок и история останутся на месте.")
                .setNegativeButton("Отмена",null)
                .setPositiveButton("Удалить",(d,w)->{
                    credentials.clearAll();
                    CheckScheduler.cancel(this);
                    Toast.makeText(this,"Данные авторизации удалены",Toast.LENGTH_SHORT).show();
                    switchPage(PAGE_SETTINGS);
                }).show();
    }

    private void showEventCenterDialog() { showEventCenterPage(); }
    private void showEventCenterPage(){
        LinearLayout body=pageBody();
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(1),dp(2),0,dp(6));
        TextView back=label("‹  Центр событий",15,true,DARK);back.setOnClickListener(v->switchPage(PAGE_HOME));head.addView(back,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        int unread=db.unreadEventCount();TextView count=label(unread>0?"Новых: "+unread:"Всё просмотрено",9,true,unread>0?RED:GREEN);head.addView(count);body.addView(head);
        TextView sub=label("Все сообщения приложения сохраняются здесь и не перезаписывают друг друга",9,false,MUTED);sub.setPadding(dp(1),0,0,dp(7));body.addView(sub);
        LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);String[] n={"Все","Важные","Проверки","Сегодня","Система"};String[] f={"ALL","IMPORTANT","CHECKS","TODAY","SYSTEM"};for(int i=0;i<n.length;i++){final String x=f[i];boolean active=x.equals(eventFilter);TextView b=label(n[i],8,active,active?Color.WHITE:MUTED);b.setGravity(Gravity.CENTER);GradientDrawable bg=rounded(active?ACCENT:Color.WHITE,9);bg.setStroke(dp(1),active?ACCENT:Color.rgb(222,231,241));b.setBackground(bg);b.setOnClickListener(v->{eventFilter=x;showEventCenterPage();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(30),1);lp.setMargins(i==0?0:dp(2),0,0,0);filters.addView(b,lp);}body.addView(filters);
        java.util.List<AuditDb.AppEvent> events=db.appEvents(eventFilter,300);if(events.isEmpty()){LinearLayout empty=card();empty.setPadding(dp(10),dp(20),dp(10),dp(20));TextView e=label("История событий пока пуста",11,false,MUTED);e.setGravity(Gravity.CENTER);empty.addView(e);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);ep.setMargins(0,dp(7),0,0);body.addView(empty,ep);}else{for(AuditDb.AppEvent e:events){View r=eventRow(e);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.setMargins(0,dp(5),0,0);body.addView(r,rp);}}
        if(unread>0){Button all=flatButton("✓  Отметить всё просмотренным",Color.WHITE,ACCENT);GradientDrawable ab=rounded(Color.WHITE,10);ab.setStroke(dp(1),Color.rgb(190,229,240));all.setBackground(ab);all.setOnClickListener(v->{db.markAllEventsSeen();showEventCenterPage();});LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(40));ap.setMargins(0,dp(8),0,0);body.addView(all,ap);}
        pageHost.removeAllViews();pageHost.addView(pageScroll(body),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
    }
    private int eventAccent(AuditDb.AppEvent e){if(e==null)return GREEN;if("ALERT".equals(e.level)||"ERROR".equals(e.level))return RED;if("WARNING".equals(e.level))return YELLOW;if("INFO".equals(e.level))return BLUE;return GREEN;}
    private String eventHeading(AuditDb.AppEvent e){if(e==null)return "Система под контролем";if("TODAY".equals(e.category)&&("ALERT".equals(e.level)||"WARNING".equals(e.level)))return "Требуется внимание";if("ERROR".equals(e.level)||"ALERT".equals(e.level))return "Требуется внимание";if("WARNING".equals(e.level))return "Предупреждение";if("OK".equals(e.level))return "Всё хорошо";if("TODAY".equals(e.category))return "Контроль дня";return e.source==null?"Событие":e.source;}
    private View eventRow(AuditDb.AppEvent e){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(7),dp(7));GradientDrawable bg=rounded(e.seen?Color.WHITE:Color.rgb(248,252,255),11);bg.setStroke(dp(1),e.seen?Color.rgb(229,235,242):Color.rgb(182,224,238));row.setBackground(bg);int accent=eventAccent(e);TextView ic=label(("ALERT".equals(e.level)||"ERROR".equals(e.level))?"!":"WARNING".equals(e.level)?"!":"OK".equals(e.level)?"✓":"i",12,true,Color.WHITE);ic.setGravity(Gravity.CENTER);ic.setBackground(rounded(accent,30));row.addView(ic,new LinearLayout.LayoutParams(dp(30),dp(30)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(8),0,dp(5),0);LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);line.addView(label(e.source,9,true,DARK),new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));line.addView(label(displayClock(e.createdAt),8,false,MUTED));tx.addView(line);TextView m=label(e.message,10,false,TEXT);m.setMaxLines(3);m.setPadding(0,dp(2),0,0);tx.addView(m);row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));if(!e.seen){TextView dot=label("●",9,true,accent);row.addView(dot);}ImageView a=new ImageView(this);a.setImageResource(R.drawable.ic_chevron_right);a.setColorFilter(Color.rgb(93,112,145));row.addView(a,new LinearLayout.LayoutParams(dp(16),dp(16)));row.setOnClickListener(v->{db.markEventSeen(e.id);openEventAction(e);});return row;}
    private void openEventAction(AuditDb.AppEvent e){if(e==null){showEventCenterPage();return;}if("TODAY".equals(e.action)){dayAnchor.setTimeInMillis(System.currentTimeMillis());dayEventTypeFilter="ALL";switchPage(PAGE_REPORTS);}else if("JOURNAL".equals(e.action)){switchPage(PAGE_JOURNAL);}else if("CHECKS".equals(e.action)){showCheckHistoryPage();}else showEventCenterPage();}
    private void openCurrentInformerEvent(){if(currentInformerEvent!=null){AuditDb.AppEvent e=currentInformerEvent;db.markEventSeen(e.id);currentInformerEvent=null;openEventAction(e);return;}if(db.unresolvedChangeCount()>0)switchPage(PAGE_JOURNAL);else showEventCenterPage();}
    private void dismissCurrentInformerEvent(){if(currentInformerEvent!=null){db.markEventSeen(currentInformerEvent.id);currentInformerEvent=null;refreshDashboardInformer();}else showEventCenterPage();}

    private void showCheckHistoryDialog(){showCheckHistoryPage();}
    private void showCheckHistoryPage(){
        LinearLayout body=pageBody();TextView back=label("‹  История проверок",15,true,DARK);back.setPadding(dp(1),dp(3),0,dp(6));back.setOnClickListener(v->switchPage(PAGE_HOME));body.addView(back);
        EditText search=new EditText(this);search.setHint("Поиск по дате или № проверки");search.setText(historyQuery);search.setTextSize(11);search.setSingleLine(true);search.setPadding(dp(10),0,dp(10),0);search.setBackground(rounded(Color.WHITE,11));body.addView(search,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38)));search.setOnEditorActionListener((v,a,e)->{historyQuery=search.getText().toString().trim();historyLimit=20;showCheckHistoryPage();return true;});
        LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);filters.setPadding(0,dp(6),0,dp(6));String[] n={"Все","С изменениями","Ошибки","Остановленные"};String[] f={"ALL","CHANGES","ERROR","STOPPED"};for(int i=0;i<n.length;i++){final String x=f[i];boolean active=x.equals(historyFilter);TextView b=label(n[i],8,active,active?Color.WHITE:MUTED);b.setGravity(Gravity.CENTER);GradientDrawable bg=rounded(active?ACCENT:Color.WHITE,9);bg.setStroke(dp(1),active?ACCENT:Color.rgb(222,231,241));b.setBackground(bg);b.setOnClickListener(v->{historyFilter=x;historyLimit=20;showCheckHistoryPage();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(29),1);lp.setMargins(i==0?0:dp(2),0,0,0);filters.addView(b,lp);}body.addView(filters);
        java.util.List<AuditDb.RunSummary> runs=db.runsPage(historyFilter,historyQuery,historyLimit,0);String lastGroup="";for(AuditDb.RunSummary run:runs){String g=historyGroup(run.startedAt);if(!g.equals(lastGroup)){TextView gh=label(g,11,true,DARK);gh.setPadding(dp(2),dp(7),0,dp(4));body.addView(gh);lastGroup=g;}body.addView(historyFullRow(run),historyRowParams(false));}
        if(runs.isEmpty()){LinearLayout e=card();e.setPadding(dp(10),dp(18),dp(10),dp(18));TextView t=label("Проверки не найдены",11,false,MUTED);t.setGravity(Gravity.CENTER);e.addView(t);body.addView(e);}else if(runs.size()>=historyLimit){Button more=flatButton("Показать ещё",Color.WHITE,ACCENT);GradientDrawable mb=rounded(Color.WHITE,10);mb.setStroke(dp(1),Color.rgb(190,229,240));more.setBackground(mb);more.setOnClickListener(v->{historyLimit+=20;showCheckHistoryPage();});LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(40));mp.setMargins(0,dp(8),0,0);body.addView(more,mp);}
        pageHost.removeAllViews();pageHost.addView(pageScroll(body),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
    }
    private String historyGroup(String started){long ms=TimeUtil.parseDateTimeMillis(started);if(ms<=0)return "Ранее";java.util.Calendar c=java.util.Calendar.getInstance();c.setTimeInMillis(ms);java.util.Calendar now=java.util.Calendar.getInstance();if(c.get(java.util.Calendar.YEAR)==now.get(java.util.Calendar.YEAR)&&c.get(java.util.Calendar.DAY_OF_YEAR)==now.get(java.util.Calendar.DAY_OF_YEAR))return "Сегодня";now.add(java.util.Calendar.DAY_OF_YEAR,-1);if(c.get(java.util.Calendar.YEAR)==now.get(java.util.Calendar.YEAR)&&c.get(java.util.Calendar.DAY_OF_YEAR)==now.get(java.util.Calendar.DAY_OF_YEAR))return "Вчера";return new java.text.SimpleDateFormat("dd MMMM yyyy",Locale.getDefault()).format(c.getTime());}
    private View historyFullRow(AuditDb.RunSummary run){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(7),dp(7));GradientDrawable bg=rounded(Color.WHITE,11);bg.setStroke(dp(1),Color.rgb(229,235,242));row.setBackground(bg);int accent="ERROR".equals(run.status)||"STOPPED".equals(run.status)?RED:(run.newCount+run.changedCount+run.deletedCount)>0?YELLOW:GREEN;TextView ic=label("ERROR".equals(run.status)||"STOPPED".equals(run.status)?"!":"✓",13,true,Color.WHITE);ic.setGravity(Gravity.CENTER);ic.setBackground(rounded(accent,30));row.addView(ic,new LinearLayout.LayoutParams(dp(30),dp(30)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(8),0,dp(4),0);String time=homeRunTime(run.startedAt);tx.addView(label("#"+run.id+"   "+time,11,true,DARK));String mode=run.recovery?"Восстановительная":"FULL".equals(run.mode)?"Полная":"Быстрая";tx.addView(label(mode+" • "+runStatusShort(run.status)+" • "+TimeUtil.duration(run.durationMs),9,false,MUTED));LinearLayout m=new LinearLayout(this);m.setOrientation(LinearLayout.HORIZONTAL);m.addView(label("Всего: "+spacedNumber(run.total>0?run.total:db.transactionCount()),9,false,MUTED));m.addView(historyMetric(run.newCount,GREEN));m.addView(historyMetric(run.changedCount,YELLOW));m.addView(historyMetric(run.deletedCount,RED));tx.addView(m);row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));ImageView a=new ImageView(this);a.setImageResource(R.drawable.ic_chevron_right);a.setColorFilter(Color.rgb(93,112,145));row.addView(a,new LinearLayout.LayoutParams(dp(17),dp(17)));row.setOnClickListener(v->showRunDetails(run));return row;}
    private void showRunDetails(AuditDb.RunSummary run){LinearLayout body=pageBody();TextView back=label("‹  Проверка #"+run.id,15,true,DARK);back.setPadding(dp(1),dp(3),0,dp(7));back.setOnClickListener(v->showCheckHistoryPage());body.addView(back);LinearLayout c=card();c.setPadding(dp(11),dp(10),dp(11),dp(10));String mode=run.recovery?"Восстановительная":"FULL".equals(run.mode)?"Полная":"Быстрая";StringBuilder t=new StringBuilder();t.append("Тип: ").append(mode).append("\n");t.append("Начало: ").append(TimeUtil.displayDateTime(run.startedAt)).append("\n");t.append("Длительность: ").append(TimeUtil.duration(run.durationMs)).append("\n");t.append("Проверено: ").append(spacedNumber(run.total>0?run.total:db.transactionCount())).append("\n");t.append("Новые: ").append(run.newCount).append("\nИзменённые: ").append(run.changedCount).append("\nУдалённые: ").append(run.deletedCount).append("\n");t.append("Результат: ").append(runStatusShort(run.status));if(run.error!=null&&!run.error.trim().isEmpty())t.append("\nОшибка: ").append(run.error);TextView info=label(t.toString(),11,false,TEXT);info.setLineSpacing(dp(2),1f);c.addView(info);body.addView(c);if(run.newCount+run.changedCount+run.deletedCount>0){Button j=flatButton("Открыть журнал изменений",ACCENT,Color.WHITE);j.setOnClickListener(v->switchPage(PAGE_JOURNAL));LinearLayout.LayoutParams jp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(42));jp.setMargins(0,dp(7),0,0);body.addView(j,jp);}pageHost.removeAllViews();pageHost.addView(pageScroll(body),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));}

    private void refreshDashboardInformer() {
        refreshHomeQuickButton();
        if (informerText == null || informerCard == null) return;
        String state=db.getState("last_check_state");
        String title, sub; int accent, surface;
        java.util.List<AuditDb.AppEvent> unread=db.unreadEvents(1);
        int unreadCount=db.unreadEventCount();
        if(!unread.isEmpty()){
            currentInformerEvent=unread.get(0);
            title=eventHeading(currentInformerEvent);
            sub=currentInformerEvent.message+"\n1 из "+unreadCount+"  •  После просмотра — «Далее»";
            accent=eventAccent(currentInformerEvent);
            surface=(accent==RED)?Color.rgb(255,241,244):(accent==YELLOW)?Color.rgb(255,249,231):(accent==BLUE)?Color.rgb(239,247,255):Color.rgb(238,250,245);
        }
        else{
            currentInformerEvent=null;
            if (isAuditSessionActive()) { title="Выполняется " + currentCheckLabel().toLowerCase(Locale.ROOT); sub="Нажмите, чтобы увидеть прогресс"; accent=BLUE; surface=Color.rgb(239,247,255); }
            else if (!isNetworkAvailable()) { title="Нет интернета"; sub="Проверка продолжится после восстановления сети"; accent=YELLOW; surface=Color.rgb(255,249,231); }
            else if ("ERROR".equals(state)) { title="Требуется внимание"; sub="Последняя проверка завершилась ошибкой  •  Все события ›"; accent=RED; surface=Color.rgb(255,241,244); }
            else if ("1".equals(db.getState("missed_check_pending"))) { title="Требуется внимание"; sub="Была пропущена автоматическая проверка  •  Все события ›"; accent=YELLOW; surface=Color.rgb(255,249,231); }
            else if ("1".equals(db.getState("yesterday_changed_during_scan"))) { title="Данные вчерашнего дня менялись"; sub="Визуально проверьте вчерашний день  •  Все события ›"; accent=RED; surface=Color.rgb(255,241,244); }
            else if (db.unresolvedChangeCount()>0) { title="Требуется решение"; sub="Нерешённых изменений: "+db.unresolvedChangeCount()+"  •  Открыть журнал ›"; accent=RED; surface=Color.rgb(255,241,244); }
            else if ("OK".equals(state)) { title="Система под контролем"; String last=db.getState("last_check_time"); sub="Последняя проверка завершена успешно" + (last==null||last.trim().isEmpty()?"":"\n◷  "+homeRunTime(last)); accent=GREEN; surface=Color.rgb(238,250,245); }
            else { title="Защита готова"; sub="Выполните первую проверку"; accent=BLUE; surface=Color.rgb(239,247,255); }
        }

        SpannableStringBuilder info=new SpannableStringBuilder(title+"\n"+sub);
        info.setSpan(new StyleSpan(Typeface.BOLD),0,title.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        info.setSpan(new RelativeSizeSpan(1.16f),0,title.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        info.setSpan(new ForegroundColorSpan(MUTED),title.length()+1,info.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        informerText.setText(info);
        GradientDrawable bg=rounded(surface,13);
        bg.setStroke(dp(1),Color.argb(70,Color.red(accent),Color.green(accent),Color.blue(accent)));
        informerCard.setBackground(bg);
        if(informerIcon!=null){String icon=(accent==YELLOW||accent==RED)?"!":accent==BLUE?"i":"✓";informerIcon.setText(icon);informerIcon.setBackground(rounded(accent,40));}
        if(informerNext!=null){informerNext.setVisibility(unreadCount>0?View.VISIBLE:View.GONE);informerNext.setText(unreadCount>1?"Далее  ›":"Прочитано ✓");}
        if(informerAll!=null){informerAll.setText(unreadCount>0?"Все "+unreadCount+"  ›":"Все  ›");}
        if(headerStatusPill!=null){headerStatusPill.setText("●  Защита активна");headerStatusPill.setTextColor(GREEN);headerStatusPill.setBackground(rounded(Color.rgb(235,249,242),18));}
    }

    private TextView bottomItem(String icon, String caption, int color, View.OnClickListener listener) {
        TextView v=label(icon+"\n"+caption,8,false,color);
        v.setGravity(Gravity.CENTER); v.setLineSpacing(0,0.88f);
        v.setPadding(dp(1),dp(2),dp(1),dp(1)); v.setMinHeight(dp(46));
        v.setOnClickListener(listener); return v;
    }

    private void onAuditNavigationPressed() {
        switchPage(PAGE_CHECK);
    }

    private void scrollToTop() {
        View content = findViewById(android.R.id.content);
        if (content != null) content.requestFocus();
    }

    private View buildHeader() {
        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10),dp(5),dp(8),dp(5));
        header.setBackgroundColor(Color.WHITE);
        header.setElevation(dp(1));

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.ic_app_wealth);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo,new LinearLayout.LayoutParams(dp(36),dp(36)));

        TextView title=label("Cubux Security",15,true,DARK);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);
        tp.setMargins(dp(8),0,dp(4),0); header.addView(title,tp);

        headerStatusPill=label("●  Защита активна",8,true,GREEN);
        headerStatusPill.setGravity(Gravity.CENTER);
        headerStatusPill.setPadding(dp(9),dp(4),dp(9),dp(4));
        headerStatusPill.setBackground(rounded(Color.rgb(235,249,242),18));
        header.addView(headerStatusPill);

        ImageView settings=new ImageView(this);
        settings.setImageResource(R.drawable.ic_settings);
        settings.setColorFilter(Color.rgb(73,98,135));
        settings.setPadding(dp(7),dp(7),dp(7),dp(7));
        settings.setOnClickListener(v->switchPage(PAGE_SETTINGS));
        header.addView(settings,new LinearLayout.LayoutParams(dp(38),dp(38)));
        return header;
    }

    private TextView topStat(
            String icon,
            String value,
            String caption,
            int accent
    ) {
        TextView v = label(icon + "  " + value + "\n" + caption, 11, false, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(74));
        v.setPadding(dp(2), dp(8), dp(2), dp(8));
        GradientDrawable bg = rounded(Color.argb(28,255,255,255), 18);
        bg.setStroke(dp(1), Color.argb(95,255,255,255));
        v.setBackground(bg);
        return v;
    }

    private View buildAuditPanel() {
        LinearLayout card=card();
        card.setPadding(dp(10),dp(7),dp(10),dp(7));

        TextView cap=label("Прогресс проверки",14,true,DARK);
        card.addView(cap);

        LinearLayout progressRow=new LinearLayout(this);
        progressRow.setOrientation(LinearLayout.HORIZONTAL);
        progressRow.setGravity(Gravity.CENTER_VERTICAL);
        progressRow.setPadding(0,dp(2),0,dp(3));
        progressAmountText=label("Подготовка данных",14,true,DARK);
        progressRow.addView(progressAmountText,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        percentText=label("0%",17,true,DARK);
        progressRow.addView(percentText);
        card.addView(progressRow);

        progressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressDrawable(buildRoundedProgressDrawable());
        card.addView(progressBar,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(9)));

        detailsText=label("Сейчас: готов к проверке\nЭтап: ожидание\nПрогресс: 0%\nДействие: —\nСкорость: —\nПрошло: 00:00\nПоследняя активность: —\nСостояние: готово",11,false,TEXT);
        detailsText.setMinLines(8);
        detailsText.setMaxLines(8);
        detailsText.setLineSpacing(0,0.86f);
        detailsText.setPadding(dp(7),dp(5),dp(7),dp(5));
        detailsText.setBackground(rounded(Color.rgb(249,251,254),10));
        LinearLayout.LayoutParams dpv=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        dpv.setMargins(0,dp(6),0,0);
        card.addView(detailsText,dpv);

        statusText=label("Готов к проверке",1,true,DARK);
        statusText.setVisibility(View.GONE);
        card.addView(statusText,new LinearLayout.LayoutParams(1,1));

        auditButton=flatButton("▶  Быстрая проверка", Color.rgb(0,169,190), Color.WHITE);
        auditButton.setTextSize(13);
        auditButton.setOnClickListener(v->runAudit(AuditCoordinator.MODE_QUICK));
        fullAuditButton=flatButton("Полная проверка", Color.WHITE, DARK);
        fullAuditButton.setTextSize(13);
        GradientDrawable fbg=rounded(Color.WHITE,10);
        fbg.setStroke(dp(1),Color.rgb(213,224,235));
        fullAuditButton.setBackground(fbg);
        fullAuditButton.setOnClickListener(v->{ if(isAuditSessionActive()) Toast.makeText(this,"Сначала завершите текущую проверку",Toast.LENGTH_SHORT).show(); else runAudit(AuditCoordinator.MODE_FULL); });
        LinearLayout starts=new LinearLayout(this);
        starts.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams a1=new LinearLayout.LayoutParams(0,dp(38),1); a1.setMargins(0,dp(6),dp(4),0);
        LinearLayout.LayoutParams a2=new LinearLayout.LayoutParams(0,dp(38),1); a2.setMargins(dp(4),dp(6),0,0);
        starts.addView(auditButton,a1);
        starts.addView(fullAuditButton,a2);
        card.addView(starts);

        boolean runningNow = isAuditSessionActive();
        auditButton.setVisibility(runningNow ? View.GONE : View.VISIBLE);
        fullAuditButton.setVisibility(runningNow ? View.GONE : View.VISIBLE);

        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(0,dp(6),0,0);
        pauseButton=flatButton("Ⅱ  Пауза", Color.rgb(255,181,13), Color.WHITE);
        pauseButton.setTextSize(13);
        pauseButton.setVisibility(runningNow?View.VISIBLE:View.GONE);
        pauseButton.setEnabled(runningNow);
        pauseButton.setOnClickListener(v->togglePause());
        stopButton=flatButton("●  Остановить", RED, Color.WHITE);
        stopButton.setTextSize(13);
        stopButton.setVisibility(runningNow?View.VISIBLE:View.GONE);
        stopButton.setEnabled(runningNow);
        stopButton.setOnClickListener(v->stopAudit());
        LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(0,dp(38),1); p1.setMargins(0,0,dp(4),0);
        LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(0,dp(38),1); p2.setMargins(dp(4),0,0,0);
        controls.addView(pauseButton,p1);
        controls.addView(stopButton,p2);
        card.addView(controls);

        TextView stagesTitle=label("Текущий этап проверки",13,true,DARK);
        stagesTitle.setPadding(0,dp(6),0,dp(2));
        card.addView(stagesTitle);
        card.addView(buildStageChecklist());

        LinearLayout summary=new LinearLayout(this);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(dp(8),dp(5),dp(8),dp(5));
        summary.setBackground(rounded(Color.rgb(244,249,253),10));
        currentStageSummaryTitle=label("Текущий этап:  ожидание",11,true,DARK);
        currentStageSummaryBody=label("Ожидание запуска проверки.",10,false,MUTED);
        currentStageSummaryBody.setPadding(0,dp(2),0,0);
        currentStageSummaryBody.setMaxLines(2);
        summary.addView(currentStageSummaryTitle);
        summary.addView(currentStageSummaryBody);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.setMargins(0,dp(5),0,0);
        card.addView(summary,sp);

        updateStageIndicators("IDLE");
        return card;
    }

    private android.graphics.drawable.Drawable buildRoundedProgressDrawable(){
        GradientDrawable track=rounded(Color.rgb(224,233,242),20);
        GradientDrawable fill=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(0,194,113),Color.rgb(0,177,105)});
        fill.setCornerRadius(dp(20));
        android.graphics.drawable.ClipDrawable clip=new android.graphics.drawable.ClipDrawable(fill,Gravity.LEFT,android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable layer=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{track,clip});
        layer.setId(0,android.R.id.background);
        layer.setId(1,android.R.id.progress);
        return layer;
    }

    private TextView step(
            String icon,
            String caption
    ) {
        TextView v = label(icon + "\n" + caption, 11, false, MUTED);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(58));
        return v;
    }


private View buildLastCheckCard() {
    LinearLayout card=card(); TextView title=label("Последняя проверка",16,true,DARK); card.addView(title); lastCheckText=label("Проверок ещё не было",12,false,MUTED); lastCheckText.setPadding(0,dp(7),0,0); lastCheckText.setOnClickListener(v->showJournalDialog()); card.addView(lastCheckText); refreshLastCheckStatus(); return card;
}

private void refreshLastCheckStatus() {
    if (lastCheckText == null || db == null) return;
    String state = db.getState("last_check_state");
    String type = db.getState("last_check_type");
    String time = db.getState("last_check_time");
    String msg = db.getState("last_check_message");
    if ("OK".equals(state)) {
        int vn=parseIntState("last_check_new"), vc=parseIntState("last_check_changed"), vd=parseIntState("last_check_deleted");
        msg=(vn+vc+vd)==0 ? "Проверка прошла успешно, изменений нет." : "Найдены изменения: новые "+vn+", изменённые "+vc+", удалённые "+vd+".";
    }
    String activity = db.getState("last_check_activity");
    if (state == null) {
        lastCheckText.setText("Проверок ещё не было. Расписание задаётся в настройках.");
        return;
    }
    StringBuilder x = new StringBuilder();
    if (type != null && !type.isEmpty()) x.append(type);
    if (time != null && !time.isEmpty()) x.append(" • ").append(time);
    if (x.length() > 0) x.append("\n");
    x.append(msg == null ? "Состояние проверки неизвестно" : msg);
    if ("OK".equals(state)) {
        int n=parseIntState("last_check_new"), c=parseIntState("last_check_changed"), d=parseIntState("last_check_deleted");
        x.append("\nНовые: ").append(n).append(" • Изменённые: ").append(c).append(" • Удалённые: ").append(d);
    }
    if (activity != null && !activity.isEmpty()) x.append("\nПоследняя активность: ").append(activity);
    try {
        String lastMs=db.getState("last_successful_audit_ms");
        if(lastMs!=null && System.currentTimeMillis()-Long.parseLong(lastMs)>36L*60L*60L*1000L)
            x.append("\n⚠ Давно не было успешной проверки. Рекомендуется запустить проверку вручную.");
    } catch(Exception ignored) {}
    lastCheckText.setTextColor("ERROR".equals(state)?RED:"RUNNING".equals(state)?BLUE:"OK".equals(state)?GREEN:MUTED);
    lastCheckText.setText(TimeUtil.displayDateTime(x.toString()));
}

private int parseIntState(String key) {
    if (db != null && ("last_check_new".equals(key) || "last_check_changed".equals(key) || "last_check_deleted".equals(key) || "last_check_total".equals(key))) {
        return db.visibleLastCheckMetric(key);
    }
    try { return Integer.parseInt(db.getState(key)); } catch (Exception e) { return 0; }
}

private long parseLongState(String key) {
    try { return Long.parseLong(db.getState(key)); } catch (Exception e) { return 0L; }
}

    private View buildStatsRow() {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,dp(10),0,0); newCard=statCard("●",String.valueOf(parseIntState("last_check_new")),"Новые",GREEN); changedCard=statCard("●",String.valueOf(parseIntState("last_check_changed")),"Изменённые",YELLOW); deletedCard=statCard("●",String.valueOf(parseIntState("last_check_deleted")),"Удалённые",RED); row.addView(newCard,weight()); row.addView(changedCard,weight()); row.addView(deletedCard,weight()); return row;
    }

    private TextView statCard(String icon, String value, String caption, int accent) {
        String raw="●\u00A0"+caption+"\n"+value;
        TextView v=label(raw,9,false,TEXT);
        SpannableStringBuilder sp=new SpannableStringBuilder(raw);
        sp.setSpan(new ForegroundColorSpan(accent),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new RelativeSizeSpan(1.55f),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int captionStart=raw.indexOf(caption);
        if(captionStart>=0){
            sp.setSpan(new ForegroundColorSpan(Color.rgb(72,94,129)),captionStart,captionStart+caption.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new StyleSpan(Typeface.BOLD),captionStart,captionStart+caption.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        int valueStart=raw.lastIndexOf(value);
        if(valueStart>=0){
            sp.setSpan(new StyleSpan(Typeface.BOLD),valueStart,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new RelativeSizeSpan(1.7f),valueStart,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new ForegroundColorSpan(DARK),valueStart,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        v.setText(sp);
        v.setGravity(Gravity.CENTER);
        v.setMaxLines(2);
        v.setPadding(dp(3),dp(3),dp(3),dp(3));
        v.setLineSpacing(0,0.95f);
        int r=Color.red(accent),g=Color.green(accent),b=Color.blue(accent);
        GradientDrawable bg=rounded(Color.WHITE,11);
        bg.setStroke(dp(1),Color.argb(58,r,g,b));
        v.setBackground(bg);
        return v;
    }

    private Button flatButton(String text, int bgColor, int fgColor) {
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(11); b.setTextColor(fgColor);
        b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); b.setPadding(dp(7),0,dp(7),0);
        b.setMinHeight(0); b.setMinimumHeight(0); b.setBackground(rounded(bgColor,10)); return b;
    }

    private View homeActionRow(View left, View right) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams l=new LinearLayout.LayoutParams(0,dp(76),1); l.setMargins(0,0,dp(4),dp(6));
        LinearLayout.LayoutParams r=new LinearLayout.LayoutParams(0,dp(76),1); r.setMargins(dp(4),0,0,dp(6));
        row.addView(left,l); row.addView(right,r); return row;
    }

    private View homeStatusAction(int iconRes,String title,String subtitle,String status,int accent,View.OnClickListener click){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.HORIZONTAL);box.setGravity(Gravity.CENTER_VERTICAL);box.setPadding(dp(8),dp(7),dp(7),dp(7));
        int r=Color.red(accent),g=Color.green(accent),b=Color.blue(accent);GradientDrawable bg=rounded(Color.rgb(Math.min(255,250+r/45),Math.min(255,250+g/55),Math.min(255,252+b/65)),12);bg.setStroke(dp(1),Color.argb(45,r,g,b));box.setBackground(bg);box.setElevation(dp(1));box.setOnClickListener(click);
        LinearLayout bubble=new LinearLayout(this);bubble.setGravity(Gravity.CENTER);bubble.setBackground(rounded(accent,12));ImageView ic=new ImageView(this);ic.setImageResource(iconRes);ic.setColorFilter(Color.WHITE);bubble.addView(ic,new LinearLayout.LayoutParams(dp(22),dp(22)));box.addView(bubble,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(8),0,dp(3),0);TextView tt=label(title,11,true,DARK);tt.setMaxLines(2);tx.addView(tt);TextView sub=label(subtitle,8,false,MUTED);sub.setMaxLines(1);tx.addView(sub);TextView st=label(status,8,true,status.startsWith("⚠")?RED:status.contains("выключ")?MUTED:Color.rgb(22,145,86));st.setMaxLines(1);st.setPadding(0,dp(2),0,0);tx.addView(st);box.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        ImageView arrow=new ImageView(this);arrow.setImageResource(R.drawable.ic_chevron_right);arrow.setColorFilter(Color.rgb(93,112,145));box.addView(arrow,new LinearLayout.LayoutParams(dp(15),dp(15)));return box;
    }

    private String closedPeriodsHomeStatus(){int changed=db.closedPeriodChangedCount();int count=db.closedPeriodCount();if(changed>0)return "⚠ Изменений: "+changed;if(count<=0)return "Ещё нет данных";return "✓ Под контролем";}
    private String scheduleHomeStatus(){long next=parseLongState("next_scheduled_check_ms");if(next<=0)return "Автопроверка выключена";java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("dd.MM HH:mm",Locale.getDefault());java.text.SimpleDateFormat today=new java.text.SimpleDateFormat("yyyyMMdd",Locale.US);String prefix=today.format(new java.util.Date(next)).equals(today.format(new java.util.Date()))?"Сегодня ":"";return "Следующая: "+prefix+(prefix.isEmpty()?f.format(new java.util.Date(next)):new java.text.SimpleDateFormat("HH:mm",Locale.US).format(new java.util.Date(next)));}
    private String backupHomeStatus(){String t=db.getState("backup_last_archive_time");if(t==null||t.trim().isEmpty())t=db.getState("auto_backup_time");if(t==null||t.trim().isEmpty())return "Создать копию";return "Последняя: "+TimeUtil.displayDateTime(t);}


    private View homeAction(int iconRes,String title,String subtitle,int accent,View.OnClickListener click) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(8),dp(7),dp(7),dp(7)); GradientDrawable bg=rounded(Color.WHITE,11);
        bg.setStroke(dp(1),Color.rgb(229,235,242)); box.setBackground(bg); box.setElevation(dp(1)); box.setOnClickListener(click);
        LinearLayout bubble=new LinearLayout(this); bubble.setGravity(Gravity.CENTER); bubble.setBackground(rounded(accent,11));
        ImageView ic=new ImageView(this); ic.setImageResource(iconRes); ic.setColorFilter(Color.WHITE); bubble.addView(ic,new LinearLayout.LayoutParams(dp(21),dp(21)));
        box.addView(bubble,new LinearLayout.LayoutParams(dp(38),dp(38)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(8),0,0,0);
        tx.addView(label(title,11,true,DARK)); TextView st=label(subtitle,10,false,MUTED); st.setPadding(0,dp(1),0,0); st.setLineSpacing(0,0.94f); tx.addView(st);
        box.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        ImageView arrow=new ImageView(this); arrow.setImageResource(R.drawable.ic_chevron_right); arrow.setColorFilter(Color.rgb(93,112,145)); box.addView(arrow,new LinearLayout.LayoutParams(dp(15),dp(15)));
        return box;
    }

    private View processRow(String number,String title,String subtitle) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(5),0,dp(5));
        TextView n=label(number,11,true,BLUE); n.setGravity(Gravity.CENTER); n.setBackground(rounded(Color.rgb(235,246,255),30));
        row.addView(n,new LinearLayout.LayoutParams(dp(30),dp(30)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(8),0,0,0);
        tx.addView(label(title,10,true,DARK)); TextView sub=label(subtitle,8,false,MUTED); sub.setLineSpacing(0,0.94f); tx.addView(sub);
        row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1)); return row;
    }

    private TextView reportTile(String value,String caption,int accent) {
        TextView t=label(value+"\n"+caption,8,true,DARK); t.setGravity(Gravity.CENTER); t.setMinHeight(dp(54));
        int r=Color.red(accent),g=Color.green(accent),b=Color.blue(accent);
        GradientDrawable bg=rounded(Color.rgb(Math.min(255,247+r/70),Math.min(255,249+g/70),Math.min(255,251+b/85)),9);
        bg.setStroke(dp(1),Color.argb(60,r,g,b)); t.setBackground(bg); return t;
    }

    private View reportLine(String title,int value,int accent){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(5),0,dp(5));
        TextView left=label("●  "+title,9,false,accent); row.addView(left,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        TextView right=label(String.valueOf(value),9,true,DARK); row.addView(right); return row;
    }

    private View settingRow(String title,String value,String right) {
        return settingRow(title,value,right,v->{});
    }

    private View settingRow(String title,String value,String right,View.OnClickListener listener) {
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2),dp(9),dp(2),dp(9));
        row.setClickable(true);
        row.setFocusable(true);
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL);
        TextView tt=label(title,11,true,DARK); tt.setMaxLines(2); tx.addView(tt);
        TextView vv=label(value,9,false,MUTED); vv.setMaxLines(2); vv.setPadding(0,dp(1),0,0); tx.addView(vv);
        row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        TextView r=label(right,13,true,right.equals("●")?GREEN:MUTED); r.setGravity(Gravity.CENTER); row.addView(r,new LinearLayout.LayoutParams(dp(28),dp(34)));
        row.setOnClickListener(listener);
        return row;
    }

    private View settingsSection(String title, View... rows) {
        TextView h=label(title,10,true,DARK); LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setPadding(0,dp(5),0,0); wrap.addView(h);
        LinearLayout c=card(); c.setPadding(dp(10),dp(3),dp(10),dp(3)); for(View v:rows)c.addView(v);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT); cp.setMargins(0,dp(4),0,0); wrap.addView(c,cp); return wrap;
    }


    private View buildStageChecklist(){
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        String[] names={
                "Подключение к Cubux",
                "Получение списка периодов",
                "Загрузка данных",
                "Сравнение с базой",
                "Проверка изменений",
                "Запись результатов",
                "Резервная копия и итог",
                "Завершение проверки"
        };
        for(int i=0;i<stageRows.length;i++){
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0,dp(1),0,dp(1));

            TextView icon=label("",10,true,Color.WHITE);
            icon.setGravity(Gravity.CENTER);
            stageIconViews[i]=icon;
            row.addView(icon,new LinearLayout.LayoutParams(dp(22),dp(22)));

            TextView name=label(names[i],11,false,MUTED);
            name.setPadding(dp(7),0,dp(4),0);
            stageRows[i]=name;
            row.addView(name,new LinearLayout.LayoutParams(0,dp(25),1));

            TextView status=label("Ожидание",9,false,MUTED);
            status.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            stageStatusViews[i]=status;
            row.addView(status,new LinearLayout.LayoutParams(dp(74),dp(25)));
            list.addView(row);
        }
        return list;
    }

    private class ChangeChartView extends View {
        private final android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        ChangeChartView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        @Override protected void onDraw(android.graphics.Canvas canvas){
            super.onDraw(canvas); float w=getWidth(), h=getHeight(); float left=dp(6), bottom=h-dp(12), top=dp(10);
            paint.setStrokeWidth(dp(1)); paint.setColor(Color.rgb(231,237,244));
            for(int i=0;i<4;i++){ float y=top+(bottom-top)*i/3f; canvas.drawLine(left,y,w-dp(4),y,paint); }
            int n=Math.max(0,parseIntState("last_check_new")); int c=Math.max(0,parseIntState("last_check_changed")); int d=Math.max(0,parseIntState("last_check_deleted"));
            if(n+c+d==0){paint.setColor(MUTED);paint.setTextSize(dp(10));canvas.drawText("Изменений нет",left,top+dp(18),paint);return;}
            int groups=12; float gap=dp(4); float group=(w-left-dp(6))/groups; float bw=Math.max(dp(2), (group-gap)/3f);
            int max=Math.max(1,Math.max(n,Math.max(c,d)));
            for(int i=0;i<groups;i++){
                float f=(float)(0.25+0.75*Math.abs(Math.sin((i+1)*1.37)));
                float hn=(bottom-top)*f*(n/(float)max); float hc=(bottom-top)*0.75f*f*(c/(float)max); float hd=(bottom-top)*0.65f*(1f-f/2f)*(d/(float)max);
                float x=left+i*group+gap/2f;
                paint.setColor(GREEN); canvas.drawRect(x,bottom-hn,x+bw,bottom,paint);
                paint.setColor(YELLOW); canvas.drawRect(x+bw,bottom-hc,x+2*bw,bottom,paint);
                paint.setColor(RED); canvas.drawRect(x+2*bw,bottom-hd,x+3*bw,bottom,paint);
            }
        }
    }

    private void showClosedPeriods() {
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(12),dp(4),dp(12),dp(6));
        int changed=db.closedPeriodChangedCount();int count=db.closedPeriodCount();
        TextView state=label(changed>0?"⚠ Есть изменения в закрытых периодах":"✓ Все закрытые периоды под контролем",12,true,changed>0?RED:Color.rgb(22,145,86));state.setPadding(dp(10),dp(9),dp(10),dp(9));state.setBackground(rounded(changed>0?Color.rgb(255,241,243):Color.rgb(234,250,241),11));body.addView(state);
        TextView info=label(count<=0?"После успешных проверок здесь появятся завершённые периоды.":"Проверяется целостность прошлых данных. Новые события не перезаписывают контрольные снимки.",9,false,MUTED);info.setPadding(dp(3),dp(7),dp(3),dp(7));body.addView(info);
        java.util.List<AuditDb.ClosureMonthSummary> months=db.closureMonths(12);
        for(AuditDb.ClosureMonthSummary m:months){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(6),dp(7));GradientDrawable bg=rounded(Color.WHITE,10);bg.setStroke(dp(1),Color.rgb(229,235,242));row.setBackground(bg);
            LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(label(monthTitle(m.month),10,true,DARK));tx.addView(label(m.days+" дн. • "+spacedNumber(m.records)+" операций",8,false,MUTED));row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));TextView badge=label(m.changedDays>0?"Есть изменения":"Без изменений",8,true,m.changedDays>0?Color.WHITE:Color.rgb(22,145,86));badge.setPadding(dp(7),dp(4),dp(7),dp(4));badge.setBackground(rounded(m.changedDays>0?RED:Color.rgb(232,249,239),10));row.addView(badge);if(m.changedDays>0)row.setOnClickListener(v->{journalResolutionFilter="OPEN";journalTypeFilter="ALL";switchPage(PAGE_JOURNAL);});LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rp.setMargins(0,0,0,dp(5));body.addView(row,rp);}
        ScrollView scroll=new ScrollView(this);scroll.addView(body);AlertDialog d=new AlertDialog.Builder(this).setTitle("Контроль периодов").setView(scroll).setNegativeButton("Закрыть",null).setPositiveButton(changed>0?"Открыть журнал":"Готово",null).create();d.setOnShowListener(x->{if(changed>0)d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{d.dismiss();journalResolutionFilter="OPEN";journalTypeFilter="ALL";switchPage(PAGE_JOURNAL);});});d.show();
    }
    private String monthTitle(String ym){try{java.util.Date d=new java.text.SimpleDateFormat("yyyy-MM",Locale.US).parse(ym);String x=new java.text.SimpleDateFormat("LLLL yyyy",new Locale("ru","RU")).format(d);return x.substring(0,1).toUpperCase(new Locale("ru","RU"))+x.substring(1);}catch(Exception e){return ym==null?"Период":ym;}}

    private View buildNavigationGrid() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(14), 0, 0);

        wrap.addView(navRow(
                navCard("↺", "История проверкаов", "Просмотр результатов прошлых проверок", Color.rgb(0,202,116),
                        v -> resultText.setText("ИСТОРИЯ ПРОВЕРОК\n\n" + db.recentRunsText())),
                navCard("▤", "Журнал изменений", "Все найденные изменения операций", YELLOW,
                        v -> showJournalDialog())
        ));

        wrap.addView(navRow(
                navCard("◔", "Сегодня", "Почасовой контроль текущего дня", BLUE,
                        v -> switchPage(PAGE_REPORTS)),
                navCard("▦", "Банковская сверка", "Сравнение Cubux с выпиской банка", PURPLE,
                        v -> showBankDialog())
        ));

        wrap.addView(navCardWide("▣", "Закрытые периоды",
                "Контроль изменений в уже завершённых периодах", Color.rgb(245,65,122),
                v -> resultText.setText("Закрытые периоды контролируются автоматически по SHA-256.\n" +
                        "Контрольная база прошлых дней не перезаписывается.")));

        wrap.addView(navRow(
                navCard("⬆", "Резервные копии", "Список копий и автоматическое сохранение", Color.rgb(0,160,180),
                        v -> showBackupPage(false)),
                navCard("⬇", "Восстановление", "Выберите сохранённую копию или файл", Color.rgb(90,110,140),
                        v -> showBackupPage(true))
        ));
        return wrap;
    }

    private View navRow(
            View left,
            View right
    ) {
        LinearLayout row =
                new LinearLayout(this);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        lp.setMargins(
                0,
                0,
                dp(7),
                dp(12)
        );

        LinearLayout.LayoutParams rp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        rp.setMargins(
                dp(7),
                0,
                0,
                dp(12)
        );

        row.addView(
                left,
                lp
        );

        row.addView(
                right,
                rp
        );

        return row;
    }

    private View navCard(
            String icon,
            String title,
            String subtitle,
            int accent,
            View.OnClickListener listener
    ) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(13), dp(15), dp(11), dp(15));
        box.setMinimumHeight(dp(112));
        GradientDrawable bg = rounded(Color.WHITE, 20);
        bg.setStroke(dp(1), Color.rgb(232,237,244));
        box.setBackground(bg);
        box.setOnClickListener(listener);

        TextView bubble = label(icon, 23, true, Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable ibg = rounded(accent, 18);
        bubble.setBackground(ibg);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(54), dp(54));
        ip.setMargins(0,0,dp(12),0);
        box.addView(bubble, ip);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = label(title, 15, true, TEXT);
        TextView st = label(subtitle, 12, false, MUTED);
        st.setPadding(0,dp(4),0,0);
        texts.addView(t);
        texts.addView(st);
        box.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView arrow = label("›", 28, false, MUTED);
        arrow.setGravity(Gravity.CENTER);
        box.addView(arrow, new LinearLayout.LayoutParams(dp(22), dp(50)));
        return box;
    }


    private View navCardWide(String icon, String title, String subtitle, int accent, View.OnClickListener listener) {
        View v = navCard(icon, title, subtitle, accent, listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(10),dp(10),dp(10),dp(10));
        GradientDrawable bg=rounded(Color.WHITE,12); bg.setStroke(dp(1),Color.rgb(228,235,243)); c.setBackground(bg); c.setElevation(dp(1)); return c;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1); p.setMargins(dp(2),0,dp(2),0); return p;
    }

    private TextView iconText(
            String value,
            int size
    ) {
        TextView v =
                label(
                        value,
                        size,
                        true,
                        Color.WHITE
                );

        v.setGravity(
                Gravity.CENTER
        );

        v.setPadding(
                dp(6),
                dp(6),
                dp(6),
                dp(6)
        );

        return v;
    }

    private TextView label(String value, int size, boolean bold, int color) {
        int readableSize = size <= 1 ? size : size + 1;
        TextView v=new TextView(this); v.setText(TimeUtil.displayDateTime(value)); v.setTextSize(readableSize); v.setTextColor(color); v.setFontFeatureSettings("kern"); v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif", Typeface.NORMAL)); return v;
    }

    private GradientDrawable rounded(
            int color,
            int radiusDp
    ) {
        GradientDrawable d =
                new GradientDrawable();

        d.setColor(color);

        d.setCornerRadius(
                dp(radiusDp)
        );

        return d;
    }

    private int dp(
            int value
    ) {
        return (int) (
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density +
                        0.5f
        );
    }

    private void runAudit() { runAudit(AuditCoordinator.MODE_QUICK); }

    private void runAudit(String mode) {
        recoverOrphanedAuditSession();
        if (isAuditSessionActive()) {
            switchPage(PAGE_CHECK);
            try { syncProgressFromService(); } catch (Throwable ignored) {}
            return;
        }

        String login = credentials.getLogin();
        String password = credentials.getPassword();
        if (login.isEmpty() || password.isEmpty()) {
            showLoginDialog(true);
            return;
        }

        auditButton.setEnabled(false);
        auditRunning = true;
        activeCheckMode = mode;
        final long sessionId = ++auditSessionCounter;
        activeAuditSession = sessionId;
        maxPageShown = 0; maxLoadedShown = 0; maxPercentShown = 0; maxStageIndexShown = 0;
        final AuditControl sessionControl = new AuditControl();
        auditControl = sessionControl;
        startedMs = System.currentTimeMillis();
        final long liveRunId = AuditSessionStore.begin(this, mode, startedMs);
        AuditControlRegistry.attach(sessionControl, mode);
        AuditForegroundService.reset(startedMs);
        AuditForegroundService.start(this);
        scanContext = AuditCoordinator.MODE_FULL.equals(mode) ? "Основное чтение полной проверки" : "Быстрая проверка";
        currentStageForUi = "PREPARING";
        currentWaitForUi = "";
        updateStageIndicators("START");
        DiagnosticLog.write(this, "CONTROL", "Ручная проверка запущена. Режим=" + mode + ", runId=" + liveRunId);
        CheckStatusStore.running(this, AuditCoordinator.MODE_FULL.equals(mode) ? "Полная проверка" : "Быстрая проверка");
        if (auditButton != null) { auditButton.setEnabled(false); auditButton.setVisibility(View.GONE); }
        if (fullAuditButton != null) { fullAuditButton.setEnabled(false); fullAuditButton.setVisibility(View.GONE); }
        pauseButton.setEnabled(true); pauseButton.setVisibility(View.VISIBLE); pauseButton.setText("⏸  ПАУЗА");
        stopButton.setEnabled(true); stopButton.setVisibility(View.VISIBLE);
        refreshCheckModeUi(); refreshHomeQuickButton();
        progressBar.setProgress(0); percentText.setText("0%"); resultText.setText(""); retries = 0;

        AuditCoordinator coordinator = new AuditCoordinator(this);
        boolean recovery = coordinator.isRecovery();

        new Thread(() -> {
            try {
                AuditEngine.Result r = coordinator.runMode(login,password,recovery,
                        progressListener(sessionId, sessionControl), sessionControl, mode);
                runOnUiThread(() -> {
                    if (sessionId == activeAuditSession && liveRunId == AuditSessionStore.currentRunId(MainActivity.this)) {
                        showResult(r);
                        AuditSessionStore.finish(MainActivity.this, liveRunId, AuditSessionStore.COMPLETED, "Проверка завершена успешно");
                    }
                    finishManualSession(sessionId,sessionControl,liveRunId);
                });
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                runOnUiThread(() -> {
                    boolean stopped = msg.contains("остановлен пользователем") || msg.contains("остановлена пользователем");
                    if (sessionId == activeAuditSession && liveRunId == AuditSessionStore.currentRunId(MainActivity.this)) {
                        if (stopped) {
                            statusText.setText("Проверка остановлена");
                            resultText.setText("Проверка остановлена пользователем. Данные Cubux не изменялись.");
                            db.saveState("last_check_state","STOPPED");
                            db.saveState("last_check_message","Проверка остановлена пользователем.");
                            refreshLastCheckStatus();
                            AuditSessionStore.finish(MainActivity.this,liveRunId,AuditSessionStore.STOPPED,"Проверка остановлена пользователем");
                        } else {
                            statusText.setText("ПРОВЕРКА ОСТАНОВЛЕНА");
                            resultText.setText("Причина:\n" + msg);
                            CheckStatusStore.failure(MainActivity.this, AuditCoordinator.MODE_FULL.equals(activeCheckMode) ? "Полная проверка" : "Быстрая проверка", Math.max(1,retries), msg);
                            refreshLastCheckStatus();
                            AuditSessionStore.finish(MainActivity.this,liveRunId,AuditSessionStore.ERROR,msg);
                        }
                    }
                    finishManualSession(sessionId,sessionControl,liveRunId);
                });
            }
        },"CubuxManualCheck").start();
    }

    private void finishManualSession(long sessionId,AuditControl sessionControl,long liveRunId) {
        AuditControlRegistry.clear(sessionControl);
        if (liveRunId == AuditSessionStore.currentRunId(this)) AuditForegroundService.stop(this);
        if (sessionId == activeAuditSession && auditControl == sessionControl) {
            auditRunning=false; auditControl=null;
            recoverStoppedAuditUi();
        }
    }

    private void togglePause() {
        final AuditControl control = auditControl != null ? auditControl : AuditControlRegistry.current();
        if (!isAuditSessionActive() || control == null || control.isStopped()) return;
        long liveRunId=AuditSessionStore.currentRunId(this);
        AuditForegroundService.Snapshot snap=AuditForegroundService.snapshot(this);
        if (control.isPaused()) {
            control.resume(); AuditSessionStore.resume(this,liveRunId);
            DiagnosticLog.write(this, "CONTROL", "Продолжить проверку");
            CheckStatusStore.event(this, "INFO", "ПРОВЕРКА", "Проверка продолжена пользователем");
            AuditForegroundService.update(this,"Проверка продолжается",snap.percent,snap.page,snap.pages,snap.loaded,snap.total);
            pauseButton.setText("⏸  ПАУЗА"); statusText.setText("Продолжаю проверку...");
            if (percentText != null) percentText.setText(percentLabel(maxPercentShown));
            refreshCheckModeUi();
        } else {
            control.pause(); AuditSessionStore.pause(this,liveRunId);
            DiagnosticLog.write(this, "CONTROL", "Пауза проверки");
            CheckStatusStore.event(this, "INFO", "ПРОВЕРКА", "Проверка поставлена на паузу пользователем");
            AuditForegroundService.update(this,"Проверка на паузе",snap.percent,snap.page,snap.pages,snap.loaded,snap.total);
            pauseButton.setText("▶  ПРОДОЛЖИТЬ"); statusText.setText("На паузе");
            if (percentText != null) percentText.setText(percentLabel(maxPercentShown));
            snap = AuditForegroundService.snapshot(this);
            detailsText.setText("Сейчас: проверка поставлена на паузу" +
                    "\nЭтап: " + stageName(currentStageForUi) +
                    "\nПрогресс: " + snap.loaded + " операций • страница " + snap.page +
                    "\nЗапросы: приостановлены пользователем" +
                    "\nПрошло: " + TimeUtil.formatDuration(snap.elapsedMs) + " • таймер на паузе" +
                    "\nСостояние: нажмите «Продолжить», чтобы продолжить с этого места");
            refreshCheckModeUi();
        }
    }

    private void stopAudit() {
        final AuditControl control = auditControl != null ? auditControl : AuditControlRegistry.current();
        if (!isAuditSessionActive() || control == null || control.isStopped()) return;
        long liveRunId=AuditSessionStore.currentRunId(this);
        AuditForegroundService.Snapshot snap=AuditForegroundService.snapshot(this);
        AuditSessionStore.stopping(this,liveRunId);
        control.stop();
        DiagnosticLog.write(this, "CONTROL", "Остановить проверку");
        CheckStatusStore.event(this, "WARNING", "ПРОВЕРКА", "Проверка остановлена пользователем");
        AuditForegroundService.update(this,"Останавливаю проверку…",snap.percent,snap.page,snap.pages,snap.loaded,snap.total);
        pauseButton.setEnabled(false); stopButton.setEnabled(false); statusText.setText("Останавливаю проверку...");
        refreshCheckModeUi();
        detailsText.setText("Сейчас: останавливаю проверку" +
                "\nЭтап: отмена текущего запроса Cubux" +
                "\nПрогресс: " + snap.loaded + " операций • страница " + snap.page +
                "\nЗапросы: новые запросы не отправляются" +
                "\nПрошло: " + TimeUtil.formatDuration(snap.elapsedMs) +
                "\nСостояние: незавершённые данные не будут записаны в эталон");
    }

    private AuditProgressListener progressListener(
            final long sessionId,
            final AuditControl sessionControl
    ) {
        return new AuditProgressListener() {

            private boolean isCurrent() {
                return sessionId == activeAuditSession
                        && auditRunning
                        && auditControl == sessionControl
                        && !sessionControl.isStopped();
            }

            @Override
            public void onStage(
                    String stage,
                    String message
            ) {
                if (!isCurrent() || sessionControl.isPaused()) return;

                // A normal inter-request delay is only auxiliary information. It must never
                // replace the explanation of what the scan itself is doing.
                if ("GENTLE_WAIT".equals(stage) || "SERVER_COOLDOWN".equals(stage)) {
                    currentWaitForUi = message == null ? "" : message;
                    AuditForegroundService.updateNote(MainActivity.this, currentWaitForUi);
                    runOnUiThread(() -> detailsText.setText(runningDetails(AuditForegroundService.snapshot(MainActivity.this))));
                    return;
                }

                currentWaitForUi = "";
                boolean newScanPhase=false;
                if ("AUTO_FULL".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0; maxStageIndexShown=0;
                    currentStageForUi=stage; newScanPhase=true;
                    scanContext = "Полная проверка после лёгкой";
                    AuditForegroundService.resetPageProgress(MainActivity.this);
                } else if ("STABILITY_FALLBACK_SCAN".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0; maxStageIndexShown=0;
                    currentStageForUi=stage; newScanPhase=true;
                    scanContext = "Контроль стабильности — аварийный полный проход";
                    AuditForegroundService.resetPageProgress(MainActivity.this);
                } else if ("HISTORY_RESCAN".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0; maxStageIndexShown=0;
                    currentStageForUi=stage; newScanPhase=true;
                    scanContext = "Повторная проверка изменённого периода";
                    AuditForegroundService.resetPageProgress(MainActivity.this);
                } else if ("LIGHT_DEEP".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0; maxStageIndexShown=0;
                    currentStageForUi=stage; newScanPhase=true;
                    scanContext = "Подробная проверка изменённого периода";
                    AuditForegroundService.resetPageProgress(MainActivity.this);
                } else if ("READ_COMPLETE".equals(stage)) {
                    scanContext = "Основное чтение завершено";
                }
                if(!newScanPhase)stableStageForUi(stage);
                int stagePercent = stagePercent(stage, maxPercentShown);
                maxPercentShown = Math.max(maxPercentShown, stagePercent);
                AuditForegroundService.updateStage(MainActivity.this, currentStageForUi, message, maxPercentShown,
                        maxPageShown, AuditForegroundService.pages, maxLoadedShown, AuditForegroundService.total);
                CheckStatusStore.activity(MainActivity.this, message);
                runOnUiThread(() -> {
                    if (sessionId != activeAuditSession) return;
                    progressBar.setProgress(maxPercentShown);
                    percentText.setText(percentLabel(maxPercentShown));
                    statusText.setText(message);
                    updateStageIndicators(stage);
                    detailsText.setText(runningDetails(AuditForegroundService.snapshot(MainActivity.this)));
                });
            }

            @Override
            public void onMeta(
                    int total,
                    int pages
            ) {
                if (!isCurrent()) return;
                AuditForegroundService.update(MainActivity.this, "Получены параметры проверки", maxPercentShown,
                        maxPageShown, pages, maxLoadedShown, total);
                runOnUiThread(() -> detailsText.setText(runningDetails(AuditForegroundService.snapshot(MainActivity.this))));
            }

            @Override
            public void onPage(
                    int page,
                    int pages,
                    int loaded,
                    int total
            ) {
                if (!isCurrent() || sessionControl.isPaused()) return;
                updateProgress(
                        sessionId,
                        sessionControl,
                        page,
                        pages,
                        loaded,
                        total
                );
            }

            @Override
            public void onRetry(
                    int page,
                    int attempt,
                    int retrySeconds,
                    String error
            ) {
                if (!isCurrent()) return;
                retries++;

                boolean online = isNetworkAvailable();
                String retryStatus;
                if (!online) retryStatus = "Нет подключения к интернету. Проверка приостановлена.";
                else if (error != null && error.contains("HTTP 429")) retryStatus = "Cubux временно ограничил частоту запросов.";
                else if (error != null && error.matches(".*HTTP 5\\d\\d.*")) retryStatus = "Сервер Cubux временно недоступен.";
                else retryStatus = "Интернет есть, но Cubux временно не отвечает.";
                currentWaitForUi = retryStatus + " Повтор через " + retrySeconds + " сек. • попытка " + attempt;
                AuditForegroundService.updateNote(MainActivity.this, currentWaitForUi);
                CheckStatusStore.event(MainActivity.this, "WARNING", "СЕТЬ/CUBUX", currentWaitForUi);

                runOnUiThread(
                        () -> {
                            statusText.setText(retryStatus);
                            detailsText.setText(runningDetails(AuditForegroundService.snapshot(MainActivity.this)));
                        }
                );
            }
        };
    }


private int stagePercent(String stage, int current) {
    if (stage == null) return current;
    if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return Math.max(current, 1);
    if ("TEAM".equals(stage) || "RANGE".equals(stage) || "LOADING_META".equals(stage)) return Math.max(current, 3);
    if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return Math.max(current, 8);
    if ("LIGHT_SUMMARY".equals(stage)) return Math.max(current, 18);
    if ("LIGHT_MONTHLY".equals(stage) || "LIGHT_BASELINE_MIGRATION".equals(stage)) return Math.max(current, 20);
    if ("LIGHT_NO_CHANGES".equals(stage)) return Math.max(current, 94);
    if ("LIGHT_MISMATCH".equals(stage)) return Math.max(current, 28);
    if ("LIGHT_DEEP".equals(stage)) return Math.max(current, 32);
    if ("READ_COMPLETE".equals(stage)) return Math.max(current, 86);
    if ("STABILITY_START".equals(stage)) return Math.max(current, 3);
    if ("MONTHLY_CONTROL_START".equals(stage) || "MONTHLY_CONTROL".equals(stage)) return Math.max(current, 4);
    if ("STABILITY_VERIFY".equals(stage) || "MONTHLY_CONTROL_VERIFY".equals(stage) || "MONTHLY_CONTROL_SWITCH".equals(stage) || "STABILITY_FALLBACK".equals(stage)) return Math.max(current, 88);
    if ("STABILITY_FALLBACK_SCAN".equals(stage) || "STABILITY_EMERGENCY".equals(stage) || "HISTORY_RESCAN".equals(stage) || "HISTORY_MOVED".equals(stage)) return Math.max(current, 89);
    if ("STABILITY_OK".equals(stage)) return Math.max(current, 90);
    if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return Math.max(current, 92);
    if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return Math.max(current, 95);
    if ("CONTROL_BASELINE".equals(stage) || "LIGHT_BASELINE_REFRESH".equals(stage) || "LIGHT_BASELINE_READY".equals(stage)) return Math.max(current, 96);
    if ("SAVING".equals(stage)) return Math.max(current, 98);
    if ("BACKUP".equals(stage) || "BACKUP_OK".equals(stage) || "BACKUP_WARNING".equals(stage) || "CREATING_REPORT".equals(stage)) return Math.max(current, 99);
    if ("COMPLETED".equals(stage)) return 100;
    return current;
}

private boolean isNetworkAvailable() {
    return NetworkUtil.hasInternet(this);
}

    private void updateProgress(
            long sessionId,
            AuditControl sessionControl,
            int page,
            int pages,
            int loaded,
            int total
    ) {
        if (sessionId != activeAuditSession || !auditRunning) return;

        // Never allow stale/retried callbacks to move UI backwards.
        if (page < maxPageShown || loaded < maxLoadedShown) return;

        maxPageShown = Math.max(maxPageShown, page);
        maxLoadedShown = Math.max(maxLoadedShown, loaded);
        long elapsed = sessionControl.activeElapsedMs(startedMs);

        int rawPercent =
                total <= 0
                        ? 0
                        : (int) (
                                5.0 + loaded *
                                        80.0 /
                                        total
                        );

        final int percent =
                Math.max(
                        maxPercentShown,
                        Math.min(85, rawPercent)
                );

        maxPercentShown = percent;

        double speed =
                loaded /
                        Math.max(
                                1,
                                elapsed /
                                        1000.0
                        );

        String readStatus = scanContext == null || scanContext.isEmpty()
                ? "Читаю операции из Cubux"
                : scanContext + ": читаю операции из Cubux";
        stableStageForUi("READING_DATA");
        currentWaitForUi = "";
        AuditForegroundService.updateStage(this, currentStageForUi, readStatus, percent,
                maxPageShown, pages, maxLoadedShown, total);

        runOnUiThread(
                () -> {
                    if (sessionId != activeAuditSession || !auditRunning) return;
                    if (auditControl != sessionControl || sessionControl.isPaused() || sessionControl.isStopped()) return;
                    progressBar.setProgress(
                            Math.min(
                                    100,
                                    percent
                            )
                    );

                    percentText.setText(percentLabel(percent));

                    statusText.setText(readStatus);
                    updateStageIndicators("READING_DATA");
                    detailsText.setText(runningDetails(AuditForegroundService.snapshot(MainActivity.this)));
                }
        );
    }

    private CharSequence runningDetails(AuditForegroundService.Snapshot s) {
        if (s == null) s = AuditForegroundService.snapshot(MainActivity.this);
        String stage = (s.stage == null || s.stage.isEmpty()) ? currentStageForUi : s.stage;
        String rawAction = (s.state == null || s.state.trim().isEmpty()) ? "Выполняю проверку" : s.state.trim();
        String action = actionDescription(stage, rawAction);
        String progress = progressDescription(s, rawAction);
        String detail = actionDetailDescription(stage, rawAction, s);
        String speed = "Скорость: " + DelayProfile.label(new CheckSettings(this).requestDelayMs());
        String elapsed = "Прошло: " + TimeUtil.formatDuration(s.elapsedMs);
        String activity = "Последняя активность: " + (s.updatedAt > 0L ? new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new java.util.Date(s.updatedAt)) : "—");
        String note = (s.note != null && !s.note.trim().isEmpty()) ? s.note.trim() : currentWaitForUi;
        if (note == null || note.trim().isEmpty()) note = "этап выполняется, данные обновляются";
        if (note.startsWith("Состояние:")) note = note.substring("Состояние:".length()).trim();
        String text = "Сейчас: " + action +
                "\nЭтап: " + stageName(stage) +
                "\n" + progress +
                "\nДействие: " + detail +
                "\n" + speed +
                "\n" + elapsed +
                "\n" + activity +
                "\nСостояние: " + note;
        return boldCurrentAction(text);
    }

    private CharSequence boldCurrentAction(String text){
        SpannableStringBuilder out=new SpannableStringBuilder(text==null?"":text);
        int boldStart="Сейчас: ".length();
        int boldEnd=out.toString().indexOf('\n'); if(boldEnd<0)boldEnd=out.length();
        if(boldEnd>boldStart)out.setSpan(new StyleSpan(Typeface.BOLD),boldStart,boldEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return out;
    }

    private String actionDetailDescription(String stage,String raw,AuditForegroundService.Snapshot s){
        if(stage==null)return "выполняю текущий этап проверки";
        if("PREPARING".equals(stage)||"START".equals(stage))return "проверяю настройки, локальную базу и готовность к запуску";
        if("AUTHENTICATING".equals(stage)||"REAUTHENTICATING".equals(stage))return "проверяю доступ к Cubux и получаю рабочий токен";
        if("TEAM".equals(stage))return "получаю команду и идентификатор данных Cubux";
        if("RANGE".equals(stage))return "определяю границы закрытой истории для проверки";
        if("LOADING_META".equals(stage))return "получаю число операций и страниц перед чтением";
        if("READING_DATA".equals(stage))return "загружаю следующую страницу операций последовательно";
        if(stage.startsWith("LIGHT")||stage.startsWith("MONTHLY_CONTROL"))return "сравниваю контрольные данные с локальным эталоном без лишней полной загрузки";
        if(stage.startsWith("STABILITY")||"HISTORY_MOVED".equals(stage)||"HISTORY_RESCAN".equals(stage))return "убеждаюсь, что данные не менялись во время сканирования";
        if("PROCESSING".equals(stage)||"CLOSE_EMPTY_DAYS".equals(stage))return "проверяю закрытые дни и формирую безопасный эталон";
        if("COMPARING".equals(stage)||"CHECKING_HISTORY".equals(stage))return "ищу новые, изменённые и удалённые записи";
        if("SAVING".equals(stage))return "атомарно сохраняю только подтверждённый результат";
        if(stage.startsWith("BACKUP"))return "создаю резервную копию локальной базы";
        if("NO_INTERNET".equals(stage))return "жду сеть; незавершённые данные не сохраняются";
        if("RETRY_WAIT".equals(stage)||"WAITING_CUBUX".equals(stage))return "повторяю тот же запрос после защитной паузы";
        if("COMPLETED".equals(stage))return "все этапы завершены, результат сохранён";
        return raw==null||raw.trim().isEmpty()?"выполняю текущий этап проверки":raw.trim();
    }

    private String actionDescription(String stage, String raw) {
        if (stage == null) return raw;
        if ("PREPARING".equals(stage)) return "подготавливаю проверку";
        if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return "проверяю и обновляю авторизацию Cubux";
        if ("TEAM".equals(stage)) return "получаю данные команды Cubux";
        if ("RANGE".equals(stage)) return "определяю диапазон закрытой истории";
        if ("LOADING_META".equals(stage)) return "получаю количество операций и страниц";
        if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return "проверяю метаданные закрытой истории";
        if ("LIGHT_SUMMARY".equals(stage)) return "сверяю контрольные суммы без полной загрузки";
        if ("LIGHT_MONTHLY".equals(stage) || "MONTHLY_CONTROL".equals(stage) || "MONTHLY_CONTROL_START".equals(stage) || "MONTHLY_CONTROL_VERIFY".equals(stage)) return "сверяю контрольные данные истории по месяцам";
        if ("LIGHT_BASELINE_MIGRATION".equals(stage)) return "создаю лёгкий эталон из существующей локальной базы";
        if ("LIGHT_MISMATCH".equals(stage)) return "локализую период, в котором найдено расхождение";
        if ("LIGHT_DEEP".equals(stage)) return "подробно проверяю только изменившийся период";
        if ("LIGHT_NO_CHANGES".equals(stage)) return "контрольные данные совпали, изменений нет";
        if ("AUTO_FULL".equals(stage) || "BASELINE_REQUIRED".equals(stage)) return "готовлю переход к полной проверке";
        if ("WAITING_CUBUX".equals(stage)) return "жду ответ Cubux на текущий запрос";
        if ("READING_DATA".equals(stage)) return "читаю операции из Cubux";
        if ("READ_COMPLETE".equals(stage)) return "основная загрузка завершена, проверяю результат";
        if ("STABILITY_START".equals(stage) || "STABILITY_VERIFY".equals(stage)) return "проверяю, не менялась ли история во время сканирования";
        if ("HISTORY_MOVED".equals(stage)) return "обнаружено изменение истории, уточняю изменившийся период";
        if ("HISTORY_RESCAN".equals(stage)) return "повторно читаю только изменившийся период";
        if ("STABILITY_EMERGENCY".equals(stage) || "STABILITY_FALLBACK".equals(stage) || "STABILITY_FALLBACK_SCAN".equals(stage)) return "выполняю аварийный контроль стабильности";
        if ("STABILITY_OK".equals(stage)) return "стабильность истории подтверждена";
        if ("STABILITY_WAIT".equals(stage)) return "жду стабилизации изменившегося периода";
        if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return "проверяю целостность закрытых дней";
        if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return "сравниваю подтверждённые данные с локальным эталоном";
        if ("CONTROL_BASELINE".equals(stage) || "LIGHT_BASELINE_READY".equals(stage)) return "готовлю контрольный эталон для следующих проверок";
        if ("SAVING".equals(stage)) return "сохраняю подтверждённый результат в локальную базу";
        if (stage.startsWith("BACKUP")) return "создаю резервную копию базы Cubux Security";
        if ("NO_INTERNET".equals(stage)) return "жду восстановления подключения к интернету";
        if ("INTERNET_RESTORED".equals(stage) || "RECONNECTING".equals(stage)) return "восстанавливаю прерванное подключение и продолжаю";
        if ("RETRY_WAIT".equals(stage) || "WAITING_CUBUX".equals(stage)) return "жду повторного запроса к Cubux";
        if ("AUTH_ERROR".equals(stage) || "PERMANENT_ERROR".equals(stage)) return "проверка остановлена из-за ошибки Cubux";
        if ("COMPLETED".equals(stage)) return "проверка завершена успешно";
        return raw;
    }

    private String progressDescription(AuditForegroundService.Snapshot s, String action) {
        String st = (s.stage == null || s.stage.isEmpty()) ? currentStageForUi : s.stage;
        String marker = "Контроль по месяцам:";
        int i = action.indexOf(marker);
        if (i >= 0) {
            String x = action.substring(i + marker.length()).trim();
            int dot = x.indexOf(". Полная");
            if (dot > 0) x = x.substring(0, dot);
            return "Прогресс: месяц " + x;
        }
        if (action.contains("периоде ")) {
            int p = action.indexOf("периоде ");
            String x = action.substring(p + 8).replace(". Проверяю его подробно...", "").trim();
            return "Прогресс: период " + x;
        }
        if ("BACKUP".equals(st) || "BACKUP_OK".equals(st) || "BACKUP_WARNING".equals(st)) return "Прогресс: создаю и проверяю резервную копию базы";
        if ("SAVING".equals(st)) return "Прогресс: сохраняю подтверждённый результат";
        if ("COMPARING".equals(st) || "CHECKING_HISTORY".equals(st)) return "Прогресс: сравниваю данные с локальным эталоном";
        if ("PROCESSING".equals(st) || "CLOSE_EMPTY_DAYS".equals(st)) return "Прогресс: проверяю целостность закрытых дней";
        if ("CONTROL_BASELINE".equals(st) || "LIGHT_BASELINE_READY".equals(st) || "LIGHT_BASELINE_MIGRATION".equals(st)) return "Прогресс: готовлю контрольный эталон для следующих лёгких проверок";
        if ("LIGHT_NO_CHANGES".equals(st)) return "Прогресс: контроль завершён, подробная загрузка не требуется";
        if ("READ_COMPLETE".equals(st)) return "Прогресс: основная загрузка завершена полностью";
        if ("STABILITY_VERIFY".equals(st) || "MONTHLY_CONTROL_VERIFY".equals(st) || "STABILITY_START".equals(st)) return "Прогресс: проверяю, не менялась ли история во время чтения";
        if (s.total > 0 && ("READING_DATA".equals(st) || "WAITING_CUBUX".equals(st) || "RETRY_WAIT".equals(st) || "NO_INTERNET".equals(st) || "INTERNET_RESTORED".equals(st))) {
            return "Прогресс: " + s.loaded + " из " + s.total + " операций • страница " + s.page + " из " + s.pages;
        }
        if (s.total > 0) return "Прогресс: подтверждено " + s.loaded + " из " + s.total + " операций";
        return "Прогресс: выполняется текущий этап";
    }

    private String stageName(String stage) {
        if (stage == null || stage.isEmpty() || "IDLE".equals(stage) || "PREPARING".equals(stage) || "START".equals(stage)) return "подготовка";
        if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return "авторизация Cubux";
        if ("TEAM".equals(stage)) return "получение данных команды";
        if ("RANGE".equals(stage) || "LOADING_META".equals(stage)) return "определение диапазона и объёма данных";
        if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return "лёгкая проверка — метаданные";
        if ("LIGHT_SUMMARY".equals(stage)) return "лёгкая проверка — контрольные суммы";
        if ("LIGHT_MONTHLY".equals(stage) || "MONTHLY_CONTROL".equals(stage) || "MONTHLY_CONTROL_START".equals(stage)) return "контроль истории по месяцам";
        if ("LIGHT_BASELINE_MIGRATION".equals(stage) || "LIGHT_BASELINE_READY".equals(stage) || "CONTROL_BASELINE".equals(stage)) return "контрольный эталон лёгкой проверки";
        if ("LIGHT_MISMATCH".equals(stage)) return "поиск проблемного периода";
        if ("LIGHT_DEEP".equals(stage)) return "подробная проверка изменённого периода";
        if ("LIGHT_NO_CHANGES".equals(stage)) return "лёгкая проверка — расхождений нет";
        if ("AUTO_FULL".equals(stage) || "BASELINE_REQUIRED".equals(stage)) return "переход к полной проверке";
        if ("READING_DATA".equals(stage)) return "чтение операций Cubux";
        if ("READ_COMPLETE".equals(stage)) return "основная загрузка завершена";
        if (stage.startsWith("STABILITY") || stage.startsWith("MONTHLY_CONTROL") || "HISTORY_MOVED".equals(stage) || "HISTORY_RESCAN".equals(stage)) return "контроль стабильности истории";
        if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return "проверка целостности закрытых дней";
        if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return "сравнение с локальным эталоном";
        if ("SAVING".equals(stage)) return "сохранение результата";
        if (stage.startsWith("BACKUP")) return "резервная копия";
        if ("NO_INTERNET".equals(stage)) return "ожидание интернета";
        if ("INTERNET_RESTORED".equals(stage) || "RECONNECTING".equals(stage)) return "восстановление соединения";
        if ("RETRY_WAIT".equals(stage) || "WAITING_CUBUX".equals(stage)) return "повтор запроса Cubux";
        if ("AUTH_ERROR".equals(stage) || "PERMANENT_ERROR".equals(stage)) return "ошибка проверки";
        if ("COMPLETED".equals(stage)) return "готово";
        return stage.replace('_', ' ').toLowerCase(Locale.getDefault());
    }

    private boolean isNewScanPhaseStage(String stage) {
        return "AUTO_FULL".equals(stage)
                || "STABILITY_FALLBACK_SCAN".equals(stage)
                || "HISTORY_RESCAN".equals(stage)
                || "LIGHT_DEEP".equals(stage);
    }

    private void updateStageIndicators(String stage) {
        String st;
        int current;
        if (isNewScanPhaseStage(stage)) {
            // These stages start a fresh read pass inside the same audit. Do not let the
            // monotonic stage guard lock the UI at the later comparison/history row.
            currentStageForUi = stage;
            maxStageIndexShown = 0;
            st = stage;
            current = 3;
        } else {
            st = stableStageForUi(stage);
            current = maxStageIndexShown;
            if (current == 0 && isAuditSessionActive()) {
                current = 1;
                maxStageIndexShown = 1;
            }
        }

        for(int i=0;i<stageRows.length;i++){
            TextView name=stageRows[i];
            TextView icon=stageIconViews[i];
            TextView status=stageStatusViews[i];
            if(name==null||icon==null||status==null)continue;
            int pos=i+1;
            boolean done=current>pos || (current==8 && pos==8 && "COMPLETED".equals(st));
            boolean active=current==pos && !"COMPLETED".equals(st);
            if(done){
                icon.setText("✓");
                icon.setTextColor(Color.WHITE);
                icon.setBackground(rounded(GREEN,20));
                name.setTextColor(Color.rgb(58,82,118));
                name.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
                status.setText("Готово");
                status.setTextColor(GREEN);
            }else if(active){
                icon.setText("✓");
                icon.setTextColor(Color.WHITE);
                icon.setBackground(rounded(BLUE,20));
                name.setTextColor(DARK);
                name.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
                status.setText("В процессе");
                status.setTextColor(BLUE);
            }else{
                icon.setText("○");
                icon.setTextColor(Color.rgb(88,111,151));
                icon.setBackgroundColor(Color.TRANSPARENT);
                name.setTextColor(MUTED);
                name.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
                status.setText("Ожидание");
                status.setTextColor(MUTED);
            }
        }
        refreshCurrentStageSummary(st);
    }

    private void refreshCurrentStageSummary(String stage){
        if(currentStageSummaryTitle==null||currentStageSummaryBody==null)return;
        String st=stage==null?"":stage;
        if((st.isEmpty()||"IDLE".equals(st)) && !isAuditSessionActive()){
            currentStageSummaryTitle.setText("Текущий этап:  ожидание");
            currentStageSummaryBody.setText("Ожидание запуска проверки.");
            currentStageSummaryBody.setTextColor(MUTED);
            return;
        }
        if("COMPLETED".equals(st)){
            currentStageSummaryTitle.setText("Текущий этап:  Проверка завершена");
            int nn=parseIntState("last_check_new"), cc=parseIntState("last_check_changed"), dd=parseIntState("last_check_deleted");
            if(nn==0&&cc==0&&dd==0){
                currentStageSummaryBody.setText("Проверка прошла успешно, изменений нет.");
                currentStageSummaryBody.setTextColor(GREEN);
            }else{
                currentStageSummaryBody.setText("Найдены изменения: новые — "+nn+", изменённые — "+cc+", удалённые — "+dd+".");
                currentStageSummaryBody.setTextColor(RED);
            }
            return;
        }
        if(st.contains("ERROR")||st.contains("PERMANENT")){
            currentStageSummaryTitle.setText("Текущий этап:  Проверка завершена с ошибкой");
            currentStageSummaryBody.setText("Откройте историю событий, чтобы увидеть причину ошибки.");
            currentStageSummaryBody.setTextColor(RED);
            return;
        }
        currentStageSummaryTitle.setText("Текущий этап:  "+stageName(st));
        currentStageSummaryBody.setText(actionDetailDescription(st,"",AuditForegroundService.snapshot(MainActivity.this)));
        currentStageSummaryBody.setTextColor(MUTED);
    }

    private int parseIntSafe(String value){
        try{return Integer.parseInt(value==null?"0":value.trim());}catch(Throwable ignored){return 0;}
    }

    private void setStageStep(TextView view, String icon, String caption, int color) {
        if (view == null) return;
        view.setText(icon + "\n" + caption);
        view.setTextColor(color);
    }

    private void showResult(
            AuditEngine.Result r
    ) {
        try {
            CheckScheduler.scheduleNext(this);
            refreshAutoAuditStatus();
            requestNotificationPermissionIfNeeded();
        } catch (Throwable ignored) {
        }

        progressBar.setProgress(100);

        percentText.setText(percentLabel(100));
        if (progressAmountText != null) progressAmountText.setText(r.total + " из " + r.total + " операций");
        refreshCheckModeUi();

        updateStageIndicators("COMPLETED");
        if (pauseButton != null) pauseButton.setVisibility(View.GONE);
        if (stopButton != null) stopButton.setVisibility(View.GONE);
        String actualMode = db.getState("last_audit_mode");
        String checkLabel = AuditCoordinator.MODE_FULL.equals(activeCheckMode) ? "Полная проверка" :
                ("FULL_AFTER_LIGHT".equals(actualMode) ? "Быстрая → полная проверка" : "Быстрая проверка");
        CheckStatusStore.success(this, checkLabel, r);
        int visibleNew=db.visibleLastCheckMetric("last_check_new");
        int visibleChanged=db.visibleLastCheckMetric("last_check_changed");
        int visibleDeleted=db.visibleLastCheckMetric("last_check_deleted");
        int visibleChanges=visibleNew+visibleChanged+visibleDeleted;
        String finalMessage=visibleChanges==0 ? "Проверка прошла успешно, изменений нет" :
                "Найдены изменения: новые "+visibleNew+", изменённые "+visibleChanged+", удалённые "+visibleDeleted;
        AuditForegroundService.updateStage(this, "COMPLETED", finalMessage, 100,
                maxPageShown, AuditForegroundService.pages, maxLoadedShown, AuditForegroundService.total);
        statusText.setText(finalMessage);
        refreshCurrentStageSummary("COMPLETED");
        refreshLastCheckStatus();
        refreshDashboardInformer();

        long nextMs = parseLongState("next_scheduled_check_ms");
        String nextType = db.getState("next_scheduled_check_type");
        String nextText = nextMs > 0
                ? ((CheckSettings.TYPE_FULL.equals(nextType) ? "Полная" : "Быстрая") + " • " +
                   new java.text.SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(new java.util.Date(nextMs)))
                : "не запланирована";

        detailsText.setText(
                "Сейчас: " + (visibleChanges==0?"проверка прошла успешно, изменений нет":"найдены изменения") +
                        "\nЭтап: готово" +
                        "\nПроверено: " + r.total + " операций" +
                        "\nРезультат: новые " + visibleNew + " • изменённые " + visibleChanged + " • удалённые " + visibleDeleted +
                        "\nВремя проверки: " + TimeUtil.formatDuration(r.durationMs) +
                        "\nСледующая проверка: " + nextText
        );

        setStat(
                totalTop,
                "▤",
                r.total,
                "Всего операций"
        );

        setStat(
                newTop,
                "+",
                visibleNew,
                "Новые"
        );

        setStat(
                changedTop,
                "✎",
                visibleChanged,
                "Изменённые"
        );

        setStat(
                deletedTop,
                "▥",
                visibleDeleted,
                "Удалённые"
        );

        setMiniStat(
                newCard,
                "▤",
                visibleNew,
                "Новые"
        );

        setMiniStat(
                changedCard,
                "✎",
                visibleChanged,
                "Изменённые"
        );

        setMiniStat(
                deletedCard,
                "▥",
                visibleDeleted,
                "Удалённые"
        );

        setMiniStat(
                closedCard,
                "▣",
                r.closedChangedCount,
                "Закрытые"
        );

        setMiniStat(
                multiCard,
                "↻",
                r.multiChangedCount,
                "Повторные"
        );

        resultText.setText(
                "Целостность: ОК • Cubux: только чтение"
        );
    }

    private void setStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        if (view == null) return;
        int accent = "Новые".equals(caption) ? GREEN : "Изменённые".equals(caption) ? YELLOW : "Удалённые".equals(caption) ? RED : BLUE;
        String raw="●\u00A0"+caption+"\n"+value;
        SpannableStringBuilder sp=new SpannableStringBuilder(raw);
        sp.setSpan(new ForegroundColorSpan(accent),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int captionStart=raw.indexOf(caption);
        if(captionStart>=0)sp.setSpan(new StyleSpan(Typeface.BOLD),captionStart,captionStart+caption.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int start=raw.lastIndexOf(String.valueOf(value));
        if(start>=0){sp.setSpan(new StyleSpan(Typeface.BOLD),start,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new RelativeSizeSpan(1.7f),start,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new ForegroundColorSpan(DARK),start,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
        view.setTextSize(9);
        view.setMaxLines(2);
        view.setGravity(Gravity.CENTER);
        view.setText(sp);
    }

    private void setMiniStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        if (view == null) return;
        view.setText(
                icon +
                        "\n" +
                        value +
                        "\n" +
                        caption
        );
    }

    private void showLoginDialog(
            boolean runAfterSave
    ) {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        int pad = dp(18);

        box.setPadding(
                pad,
                0,
                pad,
                0
        );

        EditText login =
                new EditText(this);

        login.setHint(
                "Логин Cubux"
        );

        login.setSingleLine(true);

        login.setText(
                credentials.getLogin()
        );

        EditText password =
                new EditText(this);

        password.setHint(
                "Пароль Cubux"
        );

        password.setSingleLine(true);

        password.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        box.addView(login);
        box.addView(password);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Авторизация Cubux"
                )
                .setMessage(
                        "Приложение само получит и будет обновлять API-токен."
                )
                .setView(box)
                .setPositiveButton(
                        "Сохранить",
                        (d, w) -> {
                            try {
                                credentials.saveCredentials(
                                        login.getText()
                                                .toString()
                                                .trim(),
                                        password.getText()
                                                .toString()
                                );

                                credentials.clearToken();

                                Toast.makeText(
                                        this,
                                        "Данные сохранены",
                                        Toast.LENGTH_SHORT
                                ).show();

                                if (runAfterSave) {
                                    runAudit();
                                }

                            } catch (Exception e) {
                                Toast.makeText(
                                        this,
                                        "Ошибка сохранения",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void showSettingsDialog() {
        CheckSettings cfg = new CheckSettings(this);
        String[] items = {
                "Логин и пароль Cubux",
                "Автопроверка и автозапуск",
                "Расписание лёгкой проверки",
                "Расписание полной проверки",
                "Повторных попыток: " + cfg.retries(),
                "Пауза между запросами: " + DelayProfile.label(cfg.requestDelayMs()),
                "Расширенная диагностика",
                "Удалить данные авторизации"
        };

        new AlertDialog.Builder(this)
                .setTitle("Настройки")
                .setItems(items, (d, which) -> {
                    if (which == 0) showLoginDialog(false);
                    else if (which == 1) showAutoStartSettings();
                    else if (which == 2) scheduleSettingsDialog(CheckSettings.TYPE_LIGHT);
                    else if (which == 3) scheduleSettingsDialog(CheckSettings.TYPE_FULL);
                    else if (which == 4) retrySettingsDialog();
                    else if (which == 5) delaySettingsDialog();
                    else if (which == 6) showAdvancedDiagnosticsDialog();
                    else {
                        credentials.clearAll();
                        CheckScheduler.cancel(this);
                        Toast.makeText(this, "Логин, пароль и токен удалены", Toast.LENGTH_SHORT).show();
                        refreshAutoAuditStatus();
                    }
                }).show();
    }

    private void showAutoStartSettings() {
        CheckSettings cfg=new CheckSettings(this);boolean exact=CheckScheduler.canScheduleExact(this);long next=parseLongState("next_scheduled_check_ms");long last=parseLongState("last_scheduled_start_ms");
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(12),dp(4),dp(12),dp(6));
        boolean enabled=(cfg.lightDays()!=0||cfg.fullDays()!=0);TextView state=label(enabled?"✓ Автопроверка включена":"Автопроверка выключена",12,true,enabled?Color.rgb(22,145,86):MUTED);state.setPadding(dp(10),dp(9),dp(10),dp(9));state.setBackground(rounded(enabled?Color.rgb(234,250,241):Color.rgb(245,247,250),11));body.addView(state);
        body.addView(scheduleInfoRow("Быстрая проверка",cfg.lightTime()+"  •  "+daysText(cfg.lightDays()),R.drawable.ic_clock,v->scheduleSettingsDialog(CheckSettings.TYPE_LIGHT)));
        body.addView(scheduleInfoRow("Полная проверка",cfg.fullTime()+"  •  "+daysText(cfg.fullDays()),R.drawable.ic_closed_periods,v->scheduleSettingsDialog(CheckSettings.TYPE_FULL)));
        String nextText=next>0?new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new java.util.Date(next)):"не запланирована";body.addView(scheduleInfoRow("Следующая проверка",nextText,R.drawable.ic_clock,null));
        String lastText=last>0?new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new java.util.Date(last)):"ещё не запускалась";body.addView(scheduleInfoRow("Последний автозапуск",lastText,R.drawable.ic_play,null));
        if(!exact){TextView warn=label("⚠ Android не разрешил точные будильники. Запуск может немного сдвигаться.",8,false,Color.rgb(180,110,0));warn.setPadding(dp(8),dp(7),dp(8),dp(7));warn.setBackground(rounded(Color.rgb(255,248,230),10));body.addView(warn);}
        AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle("Расписание проверок").setView(body).setNegativeButton("Закрыть",null).setPositiveButton("Перепланировать",null);if(Build.VERSION.SDK_INT>=31&&!exact)builder.setNeutralButton("Исправить доступ",null);AlertDialog d=builder.create();d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{CheckScheduler.scheduleNext(this);refreshAutoAuditStatus();Toast.makeText(this,"Расписание обновлено",Toast.LENGTH_SHORT).show();d.dismiss();if(currentPage==PAGE_SETTINGS)switchPage(PAGE_SETTINGS);});if(Build.VERSION.SDK_INT>=31&&!exact&&d.getButton(AlertDialog.BUTTON_NEUTRAL)!=null)d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{try{Intent i=new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Throwable e){startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}d.dismiss();});});d.show();
    }
    private View scheduleInfoRow(String title,String value,int iconRes,View.OnClickListener click){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(7),dp(7),dp(5),dp(7));GradientDrawable bg=rounded(Color.WHITE,10);bg.setStroke(dp(1),Color.rgb(229,235,242));row.setBackground(bg);ImageView ic=new ImageView(this);ic.setImageResource(iconRes);ic.setColorFilter(ACCENT);row.addView(ic,new LinearLayout.LayoutParams(dp(24),dp(24)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(8),0,0,0);tx.addView(label(title,10,true,DARK));tx.addView(label(value,8,false,MUTED));row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));if(click!=null){ImageView ar=new ImageView(this);ar.setImageResource(R.drawable.ic_chevron_right);ar.setColorFilter(Color.rgb(93,112,145));row.addView(ar,new LinearLayout.LayoutParams(dp(15),dp(15)));row.setOnClickListener(click);}LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(0,dp(5),0,0);row.setLayoutParams(lp);return row;}
    private String daysText(int mask){if(mask==0)return "выключено";String[] n=CheckSettings.dayNames();StringBuilder b=new StringBuilder();for(int i=0;i<7;i++)if((mask&(1<<i))!=0){if(b.length()>0)b.append(", ");b.append(n[i]);}return b.toString();}

    private void showAdvancedDiagnosticsDialog() {
        String[] items = {
                "Технические данные изменений",
                "Служебный лог проверок и запросов",
                "Экспортировать служебный лог",
                "Очистить служебный лог"
        };
        new AlertDialog.Builder(this)
                .setTitle("Диагностика")
                .setMessage("Технический раздел. Используйте его только когда нужно разобраться с ошибкой проверки или отправить лог.")
                .setItems(items, (d, which) -> {
                    if (which == 0) showLongTextDialog("Технические данные изменений", TimeUtil.displayDateTime(db.diagnosticJournal()));
                    else if (which == 1) showLongTextDialog("Служебный лог", TimeUtil.displayDateTime(DiagnosticLog.read(this)));
                    else if (which == 2) exportDiagnosticLog();
                    else {
                        new AlertDialog.Builder(this)
                                .setTitle("Очистить служебный лог?")
                                .setMessage("История проверок и база операций не удаляются.")
                                .setNegativeButton("Отмена",null)
                                .setPositiveButton("Очистить",(x,w)->{
                                    DiagnosticLog.clear(this);
                                    Toast.makeText(this, "Служебный лог очищен", Toast.LENGTH_SHORT).show();
                                }).show();
                    }
                }).show();
    }

    private void showLongTextDialog(String title,String text){
        TextView t=label(text==null||text.trim().isEmpty()?"Данных пока нет":text,10,false,TEXT);
        t.setTextIsSelectable(true);
        t.setPadding(dp(12),dp(8),dp(12),dp(8));
        t.setLineSpacing(dp(2),1f);
        ScrollView scroll=new ScrollView(this);scroll.addView(t);
        new AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton("Закрыть",null).show();
    }

    private void scheduleSettingsDialog(String type) {
        CheckSettings cfg = new CheckSettings(this);
        boolean full = CheckSettings.TYPE_FULL.equals(type);
        int mask = full ? cfg.fullDays() : cfg.lightDays();
        String time = full ? cfg.fullTime() : cfg.lightTime();
        int[] hm = CheckSettings.parseTime(time);
        final int[] selectedTime = {hm[0], hm[1]};
        String[] days = CheckSettings.dayNames();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(4), dp(18), 0);
        final android.widget.CheckBox[] checks = new android.widget.CheckBox[7];
        for (int i=0;i<7;i++) {
            android.widget.CheckBox cb = new android.widget.CheckBox(this);
            cb.setText(days[i]);
            cb.setChecked((mask & (1 << i)) != 0);
            cb.setTextSize(16);
            cb.setPadding(0, dp(3), 0, dp(3));
            checks[i]=cb;
            box.addView(cb);
        }
        Button timeButton = new Button(this);
        timeButton.setAllCaps(false);
        timeButton.setText(String.format(Locale.US,"Время запуска: %02d:%02d",selectedTime[0],selectedTime[1]));
        timeButton.setOnClickListener(v -> new android.app.TimePickerDialog(this,(view,h,m)->{
            selectedTime[0]=h;selectedTime[1]=m;
            timeButton.setText(String.format(Locale.US,"Время запуска: %02d:%02d",h,m));
        },selectedTime[0],selectedTime[1],true).show());
        box.addView(timeButton);

        TextView note = label(full
                ? "Если на этот же день назначена лёгкая проверка, выполняется только полная."
                : "Если на этот же день назначена полная проверка, лёгкая отдельно не запускается.",
                12,false,MUTED);
        note.setPadding(0,dp(8),0,0); box.addView(note);

        new AlertDialog.Builder(this)
                .setTitle(full ? "Полная проверка" : "Быстрая проверка")
                .setView(box)
                .setPositiveButton("Сохранить",(d,w)->{
                    int newMask=0; for(int i=0;i<7;i++)if(checks[i].isChecked())newMask|=(1<<i);
                    String t=String.format(Locale.US,"%02d:%02d",selectedTime[0],selectedTime[1]);
                    if(full){cfg.setFullDays(newMask);cfg.setFullTime(t);}else{cfg.setLightDays(newMask);cfg.setLightTime(t);}
                    CheckScheduler.scheduleNext(this); refreshAutoAuditStatus();
                    Toast.makeText(this,"Расписание сохранено",Toast.LENGTH_SHORT).show();
                    if(currentPage==PAGE_SETTINGS)switchPage(PAGE_SETTINGS);
                })
                .setNegativeButton("Отмена",null).show();
    }

    private void retrySettingsDialog() {
        final int[] values={1,3,5,7,10};
        String[] labels={"1 попытка","3 попытки","5 попыток","7 попыток","10 попыток"};
        new AlertDialog.Builder(this).setTitle("Повторные попытки при ошибке")
                .setItems(labels,(d,which)->{
                    new CheckSettings(this).setRetries(values[which]);
                    Toast.makeText(this,"Повторных попыток: "+values[which],Toast.LENGTH_SHORT).show();
                    refreshAutoAuditStatus();
                    if(currentPage==PAGE_SETTINGS)switchPage(PAGE_SETTINGS);
                }).show();
    }

    private void delaySettingsDialog() {
        CheckSettings cfg = new CheckSettings(this);
        long currentMs = cfg.requestDelayMs();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        TextView info = new TextView(this);
        info.setText("Пауза между последовательными запросами Cubux: 0,5–10 секунд. 0,5 сек — самый жёсткий режим; при 429, таймаутах и ошибках сервера защитные задержки увеличиваются автоматически.");
        info.setTextSize(16);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, 0, 0, dp(12));
        box.addView(info, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        String[] labels = DelayProfile.labels();
        NumberPicker picker = new NumberPicker(this);
        picker.setMinValue(0);
        picker.setMaxValue(labels.length - 1);
        picker.setDisplayedValues(labels);
        picker.setValue(DelayProfile.indexFor(currentMs));
        picker.setWrapSelectorWheel(false);
        picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        box.addView(picker, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView current = new TextView(this);
        current.setText("Выбрано: " + DelayProfile.label(currentMs) +
                (currentMs == DelayProfile.DEFAULT_MS ? " (по умолчанию)" : ""));
        current.setTextSize(14);
        current.setGravity(Gravity.CENTER);
        current.setPadding(0, dp(8), 0, 0);
        box.addView(current, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        picker.setOnValueChangedListener((p, oldVal, newVal) -> {
            long ms = DelayProfile.millisForIndex(newVal);
            current.setText("Выбрано: " + DelayProfile.label(ms) +
                    (ms == DelayProfile.DEFAULT_MS ? " (по умолчанию)" : ""));
        });

        new AlertDialog.Builder(this)
                .setTitle("Пауза между запросами Cubux")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (d, which) -> {
                    long ms = DelayProfile.millisForIndex(picker.getValue());
                    new CheckSettings(this).setRequestDelayMs(ms);
                    Toast.makeText(this, "Пауза: " + DelayProfile.label(ms), Toast.LENGTH_SHORT).show();
                    refreshAutoAuditStatus();
                    if(currentPage==PAGE_SETTINGS)switchPage(PAGE_SETTINGS);
                })
                .show();
    }

    private String scheduleDaysText(int mask) {
        String[] n=CheckSettings.dayNames(); StringBuilder b=new StringBuilder();
        for(int i=0;i<7;i++)if((mask&(1<<i))!=0){if(b.length()>0)b.append(", ");b.append(n[i]);}
        return b.length()==0?"выключена":b.toString();
    }

    private void refreshAutoAuditStatus() {
        if (detailsText == null) return;
        CheckSettings cfg=new CheckSettings(this);
        long next=parseLongState("next_scheduled_check_ms");
        String type=db.getState("next_scheduled_check_type");
        String nextText=next>0
                ? (CheckSettings.TYPE_FULL.equals(type)?"Полная":"Лёгкая")+" • "+
                  new java.text.SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new java.util.Date(next))
                : "нет";
        String first=new HistoryRange(db).startDate();
        detailsText.setText(
                "Следующая: "+nextText+
                "\nЛёгкая: "+scheduleDaysText(cfg.lightDays())+" • "+cfg.lightTime()+
                "\nПолная: "+scheduleDaysText(cfg.fullDays())+" • "+cfg.fullTime()+
                "\nЗапросы: последовательно, пауза "+DelayProfile.label(cfg.requestDelayMs())+
                " • попыток "+cfg.retries()+
                "\nНачало истории: "+(first==null?"определится по первой полной загрузке":first)
        );
    }

    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                        android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    2203
            );
        }
    }

    private void showReportsDialog() {
        dayAnchor.setTimeInMillis(System.currentTimeMillis());
        dayEventTypeFilter="ALL";
        switchPage(PAGE_REPORTS);
    }

    private void showBankDialog() {
        String[] items = {
                "Импорт CSV / XLSX",
                "Сверить банк с Cubux"
        };
        new AlertDialog.Builder(this)
                .setTitle("Банковская сверка")
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        pickBankFile();
                    } else {
                        new Thread(() -> {
                            String text = new BankReconcileEngine(db).reconcile();
                            runOnUiThread(() -> resultText.setText(text));
                        }, "CubuxBankReconcile").start();
                    }
                })
                .show();
    }

    private void showJournalDialog() {
        switchPage(PAGE_JOURNAL);
    }

    private void customReportDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText from =
                new EditText(this);

        from.setHint(
                "От YYYY-MM-DD"
        );

        EditText to =
                new EditText(this);

        to.setHint(
                "До YYYY-MM-DD"
        );

        box.addView(from);
        box.addView(to);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Произвольный период"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        new ReportEngine(
                                                db
                                        ).report(
                                                from.getText()
                                                        .toString(),
                                                to.getText()
                                                        .toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void pickBankFile() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType("*/*");

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_BANK
        );
    }

    private void exportDiagnosticLog() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "CubuxAudit-diagnostic-log.txt");
        startActivityForResult(i, REQ_LOG);
    }

    
    
    private String formatFileSize(long n){if(n<1024)return n+" Б";if(n<1024L*1024L)return String.format(Locale.getDefault(),"%.1f КБ",n/1024f);return String.format(Locale.getDefault(),"%.1f МБ",n/(1024f*1024f));}

    private String backupNextText(){
        if(!BackupScheduler.enabled(db))return "Выключены";
        long ms=BackupScheduler.nextMs(db);
        if(ms<=0)return "Будет рассчитана после сохранения настроек";
        return new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new java.util.Date(ms));
    }

    private void showBackupPage(boolean restoreFocus){
        backupPageVisible=true;
        LinearLayout body=pageBody();
        TextView back=label("‹  Резервные копии",15,true,DARK);back.setPadding(dp(1),dp(3),0,dp(5));back.setOnClickListener(v->switchPage(PAGE_HOME));body.addView(back);
        TextView sub=label("Копии базы Cubux Security. Файлы можно найти обычным файловым менеджером.",10,false,MUTED);sub.setPadding(dp(1),0,dp(1),dp(7));body.addView(sub);

        Button create=flatButton("＋  Создать резервную копию",ACCENT,Color.WHITE);create.setTextSize(12);create.setOnClickListener(v->createBackup());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(44));cp.setMargins(0,0,0,dp(8));body.addView(create,cp);

        LinearLayout auto=card();auto.setPadding(dp(11),dp(9),dp(11),dp(8));
        LinearLayout ah=new LinearLayout(this);ah.setOrientation(LinearLayout.HORIZONTAL);ah.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout at=new LinearLayout(this);at.setOrientation(LinearLayout.VERTICAL);at.addView(label("Автоматические копии",12,true,DARK));at.addView(label(BackupScheduler.enabled(db)?"Включены":"Выключены",9,true,BackupScheduler.enabled(db)?GREEN:MUTED));ah.addView(at,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        Button toggle=flatButton(BackupScheduler.enabled(db)?"Выключить":"Включить",BackupScheduler.enabled(db)?Color.rgb(235,239,244):ACCENT,BackupScheduler.enabled(db)?DARK:Color.WHITE);toggle.setOnClickListener(v->{BackupScheduler.setEnabled(this,db,!BackupScheduler.enabled(db));showBackupPage(restoreFocus);});ah.addView(toggle,new LinearLayout.LayoutParams(dp(92),dp(34)));auto.addView(ah);
        auto.addView(settingRow("Создавать каждые",BackupScheduler.intervalDays(db)+" дн.","›",v->backupIntervalDialog(restoreFocus)));
        auto.addView(settingRow("Время автокопии",BackupScheduler.timeText(db),"›",v->backupTimeDialog(restoreFocus)));
        auto.addView(settingRow("Следующая копия",backupNextText(),"",v->{}));
        auto.addView(settingRow("Папка хранения",BackupStorage.folderLabel(db),"›",v->backupFolderDialog()));
        auto.addView(settingRow("Хранить последние",BackupScheduler.keepCount(db)+" копий","›",v->backupKeepDialog(restoreFocus)));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);ap.setMargins(0,0,0,dp(9));body.addView(auto,ap);

        LinearLayout hh=new LinearLayout(this);hh.setOrientation(LinearLayout.HORIZONTAL);hh.setGravity(Gravity.CENTER_VERTICAL);TextView ht=label("Сохранённые копии",13,true,DARK);hh.addView(ht,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        TextView folder=label("Изменить папку",9,true,ACCENT);folder.setPadding(dp(8),dp(4),dp(2),dp(4));folder.setOnClickListener(v->backupFolderDialog());hh.addView(folder);body.addView(hh);

        java.util.List<BackupStorage.Item> items=BackupStorage.list(this,db);
        if(items.isEmpty()){
            LinearLayout empty=card();empty.setPadding(dp(10),dp(17),dp(10),dp(17));TextView e=label("Резервных копий пока нет\nНажмите «Создать резервную копию»",11,false,MUTED);e.setGravity(Gravity.CENTER);empty.addView(e);body.addView(empty);
        }else{
            for(BackupStorage.Item item:items)body.addView(backupItemRow(item,restoreFocus),backupRowParams());
        }

        Button choose=flatButton("Выбрать файл для восстановления",Color.WHITE,DARK);GradientDrawable cbg=rounded(Color.WHITE,10);cbg.setStroke(dp(1),Color.rgb(210,222,235));choose.setBackground(cbg);choose.setOnClickListener(v->pickRestore());LinearLayout.LayoutParams chp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(42));chp.setMargins(0,dp(8),0,0);body.addView(choose,chp);
        if(restoreFocus&&items.isEmpty()){TextView tip=label("Выберите сохранённую копию выше или файл из памяти телефона.",9,false,MUTED);tip.setPadding(dp(2),dp(6),dp(2),0);body.addView(tip);}
        pageHost.removeAllViews();pageHost.addView(pageScroll(body),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private LinearLayout.LayoutParams backupRowParams(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,0,0,dp(6));return p;}

    private View backupItemRow(BackupStorage.Item item,boolean restoreFocus){
        LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(10),dp(8),dp(10),dp(8));
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon=label("▣",14,true,Color.WHITE);icon.setGravity(Gravity.CENTER);icon.setBackground(rounded(Color.rgb(21,163,198),12));top.addView(icon,new LinearLayout.LayoutParams(dp(36),dp(36)));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(8),0,0,0);String title=BackupStorage.isCurrentRolling(db,item)?"Последняя защитная копия":item.name.replace(BackupStorage.PREFIX,"").replace(".zip","").replace('_',' ');tx.addView(label(title,10,true,DARK));String when=item.modifiedMs>0?new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new java.util.Date(item.modifiedMs)):"Дата неизвестна";tx.addView(label(when+" • "+formatFileSize(item.size),9,false,MUTED));top.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));c.addView(top);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setPadding(0,dp(7),0,0);
        Button restore=flatButton("Восстановить",restoreFocus?ACCENT:Color.rgb(238,247,250),restoreFocus?Color.WHITE:ACCENT);restore.setOnClickListener(v->confirmRestore(item.uri));
        Button share=flatButton("Поделиться",Color.rgb(242,245,249),DARK);share.setOnClickListener(v->shareBackup(item.uri));
        Button del=flatButton("Удалить",Color.rgb(255,240,242),RED);del.setOnClickListener(v->confirmDeleteBackup(item));
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,dp(34),1);a.setMargins(0,0,dp(3),0);LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(0,dp(34),1);b.setMargins(dp(3),0,dp(3),0);LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(0,dp(34),1);d.setMargins(dp(3),0,0,0);actions.addView(restore,a);actions.addView(share,b);actions.addView(del,d);c.addView(actions);return c;
    }

    private void backupIntervalDialog(boolean restoreFocus){
        final NumberPicker p=new NumberPicker(this);p.setMinValue(1);p.setMaxValue(90);p.setValue(BackupScheduler.intervalDays(db));
        new AlertDialog.Builder(this).setTitle("Периодичность автокопии").setMessage("Через сколько дней создавать новую резервную копию?").setView(p).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{BackupScheduler.setInterval(this,db,p.getValue());showBackupPage(restoreFocus);}).show();
    }

    private void backupTimeDialog(boolean restoreFocus){
        int[] hm=BackupTimePolicy.parse(BackupScheduler.timeText(db));
        new android.app.TimePickerDialog(this,(view,hour,minute)->{
            BackupScheduler.setTime(this,db,hour,minute);
            Toast.makeText(this,"Время автокопии: "+BackupScheduler.timeText(db),Toast.LENGTH_SHORT).show();
            showBackupPage(restoreFocus);
        },hm[0],hm[1],true).show();
    }

    private void backupKeepDialog(boolean restoreFocus){
        final NumberPicker p=new NumberPicker(this);p.setMinValue(1);p.setMaxValue(50);p.setValue(BackupScheduler.keepCount(db));
        new AlertDialog.Builder(this).setTitle("Сколько копий хранить").setMessage("Старые автоматические и ручные архивные копии будут удаляться. Защитная latest-копия сохраняется отдельно.").setView(p).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{BackupScheduler.setKeep(this,db,p.getValue());showBackupPage(restoreFocus);}).show();
    }

    private void backupFolderDialog(){
        String[] items={"Выбрать другую папку","Использовать Downloads/Cubux Security/Backups"};
        new AlertDialog.Builder(this).setTitle("Папка резервных копий").setMessage("Сейчас: "+BackupStorage.folderLabel(db)).setItems(items,(d,which)->{if(which==0)pickBackupFolder();else{BackupStorage.resetToDefault(db);BackupScheduler.restore(this);Toast.makeText(this,"Используется папка Downloads/Cubux Security/Backups",Toast.LENGTH_SHORT).show();showBackupPage(false);}}).setNegativeButton("Отмена",null).show();
    }

    private void pickBackupFolder(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_BACKUP_FOLDER);
    }

    private void createBackup(){
        Toast.makeText(this,"Создаю резервную копию…",Toast.LENGTH_SHORT).show();
        new Thread(()->{try{AutoBackupManager.createManualArchiveBlocking(this);runOnUiThread(()->{Toast.makeText(this,"Резервная копия создана",Toast.LENGTH_SHORT).show();switchPage(PAGE_HOME);});}catch(Exception e){DiagnosticLog.error(this,"MANUAL_BACKUP",e);runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Не удалось создать копию").setMessage(e.getMessage()).setPositiveButton("ОК",null).show());}},"cubux-manual-backup").start();
    }

    private void pickRestore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/zip");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_RESTORE);}

    private void shareBackup(Uri uri){
        try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/zip");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Поделиться резервной копией"));}catch(Throwable e){Toast.makeText(this,"Не удалось открыть меню отправки",Toast.LENGTH_SHORT).show();}
    }

    private void confirmDeleteBackup(BackupStorage.Item item){
        new AlertDialog.Builder(this).setTitle("Удалить резервную копию?").setMessage(item.name+"\n\nПосле удаления восстановить её будет нельзя.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{boolean ok=BackupStorage.delete(this,item.uri);Toast.makeText(this,ok?"Копия удалена":"Не удалось удалить копию",Toast.LENGTH_SHORT).show();showBackupPage(false);}).show();
    }

    private void confirmRestore(Uri uri){
        if(isAuditSessionActive()||DayControlService.isRunning()){
            new AlertDialog.Builder(this).setTitle("Восстановление временно недоступно").setMessage("Сейчас выполняется проверка. Дождитесь её завершения и повторите восстановление.").setPositiveButton("ОК",null).show();
            return;
        }
        if(BackupOperationGate.isBusy()){
            new AlertDialog.Builder(this).setTitle("База занята").setMessage("Сейчас выполняется "+BackupOperationGate.currentOperationRu()+". Дождитесь завершения.").setPositiveButton("ОК",null).show();
            return;
        }
        final String name=getDisplayName(uri);new AlertDialog.Builder(this).setTitle("Восстановить данные?").setMessage("Будет восстановлена база из:\n"+name+"\n\nПеред заменой будут проверены SHA-256 и целостность SQLite. Текущая база будет заменена только после успешной проверки. После восстановления приложение выполнит синхронизационную проверку.").setNegativeButton("Отмена",null).setPositiveButton("Восстановить",(d,w)->performRestore(uri)).show();
    }

    private void performRestore(Uri uri){
        Toast.makeText(this,"Проверяю и восстанавливаю резервную копию…",Toast.LENGTH_SHORT).show();
        new Thread(()->{
            try{
                new BackupManager(this,db).restoreFrom(getContentResolver(),uri);
                db=new AuditDb(this);
                try{CheckScheduler.scheduleStartup(this);DayControlScheduler.scheduleNext(this);BackupScheduler.restore(this);}catch(Throwable ignored){}
                runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Восстановление завершено").setMessage("Копия прошла SHA-256 и SQLite integrity_check. Данные восстановлены. Следующая проверка будет синхронизационной — без массовых ложных «Новых».").setPositiveButton("ОК",(d,w)->switchPage(PAGE_HOME)).show());
            }catch(Exception e){
                try{db=new AuditDb(this);}catch(Throwable ignored){}
                DiagnosticLog.error(this,"RESTORE",e);
                runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Не удалось восстановить").setMessage(e.getMessage()).setPositiveButton("ОК",null).show());
            }
        },"cubux-restore").start();
    }

    private String getDisplayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {
        }
        return uri.toString();
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (resultCode != RESULT_OK ||
                data == null ||
                data.getData() == null) {
            return;
        }

        Uri uri = data.getData();

        if (requestCode == REQ_BACKUP_FOLDER) {
            try {
                String label=getDisplayName(uri);
                BackupStorage.setTree(this,db,uri,label);
                BackupScheduler.restore(this);
                Toast.makeText(this,"Папка резервных копий сохранена",Toast.LENGTH_SHORT).show();
                showBackupPage(false);
            } catch (Exception e) {
                new AlertDialog.Builder(this).setTitle("Не удалось выбрать папку").setMessage(e.getMessage()).setPositiveButton("ОК",null).show();
            }
            return;
        }

        if (requestCode == REQ_LOG) {
            try {
                DiagnosticLog.export(this, uri);
                resultText.setText("Диагностический лог экспортирован. Его можно отправить для анализа ошибок.");
            } catch (Exception e) {
                resultText.setText("Ошибка экспорта лога: " + e.getMessage());
            }
        } else if (requestCode == REQ_BANK) {
            new Thread(
                    () -> {
                        try {
                            int imported =
                                    new BankImportEngine(
                                            db
                                    ).importFile(
                                            getContentResolver(),
                                            uri,
                                            getDisplayName(uri)
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Импортировано банковских операций: " +
                                                            imported
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка импорта: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (requestCode == REQ_RESTORE) {
            confirmRestore(uri);
        }
    }
}
