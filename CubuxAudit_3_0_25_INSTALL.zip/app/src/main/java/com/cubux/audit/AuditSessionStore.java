package com.cubux.audit;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Persistent live-state for the one active Cubux check.
 *
 * This state is intentionally stored outside the audit database: restoring an old database
 * must never resurrect an old foreground check. Notification and UI both read this state.
 */
public final class AuditSessionStore {
    private static final String PREFS="cubux_live_audit_v325";
    public static final String RUNNING="RUNNING";
    public static final String PAUSED="PAUSED";
    public static final String STOPPING="STOPPING";
    public static final String COMPLETED="COMPLETED";
    public static final String ERROR="ERROR";
    public static final String STOPPED="STOPPED";
    public static final String INTERRUPTED="INTERRUPTED";

    private AuditSessionStore(){}

    public static final class Snapshot {
        public final long runId,startedAt,updatedAt,heartbeatAt;
        public final boolean active;
        public final String mode,status,state,stage,note;
        public final int percent,page,pages,loaded,total;
        Snapshot(long runId,long startedAt,long updatedAt,long heartbeatAt,boolean active,
                 String mode,String status,String state,String stage,String note,
                 int percent,int page,int pages,int loaded,int total){
            this.runId=runId;this.startedAt=startedAt;this.updatedAt=updatedAt;this.heartbeatAt=heartbeatAt;
            this.active=active;this.mode=mode;this.status=status;this.state=state;this.stage=stage;this.note=note;
            this.percent=percent;this.page=page;this.pages=pages;this.loaded=loaded;this.total=total;
        }
    }

    private static SharedPreferences p(Context c){return c.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    private static String s(SharedPreferences p,String k,String def){String v=p.getString(k,def);return v==null?def:v;}

    public static synchronized long begin(Context c,String mode,long startedAt){
        SharedPreferences p=p(c);long now=System.currentTimeMillis();long prev=p.getLong("run_id",0L);
        long id=Math.max(now,prev+1L);long start=startedAt>0L?startedAt:now;
        p.edit().putLong("run_id",id).putBoolean("active",true)
                .putString("mode",mode==null?AuditCoordinator.MODE_QUICK:mode)
                .putString("status",RUNNING).putString("state","Подготовка проверки")
                .putString("stage","PREPARING").putString("note","")
                .putInt("percent",0).putInt("page",0).putInt("pages",0).putInt("loaded",0).putInt("total",0)
                .putLong("started_at",start).putLong("updated_at",now).putLong("heartbeat_at",now).apply();
        return id;
    }

    public static Snapshot snapshot(Context c){
        SharedPreferences p=p(c);
        return new Snapshot(p.getLong("run_id",0L),p.getLong("started_at",0L),p.getLong("updated_at",0L),p.getLong("heartbeat_at",0L),
                p.getBoolean("active",false),s(p,"mode",AuditCoordinator.MODE_QUICK),s(p,"status","IDLE"),
                s(p,"state","Подготовка проверки"),s(p,"stage","PREPARING"),s(p,"note",""),
                p.getInt("percent",0),p.getInt("page",0),p.getInt("pages",0),p.getInt("loaded",0),p.getInt("total",0));
    }

    public static boolean isActive(Context c){return p(c).getBoolean("active",false);}
    public static long currentRunId(Context c){return p(c).getLong("run_id",0L);}

    public static synchronized void update(Context c,long runId,String stage,String state,String note,
                                           int percent,int page,int pages,int loaded,int total){
        SharedPreferences p=p(c);if(!p.getBoolean("active",false)||p.getLong("run_id",0L)!=runId)return;
        long now=System.currentTimeMillis();SharedPreferences.Editor e=p.edit();
        if(stage!=null)e.putString("stage",stage);if(state!=null)e.putString("state",state);if(note!=null)e.putString("note",note);
        e.putInt("percent",Math.max(p.getInt("percent",0),Math.max(0,percent)));
        if(page>=0)e.putInt("page",page);if(pages>=0)e.putInt("pages",pages);if(loaded>=0)e.putInt("loaded",loaded);if(total>=0)e.putInt("total",total);
        e.putLong("updated_at",now).putLong("heartbeat_at",now).apply();
    }

    public static synchronized void resetPageProgress(Context c,long runId){
        SharedPreferences p=p(c);if(!p.getBoolean("active",false)||p.getLong("run_id",0L)!=runId)return;
        long now=System.currentTimeMillis();p.edit().putInt("page",0).putInt("pages",0).putInt("loaded",0).putInt("total",0)
                .putLong("updated_at",now).putLong("heartbeat_at",now).apply();
    }

    public static synchronized void heartbeat(Context c){
        SharedPreferences p=p(c);if(!p.getBoolean("active",false))return;
        p.edit().putLong("heartbeat_at",System.currentTimeMillis()).apply();
    }

    public static synchronized void setMode(Context c,long runId,String mode){
        SharedPreferences p=p(c);if(!p.getBoolean("active",false)||p.getLong("run_id",0L)!=runId)return;
        p.edit().putString("mode",mode==null?AuditCoordinator.MODE_QUICK:mode).putLong("updated_at",System.currentTimeMillis()).apply();
    }

    public static synchronized void pause(Context c,long runId){setStatus(c,runId,PAUSED,"Проверка на паузе");}
    public static synchronized void resume(Context c,long runId){setStatus(c,runId,RUNNING,"Проверка продолжается");}
    public static synchronized void stopping(Context c,long runId){setStatus(c,runId,STOPPING,"Останавливаю проверку…");}

    private static void setStatus(Context c,long runId,String status,String state){
        SharedPreferences p=p(c);if(!p.getBoolean("active",false)||p.getLong("run_id",0L)!=runId)return;
        long now=System.currentTimeMillis();p.edit().putString("status",status).putString("state",state)
                .putLong("updated_at",now).putLong("heartbeat_at",now).apply();
    }

    public static synchronized void finish(Context c,long runId,String status,String state){
        SharedPreferences p=p(c);if(p.getLong("run_id",0L)!=runId)return;
        long now=System.currentTimeMillis();SharedPreferences.Editor e=p.edit().putBoolean("active",false)
                .putString("status",status==null?COMPLETED:status).putLong("updated_at",now).putLong("heartbeat_at",now);
        if(state!=null)e.putString("state",state);
        if(COMPLETED.equals(status)){e.putString("stage","COMPLETED").putInt("percent",100);}
        else if(ERROR.equals(status)){e.putString("stage","ERROR");}
        else if(STOPPED.equals(status)){e.putString("stage","STOPPED");}
        else if(INTERRUPTED.equals(status)){e.putString("stage","INTERRUPTED");}
        e.apply();
    }

    public static synchronized void interruptOrphan(Context c,String reason){
        SharedPreferences p=p(c);if(!p.getBoolean("active",false))return;
        finish(c,p.getLong("run_id",0L),INTERRUPTED,reason==null?"Проверка прервана системой":reason);
    }
}
