package com.cubux.audit;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public class AuditForegroundService extends Service {
    public static final String CHANNEL="cubux_audit_running";
    public static final int ID=2601;
    private static final String ACTION_SCHEDULED="com.cubux.audit.RUN_SCHEDULED";
    public static final String EXTRA_RUN_ID="audit_run_id";
    public static volatile int percent=0,page=0,pages=0,loaded=0,total=0;
    public static volatile String state="Подготовка проверки";
    public static volatile String stage="PREPARING";
    public static volatile String note="";
    private static volatile long updatedAt=0L,startedAtMs=0L;
    private static volatile boolean scheduledThreadRunning=false;
    private static volatile boolean runtimeActive=false;
    private static volatile long orphanSinceMs=0L;
    private long ownedRunId=0L;
    private final Handler heartbeatHandler=new Handler(Looper.getMainLooper());
    private final Runnable heartbeatTick=new Runnable(){
        @Override public void run(){
            try{
                if(AuditSessionStore.isActive(AuditForegroundService.this)){
                    boolean owned=AuditRunGate.isRunning()||AuditControlRegistry.current()!=null||scheduledThreadRunning;
                    if(owned){orphanSinceMs=0L;}
                    else {
                        if(orphanSinceMs<=0L)orphanSinceMs=System.currentTimeMillis();
                        if(System.currentTimeMillis()-orphanSinceMs>15000L){
                            AuditSessionStore.interruptOrphan(AuditForegroundService.this,"Проверка прервана: рабочий процесс отсутствует");
                            DiagnosticLog.write(AuditForegroundService.this,"FOREGROUND","Удалено осиротевшее уведомление проверки");
                            cancelNotification(AuditForegroundService.this);stopSelf();return;
                        }
                    }
                    // The service heartbeat lets a newly-created Activity distinguish a live
                    // background check from an old notification left by a dead process.
                    AuditSessionStore.heartbeat(AuditForegroundService.this);
                    NotificationManager m=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
                    if(m!=null)m.notify(ID,buildNotification());
                }
            }catch(Throwable ignored){}
            if(runtimeActive)heartbeatHandler.postDelayed(this,2000L);
        }
    };

    public static final class Snapshot {
        public final long runId;
        public final boolean active;
        public final String mode,status;
        public final int percent,page,pages,loaded,total;
        public final String state,stage,note;
        public final long updatedAt,elapsedMs;
        Snapshot(long runId,boolean active,String mode,String status,int percent,int page,int pages,int loaded,int total,
                 String state,String stage,String note,long updatedAt,long elapsedMs){
            this.runId=runId;this.active=active;this.mode=mode;this.status=status;
            this.percent=percent;this.page=page;this.pages=pages;this.loaded=loaded;this.total=total;
            this.state=state;this.stage=stage;this.note=note;this.updatedAt=updatedAt;this.elapsedMs=elapsedMs;
        }
    }

    @Override public void onCreate(){
        super.onCreate();runtimeActive=true;createChannel();heartbeatHandler.post(heartbeatTick);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?null:intent.getAction();
        if(ACTION_SCHEDULED.equals(action)){
            String type=intent.getStringExtra("check_type");
            int attempt=intent.getIntExtra("attempt",0);boolean retry=intent.getBooleanExtra("retry",false);
            String normalized=type==null?CheckSettings.TYPE_LIGHT:type;
            String mode=CheckSettings.TYPE_FULL.equals(normalized)?AuditCoordinator.MODE_FULL:AuditCoordinator.MODE_QUICK;
            if(scheduledThreadRunning){startForeground(ID,buildNotification());DiagnosticLog.write(this,"SCHEDULED","Повторный сигнал расписания проигнорирован: автоматическая проверка уже запущена");return START_NOT_STICKY;}
            boolean gate=AuditRunGate.isRunning(),hasControl=AuditControlRegistry.current()!=null,persisted=AuditSessionStore.isActive(this);
            // A new service instance with only persisted ACTIVE state has no worker to own it:
            // this is a previous-process orphan and must not block the next scheduled check.
            if(persisted&&!gate&&!hasControl&&ownedRunId<=0L){
                AuditSessionStore.interruptOrphan(this,"Предыдущая проверка была прервана системой");
                new AuditDb(this).stopStaleRunningRuns();persisted=false;
                DiagnosticLog.write(this,"SCHEDULED","Очищена осиротевшая сессия перед новым запуском по расписанию");
            }
            boolean busy=gate||hasControl||persisted;
            if(busy){
                startForeground(ID,buildNotification());
                DiagnosticLog.write(this,"SCHEDULED","Проверка уже выполняется; второй запуск по расписанию не создаю");
                CheckScheduler.scheduleNext(this);
                return START_NOT_STICKY;
            }
            long start=System.currentTimeMillis();long liveRunId=AuditSessionStore.begin(this,mode,start);ownedRunId=liveRunId;reset(start);
            startForeground(ID,buildNotification());
            launchScheduled(normalized,attempt,retry,liveRunId);
            return START_NOT_STICKY;
        }

        // Manual start: MainActivity must already have created the persistent session and control.
        if(!AuditSessionStore.isActive(this)||AuditControlRegistry.current()==null){
            DiagnosticLog.write(this,"FOREGROUND","Сервис запущен без живой сессии; старое уведомление удалено");
            AuditSessionStore.interruptOrphan(this,"Проверка прервана: рабочий процесс отсутствует");
            cancelNotification(this);stopSelf();return START_NOT_STICKY;
        }
        ownedRunId=AuditSessionStore.currentRunId(this);
        startForeground(ID,buildNotification());
        return START_NOT_STICKY;
    }

    public static boolean isRuntimeActive(){return runtimeActive;}
    public static void start(Context c){Intent i=new Intent(c,AuditForegroundService.class);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}
    public static void startScheduled(Context c,String type,int attempt,boolean retry){Intent i=new Intent(c,AuditForegroundService.class).setAction(ACTION_SCHEDULED).putExtra("check_type",type).putExtra("attempt",attempt).putExtra("retry",retry);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}
    public static void stop(Context c){finish(c);}
    public static void finish(Context c){
        cancelNotification(c);
        try{c.stopService(new Intent(c,AuditForegroundService.class));}catch(Throwable ignored){}
    }
    private static void cancelNotification(Context c){
        try{NotificationManager m=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(m!=null)m.cancel(ID);}catch(Throwable ignored){}
    }

    @Override public void onDestroy(){
        runtimeActive=false;ownedRunId=0L;heartbeatHandler.removeCallbacks(heartbeatTick);
        try{stopForeground(true);}catch(Throwable ignored){}
        cancelNotification(this);
        super.onDestroy();
    }

    private synchronized void launchScheduled(String type,int previousAttempt,boolean retry,long liveRunId){
        if(scheduledThreadRunning)return;
        scheduledThreadRunning=true; final int attempt=previousAttempt+1; final Context app=getApplicationContext();
        final String mode=CheckSettings.TYPE_FULL.equals(type)?AuditCoordinator.MODE_FULL:AuditCoordinator.MODE_QUICK;
        final String label=CheckSettings.TYPE_FULL.equals(type)?"Полная проверка":"Быстрая проверка";
        new Thread(()->{
            AuditControl control=new AuditControl();
            boolean needRetry=false;
            try{
                AuditControlRegistry.attach(control,mode); AuditDb scheduledDb=new AuditDb(app); scheduledDb.saveState("last_scheduled_start_ms",String.valueOf(System.currentTimeMillis())); scheduledDb.saveState("yesterday_changed_during_scan","0"); scheduledDb.saveState("scheduled_check_active","1"); scheduledDb.appEvent("INFO","АВТОПРОВЕРКА",label+" запущена по расписанию");
                CheckStatusStore.running(app,label+" по расписанию");
                AuditProgressListener l=new AuditProgressListener(){
                    @Override public void onStage(String st,String msg){int pct=stagePercent(st);updateStage(app,st,msg,pct,page,pages,loaded,total);}
                    @Override public void onMeta(int t,int p){total=t;pages=p;updateStage(app,"LOADING_META","Получен объём данных Cubux",Math.max(percent,5),page,p,loaded,t);}
                    @Override public void onPage(int pg,int pgs,int ld,int ttl){int pct=ttl<=0?5:Math.min(85,(int)(5.0+80.0*ld/ttl));updateStage(app,"READING_DATA","Читаю операции из Cubux",pct,pg,pgs,ld,ttl);}
                    @Override public void onRetry(int pg,int a,int sec,String err){String msg="Повтор запроса: попытка "+a+" через "+sec+" сек • "+err;updateNote(app,msg);CheckStatusStore.event(app,"WARNING","СЕТЬ/CUBUX",msg);}
                };
                SecureCredentialsStore cr=new SecureCredentialsStore(app);String login=cr.getLogin(),password=cr.getPassword();if(login.isEmpty()||password.isEmpty())throw new Exception("Логин/пароль Cubux не сохранены");
                AuditCoordinator co=new AuditCoordinator(app);AuditEngine.Result r=co.runMode(login,password,co.isRecovery(),l,control,mode);
                CheckStatusStore.success(app,label,r);new AuditDb(app).saveState("last_scheduled_success_ms",String.valueOf(System.currentTimeMillis()));
                updateStage(app,"COMPLETED","Проверка завершена успешно",100,page,pages,loaded,total);
                AuditSessionStore.finish(app,liveRunId,AuditSessionStore.COMPLETED,"Проверка завершена успешно");
                if("1".equals(new AuditDb(app).getState("yesterday_changed_during_scan"))){String warning="Внимание: данные за вчерашний день менялись во время ночной проверки. Визуально проверьте вчерашний день в Cubux.";NotificationHelper.showWarning(app,warning);CheckStatusStore.event(app,"WARNING","АВТОПРОВЕРКА",warning);}
            }catch(Exception e){
                String msg=e.getMessage()==null?e.toString():e.getMessage();int max=new CheckSettings(app).retries();boolean stopped=msg.contains("остановлена пользователем")||msg.contains("остановлен пользователем");boolean permanent=msg.contains("Логин/пароль")||msg.contains("HTTP 401")||msg.contains("HTTP 403")||stopped;needRetry=!permanent&&attempt<max;CheckStatusStore.failure(app,label,attempt,msg);DiagnosticLog.error(app,"SCHEDULED_ERROR",e);if(!stopped)NotificationHelper.showAuditResult(app,false,needRetry?label+" не выполнена. Повтор будет автоматически.":label+" не выполнена. Причина: "+msg);
                AuditSessionStore.finish(app,liveRunId,stopped?AuditSessionStore.STOPPED:AuditSessionStore.ERROR,stopped?"Проверка остановлена пользователем":msg);
            }finally{
                new AuditDb(app).saveState("scheduled_check_active","0"); AuditControlRegistry.clear(control);scheduledThreadRunning=false;final boolean nr=needRetry;
                if(nr)CheckScheduler.scheduleRetry(app,type,attempt);else CheckScheduler.scheduleNext(app);
                // Never let an old scheduled thread stop the foreground service of a newer run.
                if(AuditSessionStore.currentRunId(app)==liveRunId)finish(app);
            }
        },"CubuxScheduledCheck").start();
    }

    private static int stagePercent(String st){if(st==null)return percent;if(st.startsWith("BACKUP"))return Math.max(percent,99);if("SAVING".equals(st))return Math.max(percent,97);if("COMPARING".equals(st)||"PROCESSING".equals(st))return Math.max(percent,90);if(st.startsWith("STABILITY")||st.startsWith("MONTHLY_CONTROL"))return Math.max(percent,86);if("COMPLETED".equals(st))return 100;return percent;}

    public static synchronized void update(Context c,String st,int pct,int pg,int pgs,int ld,int ttl){
        state=st==null?state:st;percent=Math.max(percent,pct);if(pg>=0)page=pg;if(pgs>=0)pages=pgs;if(ld>=0)loaded=ld;if(ttl>=0)total=ttl;updatedAt=System.currentTimeMillis();
        long runId=AuditSessionStore.currentRunId(c);AuditSessionStore.update(c,runId,stage,state,note,percent,page,pages,loaded,total);notifyNow(c);
    }
    public static synchronized void updateStage(Context c,String stageKey,String st,int pct,int pg,int pgs,int ld,int ttl){stage=stageKey==null?stage:stageKey;note="";if("AUTO_FULL".equals(stageKey))AuditSessionStore.setMode(c,AuditSessionStore.currentRunId(c),"FULL_AFTER_LIGHT");update(c,st,pct,pg,pgs,ld,ttl);}
    public static synchronized void updateNote(Context c,String text){note=text==null?"":text;updatedAt=System.currentTimeMillis();long runId=AuditSessionStore.currentRunId(c);AuditSessionStore.update(c,runId,stage,state,note,percent,page,pages,loaded,total);notifyNow(c);}
    private static void notifyNow(Context c){try{NotificationManager m=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(m!=null)m.notify(ID,buildStatic(c));}catch(Throwable ignored){}}

    /** Persistent snapshot used by both the notification and Activity. */
    public static synchronized Snapshot snapshot(Context c){
        AuditSessionStore.Snapshot p=AuditSessionStore.snapshot(c);long start=p.startedAt>0?p.startedAt:startedAtMs;
        long elapsed=start<=0?0:AuditControlRegistry.activeElapsedMs(start);
        return new Snapshot(p.runId,p.active,p.mode,p.status,p.percent,p.page,p.pages,p.loaded,p.total,p.state,p.stage,p.note,p.updatedAt,elapsed);
    }
    /** Legacy in-process snapshot kept for internal compatibility. */
    public static synchronized Snapshot snapshot(){long elapsed=startedAtMs<=0?0:AuditControlRegistry.activeElapsedMs(startedAtMs);return new Snapshot(0L,AuditRunGate.isRunning(),AuditControlRegistry.mode(),"RUNNING",percent,page,pages,loaded,total,state,stage,note,updatedAt,elapsed);}
    public static synchronized void reset(){reset(System.currentTimeMillis());}
    public static synchronized void reset(long startedAt){percent=page=pages=loaded=total=0;state="Подготовка проверки";stage="PREPARING";note="";startedAtMs=startedAt>0?startedAt:System.currentTimeMillis();updatedAt=System.currentTimeMillis();}
    public static synchronized void resetPageProgress(Context c){page=0;pages=0;loaded=0;total=0;updatedAt=System.currentTimeMillis();AuditSessionStore.resetPageProgress(c,AuditSessionStore.currentRunId(c));}
    public static synchronized void resetPageProgress(){page=0;pages=0;loaded=0;total=0;updatedAt=System.currentTimeMillis();}

    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager m=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);if(m!=null){NotificationChannel ch=new NotificationChannel(CHANNEL,"Текущая проверка",NotificationManager.IMPORTANCE_LOW);ch.setDescription("Прогресс выполняющейся проверки Cubux");m.createNotificationChannel(ch);}}}
    private Notification buildNotification(){return buildStatic(this);}
    private static Notification buildStatic(Context c){
        Snapshot s=snapshot(c);AuditControl control=AuditControlRegistry.current();boolean paused=(AuditSessionStore.PAUSED.equals(s.status))||(control!=null&&control.isPaused());boolean stopped=AuditSessionStore.STOPPING.equals(s.status)||(control!=null&&control.isStopped());String modeTitle=AuditCoordinator.MODE_FULL.equals(s.mode)?"Полная проверка":("FULL_AFTER_LIGHT".equals(s.mode)?"Быстрая → полная":"Быстрая проверка");
        Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra(MainActivity.EXTRA_NOTIFICATION_TARGET,MainActivity.TARGET_CHECK).putExtra(EXTRA_RUN_ID,s.runId);PendingIntent content=PendingIntent.getActivity(c,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);PendingIntent pause=action(c,"PAUSE",2,s.runId),resume=action(c,"RESUME",3,s.runId),stop=action(c,"STOP",4,s.runId);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);String title=stopped?"Проверка останавливается":paused?("Проверка на паузе · "+s.percent+"%"):modeTitle+" · "+s.percent+"%";String status=(s.note!=null&&!s.note.trim().isEmpty())?s.note.trim():s.state;String sub="Прошло "+TimeUtil.formatDuration(s.elapsedMs);if(s.total>0)sub+=" · "+s.loaded+" из "+s.total;
        b.setSmallIcon(R.drawable.ic_shield_check).setColor(android.graphics.Color.rgb(0,169,190)).setContentTitle(title).setContentText(status).setSubText(sub).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(content).setShowWhen(false).setProgress(100,Math.min(100,s.percent),false);
        if(s.active&&!stopped){if(paused)b.addAction(new Notification.Action.Builder(null,"Продолжить",resume).build());else b.addAction(new Notification.Action.Builder(null,"Пауза",pause).build());b.addAction(new Notification.Action.Builder(null,"Стоп",stop).build());}
        return b.build();
    }
    private static PendingIntent action(Context c,String a,int code,long runId){Intent i=new Intent(c,AuditActionReceiver.class).setAction("com.cubux.audit."+a).putExtra(EXTRA_RUN_ID,runId);return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    @Override public IBinder onBind(Intent intent){return null;}
}
