package com.cubux.audit;

public final class AuditSessionPolicyTest {
    private static void need(boolean v,String m){if(!v)throw new AssertionError(m);}
    public static void main(String[] args){
        need(AuditSessionPolicy.isActive(false,false,true,false),"run gate must make session active");
        need(AuditSessionPolicy.isActive(false,false,false,true),"control must make session active");
        need(AuditSessionPolicy.isActive(true,true,false,false),"persisted session + live service must stay visible");
        need(!AuditSessionPolicy.isActive(true,false,false,false),"persisted orphan alone must not look active");
        need(AuditSessionPolicy.shouldRecoverOrphan(true,false,false,false),"cold orphan must be recovered");
        need(!AuditSessionPolicy.shouldRecoverOrphan(true,true,false,false),"live service state must not be erased by UI");
        need(AuditSessionPolicy.acceptsAction(true,77L,77L),"current notification action must be accepted");
        need(!AuditSessionPolicy.acceptsAction(true,77L,76L),"old notification action must be rejected");
        need(!AuditSessionPolicy.acceptsAction(false,77L,77L),"inactive session action must be rejected");
        System.out.println("PASS AuditSessionPolicyTest");
    }
}
