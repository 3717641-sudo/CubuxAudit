package com.cubux.audit;

/** Thread-safe manual audit controller used by UI, HTTP client and loader. */
public final class AuditControl {
    private final Object lock = new Object();
    private volatile boolean paused;
    private volatile boolean stopped;
    private volatile Runnable cancelAction;

    public void pause() {
        if (!stopped) {
            paused = true;
        }
    }

    public void resume() {
        synchronized (lock) {
            if (stopped) return;
            paused = false;
            lock.notifyAll();
        }
    }

    public void stop() {
        Runnable action;
        synchronized (lock) {
            stopped = true;
            paused = false;
            action = cancelAction;
            lock.notifyAll();
        }

        // Abort the active network request immediately, if there is one.
        if (action != null) {
            try {
                action.run();
            } catch (Throwable ignored) {
            }
        }
    }

    public boolean isPaused() {
        return paused;
    }

    public boolean isStopped() {
        return stopped;
    }

    public void setCancelAction(Runnable action) {
        cancelAction = action;
        if (stopped && action != null) {
            try {
                action.run();
            } catch (Throwable ignored) {
            }
        }
    }

    public void clearCancelAction(Runnable action) {
        if (cancelAction == action) {
            cancelAction = null;
        }
    }

    public void checkpoint() throws AuditStoppedException {
        if (stopped) {
            throw new AuditStoppedException();
        }

        synchronized (lock) {
            while (paused && !stopped) {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new AuditStoppedException();
                }
            }
        }

        if (stopped) {
            throw new AuditStoppedException();
        }
    }

    public static final class AuditStoppedException extends Exception {
        public AuditStoppedException() {
            super("Проверка остановлена пользователем");
        }
    }
}
