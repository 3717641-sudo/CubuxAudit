package com.cubux.audit;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.PersistableBundle;
import java.util.Calendar;

/** Schedules exactly one next check, preventing duplicate light/full jobs. */
public final class CheckScheduler {
    public static final int JOB_ID=2801;
    private static final int LEGACY_AUTO_JOB=2201;
    private static final int LEGACY_NIGHT_JOB=2604;
    private CheckScheduler(){}

    public static final class Next {
        public final long whenMs; public final String type;
        Next(long w,String t){whenMs=w;type=t;}
    }

    public static void cancelLegacy(Context c){
        try{JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js!=null){js.cancel(LEGACY_AUTO_JOB);js.cancel(LEGACY_NIGHT_JOB);}}catch(Throwable ignored){}
        AuditDb db=new AuditDb(c);db.saveState("auto_audit_enabled","0");db.saveState("next_auto_audit_ms","0");
    }


    /** On app/boot start, catch up a genuinely missed scheduled check before planning the next one. */
    public static boolean scheduleStartup(Context c){
        cancelLegacy(c);
        AuditDb db=new AuditDb(c);
        long last=0L;
        try{String v=db.getState("last_successful_audit_ms");if(v!=null)last=Long.parseLong(v);}catch(Exception ignored){}
        long now=System.currentTimeMillis();
        if(last>0L){
            String missed=missedType(c,last,now);
            if(missed!=null){
                long target=now+30_000L;
                DiagnosticLog.write(c,"SCHEDULE","Обнаружена пропущенная проверка. Запускаю восстановительную: "+missed);
                return scheduleAt(c,target,missed,0,false);
            }
        }
        return scheduleNext(c);
    }

    private static String missedType(Context c,long fromMs,long toMs){
        CheckSettings s=new CheckSettings(c);
        Calendar day=Calendar.getInstance();day.setTimeInMillis(fromMs);
        day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);
        boolean light=false;
        for(int i=0;i<40 && day.getTimeInMillis()<=toMs;i++){
            int dow=day.get(Calendar.DAY_OF_WEEK);
            if(s.enabled(CheckSettings.TYPE_FULL,dow)){
                int[] hm=CheckSettings.parseTime(s.fullTime());Calendar x=(Calendar)day.clone();x.set(Calendar.HOUR_OF_DAY,hm[0]);x.set(Calendar.MINUTE,hm[1]);
                if(x.getTimeInMillis()>fromMs&&x.getTimeInMillis()<=toMs)return CheckSettings.TYPE_FULL;
            } else if(s.enabled(CheckSettings.TYPE_LIGHT,dow)){
                int[] hm=CheckSettings.parseTime(s.lightTime());Calendar x=(Calendar)day.clone();x.set(Calendar.HOUR_OF_DAY,hm[0]);x.set(Calendar.MINUTE,hm[1]);
                if(x.getTimeInMillis()>fromMs&&x.getTimeInMillis()<=toMs)light=true;
            }
            day.add(Calendar.DAY_OF_YEAR,1);day.set(Calendar.HOUR_OF_DAY,0);day.set(Calendar.MINUTE,0);
        }
        return light?CheckSettings.TYPE_LIGHT:null;
    }

    public static Next calculateNext(Context c,long nowMs){
        CheckSettings s=new CheckSettings(c);
        Calendar now=Calendar.getInstance();now.setTimeInMillis(nowMs);
        Next best=null;
        for(int add=0;add<15;add++){
            Calendar day=(Calendar)now.clone();day.add(Calendar.DAY_OF_YEAR,add);
            int dow=day.get(Calendar.DAY_OF_WEEK);
            String type=null,time=null;
            // Full wins the entire day if both boxes are checked.
            if(s.enabled(CheckSettings.TYPE_FULL,dow)){type=CheckSettings.TYPE_FULL;time=s.fullTime();}
            else if(s.enabled(CheckSettings.TYPE_LIGHT,dow)){type=CheckSettings.TYPE_LIGHT;time=s.lightTime();}
            if(type==null)continue;
            int[] hm=CheckSettings.parseTime(time);
            day.set(Calendar.HOUR_OF_DAY,hm[0]);day.set(Calendar.MINUTE,hm[1]);day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);
            if(day.getTimeInMillis()<=nowMs)continue;
            if(best==null||day.getTimeInMillis()<best.whenMs)best=new Next(day.getTimeInMillis(),type);
        }
        return best;
    }

    public static boolean scheduleNext(Context c){
        Next n=calculateNext(c,System.currentTimeMillis());
        if(n==null){cancel(c);return false;}
        return scheduleAt(c,n.whenMs,n.type,0,false);
    }

    public static boolean scheduleRetry(Context c,String type,int completedAttempts){
        long[] b=CheckSettings.retryBackoffSeconds();
        int idx=Math.max(0,Math.min(completedAttempts-1,b.length-1));
        long target=System.currentTimeMillis()+b[idx]*1000L;
        return scheduleAt(c,target,type,completedAttempts,true);
    }

    private static boolean scheduleAt(Context c,long target,String type,int attempt,boolean retry){
        try{
            long delay=Math.max(1000L,target-System.currentTimeMillis());
            PersistableBundle x=new PersistableBundle();x.putString("check_type",type);x.putInt("attempt",attempt);x.putBoolean("retry",retry);
            JobInfo job=new JobInfo.Builder(JOB_ID,new ComponentName(c,ScheduledCheckJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setMinimumLatency(delay)
                    .setOverrideDeadline(delay+10L*60L*1000L)
                    .setPersisted(true).setExtras(x).build();
            JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js==null)return false;
            js.cancel(JOB_ID);int r=js.schedule(job);
            if(r==JobScheduler.RESULT_SUCCESS){AuditDb db=new AuditDb(c);db.saveState("next_scheduled_check_ms",String.valueOf(target));db.saveState("next_scheduled_check_type",type);db.saveState("next_scheduled_check_retry",retry?"1":"0");return true;}
        }catch(Throwable e){DiagnosticLog.error(c,"CHECK_SCHEDULE",e);}return false;
    }

    public static void cancel(Context c){
        try{JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js!=null)js.cancel(JOB_ID);}catch(Throwable ignored){}
        AuditDb db=new AuditDb(c);db.saveState("next_scheduled_check_ms","0");db.saveState("next_scheduled_check_type","");
    }
}
