package com.cubux.audit;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/** Sequential, rate-limited transaction loader. No parallel requests. */
public class CubuxLoader {
    private final CubuxClient client;
    private final String teamId;
    private final String from;
    private final String to;
    private final AuditProgressListener listener;
    private final AuditControl control;
    private final int maxAttempts;

    public CubuxLoader(CubuxClient client, String teamId, String from, String to,
                       AuditProgressListener listener, AuditControl control, int maxAttempts) {
        this.client = client;
        this.teamId = teamId;
        this.from = from;
        this.to = to;
        this.listener = listener;
        this.control = control;
        this.maxAttempts = Math.max(1, Math.min(10, maxAttempts));
    }

    public Result loadAll() throws Exception {
        List<JSONObject> all = new ArrayList<>();
        checkpoint();
        stage("LOADING_META", "Получаю количество операций из Cubux...");
        JSONObject first = pageRetry(1);
        JSONObject meta = first.optJSONObject("_meta");
        if (meta == null) throw new IOException("Cubux: отсутствует _meta");
        int total = meta.optInt("totalCount", -1);
        int pages = meta.optInt("pageCount", -1);
        if (total < 0 || pages < 1) throw new IOException("Cubux: некорректный _meta");
        if (listener != null) listener.onMeta(total, pages);
        add(first, all);
        progress(1, pages, all.size(), total);

        for (int p = 2; p <= pages; p++) {
            checkpoint();
            stage("READING_DATA", "Загрузка страницы " + p + " из " + pages + "...");
            JSONObject data = pageRetry(p);
            JSONObject pm = data.optJSONObject("_meta");
            if (pm == null || pm.optInt("totalCount", -1) != total ||
                    pm.optInt("pageCount", -1) != pages) {
                throw new IOException("Cubux изменил список операций во время загрузки. Проверка будет повторена позже.");
            }
            add(data, all);
            progress(p, pages, all.size(), total);
        }

        checkpoint();
        if (all.size() != total) {
            throw new IOException("НЕПОЛНАЯ ЗАГРУЗКА: " + all.size() + " из " + total);
        }
        return new Result(total, pages, all);
    }

    /** Reads only page 1 and returns meta. Used by the light control check. */
    public Meta loadMetaOnly() throws Exception {
        checkpoint();
        JSONObject first = pageRetry(1);
        JSONObject meta = first.optJSONObject("_meta");
        if (meta == null) throw new IOException("Cubux: отсутствует _meta");
        int total = meta.optInt("totalCount", -1);
        int pages = meta.optInt("pageCount", -1);
        if (total < 0 || pages < 1) throw new IOException("Cubux: некорректный _meta");
        return new Meta(total, pages);
    }

    private JSONObject pageRetry(int page) throws Exception {
        int attempt = 0;
        while (true) {
            checkpoint();
            attempt++;
            try {
                stage("WAITING_CUBUX", "Ожидаю ответа Cubux...");
                return page(page);
            } catch (IOException e) {
                String message = e.getMessage() == null ? "" : e.getMessage();
                if (isPermanent(message) || attempt >= maxAttempts) throw e;
                long[] waits = CheckSettings.retryBackoffSeconds();
                int waitSeconds = (int) waits[Math.min(attempt - 1, waits.length - 1)];
                if (listener != null) listener.onRetry(page, attempt, waitSeconds, message);
                waitWithStatus(waitSeconds, attempt, message);
                stage("RECONNECTING", "Повторяю подключение к Cubux...");
            }
        }
    }

    private void waitWithStatus(int seconds, int attempt, String error) throws Exception {
        for (int left = seconds; left > 0; left--) {
            checkpoint();
            if (left == seconds || left <= 5 || left % 5 == 0) {
                stage("RETRY_WAIT", "Cubux временно не отвечает. Попытка " + (attempt + 1) +
                        " из " + maxAttempts + " через " + left + " сек. " + shortError(error));
            }
            Thread.sleep(1000L);
        }
    }

    private boolean isPermanent(String message) {
        return message.contains("HTTP 400") || message.contains("HTTP 401") ||
                message.contains("HTTP 403") || message.contains("HTTP 404");
    }

    private String shortError(String x) {
        if (x == null) return "";
        return x.length() > 90 ? x.substring(0,90) : x;
    }

    private JSONObject page(int page) throws Exception {
        StringBuilder u = new StringBuilder("https://app.cubux.net/api/v1/transaction/team/")
                .append(enc(teamId)).append("?mn=1&page=").append(page);
        if (from != null && !from.trim().isEmpty()) u.append("&dateSince=").append(enc(from));
        if (to != null && !to.trim().isEmpty()) u.append("&dateUntil=").append(enc(to));
        return new JSONObject(client.get(u.toString()));
    }

    private static String enc(String s) {
        try { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); }
        catch (Exception e) { return s == null ? "" : s; }
    }

    private void add(JSONObject data, List<JSONObject> out) throws Exception {
        JSONArray items = data.optJSONArray("items");
        if (items == null) throw new IOException("Cubux: отсутствует items");
        for (int i = 0; i < items.length(); i++) {
            checkpoint();
            JSONObject item = items.optJSONObject(i);
            if (item != null) out.add(item);
        }
    }

    private void checkpoint() throws AuditControl.AuditStoppedException {
        if (control != null) control.checkpoint();
    }
    private void stage(String stage, String message) { if (listener != null) listener.onStage(stage, message); }
    private void progress(int page, int pages, int loaded, int total) {
        if (listener != null) listener.onPage(page, pages, loaded, total);
    }

    public static class Meta {
        public final int totalCount, pageCount;
        Meta(int t, int p){ totalCount=t; pageCount=p; }
    }

    public static class Result {
        public final int totalCount;
        public final int pageCount;
        public final List<JSONObject> items;
        Result(int totalCount, int pageCount, List<JSONObject> items) {
            this.totalCount = totalCount;
            this.pageCount = pageCount;
            this.items = items;
        }
    }
}
