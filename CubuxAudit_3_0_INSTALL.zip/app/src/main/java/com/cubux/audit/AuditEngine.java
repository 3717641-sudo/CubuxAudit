package com.cubux.audit;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONObject;
import java.util.*;

public class AuditEngine {
    private final AuditDb db;
    public AuditEngine(Context c){db=new AuditDb(c);}

    public Result audit(List<JSONObject> items,int expected,long runId,Set<String>detailed,
                        int closedChanged,long started)throws Exception{
        return audit(items,expected,runId,detailed,closedChanged,started,false,null,null,false);
    }

    public Result audit(List<JSONObject> items,int expected,long runId,Set<String>detailed,
                        int closedChanged,long started,boolean partial,String fromDate,
                        boolean suppressNewEvents)throws Exception{
        return audit(items,expected,runId,detailed,closedChanged,started,partial,fromDate,null,suppressNewEvents);
    }

    /** Compatibility entry point. New 3.0 code uses the PeriodControlEngine.Result overload. */
    public Result audit(List<JSONObject> items,int expected,long runId,Set<String>detailed,
                        int closedChanged,long started,boolean partial,String fromDate,String toDate,
                        boolean suppressNewEvents)throws Exception{
        PeriodControlEngine.Result period = new PeriodControlEngine.Result(
                detailed==null?new HashSet<>():detailed,
                closedChanged,new HashSet<>(),new LinkedHashMap<>());
        return audit(items,expected,runId,period,started,partial,fromDate,toDate,suppressNewEvents);
    }

    /**
     * Applies transaction changes and day-control baselines in one SQLite transaction.
     * The caller must only invoke this after the remote scan has passed stability checks.
     */
    public Result audit(List<JSONObject> items,int expected,long runId,PeriodControlEngine.Result period,
                        long started,boolean partial,String fromDate,String toDate,
                        boolean suppressNewEvents)throws Exception{
        if(items==null||items.size()!=expected)throw new Exception("НЕПОЛНАЯ ЗАГРУЗКА");
        if(period==null)throw new Exception("Нет плана контроля периода");

        String cutoff=TimeUtil.yesterday();
        if(toDate==null||toDate.compareTo(cutoff)>0)toDate=cutoff;
        String now=TimeUtil.now();
        Map<String,String> old=db.transactions(),cur=new HashMap<>(),dates=new HashMap<>();
        boolean firstBaseline=old.isEmpty();

        for(JSONObject o:items){
            String id=id(o);
            if(id==null)throw new Exception("Запись без ID");
            if(cur.containsKey(id))throw new Exception("Дубликат ID: "+id);
            JSONObject n=normalizeRecord(o);
            String d=date(n);
            if(d!=null&&d.compareTo(cutoff)>0)
                throw new Exception("Cubux вернул незакрытый текущий день. Проверка остановлена без сохранения.");
            cur.put(id,n.toString());
            dates.put(id,d);
        }

        int nn=0,ch=0,del=0,multi=0;
        List<C> changes=new ArrayList<>();

        for(Map.Entry<String,String>e:cur.entrySet()){
            String id=e.getKey(),nd=e.getValue(),d=dates.get(id),od=old.get(id);
            boolean det=d==null||period.detailedDates==null||period.detailedDates.contains(d);
            boolean baselineDay=d!=null&&period.baselineDates.contains(d);
            boolean suppress=suppressNewEvents||firstBaseline||baselineDay;
            if(od==null){
                if(!suppress){
                    nn++;
                    changes.add(new C(id,d,"NEW",null,nd,true));
                }
            }else if(det&&!HashUtil.sha256(od).equals(HashUtil.sha256(nd))){
                if(!suppress){
                    ch++;
                    if(db.changeCount(id)>=1)multi++;
                    changes.add(new C(id,d,"CHANGED",od,nd,true));
                }
            }
        }

        Set<String> missing=new HashSet<>();
        for(Map.Entry<String,String> e:old.entrySet()){
            String id=e.getKey();
            if(cur.containsKey(id))continue;

            String d=null;
            try{d=date(new JSONObject(e.getValue()));}catch(Exception ignored){}

            // Only records inside the requested closed-day range are eligible for deletion.
            if(fromDate!=null&&d!=null&&d.compareTo(fromDate)<0)continue;
            if(toDate!=null&&d!=null&&d.compareTo(toDate)>0)continue;
            if(partial&&d==null)continue; // ambiguous record: never delete it from a partial scan

            boolean det=d==null||period.detailedDates==null||period.detailedDates.contains(d);
            if(!det)continue;
            boolean baselineDay=d!=null&&period.baselineDates.contains(d);
            boolean suppress=suppressNewEvents||firstBaseline||baselineDay;
            missing.add(id);
            if(!suppress){
                del++;
                changes.add(new C(id,d,"DELETED",e.getValue(),null,true));
            }
        }

        SQLiteDatabase sql=db.begin(); boolean ok=false;
        try{
            for(C c:changes)db.change(c.id,c.date,c.type,c.oldD,c.newD,c.closed);
            for(Map.Entry<String,String>e:cur.entrySet())
                db.upsert(e.getKey(),dates.get(e.getKey()),e.getValue(),now,old.containsKey(e.getKey()));
            for(String id:missing)db.deleteTx(id);
            for(Map.Entry<String,PeriodControlEngine.SnapData> e:period.closureUpdates.entrySet()){
                PeriodControlEngine.SnapData x=e.getValue();
                db.upsertClosure(e.getKey(),x.count,x.income,x.expense,x.currencies,x.hash,x.baseline,x.status);
            }
            db.end(sql,true); ok=true;
        }finally{
            if(!ok)try{db.end(sql,false);}catch(Exception ignored){}
        }

        if(firstBaseline) db.saveState("baseline_created_at",now);
        if(suppressNewEvents) db.saveState("restore_sync_pending","0");

        int currentTotal=db.transactions().size();
        long dur=System.currentTimeMillis()-started;
        db.finishRun(runId,dur,currentTotal,nn,ch,del,period.closedChangedCount,multi);
        return new Result(currentTotal,nn,ch,del,period.closedChangedCount,multi,runId,dur);
    }

    public static JSONObject normalizeRecord(JSONObject s)throws Exception{
        String[]f={"id","uuid","date","category_id","category_uuid","category","amount","currency_code",
                "amount2","currency_code2","account","account_uuid","account2","account2_uuid",
                "loan_id","loan_uuid","project_uuid","receipt_uuid","is_imported","user_id",
                "user_uuid","user_name","description","type"};
        JSONObject r=new JSONObject();
        for(String x:f)r.put(x,s.opt(x));
        return r;
    }

    private String id(JSONObject o){
        Object x=o.opt("id");
        if(x==null)return null;
        String s=String.valueOf(x).trim();
        return s.isEmpty()?null:s;
    }

    static String operationDate(JSONObject o){return date(o);}
    private static String date(JSONObject o){
        String d=o.optString("date","");
        return d.length()>=10?d.substring(0,10):null;
    }

    static class C{
        String id,date,type,oldD,newD; boolean closed;
        C(String i,String d,String t,String o,String n,boolean c){
            id=i;date=d;type=t;oldD=o;newD=n;closed=c;
        }
    }

    public static class Result{
        public final int total,newCount,changedCount,deletedCount,closedChangedCount,multiChangedCount;
        public final long runId,durationMs;
        Result(int t,int n,int c,int d,int cc,int m,long r,long dur){
            total=t;newCount=n;changedCount=c;deletedCount=d;
            closedChangedCount=cc;multiChangedCount=m;runId=r;durationMs=dur;
        }
    }
}
