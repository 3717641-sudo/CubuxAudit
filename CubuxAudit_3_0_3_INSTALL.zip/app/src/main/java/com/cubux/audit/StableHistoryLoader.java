package com.cubux.audit;

import android.content.Context;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Loads only closed history and proves that it was stable while being scanned.
 * If a user edits/adds/deletes an old record during the scan, only the affected
 * month range is re-read when Cubux aggregate controls can localize it.
 */
public final class StableHistoryLoader {
    private static final int MAX_STABILITY_RETRIES = 3;
    private static final int QUIET_WAIT_SECONDS = 5;

    private final Context context;
    private final AuditDb db;
    private final CubuxClient client;
    private final String teamId;
    private final AuditProgressListener listener;
    private final AuditControl control;
    private final int requestAttempts;
    private LightCheckEngine.ControlSnapshot stableControl;

    public StableHistoryLoader(Context context, AuditDb db, CubuxClient client, String teamId,
                               AuditProgressListener listener, AuditControl control, int requestAttempts) {
        this.context=context.getApplicationContext();
        this.db=db; this.client=client; this.teamId=teamId; this.listener=listener;
        this.control=control; this.requestAttempts=requestAttempts;
    }

    public CubuxLoader.Result load(String from,String to) throws Exception {
        LightCheckEngine guard=new LightCheckEngine(context,db,client,teamId,listener,control,requestAttempts);
        stage("STABILITY_START","Фиксирую контрольное состояние закрытой истории...");
        LightCheckEngine.ControlSnapshot before=guard.captureControl(from,to);

        CubuxLoader.Result master=new CubuxLoader(client,teamId,from,to,listener,control,requestAttempts).loadAll();
        stage("READ_COMPLETE","Основное чтение завершено: получено "+master.totalCount+" операций, "+master.pageCount+" страниц. Перехожу к контролю стабильности истории...");

        if(before==null){
            DiagnosticLog.write(context,"STABILITY","Контрольный агрегат недоступен; использую двойное чтение истории");
            stage("STABILITY_FALLBACK","Контрольные агрегаты Cubux недоступны. Для безопасности подтверждаю результат повторным чтением истории.");
            return fallbackDoubleRead(master,from,to);
        }

        stage("STABILITY_VERIFY","Проверяю, не менялась ли закрытая история во время сканирования...");
        LightCheckEngine.ControlSnapshot after=guard.captureControl(from,to);
        if(LightCheckEngine.sameControl(before,after)){
            stableControl=after;
            stage("STABILITY_OK","Контроль стабильности завершён: закрытая история не менялась во время сканирования.");
            return master;
        }

        for(int attempt=1;attempt<=MAX_STABILITY_RETRIES;attempt++){
            checkpoint();
            boolean candidateUpdated=false;
            Set<String> months=LightCheckEngine.changedMonths(before,after);
            if(!months.isEmpty()){
                String first=Collections.min(months)+"-01";
                String last=monthEnd(Collections.max(months));
                if(from!=null&&first.compareTo(from)<0)first=from;
                if(to!=null&&last.compareTo(to)>0)last=to;
                stage("HISTORY_MOVED","Закрытая история изменилась во время проверки. Подготавливаю повтор периода "+first+" — "+last+" ("+attempt+"/"+MAX_STABILITY_RETRIES+")...");
                quietWait();

                LightCheckEngine.ControlSnapshot patchBefore=guard.captureControl(first,last);
                stage("HISTORY_RESCAN","Повторно читаю только изменённый период "+first+" — "+last+". Эталон пока не изменяется.");
                CubuxLoader.Result patch=new CubuxLoader(client,teamId,first,last,listener,control,requestAttempts).loadAll();
                LightCheckEngine.ControlSnapshot patchAfter=guard.captureControl(first,last);
                if(patchBefore!=null&&patchAfter!=null&&LightCheckEngine.sameControl(patchBefore,patchAfter)){
                    master=merge(master,patch,first,last);
                    candidateUpdated=true;
                } else {
                    // Period was still moving. Do not merge an unstable fragment.
                    DiagnosticLog.write(context,"STABILITY","Изменённый период продолжал меняться; повтор не принят");
                }
            }else{
                stage("HISTORY_MOVED","Закрытая история изменилась, но период не локализован. Повторяю полный скан ("+attempt+"/"+MAX_STABILITY_RETRIES+")...");
                quietWait();
                master=new CubuxLoader(client,teamId,from,to,listener,control,requestAttempts).loadAll();
                candidateUpdated=true;
            }

            LightCheckEngine.ControlSnapshot current=guard.captureControl(from,to);
            if(candidateUpdated&&current!=null&&LightCheckEngine.sameControl(after,current)){
                stableControl=current;
                stage("STABILITY_OK","История стабильна. Результат можно сохранять.");
                return master;
            }
            before=after;
            after=current;
            if(after==null)return fallbackDoubleRead(master,from,to);
        }

        throw new Exception("Данные Cubux продолжают изменяться во время проверки. Ничего не сохранено; повторите проверку позже.");
    }

    public LightCheckEngine.ControlSnapshot getStableControl(){return stableControl;}

    private CubuxLoader.Result fallbackDoubleRead(CubuxLoader.Result first,String from,String to) throws Exception {
        stableControl=null;
        CubuxLoader.Result previous=first;
        String previousHash=itemsHash(previous.items);
        for(int attempt=1;attempt<=MAX_STABILITY_RETRIES;attempt++){
            stage("STABILITY_FALLBACK","Контроль стабильности: подготавливаю повторный проход "+attempt+" из "+MAX_STABILITY_RETRIES+"...");
            quietWait();
            stage("STABILITY_FALLBACK_SCAN","Контроль стабильности: повторное чтение истории, проход "+attempt+" из "+MAX_STABILITY_RETRIES+". Результат пока не сохраняется.");
            CubuxLoader.Result current=new CubuxLoader(client,teamId,from,to,listener,control,requestAttempts).loadAll();
            String currentHash=itemsHash(current.items);
            if(previous.totalCount==current.totalCount&&previousHash.equals(currentHash)){
                stage("STABILITY_OK","Контрольное повторное чтение совпало. История стабильна, результат можно сохранять.");
                return current;
            }
            previous=current; previousHash=currentHash;
        }
        throw new Exception("Данные Cubux продолжают изменяться во время проверки. Ничего не сохранено; повторите проверку позже.");
    }

    private CubuxLoader.Result merge(CubuxLoader.Result master,CubuxLoader.Result patch,String from,String to){
        List<JSONObject> out=new ArrayList<>();
        for(JSONObject x:master.items){
            String d=date(x);
            if(d==null||d.compareTo(from)<0||d.compareTo(to)>0)out.add(x);
        }
        out.addAll(patch.items);
        return new CubuxLoader.Result(out.size(),master.pageCount,out);
    }

    private String itemsHash(List<JSONObject> items)throws Exception{
        List<String> rows=new ArrayList<>();
        for(JSONObject x:items)rows.add(AuditEngine.normalizeRecord(x).toString());
        Collections.sort(rows);StringBuilder b=new StringBuilder();
        for(String x:rows)b.append(x).append('\n');
        return HashUtil.sha256(b.toString());
    }

    private String date(JSONObject o){String d=o.optString("date","");return d.length()>=10?d.substring(0,10):null;}

    private void quietWait() throws Exception{
        for(int left=QUIET_WAIT_SECONDS;left>0;left--){
            checkpoint();
            stage("STABILITY_WAIT","Жду завершения редактирования старых записей: "+left+" сек...");
            Thread.sleep(1000L);
        }
    }

    private String monthEnd(String yyyyMm){
        try{Calendar c=Calendar.getInstance();Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(yyyyMm+"-01");c.setTime(d);c.set(Calendar.DAY_OF_MONTH,c.getActualMaximum(Calendar.DAY_OF_MONTH));return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
        catch(Exception e){return yyyyMm+"-31";}
    }

    private void stage(String s,String m){CheckStatusStore.activity(context,m);if(listener!=null)listener.onStage(s,m);}
    private void checkpoint() throws AuditControl.AuditStoppedException {if(control!=null)control.checkpoint();}
}
