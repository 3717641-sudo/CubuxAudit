package com.cubux.audit;

import android.content.Context;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

/** Read-only current-day observer. Uses separate day_snapshot/day_events tables only. */
public final class DayControlEngine {
    private final Context app;
    private final AuditDb db;

    public DayControlEngine(Context context) {
        app = context.getApplicationContext();
        db = new AuditDb(app);
    }

    public AuditDb.DayScanResult scan(String day) throws Exception {
        if (day == null || day.trim().isEmpty()) day = TimeUtil.today();
        final String scanDay = day.trim();
        SecureCredentialsStore credentials = new SecureCredentialsStore(app);
        String login = credentials.getLogin();
        String password = credentials.getPassword();
        if (login == null || login.trim().isEmpty() || password == null || password.isEmpty()) {
            throw new Exception("Логин/пароль Cubux не сохранены");
        }

        CheckSettings settings = new CheckSettings(app);
        CubuxAuthClient auth = new CubuxAuthClient(app, settings.requestDelayMs());
        String token = auth.login(login, password);
        CubuxClient client = new CubuxClient(app, token,
                () -> new CubuxAuthClient(app, settings.requestDelayMs()).login(login, password),
                null, settings.requestDelayMs());
        String team = new CubuxTeamResolver(app, client).resolve();
        CubuxLoader.Result loaded = new CubuxLoader(client, team, scanDay, scanDay,
                null, null, settings.retries()).loadAll();

        Map<String,String> current = new LinkedHashMap<>();
        for (JSONObject raw : loaded.items) {
            JSONObject normalized = AuditEngine.normalizeRecord(raw);
            Object idValue = normalized.opt("id");
            if (idValue == null || idValue == JSONObject.NULL) continue;
            String id = String.valueOf(idValue).trim();
            if (id.isEmpty()) continue;
            String operationDate = AuditEngine.operationDate(normalized);
            if (operationDate != null && !scanDay.equals(operationDate)) continue;
            current.put(id, normalized.toString());
        }
        return db.applyDayScan(scanDay, current, TimeUtil.now());
    }
}
