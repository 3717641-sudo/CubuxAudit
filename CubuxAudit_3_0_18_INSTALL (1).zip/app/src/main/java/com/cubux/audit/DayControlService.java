package com.cubux.audit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import java.util.concurrent.atomic.AtomicBoolean;

/** Short foreground service for hourly current-day scans. */
public class DayControlService extends Service {
    public static final String ACTION = "com.cubux.audit.DAY_CONTROL_RUN";
    private static final String CHANNEL = "cubux_day_control";
    private static final int ID = 3181;
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    public static void startScheduled(Context c, String day, boolean finalScan, long scheduledFor) {
        Intent i = new Intent(c, DayControlService.class).setAction(ACTION)
                .putExtra("scan_day", day)
                .putExtra("final_scan", finalScan)
                .putExtra("scheduled_for", scheduledFor)
                .putExtra("manual", false);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    public static void startNow(Context c) {
        Intent i = new Intent(c, DayControlService.class).setAction(ACTION)
                .putExtra("scan_day", TimeUtil.today())
                .putExtra("final_scan", false)
                .putExtra("scheduled_for", System.currentTimeMillis())
                .putExtra("manual", true);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(ID, notification("Проверяю сегодняшние записи…"));
        if (!RUNNING.compareAndSet(false, true)) {
            DayControlScheduler.scheduleNext(this);
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        final String day = intent == null ? TimeUtil.today() : intent.getStringExtra("scan_day");
        final boolean finalScan = intent != null && intent.getBooleanExtra("final_scan", false);
        final boolean manual = intent != null && intent.getBooleanExtra("manual", false);
        final Context app = getApplicationContext();

        new Thread(() -> {
            AuditDb db = new AuditDb(app);
            try {
                AuditDb.DayScanResult r = new DayControlEngine(app).scan(day);
                db.saveState("day_control_last_scan_time", TimeUtil.now());
                db.saveState("day_control_last_scan_day", r.day);
                db.saveState("day_control_last_scan_total", String.valueOf(r.total));
                db.saveState("day_control_last_scan_status", "OK");
                db.saveState("day_control_last_scan_final", finalScan ? "1" : "0");
                db.saveState("day_control_last_error", "");

                if (r.newCount > 0) {
                    // Новая сегодняшняя запись — обычное информационное событие.
                    // Она остаётся в Центре событий, но не перегружает очередь на Главной.
                    db.appEvent("INFO", "КОНТРОЛЬ ДНЯ",
                            "За сегодня добавлено новых записей: " + r.newCount,
                            "TODAY", "TODAY", false);
                }
                if (r.changedCount > 0) {
                    db.appEvent("WARNING", "КОНТРОЛЬ ДНЯ",
                            r.changedCount == 1 ? "За сегодня изменена 1 запись" : "За сегодня изменено записей: " + r.changedCount,
                            "TODAY", "TODAY", true);
                }
                if (r.deletedCount > 0) {
                    db.appEvent("ALERT", "КОНТРОЛЬ ДНЯ",
                            r.deletedCount == 1 ? "За сегодня удалена 1 запись" : "За сегодня удалено записей: " + r.deletedCount,
                            "TODAY", "TODAY", true);
                }
                if (r.newCount + r.changedCount + r.deletedCount == 0) {
                    db.appEvent("INFO", "КОНТРОЛЬ ДНЯ",
                            "Дневной скан завершён. Изменений с прошлого скана нет.",
                            "TODAY", "TODAY", false);
                }
                DiagnosticLog.write(app, "DAY_CONTROL",
                        (manual ? "Ручной" : finalScan ? "Финальный" : "Почасовой") +
                                " скан " + r.day + ": всего " + r.total +
                                ", новых " + r.newCount + ", изменённых " + r.changedCount +
                                ", удалённых " + r.deletedCount);
            } catch (Throwable e) {
                String error = shortMessage(e);
                String previousStatus = db.getState("day_control_last_scan_status");
                String previousError = db.getState("day_control_last_error");
                db.saveState("day_control_last_scan_time", TimeUtil.now());
                db.saveState("day_control_last_scan_day", day == null ? TimeUtil.today() : day);
                db.saveState("day_control_last_scan_status", "ERROR");
                db.saveState("day_control_last_error", error);
                db.recordDayScanError(day == null ? TimeUtil.today() : day, error);
                // Одинаковую повторяющуюся ошибку не кладём в очередь Главной каждый час.
                // Все попытки всё равно остаются в day_scans и диагностическом логе.
                if (!"ERROR".equals(previousStatus) || previousError == null || !previousError.equals(error)) {
                    db.appEvent("WARNING", "КОНТРОЛЬ ДНЯ",
                            "Дневной скан не выполнен: " + error,
                            "TODAY", "TODAY", true);
                }
                DiagnosticLog.error(app, "DAY_CONTROL", e);
            } finally {
                RUNNING.set(false);
                DayControlScheduler.scheduleNext(app);
                stopSelf(startId);
            }
        }, "CubuxDayControl").start();
        return START_NOT_STICKY;
    }

    private static String shortMessage(Throwable e) {
        String s = e == null ? "неизвестная ошибка" : e.getMessage();
        if (s == null || s.trim().isEmpty()) s = String.valueOf(e);
        return s.length() > 120 ? s.substring(0, 120) : s;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager m = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (m != null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Контроль дня", NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Короткие почасовые проверки сегодняшних записей Cubux");
                m.createNotificationChannel(ch);
            }
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 3181, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("Cubux Security — Контроль дня")
                .setContentText(text)
                .setContentIntent(pi)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .build();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
