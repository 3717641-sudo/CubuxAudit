package com.cubux.audit;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class BackupScheduler {
    private static final int REQUEST_CODE=7719;
    private BackupScheduler(){}

    public static boolean enabled(AuditDb db){return "1".equals(db.getState("backup_auto_enabled"));}
    public static int intervalDays(AuditDb db){return clamp(parse(db.getState("backup_interval_days"),7),1,90);}
    public static int keepCount(AuditDb db){return clamp(parse(db.getState("backup_keep_count"),10),1,50);}
    public static long nextMs(AuditDb db){try{return Long.parseLong(nvl(db.getState("backup_next_ms"),"0"));}catch(Exception e){return 0;}}
    public static void setEnabled(Context c,AuditDb db,boolean on){db.saveState("backup_auto_enabled",on?"1":"0");if(on)scheduleFromNow(c,db);else cancel(c,db);}
    public static void setInterval(Context c,AuditDb db,int days){db.saveState("backup_interval_days",String.valueOf(clamp(days,1,90)));if(enabled(db))scheduleFromNow(c,db);}
    public static void setKeep(Context c,AuditDb db,int keep){db.saveState("backup_keep_count",String.valueOf(clamp(keep,1,50)));BackupStorage.trim(c,db,keepCount(db));}

    public static void scheduleFromNow(Context c,AuditDb db){
        long next=System.currentTimeMillis()+intervalDays(db)*86400000L;
        db.saveState("backup_next_ms",String.valueOf(next));
        scheduleAt(c,next);
    }

    public static void afterSuccess(Context c,AuditDb db){
        db.saveState("backup_last_auto_time",TimeUtil.now());
        db.saveState("backup_last_auto_status","OK");
        scheduleFromNow(c,db);
    }

    public static void retrySoon(Context c,AuditDb db,int minutes){
        long next=System.currentTimeMillis()+Math.max(1,minutes)*60000L;
        db.saveState("backup_next_ms",String.valueOf(next));
        scheduleAt(c,next);
    }

    public static void restore(Context c){
        AuditDb db=new AuditDb(c);
        try{
            if(!enabled(db)){cancel(c,db);return;}
            long next=nextMs(db);
            if(next<=0){scheduleFromNow(c,db);return;}
            if(next<=System.currentTimeMillis()){
                scheduleAt(c,System.currentTimeMillis()+5000L);
            }else scheduleAt(c,next);
        }finally{db.close();}
    }

    private static void scheduleAt(Context c,long when){
        try{
            AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
            PendingIntent pi=pending(c,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }catch(Throwable e){DiagnosticLog.error(c,"BACKUP_SCHEDULE",e);}
    }

    private static void cancel(Context c,AuditDb db){
        db.saveState("backup_next_ms","0");
        try{AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pending(c,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE));}catch(Throwable ignored){}
    }

    private static PendingIntent pending(Context c,int flags){return PendingIntent.getBroadcast(c,REQUEST_CODE,new Intent(c,BackupAlarmReceiver.class),flags);}
    private static int parse(String s,int d){try{return Integer.parseInt(s);}catch(Exception e){return d;}}
    private static int clamp(int v,int a,int b){return Math.max(a,Math.min(b,v));}
    private static String nvl(String s,String d){return s==null?d:s;}
}
