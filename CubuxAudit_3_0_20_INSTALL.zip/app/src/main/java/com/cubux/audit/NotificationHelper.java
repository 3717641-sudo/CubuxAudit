package com.cubux.audit;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** Central notification policy. Every Cubux Security notification opens the relevant screen. */
public final class NotificationHelper {

    private static final String CHANNEL = "cubux_audit_status";
    private static final int ID_AUDIT_RESULT=2202, ID_WARNING=2203, ID_DAY_WARNING=2204, ID_BACKUP=2205;

    private NotificationHelper() {}

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;
            NotificationChannel channel=new NotificationChannel(CHANNEL,"Cubux Security",NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Результаты и предупреждения Cubux Security");
            manager.createNotificationChannel(channel);
        }
    }

    private static PendingIntent route(Context context,String target,String filter,int requestCode){
        Intent open=new Intent(context,MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(MainActivity.EXTRA_NOTIFICATION_TARGET,target);
        if(filter!=null&&!filter.trim().isEmpty())open.putExtra(MainActivity.EXTRA_NOTIFICATION_FILTER,filter);
        return PendingIntent.getActivity(context,requestCode,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }

    public static void showWarning(Context context, String text) {
        try {
            ensureChannel(context);
            if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
            NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE); if(manager==null)return;
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,CHANNEL):new android.app.Notification.Builder(context);
            b.setSmallIcon(R.drawable.ic_shield_check)
                    .setColor(android.graphics.Color.rgb(255,159,10))
                    .setContentTitle("Требуется внимание")
                    .setContentText(compact(text,96))
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(text))
                    .setContentIntent(route(context,MainActivity.TARGET_EVENTS,null,22030))
                    .setAutoCancel(true);
            manager.notify(ID_WARNING,b.build());
        } catch(Throwable ignored) {}
    }

    public static void showAuditResult(Context context, boolean success, String text) {
        try {
            ensureChannel(context);
            if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
            NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE); if(manager==null)return;
            android.app.Notification.Builder builder=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,CHANNEL):new android.app.Notification.Builder(context);
            boolean hasChanges=success && text!=null && !text.contains("Изменений не обнаружено") &&
                    (text.contains("Новые:")||text.contains("Изменённые:")||text.contains("Удалённые:"));
            String target=hasChanges?MainActivity.TARGET_JOURNAL:MainActivity.TARGET_CHECK_HISTORY;
            builder.setSmallIcon(R.drawable.ic_shield_check)
                    .setColor(success?android.graphics.Color.rgb(0,169,120):android.graphics.Color.rgb(255,75,86))
                    .setContentTitle(success ? (hasChanges?"Найдены изменения":"Проверка завершена") : "Проверка не завершена")
                    .setContentText(compact(text,96))
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(text))
                    .setContentIntent(route(context,target,null,22020))
                    .setAutoCancel(true);
            manager.notify(ID_AUDIT_RESULT,builder.build());
        } catch (Throwable ignored) {}
    }

    public static void showDayControlAlert(Context context,String text,boolean deleted){
        try{
            ensureChannel(context);
            if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            NotificationManager m=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(m==null)return;
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,CHANNEL):new android.app.Notification.Builder(context);
            b.setSmallIcon(R.drawable.ic_shield_check)
                    .setColor(deleted?android.graphics.Color.rgb(255,75,86):android.graphics.Color.rgb(255,174,0))
                    .setContentTitle(deleted?"Удалена запись за сегодня":"Изменена запись за сегодня")
                    .setContentText(compact(text,96))
                    .setContentIntent(route(context,MainActivity.TARGET_TODAY,deleted?"DELETED":"CHANGED",22040))
                    .setAutoCancel(true);
            m.notify(ID_DAY_WARNING,b.build());
        }catch(Throwable ignored){}
    }

    public static void showDayControlError(Context context,String text){
        try{
            ensureChannel(context);
            if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            NotificationManager m=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(m==null)return;
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,CHANNEL):new android.app.Notification.Builder(context);
            b.setSmallIcon(R.drawable.ic_shield_check)
                    .setColor(android.graphics.Color.rgb(255,159,10))
                    .setContentTitle("Дневной контроль не выполнен")
                    .setContentText(compact(text,96))
                    .setContentIntent(route(context,MainActivity.TARGET_TODAY,"ALL",22041))
                    .setAutoCancel(true);
            m.notify(ID_DAY_WARNING,b.build());
        }catch(Throwable ignored){}
    }

    public static void clearDayControlWarning(Context context){
        try{NotificationManager m=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(m!=null)m.cancel(ID_DAY_WARNING);}catch(Throwable ignored){}
    }

    public static void showBackupResult(Context context,boolean success,String text){
        try{
            ensureChannel(context);
            if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            NotificationManager m=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(m==null)return;
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,CHANNEL):new android.app.Notification.Builder(context);
            b.setSmallIcon(R.drawable.ic_shield_check)
                    .setColor(success?android.graphics.Color.rgb(0,169,120):android.graphics.Color.rgb(255,75,86))
                    .setContentTitle(success?"Резервная копия создана":"Ошибка резервной копии")
                    .setContentText(compact(text,96))
                    .setContentIntent(route(context,MainActivity.TARGET_BACKUP,null,22050))
                    .setAutoCancel(true);
            m.notify(ID_BACKUP,b.build());
        }catch(Throwable ignored){}
    }

    private static String compact(String text,int max){String x=text==null?"":text.replace('\n',' ').trim();return x.length()>max?x.substring(0,max-1)+"…":x;}
}
