package com.cubux.audit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.os.Bundle;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_BANK = 1001;
    private static final int REQ_BACKUP = 1002;
    private static final int REQ_RESTORE = 1003;
    private static final int REQ_LOG = 1004;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_CHECK = 1;
    private static final int PAGE_BANK = 2;
    private static final int PAGE_REPORTS = 3;
    private static final int PAGE_JOURNAL = 4;
    private static final int PAGE_SETTINGS = 5;
    private static final int PAGE_COUNT = 6;

    private static final int ACCENT = Color.rgb(0, 169, 190);

    private final int GREEN = Color.rgb(0, 190, 113);
    private final int DARK = Color.rgb(18, 39, 67);
    private final int TEXT = Color.rgb(15, 31, 55);
    private final int MUTED = Color.rgb(104, 123, 153);
    private final int RED = Color.rgb(255, 75, 88);
    private final int YELLOW = Color.rgb(255, 184, 31);
    private final int PURPLE = Color.rgb(126, 79, 255);
    private final int BLUE = Color.rgb(24, 139, 232);

    private AuditDb db;
    private SecureCredentialsStore credentials;

    private LinearLayout pageHost;
    private LinearLayout bottomNav;
    private TextView informerText;
    private LinearLayout informerCard;
    private TextView informerIcon;
    private TextView headerStatusPill;
    private int currentPage = PAGE_HOME;
    private float swipeDownX;
    private float swipeDownY;

    private EditText loginInput;
    private EditText passwordInput;

    private ProgressBar progressBar;
    private TextView percentText;
    private TextView statusText;
    private TextView detailsText;
    private TextView resultText;
    private TextView lastCheckText;

    private TextView connectStep;
    private TextView readStep;
    private TextView compareStep;
    private TextView reportStep;
    private final TextView[] stageRows = new TextView[8];
    private final TextView[] detailValues = new TextView[8];
    private TextView checkBannerTitle;
    private TextView checkBannerSubtitle;
    private TextView checkModePill;
    private TextView progressAmountText;
    private final TextView[] stageIconViews = new TextView[8];
    private final TextView[] stageStatusViews = new TextView[8];
    private TextView currentStageSummaryTitle;
    private TextView currentStageSummaryBody;
    private Button homeQuickButton;

    private TextView totalTop;
    private TextView newTop;
    private TextView changedTop;
    private TextView deletedTop;

    private TextView newCard;
    private TextView changedCard;
    private TextView deletedCard;
    private TextView closedCard;
    private TextView multiCard;

    private Button auditButton;
    private Button fullAuditButton;
    private Button pauseButton;
    private Button stopButton;
    private AuditControl auditControl;
    private long auditSessionCounter = 0L;
    private volatile long activeAuditSession = 0L;
    private volatile int maxPageShown = 0;
    private volatile int maxLoadedShown = 0;
    private volatile int maxPercentShown = 0;
    private volatile boolean auditRunning;
    private String activeCheckMode = AuditCoordinator.MODE_QUICK;
    private volatile String scanContext = "";
    private volatile String currentStageForUi = "IDLE";
    private volatile String currentWaitForUi = "";

    private long startedMs;
    private int retries;

    private final Handler progressSyncHandler = new Handler(Looper.getMainLooper());
    private boolean progressSyncActive = false;
    private final Runnable progressSyncTick = new Runnable() {
        @Override public void run() {
            if (!progressSyncActive) return;
            try { syncProgressFromService(); } catch (Throwable ignored) {}
            progressSyncHandler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);

        db = new AuditDb(this);
        if (!"1".equals(db.getState("legacy_baseline_noise_cleaned"))) {
            db.cleanupLegacyBaselineNoise();
        }
        String autoBackupTime = db.getState("auto_backup_time");
        String lastSuccessfulCheck = db.getState("last_successful_audit_ms");
        // Do not create an empty automatic backup on a fresh reinstall: an older
        // Downloads backup must remain easy to identify and restore first.
        if ((autoBackupTime == null || autoBackupTime.trim().isEmpty())
                && lastSuccessfulCheck != null && !lastSuccessfulCheck.trim().isEmpty()) {
            AutoBackupManager.backupAsync(this);
        }

        credentials =
                new SecureCredentialsStore(
                        this
                );

        createUi();

        try {
            NotificationHelper.ensureChannel(this);
            CheckScheduler.scheduleStartup(this);
            DiagnosticLog.write(this, "APP", "Приложение запущено");
            db.appEvent("INFO", "ПРИЛОЖЕНИЕ", "Cubux Security 3.0.15 запущен");
            refreshAutoAuditStatus();
            refreshLastCheckStatus();
        } catch (Throwable e) {
            DiagnosticLog.error(this, "APP_START", e);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startProgressSync();
        try {
            refreshAutoAuditStatus();
            refreshLastCheckStatus();
            refreshDashboardInformer();
            AuditControl running = AuditControlRegistry.current();
            if (running != null && AuditRunGate.isRunning()) {
                auditControl = running;
                auditRunning = true;
                if (currentPage != PAGE_CHECK) { refreshDashboardInformer(); return; }
                pauseButton.setEnabled(true);
                stopButton.setEnabled(true);
                auditButton.setEnabled(false);
                auditButton.setVisibility(View.GONE);
                if (fullAuditButton != null) { fullAuditButton.setEnabled(false); fullAuditButton.setVisibility(View.GONE); }
                pauseButton.setVisibility(View.VISIBLE);
                stopButton.setVisibility(View.VISIBLE);
                AuditForegroundService.Snapshot snap = AuditForegroundService.snapshot();
                currentStageForUi = snap.stage == null ? currentStageForUi : snap.stage;
                currentWaitForUi = snap.note == null ? "" : snap.note;
                progressBar.setProgress(snap.percent);
                percentText.setText(snap.percent + "%");
                if (progressAmountText != null) progressAmountText.setText(snap.total > 0 ? (snap.loaded + " из " + snap.total + " операций") : progressFallbackText(snap));
                statusText.setText(running.isPaused() ? "Проверка на паузе" : snap.state);
                refreshCheckModeUi();
                updateStageIndicators(currentStageForUi);
                detailsText.setText(runningDetails(snap));
            }
        } catch (Throwable e) {
            DiagnosticLog.error(this, "RESUME", e);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev != null) {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                swipeDownX = ev.getX();
                swipeDownY = ev.getY();
            } else if (ev.getAction() == MotionEvent.ACTION_UP) {
                float dx = ev.getX() - swipeDownX;
                float dy = ev.getY() - swipeDownY;
                if (Math.abs(dx) > dp(85) && Math.abs(dx) > Math.abs(dy) * 1.35f) {
                    if (dx < 0 && currentPage < PAGE_COUNT - 1) switchPage(currentPage + 1);
                    else if (dx > 0 && currentPage > 0) switchPage(currentPage - 1);
                    return true;
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopProgressSync();
    }

    private void startProgressSync() {
        if (progressSyncActive) return;
        progressSyncActive = true;
        progressSyncHandler.removeCallbacks(progressSyncTick);
        progressSyncHandler.post(progressSyncTick);
    }

    private void stopProgressSync() {
        progressSyncActive = false;
        progressSyncHandler.removeCallbacks(progressSyncTick);
    }

    /** Notification and the visible screen read the same foreground-service snapshot. */
    private void syncProgressFromService() {
        if (!AuditRunGate.isRunning()) { refreshDashboardInformer(); return; }
        if (currentPage != PAGE_CHECK) { refreshDashboardInformer(); return; }
        AuditForegroundService.Snapshot s = AuditForegroundService.snapshot();
        AuditControl running = AuditControlRegistry.current();
        auditRunning = true;
        if (running != null) auditControl = running;
        maxPercentShown = Math.max(maxPercentShown, s.percent);
        maxPageShown = Math.max(maxPageShown, s.page);
        maxLoadedShown = Math.max(maxLoadedShown, s.loaded);
        currentStageForUi = s.stage == null ? currentStageForUi : s.stage;
        currentWaitForUi = s.note == null ? "" : s.note;
        if (progressBar != null) progressBar.setProgress(Math.min(100, s.percent));
        if (percentText != null) percentText.setText(s.percent + "%");
        if (progressAmountText != null) progressAmountText.setText(s.total > 0 ? (s.loaded + " из " + s.total + " операций") : progressFallbackText(s));
        if (statusText != null) statusText.setText(running != null && running.isPaused() ? "Проверка на паузе" : s.state);
        refreshCheckModeUi();
        updateStageIndicators(currentStageForUi);
        if (detailsText != null) detailsText.setText(runningDetails(s));
        if (pauseButton != null) { pauseButton.setEnabled(running != null); pauseButton.setVisibility(View.VISIBLE); }
        if (stopButton != null) { stopButton.setEnabled(running != null); stopButton.setVisibility(View.VISIBLE); }
        if (auditButton != null) { auditButton.setEnabled(false); auditButton.setVisibility(View.GONE); }
        if (fullAuditButton != null) { fullAuditButton.setEnabled(false); fullAuditButton.setVisibility(View.GONE); }
        refreshHomeQuickButton();
    }

    private void createUi() {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(Color.rgb(247, 250, 253));
        screen.addView(buildHeader(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        pageHost.setBackgroundColor(Color.rgb(247, 250, 253));
        screen.addView(pageHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        bottomNav = buildBottomNavigation();
        screen.addView(bottomNav, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(70)));
        setContentView(screen);
        switchPage(PAGE_HOME);
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(7), dp(3), dp(7), dp(3));
        GradientDrawable bg = rounded(Color.WHITE, 0);
        bg.setStroke(dp(1), Color.rgb(229, 235, 242));
        nav.setBackground(bg);
        nav.setElevation(dp(2));
        return nav;
    }

    private void rebuildBottomNavigation() {
        if (bottomNav == null) return;
        bottomNav.removeAllViews();
        int[] icons = {
                R.drawable.ic_home, R.drawable.ic_play, R.drawable.ic_bank,
                R.drawable.ic_chart, R.drawable.ic_journal, R.drawable.ic_settings
        };
        String[] names = {"Главная", "Проверка", "Банк", "Отчёты", "Журнал", "Настройки"};
        for (int i = 0; i < PAGE_COUNT; i++) {
            final int page = i;
            boolean active = currentPage == i;
            View item = bottomNavItem(icons[i], names[i], active, v -> switchPage(page));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1);
            lp.setMargins(dp(2), dp(4), dp(2), dp(4));
            bottomNav.addView(item, lp);
        }
        if (headerStatusPill != null) headerStatusPill.setVisibility(currentPage == PAGE_HOME ? View.VISIBLE : View.GONE);
    }

    private View bottomNavItem(int iconRes, String caption, boolean active, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(2), dp(4), dp(2), dp(3));
        int color = active ? ACCENT : Color.rgb(92, 112, 145);
        if (active) {
            GradientDrawable activeBg = rounded(Color.rgb(229, 246, 252), 15);
            activeBg.setStroke(dp(1), Color.rgb(190, 229, 240));
            box.setBackground(activeBg);
            box.setElevation(dp(2));
            box.setScaleX(1.0f);
            box.setScaleY(1.0f);
        }
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(color);
        int iconSize = active ? dp(26) : dp(23);
        box.addView(icon, new LinearLayout.LayoutParams(iconSize, iconSize));
        TextView text = label(caption, 10, active, color);
        text.setGravity(Gravity.CENTER);
        text.setPadding(0, dp(3), 0, 0);
        box.addView(text, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.setOnClickListener(listener);
        return box;
    }

    private void switchPage(int page) {
        if (page < 0 || page >= PAGE_COUNT || pageHost == null) return;
        currentPage = page;
        pageHost.removeAllViews();

        View content;
        if (page == PAGE_HOME) content = buildHomePage();
        else if (page == PAGE_CHECK) content = buildCheckPage();
        else if (page == PAGE_BANK) content = buildBankPage();
        else if (page == PAGE_REPORTS) content = buildReportsPage();
        else if (page == PAGE_JOURNAL) content = buildJournalPage();
        else content = buildSettingsPage();

        pageHost.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rebuildBottomNavigation();
        if (page == PAGE_HOME) refreshDashboardInformer();
        if (page == PAGE_CHECK && AuditRunGate.isRunning()) {
            try { syncProgressFromService(); } catch (Throwable ignored) {}
        }
    }

    private ScrollView pageScroll(LinearLayout body) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(Color.rgb(247, 250, 253));
        scroll.addView(body);
        return scroll;
    }

    private LinearLayout pageBody() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(9), dp(7), dp(9), dp(14));
        body.setBackgroundColor(Color.rgb(247, 250, 253));
        return body;
    }

    private View pageTitle(String title, String subtitle) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(2), dp(2), dp(2), dp(7));
        TextView t = label(title, 15, true, DARK);
        wrap.addView(t);
        if (subtitle != null && !subtitle.trim().isEmpty()) {
            TextView st = label(subtitle, 10, false, MUTED);
            st.setPadding(0, dp(2), 0, 0);
            st.setLineSpacing(0, 0.96f);
            wrap.addView(st);
        }
        return wrap;
    }

    private View buildHomePage() {
        LinearLayout body = pageBody();
        body.setPadding(dp(10), dp(8), dp(10), dp(10));

        informerCard = new LinearLayout(this);
        informerCard.setOrientation(LinearLayout.HORIZONTAL);
        informerCard.setGravity(Gravity.CENTER_VERTICAL);
        informerCard.setPadding(dp(10), dp(7), dp(10), dp(7));
        informerCard.setElevation(dp(1));
        informerIcon = label("✓", 26, true, Color.WHITE);
        informerIcon.setGravity(Gravity.CENTER);
        informerIcon.setBackground(rounded(GREEN, 40));
        informerCard.addView(informerIcon, new LinearLayout.LayoutParams(dp(46), dp(46)));
        informerText = label("Проверяю состояние...", 12, false, TEXT);
        informerText.setPadding(dp(10), 0, 0, 0);
        informerText.setLineSpacing(dp(1), 1.02f);
        informerCard.addView(informerText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        informerCard.setOnClickListener(v -> showEventCenterDialog());
        informerText.setOnClickListener(v -> showEventCenterDialog());
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(70));
        ip.setMargins(0, 0, 0, dp(7));
        body.addView(informerCard, ip);

        body.addView(buildHomeStatsRow());

        LinearLayout launch = new LinearLayout(this);
        launch.setOrientation(LinearLayout.HORIZONTAL);
        homeQuickButton = flatButton(AuditRunGate.isRunning() ? "▶  Открыть проверку" : "▶  Быстрая проверка", Color.rgb(0, 169, 190), Color.WHITE);
        homeQuickButton.setTextSize(11);
        homeQuickButton.setOnClickListener(v -> {
            if (AuditRunGate.isRunning() || auditRunning) switchPage(PAGE_CHECK);
            else { switchPage(PAGE_CHECK); runAudit(AuditCoordinator.MODE_QUICK); }
        });
        Button journal = flatButton("▤  Открыть журнал", Color.WHITE, DARK);
        journal.setTextSize(11);
        GradientDrawable jbg = rounded(Color.WHITE, 11);
        jbg.setStroke(dp(1), Color.rgb(208,220,234));
        journal.setBackground(jbg);
        journal.setOnClickListener(v -> switchPage(PAGE_JOURNAL));
        LinearLayout.LayoutParams qa=new LinearLayout.LayoutParams(0,dp(44),1.24f); qa.setMargins(0,0,dp(4),0);
        LinearLayout.LayoutParams ja=new LinearLayout.LayoutParams(0,dp(44),1f); ja.setMargins(dp(4),0,0,0);
        launch.addView(homeQuickButton,qa); launch.addView(journal,ja);
        body.addView(launch);

        LinearLayout quickGrid = new LinearLayout(this);
        quickGrid.setOrientation(LinearLayout.VERTICAL);
        quickGrid.setPadding(0,dp(7),0,0);
        quickGrid.addView(homeActionRow(
                homeAction(R.drawable.ic_closed_periods, "Закрытые периоды", "Контроль завершённых\nпериодов", Color.rgb(245,69,112), v -> showClosedPeriods()),
                homeAction(R.drawable.ic_clock, "Автопроверка", "Ночная проверка\nи автозапуск", Color.rgb(133,69,210), v -> showAutoStartSettings())));
        quickGrid.addView(homeActionRow(
                homeAction(R.drawable.ic_backup, "Резервная копия", "Экспорт базы\nи SHA-256", Color.rgb(21,163,198), v -> createBackup()),
                homeAction(R.drawable.ic_restore, "Восстановление", "Импорт из\nрезервной копии", Color.rgb(95,116,150), v -> pickRestore())));
        body.addView(quickGrid);

        LinearLayout histHead = new LinearLayout(this);
        histHead.setOrientation(LinearLayout.HORIZONTAL);
        histHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView histTitle = label("История проверок", 15, true, DARK);
        histHead.addView(histTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView all = label("Все проверки  ›", 9, false, MUTED);
        all.setGravity(Gravity.RIGHT);
        all.setPadding(dp(8), dp(4), dp(3), dp(4));
        GradientDrawable allBg=rounded(Color.WHITE, 14); allBg.setStroke(dp(1),Color.rgb(220,230,241)); all.setBackground(allBg);
        all.setOnClickListener(v -> showCheckHistoryDialog());
        histHead.addView(all);
        histHead.setPadding(dp(2), dp(7), dp(2), dp(5));
        body.addView(histHead);
        addRecentRunCards(body);

        refreshDashboardInformer();
        return pageScroll(body);
    }

    private void addRecentRunCards(LinearLayout body) {
        java.util.List<AuditDb.RunSummary> runs = db.recentRuns(4);
        if (runs == null || runs.isEmpty()) {
            LinearLayout empty = card();
            empty.setPadding(dp(10), dp(9), dp(10), dp(9));
            empty.addView(label("История пока пуста", 9, false, MUTED));
            body.addView(empty);
            return;
        }
        for (int i=0;i<runs.size();i++) {
            body.addView(recentRunRow(runs.get(i)), historyRowParams(i > 0));
        }
    }

    private LinearLayout.LayoutParams historyRowParams(boolean withTopMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        if (withTopMargin) p.setMargins(0, dp(4), 0, 0);
        return p;
    }

    private View recentRunRow(AuditDb.RunSummary run) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(7), dp(8));
        GradientDrawable bg = rounded(Color.WHITE, 11);
        bg.setStroke(dp(1), Color.rgb(229,235,242));
        row.setBackground(bg);
        row.setElevation(dp(1));
        row.setOnClickListener(v -> showCheckHistoryDialog());

        TextView number = label("#" + run.id, 15, true, ACCENT);
        number.setGravity(Gravity.CENTER);
        number.setBackground(rounded(Color.rgb(232,249,247), 12));
        row.addView(number, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(9), 0, dp(4), 0);
        TextView l1 = label(homeRunTime(run.startedAt), 12, true, DARK);
        String status = run.recovery ? "Проверка после прерывания" : runStatusShort(run.status);
        TextView l2 = label(runDurationLine(status, run.durationMs), 10, false, MUTED);
        l2.setPadding(0, dp(1), 0, dp(2));
        texts.addView(l1);
        texts.addView(l2);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.setGravity(Gravity.CENTER_VERTICAL);
        int shownTotal = run.total > 0 ? run.total : db.transactionCount();
        TextView total = label("Всего: " + spacedNumber(shownTotal), 10, false, MUTED);
        applyBoldTail(total, "Всего: ");
        metrics.addView(total);
        metrics.addView(historyMetric(run.newCount, GREEN));
        metrics.addView(historyMetric(run.changedCount, YELLOW));
        metrics.addView(historyMetric(run.deletedCount, RED));
        texts.addView(metrics);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        ImageView arrow = new ImageView(this);
        arrow.setImageResource(R.drawable.ic_chevron_right);
        arrow.setColorFilter(Color.rgb(93,112,145));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(18), dp(18)));
        return row;
    }

    private View historyMetric(int value, int accent) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setPadding(dp(7),0,0,0);
        TextView dot=label("●",12,true,accent);
        TextView valueView=label(String.valueOf(value),10,false,MUTED);
        valueView.setPadding(dp(2),0,0,0);
        chip.addView(dot); chip.addView(valueView);
        return chip;
    }

    private String runDurationLine(String status, long durationMs) {
        if (durationMs <= 0) return status;
        return status + "  •  " + TimeUtil.duration(durationMs);
    }

    private String homeRunTime(String iso) {
        long ms=TimeUtil.parseDateTimeMillis(iso);
        if(ms<=0)return TimeUtil.displayDateTime(iso);
        java.text.SimpleDateFormat dateFmt=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.getDefault());
        java.text.SimpleDateFormat timeFmt=new java.text.SimpleDateFormat("HH:mm",Locale.getDefault());
        String d=dateFmt.format(new java.util.Date(ms));
        java.util.Calendar cal=java.util.Calendar.getInstance();
        String today=dateFmt.format(cal.getTime());
        cal.add(java.util.Calendar.DAY_OF_YEAR,-1);
        String yesterday=dateFmt.format(cal.getTime());
        String prefix=d.equals(today)?"Сегодня":d.equals(yesterday)?"Вчера":new java.text.SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new java.util.Date(ms));
        return prefix+", "+timeFmt.format(new java.util.Date(ms));
    }

    private String runStatusShort(String status) {
        if("RUNNING".equals(status))return "Выполняется";
        if("STOPPED".equals(status))return "Остановлено";
        if("ERROR".equals(status))return "Ошибка";
        return "Завершено";
    }

    private String spacedNumber(int value) {
        return String.format(Locale.US,"%,d",Math.max(0,value)).replace(',', ' ');
    }

    private void applyBoldTail(TextView v,String prefix){
        CharSequence raw=v.getText();
        SpannableStringBuilder sp=new SpannableStringBuilder(raw);
        int start=Math.min(prefix.length(),sp.length());
        sp.setSpan(new StyleSpan(Typeface.BOLD),start,sp.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new ForegroundColorSpan(DARK),start,sp.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        v.setText(sp);
    }

    private View buildHomeStatsRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 0, 0, dp(7));
        newTop = statCard("●", String.valueOf(parseIntState("last_check_new")), "Новые", GREEN);
        changedTop = statCard("●", String.valueOf(parseIntState("last_check_changed")), "Изменённые", YELLOW);
        deletedTop = statCard("●", String.valueOf(parseIntState("last_check_deleted")), "Удалённые", RED);
        LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(0,dp(49),1); p1.setMargins(dp(1),0,dp(3),0);
        LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(0,dp(49),1); p2.setMargins(dp(3),0,dp(3),0);
        LinearLayout.LayoutParams p3=new LinearLayout.LayoutParams(0,dp(49),1); p3.setMargins(dp(3),0,dp(1),0);
        row.addView(newTop,p1); row.addView(changedTop,p2); row.addView(deletedTop,p3);
        return row;
    }

    private View buildHomeCheckActions() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button quick=flatButton("▶  Быстрая проверка", Color.rgb(0,169,190), Color.WHITE);
        quick.setOnClickListener(v->{switchPage(PAGE_CHECK); runAudit(AuditCoordinator.MODE_QUICK);});
        Button full=flatButton("Полная проверка", Color.WHITE, TEXT);
        GradientDrawable bg=rounded(Color.WHITE,12); bg.setStroke(dp(1),Color.rgb(216,225,235)); full.setBackground(bg);
        full.setOnClickListener(v->{switchPage(PAGE_CHECK); runAudit(AuditCoordinator.MODE_FULL);});
        row.addView(quick,new LinearLayout.LayoutParams(0,dp(48),1)); row.addView(full,new LinearLayout.LayoutParams(0,dp(48),1));
        return row;
    }

    private String currentCheckLabel() {
        String mode = AuditRunGate.isRunning() ? AuditControlRegistry.mode() : activeCheckMode;
        return AuditCoordinator.MODE_FULL.equals(mode) ? "Полная проверка" : "Быстрая проверка";
    }

    private void refreshCheckModeUi() {
        String label = currentCheckLabel();
        boolean running = AuditRunGate.isRunning() || auditRunning;
        AuditControl c = AuditControlRegistry.current();
        boolean paused = c != null && c.isPaused();
        if (checkBannerTitle != null) {
            if (running) checkBannerTitle.setText(paused ? label + " • На паузе" : "Выполняется " + label.toLowerCase(Locale.ROOT));
            else checkBannerTitle.setText("Готово к проверке");
        }
        if (checkBannerSubtitle != null) {
            checkBannerSubtitle.setText(running ? ("Режим: " + label + " • проверка завершённых периодов") : "Выберите быструю или полную проверку");
        }
        if (checkModePill != null) {
            boolean full = "Полная проверка".equals(label);
            checkModePill.setText(full ? "ПОЛНАЯ" : "БЫСТРАЯ");
            checkModePill.setTextColor(full ? PURPLE : BLUE);
            checkModePill.setBackground(rounded(full ? Color.rgb(245,238,255) : Color.rgb(235,245,255), 10));
            checkModePill.setVisibility(running ? View.VISIBLE : View.GONE);
        }
    }

    private String progressFallbackText(AuditForegroundService.Snapshot s) {
        String stage = s == null || s.stage == null ? "" : s.stage;
        if (stage.contains("CONNECT") || stage.contains("AUTH") || stage.contains("PREPAR")) return "Подключение к Cubux";
        if (stage.contains("PERIOD")) return "Получение списка периодов";
        if (stage.contains("READ") || stage.contains("LOAD")) return "Загрузка данных";
        return "Подготовка данных";
    }

    private void refreshHomeQuickButton() {
        if (homeQuickButton == null) return;
        boolean running = AuditRunGate.isRunning() || auditRunning;
        homeQuickButton.setText(running ? "▶  Открыть проверку" : "▶  Быстрая проверка");
    }

    private View buildCheckPage() {
        LinearLayout body = pageBody();
        body.setPadding(dp(8), dp(5), dp(8), dp(5));
        body.addView(buildCheckBanner());
        body.addView(buildAuditPanel(), topMargin(5));
        // Keep the legacy result target for internal messages, but the visible result
        // is now shown in the compact "Текущий этап" card inside the audit panel.
        resultText = label(db.getState("last_check_message") == null ? "" : db.getState("last_check_message"), 1, false, MUTED);
        resultText.setVisibility(View.GONE);
        body.addView(resultText, new LinearLayout.LayoutParams(1,1));
        return body;
    }

    private LinearLayout.LayoutParams topMargin(int marginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(marginDp), 0, 0);
        return p;
    }

    private View buildCheckBanner() {
        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.HORIZONTAL);
        banner.setGravity(Gravity.CENTER_VERTICAL);
        banner.setPadding(dp(7), dp(5), dp(7), dp(5));
        GradientDrawable bg = rounded(Color.WHITE, 11);
        bg.setStroke(dp(1), Color.rgb(229,235,242));
        banner.setBackground(bg);

        TextView icon = label("◎", 15, true, Color.WHITE);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(rounded(Color.rgb(45,145,245), 18));
        banner.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));

        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setPadding(dp(8), 0, 0, 0);
        checkBannerTitle = label("Готово к проверке", 11, true, DARK);
        checkBannerSubtitle = label("Выберите быструю или полную проверку", 9, false, MUTED);
        checkBannerSubtitle.setPadding(0, dp(1), 0, 0);
        text.addView(checkBannerTitle);
        text.addView(checkBannerSubtitle);
        banner.addView(text, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        checkModePill = label("БЫСТРАЯ", 7, true, BLUE);
        checkModePill.setGravity(Gravity.CENTER);
        checkModePill.setPadding(dp(6), dp(3), dp(6), dp(3));
        checkModePill.setBackground(rounded(Color.rgb(235, 245, 255), 10));
        banner.addView(checkModePill);
        refreshCheckModeUi();
        return banner;
    }

    private View buildStageCard() {
        LinearLayout c = card();
        c.setPadding(dp(10), dp(8), dp(10), dp(8));
        TextView stagesTitle = label("Текущий этап проверки", 9, true, DARK);
        c.addView(stagesTitle);
        c.addView(buildStageChecklist());
        updateStageIndicators(currentStageForUi);
        return c;
    }

    private View buildBankPage() {
        LinearLayout body = pageBody();
        body.addView(pageTitle("Проверка банковской выписки",
                "Загрузите файл выписки из банка. Система найдёт операции и сравнит их с Cubux"));
        LinearLayout c=card();
        c.setPadding(dp(10),dp(8),dp(10),dp(8));
        c.addView(processRow("1", "Выберите файл выписки", "Загрузите файл из банка в одном из поддерживаемых форматов"));
        c.addView(processRow("2", "Сканирование операций", "Система прочитает дату, сумму и описание"));
        c.addView(processRow("3", "Сравнение с Cubux", "Найдём совпадения, расхождения и спорные операции"));
        Button choose=flatButton("▣  Выбрать файл выписки", Color.rgb(22,126,235), Color.WHITE);
        choose.setOnClickListener(v->showBankDialog());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(42));
        cp.setMargins(0,dp(7),0,0); c.addView(choose,cp);
        TextView formats=label("Поддерживаемые форматы:  PDF, CSV, XLS, XLSX, OFX",8,false,MUTED);
        formats.setPadding(0,dp(5),0,0); c.addView(formats);
        body.addView(c);

        TextView lt=label("Последняя сверка",13,true,DARK);
        lt.setPadding(dp(2),dp(8),dp(2),dp(5)); body.addView(lt);
        LinearLayout sum=card();
        sum.setPadding(dp(10),dp(9),dp(10),dp(9));
        TextView summary=label(db.bankSummary(),9,false,TEXT);
        summary.setLineSpacing(dp(1),0.95f); sum.addView(summary);
        sum.setOnClickListener(v->showBankDialog()); body.addView(sum);
        return pageScroll(body);
    }

    private View buildReportsPage() {
        LinearLayout body=pageBody();
        body.addView(pageTitle("Отчёты", "Аналитика и статистика изменений"));
        LinearLayout tabs=new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(2),dp(2),dp(2),dp(2));
        tabs.setBackground(rounded(Color.WHITE,10));
        String[] ns={"День","Неделя","Месяц","Год"};
        for(int i=0;i<4;i++){
            TextView t=label(ns[i],9,i==2,i==2?Color.WHITE:MUTED);
            t.setGravity(Gravity.CENTER);
            if(i==2)t.setBackground(rounded(Color.rgb(0,174,157),8));
            tabs.addView(t,new LinearLayout.LayoutParams(0,dp(30),1));
        }
        body.addView(tabs);
        TextView period=label(new java.text.SimpleDateFormat("LLLL yyyy",Locale.getDefault()).format(new java.util.Date()),13,true,DARK);
        period.setGravity(Gravity.CENTER); period.setPadding(0,dp(8),0,dp(7)); body.addView(period);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        int total=parseIntState("last_check_total"); if(total==0) total=parseIntState("baseline_total");
        row.addView(reportTile(String.valueOf(total),"Всего\nопераций",BLUE),weight());
        row.addView(reportTile(String.valueOf(parseIntState("last_check_new")),"Новые",GREEN),weight());
        row.addView(reportTile(String.valueOf(parseIntState("last_check_changed")),"Изменено",YELLOW),weight());
        row.addView(reportTile(String.valueOf(parseIntState("last_check_deleted")),"Удалено",RED),weight());
        body.addView(row);

        LinearLayout chart=card();
        chart.setPadding(dp(10),dp(9),dp(10),dp(9));
        TextView ch=label("Изменения по дням",11,true,DARK); chart.addView(ch);
        chart.addView(new ChangeChartView(this), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(118)));
        TextView legend=label("● Новые      ● Изменённые      ● Удалённые",8,false,MUTED);
        legend.setGravity(Gravity.CENTER); chart.addView(legend);
        chart.setOnClickListener(v->showReportsDialog());
        LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        c.setMargins(0,dp(7),0,0); body.addView(chart,c);

        LinearLayout stats=card(); stats.setPadding(dp(10),dp(8),dp(10),dp(8));
        stats.addView(label("Статистика за период",11,true,DARK));
        stats.addView(reportLine("Новые операции", parseIntState("last_check_new"), GREEN));
        stats.addView(reportLine("Изменённые операции", parseIntState("last_check_changed"), YELLOW));
        stats.addView(reportLine("Удалённые операции", parseIntState("last_check_deleted"), RED));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT); sp.setMargins(0,dp(7),0,0); body.addView(stats,sp);
        return pageScroll(body);
    }

    private View buildJournalPage() {
        LinearLayout body=pageBody();
        body.addView(pageTitle("Журнал изменений", "Список операций с фильтрами"));
        final TextView journal=label(db.journalText("ALL",""),9,false,TEXT); journal.setTextIsSelectable(true);
        LinearLayout filters=new LinearLayout(this); filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setPadding(dp(2),dp(2),dp(2),dp(2)); filters.setBackground(rounded(Color.WHITE,10));
        String[] names={"Все","Новые","Изменённые","Удалённые"}; String[] values={"ALL","NEW","CHANGED","DELETED"};
        for(int i=0;i<names.length;i++){
            final String f=values[i]; TextView b=label(names[i],8,i==0,i==0?Color.WHITE:MUTED);
            b.setGravity(Gravity.CENTER); if(i==0)b.setBackground(rounded(GREEN,8));
            b.setOnClickListener(v->journal.setText(TimeUtil.displayDateTime(db.journalText(f,""))));
            filters.addView(b,new LinearLayout.LayoutParams(0,dp(28),1));
        }
        body.addView(filters);
        EditText search=new EditText(this); search.setHint("Поиск по описанию, сумме, контрагенту...");
        search.setTextSize(9); search.setSingleLine(true); search.setPadding(dp(10),0,dp(10),0);
        search.setBackground(rounded(Color.WHITE,10));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(36)); sp.setMargins(0,dp(6),0,dp(6)); body.addView(search,sp);
        search.setOnEditorActionListener((v,a,e)->{journal.setText(TimeUtil.displayDateTime(db.journalText("ALL",search.getText().toString().trim()))); return true;});
        LinearLayout list=card(); list.setPadding(dp(10),dp(8),dp(10),dp(8));
        journal.setLineSpacing(dp(1),0.96f); list.addView(journal); body.addView(list); resultText=journal;
        return pageScroll(body);
    }

    private View buildSettingsPage() {
        LinearLayout body=pageBody(); body.addView(pageTitle("Настройки", "Параметры проверки, уведомления и данные"));
        CheckSettings cfg=new CheckSettings(this);
        body.addView(settingsSection("Автоматическая проверка",
                settingRow("Автоматическая проверка", "Включена по расписанию", "●"),
                settingRow("Время запуска", cfg.lightTime(), "›"),
                settingRow("При пропуске проверки", "Повторить при следующем запуске", "›"),
                settingRow("Интервал между запросами", DelayProfile.label(cfg.requestDelayMs()), "›")));
        body.addView(settingsSection("Уведомления",
                settingRow("Push-уведомления", "Включены", "●"),
                settingRow("Telegram-отчёты", "Настраиваются отдельно", "●"),
                settingRow("Уведомления об изменениях", "Включены", "●")));
        body.addView(settingsSection("Энергосбережение",
                settingRow("Работать только при зарядке", "Выключено", "○"),
                settingRow("Ограничение ЦП", "50%", "›"),
                settingRow("Не запускать при низком заряде", "Включено", "●")));
        body.addView(settingsSection("Данные и безопасность",
                settingRow("Путь к базе Cubux", "/storage/cubux", "›"),
                settingRow("Резервные копии", "Хранить 12 месяцев", "›"),
                settingRow("Закрытые периоды", "Контроль целостности", "›")));
        Button open=flatButton("Открыть все параметры", Color.rgb(0,169,190), Color.WHITE);
        open.setOnClickListener(v->showSettingsDialog());
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(40)); op.setMargins(0,dp(7),0,0); body.addView(open,op);
        TextView ver=label("Cubux Security 3.0.15",9,false,MUTED); ver.setGravity(Gravity.CENTER); ver.setPadding(0,dp(8),0,0); body.addView(ver);
        return pageScroll(body);
    }

    private void showEventCenterDialog() {
        ScrollView scroll = new ScrollView(this);
        TextView text = label(db.eventsText(), 13, false, TEXT);
        text.setPadding(dp(16), dp(10), dp(16), dp(18));
        text.setTextIsSelectable(true);
        scroll.addView(text);
        new AlertDialog.Builder(this)
                .setTitle("История событий")
                .setView(scroll)
                .setPositiveButton("Закрыть", null)
                .show();
    }

    private void showCheckHistoryDialog() {
        int n=parseIntState("last_check_new"), c=parseIntState("last_check_changed"), d=parseIntState("last_check_deleted");
        String head="Новые: "+n+"    Изменённые: "+c+"    Удалённые: "+d+"\n\n";
        ScrollView scroll = new ScrollView(this);
        TextView text = label(head + db.recentRunsText(), 13, false, TEXT);
        text.setPadding(dp(16), dp(10), dp(16), dp(18));
        text.setTextIsSelectable(true);
        scroll.addView(text);
        new AlertDialog.Builder(this)
                .setTitle("История проверок")
                .setView(scroll)
                .setPositiveButton("Закрыть", null)
                .show();
    }

    private void refreshDashboardInformer() {
        refreshHomeQuickButton();
        if (informerText == null || informerCard == null) return;
        String state=db.getState("last_check_state");
        int n=parseIntState("last_check_new"), c=parseIntState("last_check_changed"), d=parseIntState("last_check_deleted");
        String title, sub; int accent, surface;
        if (AuditRunGate.isRunning()) { title="Выполняется " + currentCheckLabel().toLowerCase(Locale.ROOT); sub="Нажмите «Открыть проверку», чтобы увидеть прогресс"; accent=BLUE; surface=Color.rgb(239,247,255); }
        else if (!isNetworkAvailable()) { title="Нет интернета"; sub="Проверка продолжится после восстановления сети"; accent=YELLOW; surface=Color.rgb(255,249,231); }
        else if ("ERROR".equals(state)) { title="Требуется внимание"; sub="Последняя проверка завершилась ошибкой  •  История событий ›"; accent=RED; surface=Color.rgb(255,241,244); }
        else if ("1".equals(db.getState("missed_check_pending"))) { title="Требуется внимание"; sub="Была пропущена автоматическая проверка  •  История событий ›"; accent=YELLOW; surface=Color.rgb(255,249,231); }
        else if ("1".equals(db.getState("yesterday_changed_during_scan"))) { title="Данные вчерашнего дня менялись"; sub="Визуально проверьте вчерашний день  •  История событий ›"; accent=RED; surface=Color.rgb(255,241,244); }
        else if (c>0 || d>0) { title="Найдены изменения"; sub="Изменённые: "+c+"  •  Удалённые: "+d+"  •  Открыть журнал ›"; accent=RED; surface=Color.rgb(255,241,244); }
        else if (n>0) { title="Найдены новые записи"; sub="Новые: "+n+"  •  изменённых и удалённых нет"; accent=GREEN; surface=Color.rgb(238,250,245); }
        else if ("OK".equals(state)) { title="Система под контролем"; String last=db.getState("last_check_time"); sub="Последняя проверка завершена успешно" + (last==null||last.trim().isEmpty()?"":"\n◷  "+homeRunTime(last)); accent=GREEN; surface=Color.rgb(238,250,245); }
        else { title="Защита готова"; sub="Выполните первую проверку"; accent=BLUE; surface=Color.rgb(239,247,255); }

        SpannableStringBuilder info=new SpannableStringBuilder(title+"\n"+sub);
        info.setSpan(new StyleSpan(Typeface.BOLD),0,title.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        info.setSpan(new RelativeSizeSpan(1.16f),0,title.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        info.setSpan(new ForegroundColorSpan(MUTED),title.length()+1,info.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        informerText.setText(info);
        GradientDrawable bg=rounded(surface,13);
        bg.setStroke(dp(1),Color.argb(70,Color.red(accent),Color.green(accent),Color.blue(accent)));
        informerCard.setBackground(bg);
        if(informerIcon!=null){informerIcon.setText((accent==YELLOW||accent==RED)?"!":"✓"); informerIcon.setBackground(rounded(accent,40));}
        if(headerStatusPill!=null){headerStatusPill.setText("●  Защита активна"); headerStatusPill.setTextColor(GREEN); headerStatusPill.setBackground(rounded(Color.rgb(235,249,242),18));}
    }

    private TextView bottomItem(String icon, String caption, int color, View.OnClickListener listener) {
        TextView v=label(icon+"\n"+caption,8,false,color);
        v.setGravity(Gravity.CENTER); v.setLineSpacing(0,0.88f);
        v.setPadding(dp(1),dp(2),dp(1),dp(1)); v.setMinHeight(dp(46));
        v.setOnClickListener(listener); return v;
    }

    private void onAuditNavigationPressed() {
        switchPage(PAGE_CHECK);
    }

    private void scrollToTop() {
        View content = findViewById(android.R.id.content);
        if (content != null) content.requestFocus();
    }

    private View buildHeader() {
        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10),dp(5),dp(8),dp(5));
        header.setBackgroundColor(Color.WHITE);
        header.setElevation(dp(1));

        LinearLayout logoBubble=new LinearLayout(this);
        logoBubble.setGravity(Gravity.CENTER);
        logoBubble.setBackground(rounded(ACCENT,30));
        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.ic_shield_check);
        // Keep the drawable's own white shield + teal check colors.

        logoBubble.addView(logo,new LinearLayout.LayoutParams(dp(21),dp(21)));
        header.addView(logoBubble,new LinearLayout.LayoutParams(dp(32),dp(32)));

        TextView title=label("Cubux Security",15,true,DARK);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);
        tp.setMargins(dp(8),0,dp(4),0); header.addView(title,tp);

        headerStatusPill=label("●  Защита активна",8,true,GREEN);
        headerStatusPill.setGravity(Gravity.CENTER);
        headerStatusPill.setPadding(dp(9),dp(4),dp(9),dp(4));
        headerStatusPill.setBackground(rounded(Color.rgb(235,249,242),18));
        header.addView(headerStatusPill);

        ImageView settings=new ImageView(this);
        settings.setImageResource(R.drawable.ic_settings);
        settings.setColorFilter(Color.rgb(73,98,135));
        settings.setPadding(dp(7),dp(7),dp(7),dp(7));
        settings.setOnClickListener(v->switchPage(PAGE_SETTINGS));
        header.addView(settings,new LinearLayout.LayoutParams(dp(38),dp(38)));
        return header;
    }

    private TextView topStat(
            String icon,
            String value,
            String caption,
            int accent
    ) {
        TextView v = label(icon + "  " + value + "\n" + caption, 11, false, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(74));
        v.setPadding(dp(2), dp(8), dp(2), dp(8));
        GradientDrawable bg = rounded(Color.argb(28,255,255,255), 18);
        bg.setStroke(dp(1), Color.argb(95,255,255,255));
        v.setBackground(bg);
        return v;
    }

    private View buildAuditPanel() {
        LinearLayout card=card();
        card.setPadding(dp(10),dp(7),dp(10),dp(7));

        TextView cap=label("Прогресс проверки",12,true,DARK);
        card.addView(cap);

        LinearLayout progressRow=new LinearLayout(this);
        progressRow.setOrientation(LinearLayout.HORIZONTAL);
        progressRow.setGravity(Gravity.CENTER_VERTICAL);
        progressRow.setPadding(0,dp(2),0,dp(3));
        progressAmountText=label("Подготовка данных",12,true,DARK);
        progressRow.addView(progressAmountText,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        percentText=label("0%",15,true,DARK);
        progressRow.addView(percentText);
        card.addView(progressRow);

        progressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressDrawable(buildRoundedProgressDrawable());
        card.addView(progressBar,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(9)));

        detailsText=label("Сейчас: готов к проверке\nЭтап: ожидание\nПрогресс: 0%\nДействие: —\nСкорость: —\nПрошло: 00:00\nПоследняя активность: —\nСостояние: готово",10,false,TEXT);
        detailsText.setMinLines(8);
        detailsText.setMaxLines(8);
        detailsText.setLineSpacing(0,0.91f);
        detailsText.setPadding(dp(7),dp(5),dp(7),dp(5));
        detailsText.setBackground(rounded(Color.rgb(249,251,254),10));
        LinearLayout.LayoutParams dpv=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        dpv.setMargins(0,dp(6),0,0);
        card.addView(detailsText,dpv);

        statusText=label("Готов к проверке",1,true,DARK);
        statusText.setVisibility(View.GONE);
        card.addView(statusText,new LinearLayout.LayoutParams(1,1));

        auditButton=flatButton("▶  Быстрая проверка", Color.rgb(0,169,190), Color.WHITE);
        auditButton.setOnClickListener(v->runAudit(AuditCoordinator.MODE_QUICK));
        fullAuditButton=flatButton("Полная проверка", Color.WHITE, DARK);
        GradientDrawable fbg=rounded(Color.WHITE,10);
        fbg.setStroke(dp(1),Color.rgb(213,224,235));
        fullAuditButton.setBackground(fbg);
        fullAuditButton.setOnClickListener(v->{ if(auditRunning) Toast.makeText(this,"Сначала завершите текущую проверку",Toast.LENGTH_SHORT).show(); else runAudit(AuditCoordinator.MODE_FULL); });
        LinearLayout starts=new LinearLayout(this);
        starts.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams a1=new LinearLayout.LayoutParams(0,dp(38),1); a1.setMargins(0,dp(6),dp(4),0);
        LinearLayout.LayoutParams a2=new LinearLayout.LayoutParams(0,dp(38),1); a2.setMargins(dp(4),dp(6),0,0);
        starts.addView(auditButton,a1);
        starts.addView(fullAuditButton,a2);
        card.addView(starts);

        boolean runningNow = AuditRunGate.isRunning() || auditRunning;
        auditButton.setVisibility(runningNow ? View.GONE : View.VISIBLE);
        fullAuditButton.setVisibility(runningNow ? View.GONE : View.VISIBLE);

        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(0,dp(6),0,0);
        pauseButton=flatButton("Ⅱ  Пауза", Color.rgb(255,181,13), Color.WHITE);
        pauseButton.setVisibility(runningNow?View.VISIBLE:View.GONE);
        pauseButton.setEnabled(runningNow);
        pauseButton.setOnClickListener(v->togglePause());
        stopButton=flatButton("●  Остановить", RED, Color.WHITE);
        stopButton.setVisibility(runningNow?View.VISIBLE:View.GONE);
        stopButton.setEnabled(runningNow);
        stopButton.setOnClickListener(v->stopAudit());
        LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(0,dp(38),1); p1.setMargins(0,0,dp(4),0);
        LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(0,dp(38),1); p2.setMargins(dp(4),0,0,0);
        controls.addView(pauseButton,p1);
        controls.addView(stopButton,p2);
        card.addView(controls);

        TextView stagesTitle=label("Текущий этап проверки",11,true,DARK);
        stagesTitle.setPadding(0,dp(6),0,dp(2));
        card.addView(stagesTitle);
        card.addView(buildStageChecklist());

        LinearLayout summary=new LinearLayout(this);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(dp(8),dp(5),dp(8),dp(5));
        summary.setBackground(rounded(Color.rgb(244,249,253),10));
        currentStageSummaryTitle=label("Текущий этап:  ожидание",10,true,DARK);
        currentStageSummaryBody=label("Ожидание запуска проверки.",9,false,MUTED);
        currentStageSummaryBody.setPadding(0,dp(2),0,0);
        currentStageSummaryBody.setMaxLines(2);
        summary.addView(currentStageSummaryTitle);
        summary.addView(currentStageSummaryBody);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.setMargins(0,dp(5),0,0);
        card.addView(summary,sp);

        updateStageIndicators("IDLE");
        return card;
    }

    private android.graphics.drawable.Drawable buildRoundedProgressDrawable(){
        GradientDrawable track=rounded(Color.rgb(224,233,242),20);
        GradientDrawable fill=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(0,194,113),Color.rgb(0,177,105)});
        fill.setCornerRadius(dp(20));
        android.graphics.drawable.ClipDrawable clip=new android.graphics.drawable.ClipDrawable(fill,Gravity.LEFT,android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable layer=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{track,clip});
        layer.setId(0,android.R.id.background);
        layer.setId(1,android.R.id.progress);
        return layer;
    }

    private TextView step(
            String icon,
            String caption
    ) {
        TextView v = label(icon + "\n" + caption, 11, false, MUTED);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(58));
        return v;
    }


private View buildLastCheckCard() {
    LinearLayout card=card(); TextView title=label("Последняя проверка",16,true,DARK); card.addView(title); lastCheckText=label("Проверок ещё не было",12,false,MUTED); lastCheckText.setPadding(0,dp(7),0,0); lastCheckText.setOnClickListener(v->showJournalDialog()); card.addView(lastCheckText); refreshLastCheckStatus(); return card;
}

private void refreshLastCheckStatus() {
    if (lastCheckText == null || db == null) return;
    String state = db.getState("last_check_state");
    String type = db.getState("last_check_type");
    String time = db.getState("last_check_time");
    String msg = db.getState("last_check_message");
    String activity = db.getState("last_check_activity");
    if (state == null) {
        lastCheckText.setText("Проверок ещё не было. Расписание задаётся в настройках.");
        return;
    }
    StringBuilder x = new StringBuilder();
    if (type != null && !type.isEmpty()) x.append(type);
    if (time != null && !time.isEmpty()) x.append(" • ").append(time);
    if (x.length() > 0) x.append("\n");
    x.append(msg == null ? "Состояние проверки неизвестно" : msg);
    if ("OK".equals(state)) {
        int n=parseIntState("last_check_new"), c=parseIntState("last_check_changed"), d=parseIntState("last_check_deleted");
        x.append("\nНовые: ").append(n).append(" • Изменённые: ").append(c).append(" • Удалённые: ").append(d);
    }
    if (activity != null && !activity.isEmpty()) x.append("\nПоследняя активность: ").append(activity);
    try {
        String lastMs=db.getState("last_successful_audit_ms");
        if(lastMs!=null && System.currentTimeMillis()-Long.parseLong(lastMs)>36L*60L*60L*1000L)
            x.append("\n⚠ Давно не было успешной проверки. Рекомендуется запустить проверку вручную.");
    } catch(Exception ignored) {}
    lastCheckText.setTextColor("ERROR".equals(state)?RED:"RUNNING".equals(state)?BLUE:"OK".equals(state)?GREEN:MUTED);
    lastCheckText.setText(TimeUtil.displayDateTime(x.toString()));
}

private int parseIntState(String key) {
    try { return Integer.parseInt(db.getState(key)); } catch (Exception e) { return 0; }
}

private long parseLongState(String key) {
    try { return Long.parseLong(db.getState(key)); } catch (Exception e) { return 0L; }
}

    private View buildStatsRow() {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,dp(10),0,0); newCard=statCard("●",String.valueOf(parseIntState("last_check_new")),"Новые",GREEN); changedCard=statCard("●",String.valueOf(parseIntState("last_check_changed")),"Изменённые",YELLOW); deletedCard=statCard("●",String.valueOf(parseIntState("last_check_deleted")),"Удалённые",RED); row.addView(newCard,weight()); row.addView(changedCard,weight()); row.addView(deletedCard,weight()); return row;
    }

    private TextView statCard(String icon, String value, String caption, int accent) {
        String raw="●  "+caption+"\n    "+value;
        TextView v=label(raw,10,false,TEXT);
        SpannableStringBuilder sp=new SpannableStringBuilder(raw);
        sp.setSpan(new ForegroundColorSpan(accent),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new RelativeSizeSpan(1.82f),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int captionStart=raw.indexOf(caption);
        if(captionStart>=0){
            sp.setSpan(new ForegroundColorSpan(Color.rgb(72,94,129)),captionStart,captionStart+caption.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        int valueStart=raw.lastIndexOf(value);
        if(valueStart>=0){
            sp.setSpan(new StyleSpan(Typeface.BOLD),valueStart,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new RelativeSizeSpan(1.25f),valueStart,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new ForegroundColorSpan(DARK),valueStart,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        v.setText(sp);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(9),dp(3),dp(5),dp(3));
        v.setLineSpacing(0,0.92f);
        int r=Color.red(accent),g=Color.green(accent),b=Color.blue(accent);
        GradientDrawable bg=rounded(Color.WHITE,11);
        bg.setStroke(dp(1),Color.argb(58,r,g,b));
        v.setBackground(bg);
        return v;
    }

    private Button flatButton(String text, int bgColor, int fgColor) {
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(10); b.setTextColor(fgColor);
        b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); b.setPadding(dp(7),0,dp(7),0);
        b.setMinHeight(0); b.setMinimumHeight(0); b.setBackground(rounded(bgColor,10)); return b;
    }

    private View homeActionRow(View left, View right) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams l=new LinearLayout.LayoutParams(0,dp(58),1); l.setMargins(0,0,dp(4),dp(6));
        LinearLayout.LayoutParams r=new LinearLayout.LayoutParams(0,dp(58),1); r.setMargins(dp(4),0,0,dp(6));
        row.addView(left,l); row.addView(right,r); return row;
    }

    private View homeAction(int iconRes,String title,String subtitle,int accent,View.OnClickListener click) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(8),dp(7),dp(7),dp(7)); GradientDrawable bg=rounded(Color.WHITE,11);
        bg.setStroke(dp(1),Color.rgb(229,235,242)); box.setBackground(bg); box.setElevation(dp(1)); box.setOnClickListener(click);
        LinearLayout bubble=new LinearLayout(this); bubble.setGravity(Gravity.CENTER); bubble.setBackground(rounded(accent,11));
        ImageView ic=new ImageView(this); ic.setImageResource(iconRes); ic.setColorFilter(Color.WHITE); bubble.addView(ic,new LinearLayout.LayoutParams(dp(21),dp(21)));
        box.addView(bubble,new LinearLayout.LayoutParams(dp(38),dp(38)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(8),0,0,0);
        tx.addView(label(title,10,true,DARK)); TextView st=label(subtitle,9,false,MUTED); st.setPadding(0,dp(1),0,0); st.setLineSpacing(0,0.94f); tx.addView(st);
        box.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        ImageView arrow=new ImageView(this); arrow.setImageResource(R.drawable.ic_chevron_right); arrow.setColorFilter(Color.rgb(93,112,145)); box.addView(arrow,new LinearLayout.LayoutParams(dp(15),dp(15)));
        return box;
    }

    private View processRow(String number,String title,String subtitle) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(5),0,dp(5));
        TextView n=label(number,11,true,BLUE); n.setGravity(Gravity.CENTER); n.setBackground(rounded(Color.rgb(235,246,255),30));
        row.addView(n,new LinearLayout.LayoutParams(dp(30),dp(30)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(8),0,0,0);
        tx.addView(label(title,10,true,DARK)); TextView sub=label(subtitle,8,false,MUTED); sub.setLineSpacing(0,0.94f); tx.addView(sub);
        row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1)); return row;
    }

    private TextView reportTile(String value,String caption,int accent) {
        TextView t=label(value+"\n"+caption,8,true,DARK); t.setGravity(Gravity.CENTER); t.setMinHeight(dp(54));
        int r=Color.red(accent),g=Color.green(accent),b=Color.blue(accent);
        GradientDrawable bg=rounded(Color.rgb(Math.min(255,247+r/70),Math.min(255,249+g/70),Math.min(255,251+b/85)),9);
        bg.setStroke(dp(1),Color.argb(60,r,g,b)); t.setBackground(bg); return t;
    }

    private View reportLine(String title,int value,int accent){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(5),0,dp(5));
        TextView left=label("●  "+title,9,false,accent); row.addView(left,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        TextView right=label(String.valueOf(value),9,true,DARK); row.addView(right); return row;
    }

    private View settingRow(String title,String value,String right) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(1),dp(6),dp(1),dp(6));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.addView(label(title,9,true,DARK)); tx.addView(label(value,8,false,MUTED));
        row.addView(tx,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        TextView r=label(right,11,true,right.equals("●")?GREEN:MUTED); r.setGravity(Gravity.CENTER); row.addView(r,new LinearLayout.LayoutParams(dp(28),dp(28)));
        row.setOnClickListener(v->showSettingsDialog()); return row;
    }

    private View settingsSection(String title, View... rows) {
        TextView h=label(title,10,true,DARK); LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setPadding(0,dp(5),0,0); wrap.addView(h);
        LinearLayout c=card(); c.setPadding(dp(10),dp(3),dp(10),dp(3)); for(View v:rows)c.addView(v);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT); cp.setMargins(0,dp(4),0,0); wrap.addView(c,cp); return wrap;
    }


    private View buildStageChecklist(){
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        String[] names={
                "Подключение к Cubux",
                "Получение списка периодов",
                "Загрузка данных",
                "Сравнение с базой",
                "Проверка изменений",
                "Запись результатов",
                "Формирование отчёта",
                "Завершение проверки"
        };
        for(int i=0;i<stageRows.length;i++){
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0,dp(1),0,dp(1));

            TextView icon=label("",8,true,Color.WHITE);
            icon.setGravity(Gravity.CENTER);
            stageIconViews[i]=icon;
            row.addView(icon,new LinearLayout.LayoutParams(dp(20),dp(20)));

            TextView name=label(names[i],10,false,MUTED);
            name.setPadding(dp(7),0,dp(4),0);
            stageRows[i]=name;
            row.addView(name,new LinearLayout.LayoutParams(0,dp(24),1));

            TextView status=label("Ожидание",8,false,MUTED);
            status.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            stageStatusViews[i]=status;
            row.addView(status,new LinearLayout.LayoutParams(dp(70),dp(24)));
            list.addView(row);
        }
        return list;
    }

    private class ChangeChartView extends View {
        private final android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        ChangeChartView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        @Override protected void onDraw(android.graphics.Canvas canvas){
            super.onDraw(canvas); float w=getWidth(), h=getHeight(); float left=dp(6), bottom=h-dp(12), top=dp(10);
            paint.setStrokeWidth(dp(1)); paint.setColor(Color.rgb(231,237,244));
            for(int i=0;i<4;i++){ float y=top+(bottom-top)*i/3f; canvas.drawLine(left,y,w-dp(4),y,paint); }
            int n=Math.max(1,parseIntState("last_check_new")); int c=Math.max(0,parseIntState("last_check_changed")); int d=Math.max(0,parseIntState("last_check_deleted"));
            int groups=12; float gap=dp(4); float group=(w-left-dp(6))/groups; float bw=Math.max(dp(2), (group-gap)/3f);
            for(int i=0;i<groups;i++){
                float f=(float)(0.25+0.75*Math.abs(Math.sin((i+1)*1.37)));
                float hn=(bottom-top)*f*Math.min(1f,(n+3)/12f); float hc=(bottom-top)*0.55f*f*Math.min(1f,(c+2)/8f); float hd=(bottom-top)*0.4f*(1f-f/2f)*Math.min(1f,(d+2)/8f);
                float x=left+i*group+gap/2f;
                paint.setColor(GREEN); canvas.drawRect(x,bottom-hn,x+bw,bottom,paint);
                paint.setColor(YELLOW); canvas.drawRect(x+bw,bottom-hc,x+2*bw,bottom,paint);
                paint.setColor(RED); canvas.drawRect(x+2*bw,bottom-hd,x+3*bw,bottom,paint);
            }
        }
    }

    private void showClosedPeriods() {
        new AlertDialog.Builder(this).setTitle("Закрытые периоды").setMessage("Закрытые периоды защищены контрольными суммами SHA-256 и используются для проверки целостности данных Cubux.\n\nИзменения в завершённых периодах отображаются в журнале.").setPositiveButton("Готово",null).show();
    }

    private View buildNavigationGrid() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(14), 0, 0);

        wrap.addView(navRow(
                navCard("↺", "История проверкаов", "Просмотр результатов прошлых проверок", Color.rgb(0,202,116),
                        v -> resultText.setText("ИСТОРИЯ ПРОВЕРОК\n\n" + db.recentRunsText())),
                navCard("▤", "Журнал изменений", "Все найденные изменения операций", YELLOW,
                        v -> showJournalDialog())
        ));

        wrap.addView(navRow(
                navCard("◔", "Отчёты", "Аналитика за день, неделю, месяц и год", BLUE,
                        v -> showReportsDialog()),
                navCard("▦", "Банковская сверка", "Сравнение Cubux с выпиской банка", PURPLE,
                        v -> showBankDialog())
        ));

        wrap.addView(navCardWide("▣", "Закрытые периоды",
                "Контроль изменений в уже завершённых периодах", Color.rgb(245,65,122),
                v -> resultText.setText("Закрытые периоды контролируются автоматически по SHA-256.\n" +
                        "Контрольная база прошлых дней не перезаписывается.")));

        wrap.addView(navRow(
                navCard("⬆", "Резервная копия", "Экспорт базы с проверкой SHA-256", Color.rgb(0,160,180),
                        v -> createBackup()),
                navCard("⬇", "Восстановление", "Восстановление базы из резервной копии", Color.rgb(90,110,140),
                        v -> pickRestore())
        ));
        return wrap;
    }

    private View navRow(
            View left,
            View right
    ) {
        LinearLayout row =
                new LinearLayout(this);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        lp.setMargins(
                0,
                0,
                dp(7),
                dp(12)
        );

        LinearLayout.LayoutParams rp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        rp.setMargins(
                dp(7),
                0,
                0,
                dp(12)
        );

        row.addView(
                left,
                lp
        );

        row.addView(
                right,
                rp
        );

        return row;
    }

    private View navCard(
            String icon,
            String title,
            String subtitle,
            int accent,
            View.OnClickListener listener
    ) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(13), dp(15), dp(11), dp(15));
        box.setMinimumHeight(dp(112));
        GradientDrawable bg = rounded(Color.WHITE, 20);
        bg.setStroke(dp(1), Color.rgb(232,237,244));
        box.setBackground(bg);
        box.setOnClickListener(listener);

        TextView bubble = label(icon, 23, true, Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable ibg = rounded(accent, 18);
        bubble.setBackground(ibg);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(54), dp(54));
        ip.setMargins(0,0,dp(12),0);
        box.addView(bubble, ip);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = label(title, 15, true, TEXT);
        TextView st = label(subtitle, 12, false, MUTED);
        st.setPadding(0,dp(4),0,0);
        texts.addView(t);
        texts.addView(st);
        box.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView arrow = label("›", 28, false, MUTED);
        arrow.setGravity(Gravity.CENTER);
        box.addView(arrow, new LinearLayout.LayoutParams(dp(22), dp(50)));
        return box;
    }


    private View navCardWide(String icon, String title, String subtitle, int accent, View.OnClickListener listener) {
        View v = navCard(icon, title, subtitle, accent, listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(10),dp(10),dp(10),dp(10));
        GradientDrawable bg=rounded(Color.WHITE,12); bg.setStroke(dp(1),Color.rgb(228,235,243)); c.setBackground(bg); c.setElevation(dp(1)); return c;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1); p.setMargins(dp(2),0,dp(2),0); return p;
    }

    private TextView iconText(
            String value,
            int size
    ) {
        TextView v =
                label(
                        value,
                        size,
                        true,
                        Color.WHITE
                );

        v.setGravity(
                Gravity.CENTER
        );

        v.setPadding(
                dp(6),
                dp(6),
                dp(6),
                dp(6)
        );

        return v;
    }

    private TextView label(String value, int size, boolean bold, int color) {
        TextView v=new TextView(this); v.setText(TimeUtil.displayDateTime(value)); v.setTextSize(size); v.setTextColor(color); v.setFontFeatureSettings("kern"); v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif", Typeface.NORMAL)); return v;
    }

    private GradientDrawable rounded(
            int color,
            int radiusDp
    ) {
        GradientDrawable d =
                new GradientDrawable();

        d.setColor(color);

        d.setCornerRadius(
                dp(radiusDp)
        );

        return d;
    }

    private int dp(
            int value
    ) {
        return (int) (
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density +
                        0.5f
        );
    }

    private void runAudit() { runAudit(AuditCoordinator.MODE_QUICK); }

    private void runAudit(String mode) {

        if (auditRunning) {
            onAuditNavigationPressed();
            return;
        }

        String login =
                credentials.getLogin();

        String password =
                credentials.getPassword();

        if (login.isEmpty() ||
                password.isEmpty()) {
            showLoginDialog(true);
            return;
        }

        auditButton.setEnabled(false);
        auditRunning = true;
        activeCheckMode = mode;
        final long sessionId = ++auditSessionCounter;
        activeAuditSession = sessionId;
        maxPageShown = 0;
        maxLoadedShown = 0;
        maxPercentShown = 0;
        final AuditControl sessionControl = new AuditControl();
        auditControl = sessionControl;
        AuditControlRegistry.attach(sessionControl, mode);
        startedMs = System.currentTimeMillis();
        AuditForegroundService.reset(startedMs);
        AuditForegroundService.start(this);
        scanContext = AuditCoordinator.MODE_FULL.equals(mode) ? "Основное чтение полной проверки" : "Быстрая проверка";
        currentStageForUi = "PREPARING";
        currentWaitForUi = "";
        updateStageIndicators("START");
        DiagnosticLog.write(this, "CONTROL", "Ручная проверка запущена. Режим=" + mode);
        CheckStatusStore.running(this, AuditCoordinator.MODE_FULL.equals(mode) ? "Полная проверка" : "Быстрая проверка");
        if (auditButton != null) { auditButton.setEnabled(false); auditButton.setVisibility(View.GONE); }
        if (fullAuditButton != null) { fullAuditButton.setEnabled(false); fullAuditButton.setVisibility(View.GONE); }
        pauseButton.setEnabled(true);
        pauseButton.setVisibility(View.VISIBLE);
        pauseButton.setText("⏸  ПАУЗА");
        refreshCheckModeUi();
        refreshHomeQuickButton();
        stopButton.setEnabled(true);
        stopButton.setVisibility(View.VISIBLE);
        if (fullAuditButton != null) fullAuditButton.setEnabled(false);

        progressBar.setProgress(0);
        percentText.setText("0%");

        resultText.setText("");

        retries = 0;

        AuditCoordinator coordinator =
                new AuditCoordinator(this);

        boolean recovery =
                coordinator.isRecovery();

        new Thread(
                () -> {
                    try {
                        AuditEngine.Result r =
                                coordinator.runMode(
                                        login,
                                        password,
                                        recovery,
                                        progressListener(sessionId, sessionControl),
                                        sessionControl,
                                        mode
                                );

                        runOnUiThread(
                                () -> {
                                    if (sessionId == activeAuditSession) {
                                        showResult(r);
                                    }
                                }
                        );

                    } catch (Exception e) {
                        String msg =
                                e.getMessage() == null
                                        ? e.toString()
                                        : e.getMessage();

                        runOnUiThread(
                                () -> {
                                    if (sessionId != activeAuditSession) return;
                                    if (msg.contains("остановлен пользователем")) {
                                        statusText.setText("Проверка остановлена");
                                        resultText.setText("Проверка остановлена пользователем. Данные Cubux не изменялись.");
                                        db.saveState("last_check_state","STOPPED");
                                        db.saveState("last_check_message","Проверка остановлена пользователем.");
                                        refreshLastCheckStatus();
                                    } else {
                                        statusText.setText("ПРОВЕРКА ОСТАНОВЛЕНА");
                                        resultText.setText("Причина:\n" + msg);
                                        CheckStatusStore.failure(MainActivity.this, AuditCoordinator.MODE_FULL.equals(activeCheckMode) ? "Полная проверка" : "Быстрая проверка", Math.max(1,retries), msg);
                                        refreshLastCheckStatus();
                                    }
                                }
                        );

                    } finally {
                        AuditControlRegistry.clear(sessionControl);
                        AuditForegroundService.stop(MainActivity.this);
                        if (sessionId == activeAuditSession && auditControl == sessionControl) {
                            auditRunning = false;
                        }
                        runOnUiThread(
                                () -> {
                                    if (sessionId != activeAuditSession || auditControl != sessionControl) return;
                                    auditButton.setEnabled(true);
                                    auditButton.setVisibility(View.VISIBLE);
                                    if (fullAuditButton != null) { fullAuditButton.setEnabled(true); fullAuditButton.setVisibility(View.VISIBLE); }
                                    pauseButton.setEnabled(false);
                                    pauseButton.setText("⏸  ПАУЗА");
                                    pauseButton.setVisibility(View.GONE);
                                    stopButton.setEnabled(false);
                                    stopButton.setVisibility(View.GONE);
                                    refreshCheckModeUi();
                                    refreshHomeQuickButton();
                                }
                        );
                    }
                }
        ).start();
    }

    private void togglePause() {
        final AuditControl control = auditControl;
        if (!auditRunning || control == null || control.isStopped()) return;
        if (control.isPaused()) {
            control.resume();
            DiagnosticLog.write(this, "CONTROL", "Продолжить проверку");
            CheckStatusStore.event(this, "INFO", "ПРОВЕРКА", "Проверка продолжена пользователем");
            pauseButton.setText("⏸  ПАУЗА");
            statusText.setText("Продолжаю проверку...");
            refreshCheckModeUi();
        } else {
            control.pause();
            DiagnosticLog.write(this, "CONTROL", "Пауза проверки");
            CheckStatusStore.event(this, "INFO", "ПРОВЕРКА", "Проверка поставлена на паузу пользователем");
            pauseButton.setText("▶  ПРОДОЛЖИТЬ");
            statusText.setText("Проверка на паузе");
            AuditForegroundService.Snapshot snap = AuditForegroundService.snapshot();
            detailsText.setText(
                    "Сейчас: проверка поставлена на паузу" +
                    "\nЭтап: " + stageName(currentStageForUi) +
                    "\nПрогресс: " + maxLoadedShown + " операций • страница " + maxPageShown +
                    "\nЗапросы: приостановлены пользователем" +
                    "\nПрошло: " + TimeUtil.formatDuration(snap.elapsedMs) + " • таймер на паузе" +
                    "\nСостояние: нажмите «Продолжить», чтобы продолжить с этого места"
            );
            refreshCheckModeUi();
        }
    }

    private void stopAudit() {
        final AuditControl control = auditControl;
        if (!auditRunning || control == null || control.isStopped()) return;
        control.stop();
        DiagnosticLog.write(this, "CONTROL", "Остановить проверку");
        CheckStatusStore.event(this, "WARNING", "ПРОВЕРКА", "Проверка остановлена пользователем");
        pauseButton.setEnabled(false);
        stopButton.setEnabled(false);
        statusText.setText("Останавливаю проверку...");
        refreshCheckModeUi();
        detailsText.setText(
                "Сейчас: останавливаю проверку" +
                "\nЭтап: отмена текущего запроса Cubux" +
                "\nПрогресс: " + maxLoadedShown + " операций • страница " + maxPageShown +
                "\nЗапросы: новые запросы не отправляются" +
                "\nПрошло: " + TimeUtil.formatDuration(AuditForegroundService.snapshot().elapsedMs) +
                "\nСостояние: незавершённые данные не будут записаны в эталон"
        );
    }

    private AuditProgressListener progressListener(
            final long sessionId,
            final AuditControl sessionControl
    ) {
        return new AuditProgressListener() {

            private boolean isCurrent() {
                return sessionId == activeAuditSession
                        && auditRunning
                        && auditControl == sessionControl
                        && !sessionControl.isStopped();
            }

            @Override
            public void onStage(
                    String stage,
                    String message
            ) {
                if (!isCurrent() || sessionControl.isPaused()) return;

                // A normal inter-request delay is only auxiliary information. It must never
                // replace the explanation of what the scan itself is doing.
                if ("GENTLE_WAIT".equals(stage) || "SERVER_COOLDOWN".equals(stage)) {
                    currentWaitForUi = message == null ? "" : message;
                    AuditForegroundService.updateNote(MainActivity.this, currentWaitForUi);
                    runOnUiThread(() -> detailsText.setText(runningDetails(AuditForegroundService.snapshot())));
                    return;
                }

                currentWaitForUi = "";
                if ("AUTO_FULL".equals(stage)) {
                    maxPageShown = 0;
                    maxLoadedShown = 0;
                    scanContext = "Полная проверка после лёгкой";
                    AuditForegroundService.resetPageProgress();
                } else if ("STABILITY_FALLBACK_SCAN".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0;
                    scanContext = "Контроль стабильности — аварийный полный проход";
                    AuditForegroundService.resetPageProgress();
                } else if ("HISTORY_RESCAN".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0;
                    scanContext = "Повторная проверка изменённого периода";
                    AuditForegroundService.resetPageProgress();
                } else if ("LIGHT_DEEP".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0;
                    scanContext = "Подробная проверка изменённого периода";
                    AuditForegroundService.resetPageProgress();
                } else if ("READ_COMPLETE".equals(stage)) {
                    scanContext = "Основное чтение завершено";
                }
                currentStageForUi = stage == null ? "" : stage;
                int stagePercent = stagePercent(stage, maxPercentShown);
                maxPercentShown = Math.max(maxPercentShown, stagePercent);
                AuditForegroundService.updateStage(MainActivity.this, currentStageForUi, message, maxPercentShown,
                        maxPageShown, AuditForegroundService.pages, maxLoadedShown, AuditForegroundService.total);
                CheckStatusStore.activity(MainActivity.this, message);
                runOnUiThread(() -> {
                    if (sessionId != activeAuditSession) return;
                    progressBar.setProgress(maxPercentShown);
                    percentText.setText("Проверка " + maxPercentShown + "%");
                    statusText.setText(message);
                    updateStageIndicators(stage);
                    detailsText.setText(runningDetails(AuditForegroundService.snapshot()));
                });
            }

            @Override
            public void onMeta(
                    int total,
                    int pages
            ) {
                if (!isCurrent()) return;
                AuditForegroundService.update(MainActivity.this, "Получены параметры проверки", maxPercentShown,
                        maxPageShown, pages, maxLoadedShown, total);
                runOnUiThread(() -> detailsText.setText(runningDetails(AuditForegroundService.snapshot())));
            }

            @Override
            public void onPage(
                    int page,
                    int pages,
                    int loaded,
                    int total
            ) {
                if (!isCurrent() || sessionControl.isPaused()) return;
                updateProgress(
                        sessionId,
                        sessionControl,
                        page,
                        pages,
                        loaded,
                        total
                );
            }

            @Override
            public void onRetry(
                    int page,
                    int attempt,
                    int retrySeconds,
                    String error
            ) {
                if (!isCurrent()) return;
                retries++;

                boolean online = isNetworkAvailable();
                String retryStatus;
                if (!online) retryStatus = "Нет подключения к интернету. Проверка приостановлена.";
                else if (error != null && error.contains("HTTP 429")) retryStatus = "Cubux временно ограничил частоту запросов.";
                else if (error != null && error.matches(".*HTTP 5\\d\\d.*")) retryStatus = "Сервер Cubux временно недоступен.";
                else retryStatus = "Интернет есть, но Cubux временно не отвечает.";
                currentWaitForUi = retryStatus + " Повтор через " + retrySeconds + " сек. • попытка " + attempt;
                AuditForegroundService.updateNote(MainActivity.this, currentWaitForUi);
                CheckStatusStore.event(MainActivity.this, "WARNING", "СЕТЬ/CUBUX", currentWaitForUi);

                runOnUiThread(
                        () -> {
                            statusText.setText(retryStatus);
                            detailsText.setText(runningDetails(AuditForegroundService.snapshot()));
                        }
                );
            }
        };
    }


private int stagePercent(String stage, int current) {
    if (stage == null) return current;
    if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return Math.max(current, 1);
    if ("TEAM".equals(stage) || "RANGE".equals(stage) || "LOADING_META".equals(stage)) return Math.max(current, 3);
    if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return Math.max(current, 8);
    if ("LIGHT_SUMMARY".equals(stage)) return Math.max(current, 18);
    if ("LIGHT_MONTHLY".equals(stage) || "LIGHT_BASELINE_MIGRATION".equals(stage)) return Math.max(current, 20);
    if ("LIGHT_NO_CHANGES".equals(stage)) return Math.max(current, 94);
    if ("LIGHT_MISMATCH".equals(stage)) return Math.max(current, 28);
    if ("LIGHT_DEEP".equals(stage)) return Math.max(current, 32);
    if ("READ_COMPLETE".equals(stage)) return Math.max(current, 86);
    if ("STABILITY_START".equals(stage)) return Math.max(current, 3);
    if ("MONTHLY_CONTROL_START".equals(stage) || "MONTHLY_CONTROL".equals(stage)) return Math.max(current, 4);
    if ("STABILITY_VERIFY".equals(stage) || "MONTHLY_CONTROL_VERIFY".equals(stage) || "MONTHLY_CONTROL_SWITCH".equals(stage) || "STABILITY_FALLBACK".equals(stage)) return Math.max(current, 88);
    if ("STABILITY_FALLBACK_SCAN".equals(stage) || "STABILITY_EMERGENCY".equals(stage) || "HISTORY_RESCAN".equals(stage) || "HISTORY_MOVED".equals(stage)) return Math.max(current, 89);
    if ("STABILITY_OK".equals(stage)) return Math.max(current, 90);
    if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return Math.max(current, 92);
    if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return Math.max(current, 95);
    if ("CONTROL_BASELINE".equals(stage) || "LIGHT_BASELINE_REFRESH".equals(stage) || "LIGHT_BASELINE_READY".equals(stage)) return Math.max(current, 96);
    if ("SAVING".equals(stage)) return Math.max(current, 98);
    if ("BACKUP".equals(stage) || "BACKUP_OK".equals(stage) || "BACKUP_WARNING".equals(stage) || "CREATING_REPORT".equals(stage)) return Math.max(current, 99);
    if ("COMPLETED".equals(stage)) return 100;
    return current;
}

private boolean isNetworkAvailable() {
    return NetworkUtil.hasInternet(this);
}

    private void updateProgress(
            long sessionId,
            AuditControl sessionControl,
            int page,
            int pages,
            int loaded,
            int total
    ) {
        if (sessionId != activeAuditSession || !auditRunning) return;

        // Never allow stale/retried callbacks to move UI backwards.
        if (page < maxPageShown || loaded < maxLoadedShown) return;

        maxPageShown = Math.max(maxPageShown, page);
        maxLoadedShown = Math.max(maxLoadedShown, loaded);
        long elapsed = sessionControl.activeElapsedMs(startedMs);

        int rawPercent =
                total <= 0
                        ? 0
                        : (int) (
                                5.0 + loaded *
                                        80.0 /
                                        total
                        );

        final int percent =
                Math.max(
                        maxPercentShown,
                        Math.min(85, rawPercent)
                );

        maxPercentShown = percent;

        double speed =
                loaded /
                        Math.max(
                                1,
                                elapsed /
                                        1000.0
                        );

        String readStatus = scanContext == null || scanContext.isEmpty()
                ? "Читаю операции из Cubux"
                : scanContext + ": читаю операции из Cubux";
        currentStageForUi = "READING_DATA";
        currentWaitForUi = "";
        AuditForegroundService.updateStage(this, "READING_DATA", readStatus, percent,
                maxPageShown, pages, maxLoadedShown, total);

        runOnUiThread(
                () -> {
                    if (sessionId != activeAuditSession || !auditRunning) return;
                    if (auditControl != sessionControl || sessionControl.isPaused() || sessionControl.isStopped()) return;
                    progressBar.setProgress(
                            Math.min(
                                    100,
                                    percent
                            )
                    );

                    percentText.setText(
                            "Проверка " +
                                    percent +
                                    "%"
                    );

                    statusText.setText(readStatus);
                    updateStageIndicators("READING_DATA");
                    detailsText.setText(runningDetails(AuditForegroundService.snapshot()));
                }
        );
    }

    private CharSequence runningDetails(AuditForegroundService.Snapshot s) {
        if (s == null) s = AuditForegroundService.snapshot();
        String stage = (s.stage == null || s.stage.isEmpty()) ? currentStageForUi : s.stage;
        String rawAction = (s.state == null || s.state.trim().isEmpty()) ? "Выполняю проверку" : s.state.trim();
        String action = actionDescription(stage, rawAction);
        String progress = progressDescription(s, rawAction);
        String detail = actionDetailDescription(stage, rawAction, s);
        String speed = "Скорость: " + DelayProfile.label(new CheckSettings(this).requestDelayMs());
        String elapsed = "Прошло: " + TimeUtil.formatDuration(s.elapsedMs);
        String activity = "Последняя активность: " + (s.updatedAt > 0L ? new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new java.util.Date(s.updatedAt)) : "—");
        String note = (s.note != null && !s.note.trim().isEmpty()) ? s.note.trim() : currentWaitForUi;
        if (note == null || note.trim().isEmpty()) note = "этап выполняется, данные обновляются";
        if (note.startsWith("Состояние:")) note = note.substring("Состояние:".length()).trim();
        String text = "Сейчас: " + action +
                "\nЭтап: " + stageName(stage) +
                "\n" + progress +
                "\nДействие: " + detail +
                "\n" + speed +
                "\n" + elapsed +
                "\n" + activity +
                "\nСостояние: " + note;
        return boldCurrentAction(text);
    }

    private CharSequence boldCurrentAction(String text){
        SpannableStringBuilder out=new SpannableStringBuilder(text==null?"":text);
        int boldStart="Сейчас: ".length();
        int boldEnd=out.toString().indexOf('\n'); if(boldEnd<0)boldEnd=out.length();
        if(boldEnd>boldStart)out.setSpan(new StyleSpan(Typeface.BOLD),boldStart,boldEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return out;
    }

    private String actionDetailDescription(String stage,String raw,AuditForegroundService.Snapshot s){
        if(stage==null)return "выполняю текущий этап проверки";
        if("PREPARING".equals(stage)||"START".equals(stage))return "проверяю настройки, локальную базу и готовность к запуску";
        if("AUTHENTICATING".equals(stage)||"REAUTHENTICATING".equals(stage))return "проверяю доступ к Cubux и получаю рабочий токен";
        if("TEAM".equals(stage))return "получаю команду и идентификатор данных Cubux";
        if("RANGE".equals(stage))return "определяю границы закрытой истории для проверки";
        if("LOADING_META".equals(stage))return "получаю число операций и страниц перед чтением";
        if("READING_DATA".equals(stage))return "загружаю следующую страницу операций последовательно";
        if(stage.startsWith("LIGHT")||stage.startsWith("MONTHLY_CONTROL"))return "сравниваю контрольные данные с локальным эталоном без лишней полной загрузки";
        if(stage.startsWith("STABILITY")||"HISTORY_MOVED".equals(stage)||"HISTORY_RESCAN".equals(stage))return "убеждаюсь, что данные не менялись во время сканирования";
        if("PROCESSING".equals(stage)||"CLOSE_EMPTY_DAYS".equals(stage))return "проверяю закрытые дни и формирую безопасный эталон";
        if("COMPARING".equals(stage)||"CHECKING_HISTORY".equals(stage))return "ищу новые, изменённые и удалённые записи";
        if("SAVING".equals(stage))return "атомарно сохраняю только подтверждённый результат";
        if(stage.startsWith("BACKUP"))return "создаю резервную копию локальной базы";
        if("NO_INTERNET".equals(stage))return "жду сеть; незавершённые данные не сохраняются";
        if("RETRY_WAIT".equals(stage)||"WAITING_CUBUX".equals(stage))return "повторяю тот же запрос после защитной паузы";
        if("COMPLETED".equals(stage))return "все этапы завершены, результат сохранён";
        return raw==null||raw.trim().isEmpty()?"выполняю текущий этап проверки":raw.trim();
    }

    private String actionDescription(String stage, String raw) {
        if (stage == null) return raw;
        if ("PREPARING".equals(stage)) return "подготавливаю проверку";
        if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return "проверяю и обновляю авторизацию Cubux";
        if ("TEAM".equals(stage)) return "получаю данные команды Cubux";
        if ("RANGE".equals(stage)) return "определяю диапазон закрытой истории";
        if ("LOADING_META".equals(stage)) return "получаю количество операций и страниц";
        if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return "проверяю метаданные закрытой истории";
        if ("LIGHT_SUMMARY".equals(stage)) return "сверяю контрольные суммы без полной загрузки";
        if ("LIGHT_MONTHLY".equals(stage) || "MONTHLY_CONTROL".equals(stage) || "MONTHLY_CONTROL_START".equals(stage) || "MONTHLY_CONTROL_VERIFY".equals(stage)) return "сверяю контрольные данные истории по месяцам";
        if ("LIGHT_BASELINE_MIGRATION".equals(stage)) return "создаю лёгкий эталон из существующей локальной базы";
        if ("LIGHT_MISMATCH".equals(stage)) return "локализую период, в котором найдено расхождение";
        if ("LIGHT_DEEP".equals(stage)) return "подробно проверяю только изменившийся период";
        if ("LIGHT_NO_CHANGES".equals(stage)) return "контрольные данные совпали, изменений нет";
        if ("AUTO_FULL".equals(stage) || "BASELINE_REQUIRED".equals(stage)) return "готовлю переход к полной проверке";
        if ("WAITING_CUBUX".equals(stage)) return "жду ответ Cubux на текущий запрос";
        if ("READING_DATA".equals(stage)) return "читаю операции из Cubux";
        if ("READ_COMPLETE".equals(stage)) return "основная загрузка завершена, проверяю результат";
        if ("STABILITY_START".equals(stage) || "STABILITY_VERIFY".equals(stage)) return "проверяю, не менялась ли история во время сканирования";
        if ("HISTORY_MOVED".equals(stage)) return "обнаружено изменение истории, уточняю изменившийся период";
        if ("HISTORY_RESCAN".equals(stage)) return "повторно читаю только изменившийся период";
        if ("STABILITY_EMERGENCY".equals(stage) || "STABILITY_FALLBACK".equals(stage) || "STABILITY_FALLBACK_SCAN".equals(stage)) return "выполняю аварийный контроль стабильности";
        if ("STABILITY_OK".equals(stage)) return "стабильность истории подтверждена";
        if ("STABILITY_WAIT".equals(stage)) return "жду стабилизации изменившегося периода";
        if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return "проверяю целостность закрытых дней";
        if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return "сравниваю подтверждённые данные с локальным эталоном";
        if ("CONTROL_BASELINE".equals(stage) || "LIGHT_BASELINE_READY".equals(stage)) return "готовлю контрольный эталон для следующих проверок";
        if ("SAVING".equals(stage)) return "сохраняю подтверждённый результат в локальную базу";
        if (stage.startsWith("BACKUP")) return "создаю резервную копию базы Cubux Security";
        if ("NO_INTERNET".equals(stage)) return "жду восстановления подключения к интернету";
        if ("INTERNET_RESTORED".equals(stage) || "RECONNECTING".equals(stage)) return "восстанавливаю прерванное подключение и продолжаю";
        if ("RETRY_WAIT".equals(stage) || "WAITING_CUBUX".equals(stage)) return "жду повторного запроса к Cubux";
        if ("AUTH_ERROR".equals(stage) || "PERMANENT_ERROR".equals(stage)) return "проверка остановлена из-за ошибки Cubux";
        if ("COMPLETED".equals(stage)) return "проверка завершена успешно";
        return raw;
    }

    private String progressDescription(AuditForegroundService.Snapshot s, String action) {
        String st = (s.stage == null || s.stage.isEmpty()) ? currentStageForUi : s.stage;
        String marker = "Контроль по месяцам:";
        int i = action.indexOf(marker);
        if (i >= 0) {
            String x = action.substring(i + marker.length()).trim();
            int dot = x.indexOf(". Полная");
            if (dot > 0) x = x.substring(0, dot);
            return "Прогресс: месяц " + x;
        }
        if (action.contains("периоде ")) {
            int p = action.indexOf("периоде ");
            String x = action.substring(p + 8).replace(". Проверяю его подробно...", "").trim();
            return "Прогресс: период " + x;
        }
        if ("BACKUP".equals(st) || "BACKUP_OK".equals(st) || "BACKUP_WARNING".equals(st)) return "Прогресс: создаю и проверяю резервную копию базы";
        if ("SAVING".equals(st)) return "Прогресс: сохраняю подтверждённый результат";
        if ("COMPARING".equals(st) || "CHECKING_HISTORY".equals(st)) return "Прогресс: сравниваю данные с локальным эталоном";
        if ("PROCESSING".equals(st) || "CLOSE_EMPTY_DAYS".equals(st)) return "Прогресс: проверяю целостность закрытых дней";
        if ("CONTROL_BASELINE".equals(st) || "LIGHT_BASELINE_READY".equals(st) || "LIGHT_BASELINE_MIGRATION".equals(st)) return "Прогресс: готовлю контрольный эталон для следующих лёгких проверок";
        if ("LIGHT_NO_CHANGES".equals(st)) return "Прогресс: контроль завершён, подробная загрузка не требуется";
        if ("READ_COMPLETE".equals(st)) return "Прогресс: основная загрузка завершена полностью";
        if ("STABILITY_VERIFY".equals(st) || "MONTHLY_CONTROL_VERIFY".equals(st) || "STABILITY_START".equals(st)) return "Прогресс: проверяю, не менялась ли история во время чтения";
        if (s.total > 0 && ("READING_DATA".equals(st) || "WAITING_CUBUX".equals(st) || "RETRY_WAIT".equals(st) || "NO_INTERNET".equals(st) || "INTERNET_RESTORED".equals(st))) {
            return "Прогресс: " + s.loaded + " из " + s.total + " операций • страница " + s.page + " из " + s.pages;
        }
        if (s.total > 0) return "Прогресс: подтверждено " + s.loaded + " из " + s.total + " операций";
        return "Прогресс: выполняется текущий этап";
    }

    private String stageName(String stage) {
        if (stage == null || stage.isEmpty() || "IDLE".equals(stage) || "PREPARING".equals(stage) || "START".equals(stage)) return "подготовка";
        if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return "авторизация Cubux";
        if ("TEAM".equals(stage)) return "получение данных команды";
        if ("RANGE".equals(stage) || "LOADING_META".equals(stage)) return "определение диапазона и объёма данных";
        if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return "лёгкая проверка — метаданные";
        if ("LIGHT_SUMMARY".equals(stage)) return "лёгкая проверка — контрольные суммы";
        if ("LIGHT_MONTHLY".equals(stage) || "MONTHLY_CONTROL".equals(stage) || "MONTHLY_CONTROL_START".equals(stage)) return "контроль истории по месяцам";
        if ("LIGHT_BASELINE_MIGRATION".equals(stage) || "LIGHT_BASELINE_READY".equals(stage) || "CONTROL_BASELINE".equals(stage)) return "контрольный эталон лёгкой проверки";
        if ("LIGHT_MISMATCH".equals(stage)) return "поиск проблемного периода";
        if ("LIGHT_DEEP".equals(stage)) return "подробная проверка изменённого периода";
        if ("LIGHT_NO_CHANGES".equals(stage)) return "лёгкая проверка — расхождений нет";
        if ("AUTO_FULL".equals(stage) || "BASELINE_REQUIRED".equals(stage)) return "переход к полной проверке";
        if ("READING_DATA".equals(stage)) return "чтение операций Cubux";
        if ("READ_COMPLETE".equals(stage)) return "основная загрузка завершена";
        if (stage.startsWith("STABILITY") || stage.startsWith("MONTHLY_CONTROL") || "HISTORY_MOVED".equals(stage) || "HISTORY_RESCAN".equals(stage)) return "контроль стабильности истории";
        if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return "проверка целостности закрытых дней";
        if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return "сравнение с локальным эталоном";
        if ("SAVING".equals(stage)) return "сохранение результата";
        if (stage.startsWith("BACKUP")) return "резервная копия";
        if ("NO_INTERNET".equals(stage)) return "ожидание интернета";
        if ("INTERNET_RESTORED".equals(stage) || "RECONNECTING".equals(stage)) return "восстановление соединения";
        if ("RETRY_WAIT".equals(stage) || "WAITING_CUBUX".equals(stage)) return "повтор запроса Cubux";
        if ("AUTH_ERROR".equals(stage) || "PERMANENT_ERROR".equals(stage)) return "ошибка проверки";
        if ("COMPLETED".equals(stage)) return "готово";
        return stage.replace('_', ' ').toLowerCase(Locale.getDefault());
    }

    private void updateStageIndicators(String stage) {
        String st = stage == null ? "" : stage;
        int current = 0;
        if (st.contains("AUTH") || st.contains("TEAM") || st.contains("START") || st.contains("PREPAR")) current=1;
        else if (st.contains("RANGE") || st.contains("META")) current=2;
        else if (st.contains("READ") || st.contains("LOAD") || st.contains("STABILITY") || st.contains("DEEP")) current=3;
        else if (st.contains("PROCESS") || st.contains("COMPAR")) current=4;
        else if (st.contains("HISTORY") || st.contains("CONTROL") || st.contains("LIGHT")) current=5;
        else if (st.contains("SAVING")) current=6;
        else if (st.contains("BACKUP") || st.contains("REPORT")) current=7;
        else if (st.contains("COMPLETED")) current=8;
        else if (AuditRunGate.isRunning()) current=1;

        for(int i=0;i<stageRows.length;i++){
            TextView name=stageRows[i];
            TextView icon=stageIconViews[i];
            TextView status=stageStatusViews[i];
            if(name==null||icon==null||status==null)continue;
            int pos=i+1;
            boolean done=current>pos || (current==8 && pos==8 && "COMPLETED".equals(st));
            boolean active=current==pos && !"COMPLETED".equals(st);
            if(done){
                icon.setText("✓");
                icon.setTextColor(Color.WHITE);
                icon.setBackground(rounded(GREEN,20));
                name.setTextColor(Color.rgb(58,82,118));
                name.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
                status.setText("Готово");
                status.setTextColor(GREEN);
            }else if(active){
                icon.setText("✓");
                icon.setTextColor(Color.WHITE);
                icon.setBackground(rounded(BLUE,20));
                name.setTextColor(DARK);
                name.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
                status.setText("В процессе");
                status.setTextColor(BLUE);
            }else{
                icon.setText("○");
                icon.setTextColor(Color.rgb(88,111,151));
                icon.setBackgroundColor(Color.TRANSPARENT);
                name.setTextColor(MUTED);
                name.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
                status.setText("Ожидание");
                status.setTextColor(MUTED);
            }
        }
        refreshCurrentStageSummary(st);
    }

    private void refreshCurrentStageSummary(String stage){
        if(currentStageSummaryTitle==null||currentStageSummaryBody==null)return;
        String st=stage==null?"":stage;
        if((st.isEmpty()||"IDLE".equals(st)) && !AuditRunGate.isRunning() && !auditRunning){
            currentStageSummaryTitle.setText("Текущий этап:  ожидание");
            currentStageSummaryBody.setText("Ожидание запуска проверки.");
            currentStageSummaryBody.setTextColor(MUTED);
            return;
        }
        if("COMPLETED".equals(st)){
            currentStageSummaryTitle.setText("Текущий этап:  Проверка завершена");
            String n=db.getState("last_check_new");
            String c=db.getState("last_check_changed");
            String d=db.getState("last_check_deleted");
            int nn=parseIntSafe(n), cc=parseIntSafe(c), dd=parseIntSafe(d);
            if(nn==0&&cc==0&&dd==0){
                currentStageSummaryBody.setText("Проверка прошла успешно. Изменений не обнаружено.");
                currentStageSummaryBody.setTextColor(GREEN);
            }else{
                currentStageSummaryBody.setText("Найдены изменения: новые — "+nn+", изменённые — "+cc+", удалённые — "+dd+".");
                currentStageSummaryBody.setTextColor(RED);
            }
            return;
        }
        if(st.contains("ERROR")||st.contains("PERMANENT")){
            currentStageSummaryTitle.setText("Текущий этап:  Проверка завершена с ошибкой");
            currentStageSummaryBody.setText("Откройте историю событий, чтобы увидеть причину ошибки.");
            currentStageSummaryBody.setTextColor(RED);
            return;
        }
        currentStageSummaryTitle.setText("Текущий этап:  "+stageName(st));
        currentStageSummaryBody.setText(actionDetailDescription(st,"",AuditForegroundService.snapshot()));
        currentStageSummaryBody.setTextColor(MUTED);
    }

    private int parseIntSafe(String value){
        try{return Integer.parseInt(value==null?"0":value.trim());}catch(Throwable ignored){return 0;}
    }

    private void setStageStep(TextView view, String icon, String caption, int color) {
        if (view == null) return;
        view.setText(icon + "\n" + caption);
        view.setTextColor(color);
    }

    private void showResult(
            AuditEngine.Result r
    ) {
        try {
            CheckScheduler.scheduleNext(this);
            refreshAutoAuditStatus();
            requestNotificationPermissionIfNeeded();
        } catch (Throwable ignored) {
        }

        AuditForegroundService.updateStage(this, "COMPLETED", "Проверка завершена успешно", 100,
                maxPageShown, AuditForegroundService.pages, maxLoadedShown, AuditForegroundService.total);
        progressBar.setProgress(100);

        percentText.setText("100%");
        if (progressAmountText != null) progressAmountText.setText(r.total + " из " + r.total + " операций");
        refreshCheckModeUi();

        statusText.setText(
                "Проверка завершена успешно"
        );
        updateStageIndicators("COMPLETED");
        if (pauseButton != null) pauseButton.setVisibility(View.GONE);
        if (stopButton != null) stopButton.setVisibility(View.GONE);
        String actualMode = db.getState("last_audit_mode");
        String checkLabel = AuditCoordinator.MODE_FULL.equals(activeCheckMode) ? "Полная проверка" :
                ("FULL_AFTER_LIGHT".equals(actualMode) ? "Быстрая → полная проверка" : "Быстрая проверка");
        CheckStatusStore.success(this, checkLabel, r);
        refreshCurrentStageSummary("COMPLETED");
        refreshLastCheckStatus();
        refreshDashboardInformer();

        long nextMs = parseLongState("next_scheduled_check_ms");
        String nextType = db.getState("next_scheduled_check_type");
        String nextText = nextMs > 0
                ? ((CheckSettings.TYPE_FULL.equals(nextType) ? "Полная" : "Быстрая") + " • " +
                   new java.text.SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(new java.util.Date(nextMs)))
                : "не запланирована";

        detailsText.setText(
                "Сейчас: проверка завершена успешно" +
                        "\nЭтап: готово" +
                        "\nПроверено: " + r.total + " операций" +
                        "\nРезультат: новые " + r.newCount + " • изменённые " + r.changedCount + " • удалённые " + r.deletedCount +
                        "\nВремя проверки: " + TimeUtil.formatDuration(r.durationMs) +
                        "\nСледующая проверка: " + nextText
        );

        setStat(
                totalTop,
                "▤",
                r.total,
                "Всего операций"
        );

        setStat(
                newTop,
                "+",
                r.newCount,
                "Новые"
        );

        setStat(
                changedTop,
                "✎",
                r.changedCount,
                "Изменённые"
        );

        setStat(
                deletedTop,
                "▥",
                r.deletedCount,
                "Удалённые"
        );

        setMiniStat(
                newCard,
                "▤",
                r.newCount,
                "Новые"
        );

        setMiniStat(
                changedCard,
                "✎",
                r.changedCount,
                "Изменённые"
        );

        setMiniStat(
                deletedCard,
                "▥",
                r.deletedCount,
                "Удалённые"
        );

        setMiniStat(
                closedCard,
                "▣",
                r.closedChangedCount,
                "Закрытые"
        );

        setMiniStat(
                multiCard,
                "↻",
                r.multiChangedCount,
                "Повторные"
        );

        resultText.setText(
                "Целостность: ОК • Cubux: только чтение"
        );
    }

    private void setStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        if (view == null) return;
        int accent = "Новые".equals(caption) ? GREEN : "Изменённые".equals(caption) ? YELLOW : "Удалённые".equals(caption) ? RED : BLUE;
        String raw="●  "+caption+"\n    "+value;
        SpannableStringBuilder sp=new SpannableStringBuilder(raw);
        sp.setSpan(new ForegroundColorSpan(accent),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int start=raw.lastIndexOf(value);
        if(start>=0){sp.setSpan(new StyleSpan(Typeface.BOLD),start,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new RelativeSizeSpan(1.15f),start,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new ForegroundColorSpan(DARK),start,raw.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
        view.setText(sp);
    }

    private void setMiniStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        if (view == null) return;
        view.setText(
                icon +
                        "\n" +
                        value +
                        "\n" +
                        caption
        );
    }

    private void showLoginDialog(
            boolean runAfterSave
    ) {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        int pad = dp(18);

        box.setPadding(
                pad,
                0,
                pad,
                0
        );

        EditText login =
                new EditText(this);

        login.setHint(
                "Логин Cubux"
        );

        login.setSingleLine(true);

        login.setText(
                credentials.getLogin()
        );

        EditText password =
                new EditText(this);

        password.setHint(
                "Пароль Cubux"
        );

        password.setSingleLine(true);

        password.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        box.addView(login);
        box.addView(password);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Авторизация Cubux"
                )
                .setMessage(
                        "Приложение само получит и будет обновлять API-токен."
                )
                .setView(box)
                .setPositiveButton(
                        "Сохранить",
                        (d, w) -> {
                            try {
                                credentials.saveCredentials(
                                        login.getText()
                                                .toString()
                                                .trim(),
                                        password.getText()
                                                .toString()
                                );

                                credentials.clearToken();

                                Toast.makeText(
                                        this,
                                        "Данные сохранены",
                                        Toast.LENGTH_SHORT
                                ).show();

                                if (runAfterSave) {
                                    runAudit();
                                }

                            } catch (Exception e) {
                                Toast.makeText(
                                        this,
                                        "Ошибка сохранения",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void showSettingsDialog() {
        CheckSettings cfg = new CheckSettings(this);
        String[] items = {
                "Логин и пароль Cubux",
                "Автопроверка и автозапуск",
                "Расписание лёгкой проверки",
                "Расписание полной проверки",
                "Повторных попыток: " + cfg.retries(),
                "Пауза между запросами: " + DelayProfile.label(cfg.requestDelayMs()),
                "Расширенная диагностика",
                "Удалить данные авторизации"
        };

        new AlertDialog.Builder(this)
                .setTitle("Настройки")
                .setItems(items, (d, which) -> {
                    if (which == 0) showLoginDialog(false);
                    else if (which == 1) showAutoStartSettings();
                    else if (which == 2) scheduleSettingsDialog(CheckSettings.TYPE_LIGHT);
                    else if (which == 3) scheduleSettingsDialog(CheckSettings.TYPE_FULL);
                    else if (which == 4) retrySettingsDialog();
                    else if (which == 5) delaySettingsDialog();
                    else if (which == 6) showAdvancedDiagnosticsDialog();
                    else {
                        credentials.clearAll();
                        CheckScheduler.cancel(this);
                        Toast.makeText(this, "Логин, пароль и токен удалены", Toast.LENGTH_SHORT).show();
                        refreshAutoAuditStatus();
                    }
                }).show();
    }

    private void showAutoStartSettings() {
        boolean exact=CheckScheduler.canScheduleExact(this);
        long next=parseLongState("next_scheduled_check_ms");
        long last=parseLongState("last_scheduled_start_ms");
        String nextText=next>0?new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new java.util.Date(next)):"не запланирована";
        String lastText=last>0?new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss",Locale.getDefault()).format(new java.util.Date(last)):"ещё не запускалась";
        String msg="Автопроверка: "+(next>0?"включена":"нет активного расписания")+
                "\nТочный запуск: "+(exact?"разрешён":"НЕ разрешён системой")+
                "\nЗапуск при закрытом приложении: включён"+
                "\nАвтозапуск после перезагрузки: включён"+
                "\nПропущенная проверка: выполнить после включения телефона"+
                "\nСледующая проверка: "+nextText+
                "\nПоследний запуск по расписанию: "+lastText;
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("Автопроверка и автозапуск").setMessage(msg).setPositiveButton("Готово",null);
        if(Build.VERSION.SDK_INT>=31&&!exact){b.setNeutralButton("Исправить",(d,w)->{try{Intent i=new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Throwable e){startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}});}
        b.setNegativeButton("Перепланировать",(d,w)->{CheckScheduler.scheduleNext(this);refreshAutoAuditStatus();Toast.makeText(this,"Расписание обновлено",Toast.LENGTH_SHORT).show();}).show();
    }

    private void showAdvancedDiagnosticsDialog() {
        String[] items = {
                "Технические данные изменений",
                "Служебный лог проверок и запросов",
                "Экспортировать служебный лог",
                "Очистить служебный лог"
        };
        new AlertDialog.Builder(this)
                .setTitle("Расширенная диагностика")
                .setMessage("Технический раздел. Здесь видны ID операций, старые/новые данные, причины NEW / CHANGED / DELETED, страницы проверки, HTTP-коды и служебные статусы.")
                .setItems(items, (d, which) -> {
                    if (which == 0) resultText.setText(TimeUtil.displayDateTime(db.diagnosticJournal()));
                    else if (which == 1) resultText.setText(TimeUtil.displayDateTime("СЛУЖЕБНЫЙ ЛОГ ПРОВЕРОК И ЗАПРОСОВ\n\n" + DiagnosticLog.read(this)));
                    else if (which == 2) exportDiagnosticLog();
                    else {
                        DiagnosticLog.clear(this);
                        Toast.makeText(this, "Служебный лог очищен", Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }

    private void scheduleSettingsDialog(String type) {
        CheckSettings cfg = new CheckSettings(this);
        boolean full = CheckSettings.TYPE_FULL.equals(type);
        int mask = full ? cfg.fullDays() : cfg.lightDays();
        String time = full ? cfg.fullTime() : cfg.lightTime();
        int[] hm = CheckSettings.parseTime(time);
        final int[] selectedTime = {hm[0], hm[1]};
        String[] days = CheckSettings.dayNames();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(4), dp(18), 0);
        final android.widget.CheckBox[] checks = new android.widget.CheckBox[7];
        for (int i=0;i<7;i++) {
            android.widget.CheckBox cb = new android.widget.CheckBox(this);
            cb.setText(days[i]);
            cb.setChecked((mask & (1 << i)) != 0);
            cb.setTextSize(16);
            cb.setPadding(0, dp(3), 0, dp(3));
            checks[i]=cb;
            box.addView(cb);
        }
        Button timeButton = new Button(this);
        timeButton.setAllCaps(false);
        timeButton.setText(String.format(Locale.US,"Время запуска: %02d:%02d",selectedTime[0],selectedTime[1]));
        timeButton.setOnClickListener(v -> new android.app.TimePickerDialog(this,(view,h,m)->{
            selectedTime[0]=h;selectedTime[1]=m;
            timeButton.setText(String.format(Locale.US,"Время запуска: %02d:%02d",h,m));
        },selectedTime[0],selectedTime[1],true).show());
        box.addView(timeButton);

        TextView note = label(full
                ? "Если на этот же день назначена лёгкая проверка, выполняется только полная."
                : "Если на этот же день назначена полная проверка, лёгкая отдельно не запускается.",
                12,false,MUTED);
        note.setPadding(0,dp(8),0,0); box.addView(note);

        new AlertDialog.Builder(this)
                .setTitle(full ? "Полная проверка" : "Быстрая проверка")
                .setView(box)
                .setPositiveButton("Сохранить",(d,w)->{
                    int newMask=0; for(int i=0;i<7;i++)if(checks[i].isChecked())newMask|=(1<<i);
                    String t=String.format(Locale.US,"%02d:%02d",selectedTime[0],selectedTime[1]);
                    if(full){cfg.setFullDays(newMask);cfg.setFullTime(t);}else{cfg.setLightDays(newMask);cfg.setLightTime(t);}
                    CheckScheduler.scheduleNext(this); refreshAutoAuditStatus();
                    Toast.makeText(this,"Расписание сохранено",Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Отмена",null).show();
    }

    private void retrySettingsDialog() {
        final int[] values={1,3,5,7,10};
        String[] labels={"1 попытка","3 попытки","5 попыток","7 попыток","10 попыток"};
        new AlertDialog.Builder(this).setTitle("Повторные попытки при ошибке")
                .setItems(labels,(d,which)->{
                    new CheckSettings(this).setRetries(values[which]);
                    Toast.makeText(this,"Повторных попыток: "+values[which],Toast.LENGTH_SHORT).show();
                    refreshAutoAuditStatus();
                }).show();
    }

    private void delaySettingsDialog() {
        CheckSettings cfg = new CheckSettings(this);
        long currentMs = cfg.requestDelayMs();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        TextView info = new TextView(this);
        info.setText("Пауза между последовательными запросами Cubux: 0,5–10 секунд. 0,5 сек — самый жёсткий режим; при 429, таймаутах и ошибках сервера защитные задержки увеличиваются автоматически.");
        info.setTextSize(16);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, 0, 0, dp(12));
        box.addView(info, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        String[] labels = DelayProfile.labels();
        NumberPicker picker = new NumberPicker(this);
        picker.setMinValue(0);
        picker.setMaxValue(labels.length - 1);
        picker.setDisplayedValues(labels);
        picker.setValue(DelayProfile.indexFor(currentMs));
        picker.setWrapSelectorWheel(false);
        picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        box.addView(picker, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView current = new TextView(this);
        current.setText("Выбрано: " + DelayProfile.label(currentMs) +
                (currentMs == DelayProfile.DEFAULT_MS ? " (по умолчанию)" : ""));
        current.setTextSize(14);
        current.setGravity(Gravity.CENTER);
        current.setPadding(0, dp(8), 0, 0);
        box.addView(current, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        picker.setOnValueChangedListener((p, oldVal, newVal) -> {
            long ms = DelayProfile.millisForIndex(newVal);
            current.setText("Выбрано: " + DelayProfile.label(ms) +
                    (ms == DelayProfile.DEFAULT_MS ? " (по умолчанию)" : ""));
        });

        new AlertDialog.Builder(this)
                .setTitle("Пауза между запросами Cubux")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (d, which) -> {
                    long ms = DelayProfile.millisForIndex(picker.getValue());
                    new CheckSettings(this).setRequestDelayMs(ms);
                    Toast.makeText(this, "Пауза: " + DelayProfile.label(ms), Toast.LENGTH_SHORT).show();
                    refreshAutoAuditStatus();
                })
                .show();
    }

    private String scheduleDaysText(int mask) {
        String[] n=CheckSettings.dayNames(); StringBuilder b=new StringBuilder();
        for(int i=0;i<7;i++)if((mask&(1<<i))!=0){if(b.length()>0)b.append(", ");b.append(n[i]);}
        return b.length()==0?"выключена":b.toString();
    }

    private void refreshAutoAuditStatus() {
        if (detailsText == null) return;
        CheckSettings cfg=new CheckSettings(this);
        long next=parseLongState("next_scheduled_check_ms");
        String type=db.getState("next_scheduled_check_type");
        String nextText=next>0
                ? (CheckSettings.TYPE_FULL.equals(type)?"Полная":"Лёгкая")+" • "+
                  new java.text.SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new java.util.Date(next))
                : "нет";
        String first=new HistoryRange(db).startDate();
        detailsText.setText(
                "Следующая: "+nextText+
                "\nЛёгкая: "+scheduleDaysText(cfg.lightDays())+" • "+cfg.lightTime()+
                "\nПолная: "+scheduleDaysText(cfg.fullDays())+" • "+cfg.fullTime()+
                "\nЗапросы: последовательно, пауза "+DelayProfile.label(cfg.requestDelayMs())+
                " • попыток "+cfg.retries()+
                "\nНачало истории: "+(first==null?"определится по первой полной загрузке":first)
        );
    }

    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                        android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    2203
            );
        }
    }

    private void showReportsDialog() {
        String[] items = {
                "День",
                "Неделя",
                "Месяц",
                "Год",
                "Произвольный период"
        };

        ReportEngine r =
                new ReportEngine(db);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Отчёты"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                resultText.setText(
                                        r.today()
                                );
                            } else if (
                                    which == 1
                            ) {
                                resultText.setText(
                                        r.week()
                                );
                            } else if (
                                    which == 2
                            ) {
                                resultText.setText(
                                        r.month()
                                );
                            } else if (
                                    which == 3
                            ) {
                                resultText.setText(
                                        r.year()
                                );
                            } else {
                                customReportDialog();
                            }
                        }
                )
                .show();
    }

    private void showBankDialog() {
        String[] items = {
                "Импорт CSV / XLSX",
                "Сверить банк с Cubux"
        };

        new AlertDialog.Builder(this)
                .setTitle(
                        "Банковская сверка"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                pickBankFile();
                            } else {
                                new Thread(
                                        () -> {
                                            String text =
                                                    new BankReconcileEngine(
                                                            db
                                                    ).reconcile();

                                            runOnUiThread(
                                                    () ->
                                                            resultText
                                                                    .setText(
                                                                            text
                                                                    )
                                            );
                                        }
                                ).start();
                            }
                        }
                )
                .show();
    }

    private void showJournalDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText search =
                new EditText(this);

        search.setHint(
                "Поиск: дата, сумма, категория, счёт, описание, ID"
        );

        Spinner filter =
                new Spinner(this);

        String[] values = {
                "Все",
                "Новые",
                "Изменённые",
                "Удалённые",
                "Закрытые периоды",
                "Повторные изменения"
        };

        filter.setAdapter(
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        values
                )
        );

        box.addView(search);
        box.addView(filter);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Журнал изменений"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        db.journalText(
                                                journalFilterKey(filter.getSelectedItemPosition()),
                                                search.getText().toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private String journalFilterKey(int position) {
        switch (position) {
            case 1: return "NEW";
            case 2: return "CHANGED";
            case 3: return "DELETED";
            case 4: return "CLOSED";
            case 5: return "MULTI";
            default: return "ALL";
        }
    }

    private void customReportDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText from =
                new EditText(this);

        from.setHint(
                "От YYYY-MM-DD"
        );

        EditText to =
                new EditText(this);

        to.setHint(
                "До YYYY-MM-DD"
        );

        box.addView(from);
        box.addView(to);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Произвольный период"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        new ReportEngine(
                                                db
                                        ).report(
                                                from.getText()
                                                        .toString(),
                                                to.getText()
                                                        .toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void pickBankFile() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType("*/*");

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_BANK
        );
    }

    private void exportDiagnosticLog() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "CubuxAudit-diagnostic-log.txt");
        startActivityForResult(i, REQ_LOG);
    }

    private void createBackup() {
        Intent i =
                new Intent(
                        Intent.ACTION_CREATE_DOCUMENT
                );

        i.setType(
                "application/zip"
        );

        i.putExtra(
                Intent.EXTRA_TITLE,
                "CubuxAudit-backup.zip"
        );

        startActivityForResult(
                i,
                REQ_BACKUP
        );
    }

    private void pickRestore() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType(
                "application/zip"
        );

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_RESTORE
        );
    }

    private String getDisplayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {
        }
        return uri.toString();
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (resultCode != RESULT_OK ||
                data == null ||
                data.getData() == null) {
            return;
        }

        Uri uri = data.getData();

        if (requestCode == REQ_LOG) {
            try {
                DiagnosticLog.export(this, uri);
                resultText.setText("Диагностический лог экспортирован. Его можно отправить для анализа ошибок.");
            } catch (Exception e) {
                resultText.setText("Ошибка экспорта лога: " + e.getMessage());
            }
        } else if (requestCode == REQ_BANK) {
            new Thread(
                    () -> {
                        try {
                            int imported =
                                    new BankImportEngine(
                                            db
                                    ).importFile(
                                            getContentResolver(),
                                            uri,
                                            getDisplayName(uri)
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Импортировано банковских операций: " +
                                                            imported
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка импорта: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (
                requestCode ==
                        REQ_BACKUP
        ) {
            new Thread(
                    () -> {
                        try {
                            String hash =
                                    new BackupManager(
                                            this,
                                            db
                                    ).exportTo(
                                            getContentResolver(),
                                            uri
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Backup создан\nSHA-256:\n" +
                                                            hash
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка backup: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (
                requestCode ==
                        REQ_RESTORE
        ) {
            new Thread(
                    () -> {
                        try {
                            new BackupManager(
                                    this,
                                    db
                            ).restoreFrom(
                                    getContentResolver(),
                                    uri
                            );

                            db =
                                    new AuditDb(this);

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                     "Резервная копия восстановлена. Следующая проверка будет синхронизационной: пропущенные операции догрузятся без массовых ложных «Новых»."
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка восстановления: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();
        }
    }
}
