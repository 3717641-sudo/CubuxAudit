package com.cubux.audit;
public class AuditControlTimerTest {
    static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
    public static void main(String[] args)throws Exception{
        AuditControl c=new AuditControl();
        long start=System.currentTimeMillis();
        Thread.sleep(120L);
        long before=c.activeElapsedMs(start);
        c.pause();
        Thread.sleep(220L);
        long paused=c.activeElapsedMs(start);
        check(Math.abs(paused-before)<80L,"manual pause must not increase active timer");
        c.resume();
        Thread.sleep(120L);
        long after=c.activeElapsedMs(start);
        check(after>=before+80L,"timer must continue after resume");
        System.out.println("PASS: manual pause excluded from elapsed time");
    }
}
