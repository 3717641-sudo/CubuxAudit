package com.cubux.audit;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
public class ClosedDayRulesTest {
    static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
    public static void main(String[] args)throws Exception{
        String today=TimeUtil.today();
        String yesterday=TimeUtil.yesterday();
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        Date t=f.parse(today), y=f.parse(yesterday);
        long days=(t.getTime()-y.getTime())/(24L*60L*60L*1000L);
        check(yesterday.compareTo(today)<0,"yesterday must be before today");
        check(days==1,"cutoff must be exactly one calendar day before today");
        System.out.println("PASS: closed-day cutoff="+yesterday+", today excluded="+today);
    }
}
