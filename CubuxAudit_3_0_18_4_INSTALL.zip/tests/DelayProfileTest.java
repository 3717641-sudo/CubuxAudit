package com.cubux.audit;
public class DelayProfileTest {
    static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
    public static void main(String[] args){
        check(DelayProfile.count()==20,"20 half-second choices expected");
        check(DelayProfile.millisForIndex(0)==500L,"first must be 0.5s");
        check(DelayProfile.millisForIndex(19)==10000L,"last must be 10s");
        check("Хард".equals(DelayProfile.name(500L)),"0.5s hard");
        check("Быстрый".equals(DelayProfile.name(1000L)),"1s fast");
        check("Оптимальный".equals(DelayProfile.name(2000L)),"2s optimal");
        check("Максимально щадящий".equals(DelayProfile.name(10000L)),"10s max gentle");
        System.out.println("PASS: "+DelayProfile.label(500L)+" ... "+DelayProfile.label(10000L));
    }
}
