package com.cubux.audit;

import android.content.Context;
import android.net.Uri;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class DiagnosticLog {
    private static final String FILE = "cubux_audit_diagnostic.log";
    private static final long MAX = 1024L * 1024L;

    private DiagnosticLog(){}

    public static synchronized void write(Context context, String tag, String message) {
        try {
            File f = new File(context.getFilesDir(), FILE);
            if (f.exists() && f.length() > MAX) {
                File old = new File(context.getFilesDir(), FILE + ".old");
                if (old.exists()) old.delete();
                f.renameTo(old);
            }
            String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(new Date());
            String safe = sanitize(message == null ? "" : message);
            try (FileOutputStream o = new FileOutputStream(f, true)) {
                o.write((time + " [" + tag + "] " + safe + "\n").getBytes(StandardCharsets.UTF_8));
            }
        } catch (Throwable ignored) {}
    }

    public static void error(Context context, String tag, Throwable e) {
        StringWriter sw = new StringWriter();
        if (e != null) e.printStackTrace(new PrintWriter(sw));
        write(context, tag, sw.toString());
    }

    public static synchronized String read(Context context) {
        File f = new File(context.getFilesDir(), FILE);
        if (!f.exists()) return "Диагностический лог пока пуст.";
        try {
            byte[] data = new byte[(int)Math.min(f.length(), 1024L * 1024L)];
            try (FileInputStream in = new FileInputStream(f)) {
                int n = in.read(data);
                return n <= 0 ? "Диагностический лог пока пуст." :
                        new String(data, 0, n, StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "Не удалось прочитать лог: " + e.getMessage();
        }
    }

    public static synchronized void clear(Context context) {
        try {
            new File(context.getFilesDir(), FILE).delete();
            new File(context.getFilesDir(), FILE + ".old").delete();
        } catch (Throwable ignored) {}
    }

    public static synchronized void export(Context context, Uri uri) throws Exception {
        OutputStream out = context.getContentResolver().openOutputStream(uri);
        if (out == null) throw new IOException("Не удалось создать файл лога");
        String text = read(context);
        out.write(text.getBytes(StandardCharsets.UTF_8));
        out.close();
    }

    private static String sanitize(String s) {
        if (s == null) return "";
        // Do not persist obvious credential/token lines.
        s = s.replaceAll("(?i)(authorization\\s*:\\s*bearer\\s+)[^\\s]+", "$1<скрыто>");
        s = s.replaceAll("(?i)(accessToken[\"'=: ]+)[A-Za-z0-9._\\-]+", "$1<скрыто>");
        s = s.replaceAll("(?i)(password[\"'=: ]+)[^\\s,}]+", "$1<скрыто>");
        return s;
    }
}
