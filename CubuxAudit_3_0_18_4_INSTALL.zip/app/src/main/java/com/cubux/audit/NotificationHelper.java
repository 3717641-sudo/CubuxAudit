package com.cubux.audit;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

public final class NotificationHelper {

    private static final String CHANNEL = "cubux_audit_status";
    private static final int ID_AUDIT_RESULT=2202, ID_WARNING=2203, ID_DAY_WARNING=2204;

    private NotificationHelper() {}

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            NotificationChannel channel = new NotificationChannel(
                    CHANNEL,
                    "Cubux Security",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Результаты автоматической проверки Cubux");
            manager.createNotificationChannel(channel);
        }
    }

    public static void showWarning(Context context, String text) {
        try {
            ensureChannel(context);
            if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
            NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE); if(manager==null)return;
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,CHANNEL):new android.app.Notification.Builder(context);
            b.setSmallIcon(R.drawable.ic_shield_check).setColor(android.graphics.Color.rgb(255,159,10)).setContentTitle("Требуется внимание").setContentText(compact(text,96)).setStyle(new android.app.Notification.BigTextStyle().bigText(text)).setAutoCancel(true);
            manager.notify(ID_WARNING,b.build());
        } catch(Throwable ignored) {}
    }

    public static void showAuditResult(
            Context context,
            boolean success,
            String text
    ) {
        try {
            ensureChannel(context);

            if (Build.VERSION.SDK_INT >= 33 &&
                    context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            NotificationManager manager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            android.app.Notification.Builder builder =
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                            ? new android.app.Notification.Builder(context, CHANNEL)
                            : new android.app.Notification.Builder(context);

            builder.setSmallIcon(R.drawable.ic_shield_check)
                    .setColor(success?android.graphics.Color.rgb(0,169,120):android.graphics.Color.rgb(255,75,86))
                    .setContentTitle(success ? "Проверка завершена" : "Проверка не завершена")
                    .setContentText(compact(text,96))
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(text))
                    .setAutoCancel(true);

            manager.notify(ID_AUDIT_RESULT, builder.build());

        } catch (Throwable ignored) {
        }
    }

    public static void showDayControlAlert(Context context,String text,boolean deleted){
        try{ensureChannel(context);if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;NotificationManager m=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(m==null)return;android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,CHANNEL):new android.app.Notification.Builder(context);b.setSmallIcon(R.drawable.ic_shield_check).setColor(deleted?android.graphics.Color.rgb(255,75,86):android.graphics.Color.rgb(255,174,0)).setContentTitle(deleted?"Удалена запись за сегодня":"Изменена запись за сегодня").setContentText(compact(text,96)).setAutoCancel(true);m.notify(ID_DAY_WARNING,b.build());}catch(Throwable ignored){}
    }
    public static void showDayControlError(Context context,String text){
        try{ensureChannel(context);if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;NotificationManager m=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(m==null)return;android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,CHANNEL):new android.app.Notification.Builder(context);b.setSmallIcon(R.drawable.ic_shield_check).setColor(android.graphics.Color.rgb(255,159,10)).setContentTitle("Дневной контроль не выполнен").setContentText(compact(text,96)).setAutoCancel(true);m.notify(ID_DAY_WARNING,b.build());}catch(Throwable ignored){}
    }
    public static void clearDayControlWarning(Context context){try{NotificationManager m=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(m!=null)m.cancel(ID_DAY_WARNING);}catch(Throwable ignored){}}
    private static String compact(String text,int max){String x=text==null?"":text.replace('\n',' ').trim();return x.length()>max?x.substring(0,max-1)+"…":x;}
}
