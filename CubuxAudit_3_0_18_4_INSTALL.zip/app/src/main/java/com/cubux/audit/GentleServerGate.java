package com.cubux.audit;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/** One shared gate for authentication, metadata and transaction requests. */
public final class GentleServerGate {
    public interface DeadlineStore { void save(long value); }
    public interface DelayProvider { long getDelayMs(); }
    private static final ReentrantLock LOCK=new ReentrantLock(true);
    private static volatile long notBefore;
    private static volatile long fallbackDelayMs=DelayProfile.DEFAULT_MS;
    private static volatile long adaptiveMs=DelayProfile.DEFAULT_MS;
    private static volatile long lastRequestFinishedAt;
    private static volatile long lastUserDelay=DelayProfile.DEFAULT_MS;
    private static int failures;
    private static DeadlineStore store;
    private static DelayProvider delayProvider;
    private GentleServerGate(){}

    public static synchronized void configure(long delay,String saved,DeadlineStore target){configure(delay,saved,target,null);}
    public static synchronized void configure(long delay,String saved,DeadlineStore target,DelayProvider provider){
        fallbackDelayMs=DelayProfile.clamp(delay); lastUserDelay=fallbackDelayMs; adaptiveMs=fallbackDelayMs;
        delayProvider=provider; store=target;
        try{notBefore=Math.max(notBefore,Long.parseLong(saved));}catch(Exception ignored){}
    }
    private static synchronized long userDelayMs(){
        long current=fallbackDelayMs;
        try{if(delayProvider!=null)current=DelayProfile.clamp(delayProvider.getDelayMs());}catch(Throwable ignored){}
        if(current!=lastUserDelay&&failures==0){adaptiveMs=current;lastUserDelay=current;}
        fallbackDelayMs=current; return current;
    }
    public static void begin(AuditControl control,AuditProgressListener listener)throws IOException{
        boolean acquired=false;
        try{
            while(!(acquired=LOCK.tryLock(250,TimeUnit.MILLISECONDS)))checkpoint(control);
            long previousSeconds=-1;String previousLabel="";
            while(true){
                checkpoint(control); long now=System.currentTimeMillis(); long selected=userDelayMs();
                long normalDelay; synchronized(GentleServerGate.class){normalDelay=Math.max(selected,adaptiveMs);}
                long userDeadline=lastRequestFinishedAt<=0?0:lastRequestFinishedAt+normalDelay;
                long deadline=Math.max(notBefore,userDeadline); long left=deadline-now; if(left<=0)break;
                long seconds=Math.max(1L,(left+999L)/1000L);
                boolean serverWait=notBefore>=userDeadline&&notBefore>now;
                boolean adaptiveWait=normalDelay>selected;
                String label=serverWait?"Защитная пауза Cubux: следующий запрос через "+seconds+" сек.":
                        adaptiveWait?"Защитный режим Cubux: следующий запрос через "+seconds+" сек. (выбрано "+DelayProfile.label(selected)+")":
                                DelayProfile.name(selected)+" режим: следующий запрос через "+DelayProfile.seconds(selected)+" сек.";
                if(listener!=null&&(seconds!=previousSeconds||!label.equals(previousLabel))){previousSeconds=seconds;previousLabel=label;listener.onStage(serverWait||adaptiveWait?"SERVER_COOLDOWN":"GENTLE_WAIT",label);}
                Thread.sleep(Math.min(250L,left));
            }
        }catch(Exception e){if(acquired)LOCK.unlock();if(e instanceof InterruptedException)Thread.currentThread().interrupt();throw new IOException(e.getMessage()==null?"Запрос прерван":e.getMessage(),e);}
    }
    private static void checkpoint(AuditControl control)throws Exception{if(control!=null)control.checkpoint();if(Thread.currentThread().isInterrupted())throw new InterruptedException();}
    public static synchronized long retryAfterMs(String value,long now){if(value==null)return 0;try{return Math.max(0,Math.multiplyExact(Long.parseLong(value.trim()),1000L));}catch(Exception ignored){}try{return Math.max(0,ZonedDateTime.parse(value.trim(),DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()-now);}catch(Exception ignored){return 0;}}
    public static synchronized void response(int code,String retryAfter){if(code==429||code>=500)failure();else if(code>=200&&code<300)failures=0;long wait=retryAfterMs(retryAfter,System.currentTimeMillis());if(wait>0)defer(wait);}
    public static synchronized void failure(){long[] waits={60000L,300000L,900000L,1800000L,3600000L};defer(waits[Math.min(failures++,waits.length-1)]);}
    private static void defer(long millis){long now=System.currentTimeMillis();long deadline=millis>Long.MAX_VALUE-now?Long.MAX_VALUE:now+millis;notBefore=Math.max(notBefore,deadline);if(store!=null)store.save(notBefore);}
    public static void end(long startedNanos,long requestedDelay){try{synchronized(GentleServerGate.class){long selected=userDelayMs();long elapsed=TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-startedNanos);adaptiveMs=elapsed>=10000L?Math.min(DelayProfile.MAX_MS,Math.max(selected,Math.max(adaptiveMs,selected)*2L)):Math.max(selected,adaptiveMs-DelayProfile.STEP_MS);lastRequestFinishedAt=System.currentTimeMillis();}}finally{LOCK.unlock();}}
}
