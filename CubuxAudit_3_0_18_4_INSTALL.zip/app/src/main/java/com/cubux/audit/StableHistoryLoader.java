package com.cubux.audit;

import android.content.Context;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Loads only closed history and proves that it was stable while being scanned.
 * 3.0.4: when aggregate controls are unavailable, uses lightweight monthly
 * fingerprints first. A second full-history pass is only the emergency fallback.
 */
public final class StableHistoryLoader {
    private static final int MAX_STABILITY_RETRIES = 3;
    private static final int QUIET_WAIT_SECONDS = 5;

    private final Context context;
    private final AuditDb db;
    private final CubuxClient client;
    private final String teamId;
    private final AuditProgressListener listener;
    private final AuditControl control;
    private final int requestAttempts;
    private LightCheckEngine.ControlSnapshot stableControl;
    private MonthlyHistoryProbe.Snapshot stableMonthlyControl;

    public StableHistoryLoader(Context context, AuditDb db, CubuxClient client, String teamId,
                               AuditProgressListener listener, AuditControl control, int requestAttempts) {
        this.context=context.getApplicationContext();
        this.db=db; this.client=client; this.teamId=teamId; this.listener=listener;
        this.control=control; this.requestAttempts=requestAttempts;
    }

    public CubuxLoader.Result load(String from,String to) throws Exception {
        db.saveState("yesterday_changed_during_scan","0");
        LightCheckEngine guard=new LightCheckEngine(context,db,client,teamId,listener,control,requestAttempts);
        MonthlyHistoryProbe monthly=new MonthlyHistoryProbe(context,db,client,teamId,listener,control,requestAttempts);

        stage("STABILITY_START","Подготавливаю контроль стабильности закрытой истории...");
        LightCheckEngine.ControlSnapshot before=guard.captureControl(from,to);
        MonthlyHistoryProbe.Snapshot monthlyBefore=null;
        if(before==null){
            if(from==null){
                stage("MONTHLY_CONTROL_START","Первая полная проверка: дата начала истории пока неизвестна. После основного чтения сверю месячные отпечатки с загруженным эталоном — второго полного прохода не будет.");
            } else {
                stage("MONTHLY_CONTROL_START","Быстрый агрегат Cubux недоступен. Фиксирую лёгкие контрольные отпечатки по месяцам вместо второго полного скана.");
                try{ monthlyBefore=monthly.capture(from,to); }
                catch(Exception e){DiagnosticLog.error(context,"MONTHLY_CONTROL_BEFORE",e);monthlyBefore=null;}
            }
        }

        CubuxLoader.Result master=new CubuxLoader(client,teamId,from,to,listener,control,requestAttempts).loadAll();
        stage("READ_COMPLETE","Основное чтение завершено: получено "+master.totalCount+" операций, "+master.pageCount+" страниц. Проверяю стабильность закрытой истории...");

        if(before==null){
            if(monthlyBefore==null && from==null){
                String learned=earliestDate(master.items);
                if(learned!=null){
                    stage("MONTHLY_CONTROL_VERIFY","Первая загрузка завершена. Сверяю месячные отпечатки Cubux с только что загруженным эталоном...");
                    try{
                        MonthlyHistoryProbe.Snapshot afterFirst=monthly.capture(learned,to);
                        if(monthly.matchesLoadedItems(afterFirst,master.items)){
                            stableMonthlyControl=afterFirst;
                            stage("STABILITY_OK","Первая история подтверждена месячным контролем. Второй полный проход не требуется.");
                            return master;
                        }
                    }catch(Exception e){DiagnosticLog.error(context,"MONTHLY_FIRST_VERIFY",e);}
                }
                stage("STABILITY_EMERGENCY","Не удалось безопасно подтвердить первую историю месячным контролем. Включаю аварийный второй полный проход.");
                return fallbackDoubleRead(master,from,to);
            }
            if(monthlyBefore==null){
                stage("STABILITY_EMERGENCY","Не удалось получить даже месячные контрольные отпечатки. Только в этом случае включаю аварийный второй полный проход.");
                return fallbackDoubleRead(master,from,to);
            }
            return verifyWithMonthlyProbe(master,from,to,monthly,monthlyBefore);
        }

        stage("STABILITY_VERIFY","Проверяю, не менялась ли закрытая история во время сканирования...");
        LightCheckEngine.ControlSnapshot after=guard.captureControl(from,to);
        if(LightCheckEngine.sameControl(before,after)){
            stableControl=after;
            stage("STABILITY_OK","Контроль стабильности завершён: закрытая история не менялась во время сканирования.");
            return master;
        }

        for(int attempt=1;attempt<=MAX_STABILITY_RETRIES;attempt++){
            checkpoint();
            if(after==null){
                stage("MONTHLY_CONTROL_SWITCH","Агрегат Cubux перестал отвечать. Перехожу на контроль по месяцам без второго полного скана.");
                MonthlyHistoryProbe.Snapshot mb=monthly.capture(from,to);
                return verifyWithMonthlyProbe(master,from,to,monthly,mb);
            }
            boolean candidateUpdated=false;
            Set<String> months=LightCheckEngine.changedMonths(before,after);
            if(!months.isEmpty()){
                String first=Collections.min(months)+"-01";
                String last=MonthlyHistoryProbe.monthEnd(Collections.max(months));
                if(from!=null&&first.compareTo(from)<0)first=from;
                if(to!=null&&last.compareTo(to)>0)last=to;
                stage("HISTORY_MOVED","Закрытая история изменилась во время проверки. Повторю только период "+first+" — "+last+" ("+attempt+"/"+MAX_STABILITY_RETRIES+").");
                quietWait("Жду окончания редактирования изменённого периода");

                LightCheckEngine.ControlSnapshot patchBefore=guard.captureControl(first,last);
                stage("HISTORY_RESCAN","Повторно читаю только изменённый период "+first+" — "+last+". Остальная история повторно не загружается.");
                CubuxLoader.Result patch=new CubuxLoader(client,teamId,first,last,listener,control,requestAttempts).loadAll();
                LightCheckEngine.ControlSnapshot patchAfter=guard.captureControl(first,last);
                if(patchBefore!=null&&patchAfter!=null&&LightCheckEngine.sameControl(patchBefore,patchAfter)){
                    markYesterdayChanged(master,patch,to,first,last);
                    master=merge(master,patch,first,last);candidateUpdated=true;
                }else DiagnosticLog.write(context,"STABILITY","Изменённый период продолжал меняться; повтор не принят");
            }else{
                stage("MONTHLY_CONTROL_SWITCH","Общий отпечаток изменился, но агрегат не локализовал месяц. Перехожу к месячному контролю вместо полного повторного скана.");
                MonthlyHistoryProbe.Snapshot mb=monthly.capture(from,to);
                return verifyWithMonthlyProbe(master,from,to,monthly,mb);
            }

            LightCheckEngine.ControlSnapshot current=guard.captureControl(from,to);
            if(candidateUpdated&&current!=null&&LightCheckEngine.sameControl(after,current)){
                stableControl=current;
                stage("STABILITY_OK","История стабильна. Изменённый период перечитан; полный второй проход не потребовался.");
                return master;
            }
            before=after;after=current;
        }
        throw new Exception("Данные Cubux продолжают изменяться во время проверки. Ничего не сохранено; повторите проверку позже.");
    }

    private CubuxLoader.Result verifyWithMonthlyProbe(CubuxLoader.Result master,String from,String to,
                                                       MonthlyHistoryProbe monthly,MonthlyHistoryProbe.Snapshot before) throws Exception {
        stage("MONTHLY_CONTROL_VERIFY","Основная загрузка завершена. Сверяю лёгкие отпечатки по месяцам; повторно читать всю историю не нужно.");
        MonthlyHistoryProbe.Snapshot after;
        try{after=monthly.capture(from,to);}catch(Exception e){
            DiagnosticLog.error(context,"MONTHLY_CONTROL_AFTER",e);
            stage("STABILITY_EMERGENCY","Месячный контроль недоступен. Включаю аварийный второй полный проход, чтобы не сохранять непроверенный эталон.");
            return fallbackDoubleRead(master,from,to);
        }
        if(MonthlyHistoryProbe.same(before,after)){
            stableMonthlyControl=after;
            stage("STABILITY_OK","Контроль по месяцам совпал. История стабильна; второй полный проход не требуется.");
            return master;
        }

        for(int attempt=1;attempt<=MAX_STABILITY_RETRIES;attempt++){
            checkpoint();
            Set<String> changed=MonthlyHistoryProbe.changedMonths(before,after);
            if(changed.isEmpty()){
                stage("STABILITY_EMERGENCY","Месячные отпечатки различаются, но период не локализован. Включаю аварийный полный контроль.");
                return fallbackDoubleRead(master,from,to);
            }
            String first=Collections.min(changed)+"-01";
            String last=MonthlyHistoryProbe.monthEnd(Collections.max(changed));
            if(from!=null&&first.compareTo(from)<0)first=from;
            if(to!=null&&last.compareTo(to)>0)last=to;
            stage("HISTORY_MOVED","Месячный контроль обнаружил изменение в периоде "+first+" — "+last+". Повторяю только этот период ("+attempt+"/"+MAX_STABILITY_RETRIES+").");
            quietWait("Жду окончания редактирования изменённого периода");

            MonthlyHistoryProbe.Snapshot patchBefore=monthly.capture(first,last);
            stage("HISTORY_RESCAN","Повторно читаю изменённый период "+first+" — "+last+". Остальные месяцы не загружаются.");
            CubuxLoader.Result patch=new CubuxLoader(client,teamId,first,last,listener,control,requestAttempts).loadAll();
            MonthlyHistoryProbe.Snapshot patchAfter=monthly.capture(first,last);
            boolean candidateUpdated=false;
            if(MonthlyHistoryProbe.same(patchBefore,patchAfter)){
                markYesterdayChanged(master,patch,to,first,last);
                master=merge(master,patch,first,last);candidateUpdated=true;
            }
            MonthlyHistoryProbe.Snapshot current=monthly.capture(from,to);
            if(candidateUpdated&&MonthlyHistoryProbe.same(after,current)){
                stableMonthlyControl=current;
                stage("STABILITY_OK","Изменённый период стабилен. Полный второй проход истории не потребовался.");
                return master;
            }
            before=after;after=current;
        }
        throw new Exception("Данные Cubux продолжают изменяться во время проверки. Ничего не сохранено; повторите проверку позже.");
    }


    private void markYesterdayChanged(CubuxLoader.Result before,CubuxLoader.Result patch,String yesterday,String from,String to){
        try{if(yesterday!=null&&from!=null&&to!=null&&yesterday.compareTo(from)>=0&&yesterday.compareTo(to)<=0&&!dayHash(before.items,yesterday).equals(dayHash(patch.items,yesterday))){db.saveState("yesterday_changed_during_scan","1");DiagnosticLog.write(context,"YESTERDAY_CHANGED","Данные вчерашнего дня менялись во время проверки: "+yesterday);}}catch(Exception e){DiagnosticLog.error(context,"YESTERDAY_GUARD",e);}
    }
    private String dayHash(List<JSONObject> items,String day)throws Exception{
        List<String> rows=new ArrayList<>();for(JSONObject x:items){String d=date(x);if(day!=null&&day.equals(d))rows.add(AuditEngine.normalizeRecord(x).toString());}Collections.sort(rows);StringBuilder b=new StringBuilder();for(String x:rows)b.append(x).append('\n');return HashUtil.sha256(b.toString());
    }

    public LightCheckEngine.ControlSnapshot getStableControl(){return stableControl;}
    public MonthlyHistoryProbe.Snapshot getStableMonthlyControl(){return stableMonthlyControl;}

    private CubuxLoader.Result fallbackDoubleRead(CubuxLoader.Result first,String from,String to) throws Exception {
        stableControl=null;stableMonthlyControl=null;
        CubuxLoader.Result previous=first;String previousHash=itemsHash(previous.items);
        for(int attempt=1;attempt<=MAX_STABILITY_RETRIES;attempt++){
            stage("STABILITY_FALLBACK","Аварийный контроль: подготавливаю полный повторный проход "+attempt+" из "+MAX_STABILITY_RETRIES+"...");
            quietWait("Жду перед аварийным контрольным проходом");
            stage("STABILITY_FALLBACK_SCAN","Аварийный полный контроль, проход "+attempt+" из "+MAX_STABILITY_RETRIES+". Используется только когда быстрые и месячные проверки недоступны.");
            CubuxLoader.Result current=new CubuxLoader(client,teamId,from,to,listener,control,requestAttempts).loadAll();
            String currentHash=itemsHash(current.items);
            if(!dayHash(previous.items,to).equals(dayHash(current.items,to))) db.saveState("yesterday_changed_during_scan","1");
            if(previous.totalCount==current.totalCount&&previousHash.equals(currentHash)){
                stage("STABILITY_OK","Аварийный контроль совпал. История стабильна.");return current;
            }
            previous=current;previousHash=currentHash;
        }
        throw new Exception("Данные Cubux продолжают изменяться во время проверки. Ничего не сохранено; повторите проверку позже.");
    }

    private CubuxLoader.Result merge(CubuxLoader.Result master,CubuxLoader.Result patch,String from,String to){
        List<JSONObject> out=new ArrayList<>();
        for(JSONObject x:master.items){String d=date(x);if(d==null||d.compareTo(from)<0||d.compareTo(to)>0)out.add(x);}
        out.addAll(patch.items);
        return new CubuxLoader.Result(out.size(),master.pageCount,out);
    }

    private String itemsHash(List<JSONObject> items)throws Exception{
        List<String> rows=new ArrayList<>();for(JSONObject x:items)rows.add(AuditEngine.normalizeRecord(x).toString());
        Collections.sort(rows);StringBuilder b=new StringBuilder();for(String x:rows)b.append(x).append('\n');return HashUtil.sha256(b.toString());
    }

    private String earliestDate(List<JSONObject> items){
        String min=null;
        for(JSONObject o:items){String d=date(o);if(d!=null&&(min==null||d.compareTo(min)<0))min=d;}
        return min;
    }

    private String date(JSONObject o){String d=o.optString("date","");return d.length()>=10?d.substring(0,10):null;}

    private void quietWait(String reason) throws Exception{
        for(int left=QUIET_WAIT_SECONDS;left>0;left--){checkpoint();stage("STABILITY_WAIT",reason+": "+left+" сек...");Thread.sleep(1000L);}
    }

    private void stage(String s,String m){CheckStatusStore.activity(context,m);if(listener!=null)listener.onStage(s,m);}
    private void checkpoint() throws AuditControl.AuditStoppedException {if(control!=null)control.checkpoint();}
}
