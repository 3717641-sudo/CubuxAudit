package com.cubux.audit;

import android.content.Context;
import org.json.JSONObject;
import java.util.List;

/** One source of truth for the first date available in Cubux. */
public final class HistoryRange {
    private static final String KEY = "cubux_history_start_date";
    private final AuditDb db;

    public HistoryRange(Context c) { db = new AuditDb(c.getApplicationContext()); }
    public HistoryRange(AuditDb db) { this.db = db; }

    public String startDate() {
        String v = db.getState(KEY);
        return valid(v) ? v.substring(0,10) : null;
    }

    /** Called after a successful full read. The earliest ever Cubux date is retained. */
    public String learnFrom(List<JSONObject> items) {
        String earliest = null;
        if (items != null) {
            for (JSONObject o : items) {
                String d = date(o);
                if (d != null && (earliest == null || d.compareTo(earliest) < 0)) earliest = d;
            }
        }
        if (earliest == null) return startDate();
        String old = startDate();
        if (old == null || earliest.compareTo(old) < 0) db.saveState(KEY, earliest);
        return old == null || earliest.compareTo(old) < 0 ? earliest : old;
    }

    public static String earliest(List<JSONObject> items) {
        String x = null;
        if (items == null) return null;
        for (JSONObject o : items) {
            String d = date(o);
            if (d != null && (x == null || d.compareTo(x) < 0)) x = d;
        }
        return x;
    }

    private static String date(JSONObject o) {
        if (o == null) return null;
        String d = o.optString("date", "");
        return valid(d) ? d.substring(0,10) : null;
    }
    private static boolean valid(String d) {
        return d != null && d.length() >= 10 && d.charAt(4) == '-' && d.charAt(7) == '-';
    }
}
