package com.cubux.audit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ScheduledAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String type=intent==null?CheckSettings.TYPE_LIGHT:intent.getStringExtra("check_type");
        int attempt=intent==null?0:intent.getIntExtra("attempt",0);
        boolean retry=intent!=null&&intent.getBooleanExtra("retry",false);
        if(type==null)type=CheckSettings.TYPE_LIGHT;
        DiagnosticLog.write(context,"ALARM","Точный будильник сработал. Тип="+type+", retry="+retry+", attempt="+attempt);
        AuditForegroundService.startScheduled(context,type,attempt,retry);
    }
}
