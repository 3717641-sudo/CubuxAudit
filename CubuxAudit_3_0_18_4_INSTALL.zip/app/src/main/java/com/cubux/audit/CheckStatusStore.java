package com.cubux.audit;

import android.content.Context;

public final class CheckStatusStore {
    private CheckStatusStore() {}

    public static void running(Context c, String type) {
        AuditDb db = new AuditDb(c);
        db.saveState("last_check_state", "RUNNING");
        db.saveState("last_check_type", type);
        db.saveState("last_check_message", "Проверка выполняется...");
        db.saveState("last_check_activity", TimeUtil.now());
        db.appEvent("INFO", "ПРОВЕРКА", type + " началась");
    }

    public static void success(Context c, String type, AuditEngine.Result r) {
        AuditDb db = new AuditDb(c);
        db.saveState("last_check_state", "OK");
        db.saveState("last_check_type", type);
        db.saveState("last_check_time", TimeUtil.now());
        db.saveState("last_check_new", String.valueOf(r.newCount));
        db.saveState("last_check_changed", String.valueOf(r.changedCount));
        db.saveState("last_check_deleted", String.valueOf(r.deletedCount));
        db.saveState("last_check_total", String.valueOf(r.total));
        db.saveState("last_check_attempts", "0");
        db.saveState("missed_check_pending", "0");
        int changes = r.newCount + r.changedCount + r.deletedCount;
        String message = changes == 0
                ? "Проверка прошла успешно. Всё хорошо, изменений записей нет."
                : "Проверка завершена успешно, но есть изменения записей — смотрите журнал.";
        db.saveState("last_check_message", message);
        db.saveState("last_check_activity", TimeUtil.now());
        if (r.changedCount > 0 || r.deletedCount > 0) {
            db.appEvent("WARNING", "ПРОВЕРКА", type + " завершена: новые " + r.newCount
                    + ", изменённые " + r.changedCount + ", удалённые " + r.deletedCount,
                    "CHECKS", "JOURNAL", true);
        } else if (r.newCount > 0) {
            db.appEvent("INFO", "ПРОВЕРКА", type + " завершена: найдено новых записей " + r.newCount,
                    "CHECKS", "JOURNAL", true);
        } else {
            db.appEvent("OK", "ПРОВЕРКА", type + " завершена. Данные не изменились",
                    "CHECKS", "CHECKS", true);
        }
    }

    public static void failure(Context c, String type, int attempts, String reason) {
        AuditDb db = new AuditDb(c);
        db.saveState("last_check_state", "ERROR");
        db.saveState("last_check_type", type);
        db.saveState("last_check_attempts", String.valueOf(Math.max(1, attempts)));
        String message = "Проверку выполнить не удалось. Сделано "
                + Math.max(1, attempts) + " попыток."
                + (reason == null || reason.trim().isEmpty() ? "" : " Причина: " + reason);
        db.saveState("last_check_message", message);
        db.saveState("last_check_activity", TimeUtil.now());
        db.appEvent("ERROR", "ПРОВЕРКА", type + ": " + message,
                "CHECKS", "CHECKS", true);
    }

    public static void activity(Context c, String message) {
        AuditDb db = new AuditDb(c);
        db.saveState("last_check_activity", TimeUtil.now());
        if (message != null && !message.isEmpty()) db.saveState("current_check_status", message);
    }

    public static void event(Context c, String level, String source, String message) {
        new AuditDb(c).appEvent(level, source, message);
    }
}
