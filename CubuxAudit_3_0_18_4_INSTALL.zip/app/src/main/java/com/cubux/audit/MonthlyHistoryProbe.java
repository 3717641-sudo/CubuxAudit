package com.cubux.audit;

import android.content.Context;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Lightweight fallback when Cubux aggregate endpoints are unavailable.
 * It fingerprints each month using transaction count plus first/middle/last page samples.
 * This is much lighter than re-reading the whole history a second time and can localize
 * a moving period so only that month needs a deep re-read.
 */
public final class MonthlyHistoryProbe {
    public static final class Snapshot {
        public final Map<String,String> signatures = new TreeMap<>();
        public final Map<String,Integer> counts = new TreeMap<>();
        public final Map<String,String> sampleRecords = new HashMap<>();

        public boolean isEmpty(){ return signatures.isEmpty(); }

        public String toJson(){
            try{
                JSONObject root=new JSONObject();
                root.put("signatures",new JSONObject(signatures));
                root.put("counts",new JSONObject(counts));
                root.put("samples",new JSONObject(sampleRecords));
                return root.toString();
            }catch(Exception e){ return "{}"; }
        }

        public static Snapshot fromJson(String text){
            Snapshot s=new Snapshot();
            try{
                JSONObject root=new JSONObject(text==null||text.isEmpty()?"{}":text);
                JSONObject sig=root.optJSONObject("signatures");
                if(sig!=null){Iterator<String>it=sig.keys();while(it.hasNext()){String k=it.next();s.signatures.put(k,sig.optString(k,""));}}
                JSONObject cnt=root.optJSONObject("counts");
                if(cnt!=null){Iterator<String>it=cnt.keys();while(it.hasNext()){String k=it.next();s.counts.put(k,cnt.optInt(k,0));}}
                JSONObject smp=root.optJSONObject("samples");
                if(smp!=null){Iterator<String>it=smp.keys();while(it.hasNext()){String k=it.next();s.sampleRecords.put(k,smp.optString(k,""));}}
            }catch(Exception ignored){}
            return s;
        }
    }

    private final Context context;
    private final AuditDb db;
    private final CubuxClient client;
    private final String teamId;
    private final AuditProgressListener listener;
    private final AuditControl control;
    private final int attempts;

    public MonthlyHistoryProbe(Context context, AuditDb db, CubuxClient client, String teamId,
                               AuditProgressListener listener, AuditControl control, int attempts){
        this.context=context.getApplicationContext();this.db=db;this.client=client;this.teamId=teamId;
        this.listener=listener;this.control=control;this.attempts=Math.max(1,Math.min(10,attempts));
    }

    public Snapshot capture(String from,String to) throws Exception {
        Snapshot out=new Snapshot();
        List<String> months=months(from,to);
        int n=months.size();
        for(int i=0;i<n;i++){
            checkpoint();
            String ym=months.get(i);
            String a=ym+"-01", b=monthEnd(ym);
            if(from!=null&&a.compareTo(from)<0)a=from;
            if(to!=null&&b.compareTo(to)>0)b=to;
            if(i==0 || i==n-1 || i%5==0) stage("MONTHLY_CONTROL","Контроль по месяцам: "+(i+1)+" из "+n+" • "+ym+". Полная история повторно не загружается.");
            CubuxLoader.Probe p=new CubuxLoader(client,teamId,a,b,listener,control,attempts).loadProbeSignature();
            out.signatures.put(ym,p.signature);
            out.counts.put(ym,p.totalCount);
            out.sampleRecords.putAll(p.sampleRecords);
        }
        return out;
    }

    public static boolean same(Snapshot a,Snapshot b){
        return a!=null&&b!=null&&a.signatures.equals(b.signatures);
    }

    public static Set<String> changedMonths(Snapshot a,Snapshot b){
        Set<String> out=new TreeSet<>();
        if(a==null||b==null)return out;
        Set<String> keys=new TreeSet<>();keys.addAll(a.signatures.keySet());keys.addAll(b.signatures.keySet());
        for(String k:keys)if(!Objects.equals(a.signatures.get(k),b.signatures.get(k)))out.add(k);
        return out;
    }

    /** Migration path after app update: no full re-download if month counts and sampled records match local baseline. */
    public boolean matchesLocalBaseline(Snapshot remote){
        try{
            Map<String,String> local=db.transactions();
            Map<String,Integer> counts=new TreeMap<>();
            Map<String,String> hashes=new HashMap<>();
            for(Map.Entry<String,String>e:local.entrySet()){
                JSONObject o=new JSONObject(e.getValue());
                String d=o.optString("date","");
                if(d.length()>=7){String ym=d.substring(0,7);counts.put(ym,counts.getOrDefault(ym,0)+1);}
                hashes.put(e.getKey(),HashUtil.sha256(o.toString()));
            }
            return mismatches(remote,counts,hashes).isEmpty();
        }catch(Exception e){DiagnosticLog.error(context,"MONTHLY_MIGRATION",e);return false;}
    }

    /** Used by the very first full scan when the historical start date was unknown before reading. */
    public boolean matchesLoadedItems(Snapshot remote,List<JSONObject> items){
        return mismatchedMonthsAgainstItems(remote,items).isEmpty();
    }

    public Set<String> mismatchedMonthsAgainstItems(Snapshot remote,List<JSONObject> items){
        Set<String> failed=new TreeSet<>();
        try{
            Map<String,Integer> counts=new TreeMap<>();
            Map<String,String> hashes=new HashMap<>();
            for(JSONObject raw:items){
                JSONObject o=AuditEngine.normalizeRecord(raw);
                String d=o.optString("date","");
                if(d.length()>=7){String ym=d.substring(0,7);counts.put(ym,counts.getOrDefault(ym,0)+1);}
                Object id=o.opt("id");if(id!=null)hashes.put(String.valueOf(id),HashUtil.sha256(o.toString()));
            }
            failed.addAll(mismatches(remote,counts,hashes));
        }catch(Exception e){DiagnosticLog.error(context,"MONTHLY_LOADED_COMPARE",e);failed.addAll(remote.signatures.keySet());}
        return failed;
    }

    private Set<String> mismatches(Snapshot remote,Map<String,Integer> counts,Map<String,String> hashes){
        Set<String> failed=new TreeSet<>();
        for(Map.Entry<String,Integer>e:remote.counts.entrySet())
            if(localMonthCount(counts,e.getKey())!=e.getValue())failed.add(e.getKey());
        for(Map.Entry<String,Integer>e:counts.entrySet())
            if(!remote.counts.containsKey(e.getKey())&&e.getValue()>0)failed.add(e.getKey());
        for(Map.Entry<String,String>e:remote.sampleRecords.entrySet()){
            String lh=hashes.get(e.getKey());
            if(lh==null||!lh.equals(e.getValue())){
                // The id itself does not encode the month. Mark all remote months conservatively when sample mapping is ambiguous.
                failed.addAll(remote.signatures.keySet());
                break;
            }
        }
        return failed;
    }

    private int localMonthCount(Map<String,Integer>m,String k){Integer x=m.get(k);return x==null?0:x;}

    private List<String> months(String from,String to) throws Exception {
        String f=(from==null||from.length()<7)?to.substring(0,7):from.substring(0,7);
        String t=to.substring(0,7);
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        Calendar c=Calendar.getInstance();c.setTime(fmt.parse(f+"-01"));
        Date end=fmt.parse(t+"-01");
        List<String> out=new ArrayList<>();
        SimpleDateFormat mf=new SimpleDateFormat("yyyy-MM",Locale.US);
        while(!c.getTime().after(end)){out.add(mf.format(c.getTime()));c.add(Calendar.MONTH,1);}
        return out;
    }

    public static String monthEnd(String ym){
        try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);Calendar c=Calendar.getInstance();c.setTime(f.parse(ym+"-01"));c.set(Calendar.DAY_OF_MONTH,c.getActualMaximum(Calendar.DAY_OF_MONTH));return f.format(c.getTime());}
        catch(Exception e){return ym+"-31";}
    }

    private void checkpoint() throws AuditControl.AuditStoppedException {if(control!=null)control.checkpoint();}
    private void stage(String s,String m){CheckStatusStore.activity(context,m);if(listener!=null)listener.onStage(s,m);}
}
