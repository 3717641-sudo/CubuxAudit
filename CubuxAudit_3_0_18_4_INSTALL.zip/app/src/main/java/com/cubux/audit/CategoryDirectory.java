package com.cubux.audit;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Locale;

/**
 * Read-only Cubux category directory.  It caches the semantic category direction
 * (income/expense) outside transaction JSON so adding this feature never changes
 * transaction fingerprints or creates false CHANGED events.
 */
public final class CategoryDirectory {
    private final AuditDb db;
    private final CubuxClient client;
    private final String teamId;

    public CategoryDirectory(AuditDb db, CubuxClient client, String teamId) {
        this.db = db;
        this.client = client;
        this.teamId = teamId;
    }

    public void refresh() {
        Throwable last = null;
        String[] urls = {
                "https://app.cubux.net/api/v1/category-read/team/" + enc(teamId),
                "https://app.cubux.net/api/v1/category-read/team/" + enc(teamId) + "/"
        };
        for (String url : urls) {
            try {
                String body = client.get(url);
                int n = parseAndSave(body);
                if (n > 0) {
                    db.saveState("category_directory_updated", TimeUtil.now());
                    db.saveState("category_directory_count", String.valueOf(n));
                    return;
                }
            } catch (Throwable e) {
                last = e;
            }
        }
        if (last != null) throw new RuntimeException(last);
    }

    private int parseAndSave(String body) throws Exception {
        String t = body == null ? "" : body.trim();
        int[] n = {0};
        if (t.startsWith("[")) walk(new JSONArray(t), "", n);
        else if (t.startsWith("{")) walk(new JSONObject(t), "", n);
        return n[0];
    }

    private void walk(Object node, String inheritedType, int[] n) {
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                Object v = a.opt(i);
                if (v instanceof JSONObject || v instanceof JSONArray) walk(v, inheritedType, n);
            }
            return;
        }
        if (!(node instanceof JSONObject)) return;

        JSONObject o = (JSONObject) node;
        String type = categoryType(o);
        if (type.isEmpty()) type = inheritedType;

        String id = first(o, "id", "uuid", "category_id", "category_uuid");
        String name = first(o, "name", "title", "label");
        if (!type.isEmpty()) {
            if (!id.isEmpty()) {
                db.saveState("category_type:" + id, type);
                n[0]++;
            }
            if (!name.isEmpty()) db.saveState("category_type_name:" + norm(name), type);
        }
        if (!id.isEmpty() && !name.isEmpty()) db.saveState("category_name:" + id, name);

        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String key = it.next();
            Object v = o.opt(key);
            if (!(v instanceof JSONObject) && !(v instanceof JSONArray)) continue;
            String childType = type;
            String fromKey = typeFromText(key);
            if (!fromKey.isEmpty()) childType = fromKey;
            walk(v, childType, n);
        }
    }

    private String categoryType(JSONObject o) {
        String[] keys = {"operation_type", "payment_type", "category_type", "direction", "flow_type", "flow", "kind", "type"};
        for (String k : keys) {
            String t = typeFromText(first(o, k));
            if (!t.isEmpty()) return t;
        }

        if (truthy(o, "is_expense", "isExpense", "expense_category", "expenseCategory")) return "Расход";
        if (truthy(o, "is_income", "isIncome", "income_category", "incomeCategory")) return "Доход";

        // Some Cubux category payloads group categories below named parent nodes.
        // Only use the object's own name as a direction when it is itself a group/container.
        boolean hasChildren = o.opt("children") instanceof JSONArray || o.opt("items") instanceof JSONArray ||
                o.opt("categories") instanceof JSONArray || o.opt("child") instanceof JSONArray;
        if (hasChildren) {
            String t = typeFromText(first(o, "name", "title", "label"));
            if (!t.isEmpty()) return t;
        }
        return "";
    }

    static String typeFromText(String raw) {
        if (raw == null) return "";
        String t = raw.trim().toLowerCase(Locale.ROOT);
        if (t.isEmpty()) return "";
        if (t.contains("expense") || t.contains("outcome") || t.contains("outgoing") ||
                t.contains("spend") || t.contains("расход") || t.equals("out")) return "Расход";
        if (t.contains("income") || t.contains("incoming") || t.contains("revenue") ||
                t.contains("приход") || t.contains("доход") || t.equals("in")) return "Доход";
        if (t.contains("transfer") || t.contains("перевод")) return "Перевод";
        // Deliberately do NOT interpret bare numeric values like 1/2 here.
        // Cubux uses numeric "type" fields for multiple unrelated concepts.
        return "";
    }

    private boolean truthy(JSONObject o, String... keys) {
        for (String k : keys) {
            Object v = o.opt(k);
            if (v == null || v == JSONObject.NULL) continue;
            if (v instanceof Boolean && (Boolean) v) return true;
            String s = String.valueOf(v).trim().toLowerCase(Locale.ROOT);
            if (s.equals("true") || s.equals("yes") || s.equals("1")) return true;
        }
        return false;
    }

    private String first(JSONObject o, String... keys) {
        for (String k : keys) {
            Object v = o.opt(k);
            if (v != null && v != JSONObject.NULL) {
                String x = String.valueOf(v).trim();
                if (!x.isEmpty() && !"null".equalsIgnoreCase(x)) return x;
            }
        }
        return "";
    }

    private String norm(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private String enc(String s) {
        try { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); }
        catch (Exception e) { return s == null ? "" : s; }
    }
}
