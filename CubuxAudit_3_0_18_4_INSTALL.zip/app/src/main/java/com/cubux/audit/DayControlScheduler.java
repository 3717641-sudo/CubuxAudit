package com.cubux.audit;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Independent current-day observer. It does not touch the closed-day audit schedule.
 * Runs at 00:30, 01:30 ... 23:30 and once more at 23:59 local time.
 */
public final class DayControlScheduler {
    public static final int ALARM_CODE = 3180;
    private DayControlScheduler() {}

    public static final class Next {
        public final long whenMs;
        public final String day;
        public final boolean finalScan;
        Next(long whenMs, String day, boolean finalScan) {
            this.whenMs = whenMs;
            this.day = day;
            this.finalScan = finalScan;
        }
    }

    public static Next calculateNext(long nowMs) {
        Calendar now = Calendar.getInstance();
        now.setTimeInMillis(nowMs);
        Calendar candidate = (Calendar) now.clone();
        candidate.set(Calendar.SECOND, 0);
        candidate.set(Calendar.MILLISECOND, 0);

        int hour = now.get(Calendar.HOUR_OF_DAY);
        int minute = now.get(Calendar.MINUTE);
        boolean finalScan = false;

        if (hour < 23) {
            if (minute < 30) {
                candidate.set(Calendar.MINUTE, 30);
            } else {
                candidate.add(Calendar.HOUR_OF_DAY, 1);
                candidate.set(Calendar.MINUTE, 30);
            }
        } else {
            if (minute < 30) {
                candidate.set(Calendar.MINUTE, 30);
            } else if (minute < 59) {
                candidate.set(Calendar.MINUTE, 59);
                finalScan = true;
            } else {
                candidate.add(Calendar.DAY_OF_YEAR, 1);
                candidate.set(Calendar.HOUR_OF_DAY, 0);
                candidate.set(Calendar.MINUTE, 30);
            }
        }

        if (candidate.getTimeInMillis() <= nowMs) {
            candidate.add(Calendar.DAY_OF_YEAR, 1);
            candidate.set(Calendar.HOUR_OF_DAY, 0);
            candidate.set(Calendar.MINUTE, 30);
            finalScan = false;
        }

        String day = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(candidate.getTime());
        return new Next(candidate.getTimeInMillis(), day, finalScan);
    }

    private static PendingIntent pending(Context c, long whenMs, String day, boolean finalScan) {
        Intent i = new Intent(c, DayControlAlarmReceiver.class)
                .setAction("com.cubux.audit.DAY_CONTROL")
                .putExtra("scan_day", day)
                .putExtra("final_scan", finalScan)
                .putExtra("scheduled_for", whenMs);
        return PendingIntent.getBroadcast(c, ALARM_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static boolean scheduleNext(Context c) {
        Next next = calculateNext(System.currentTimeMillis());
        return schedule(c, next);
    }

    private static boolean schedule(Context c, Next next) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return false;
            PendingIntent pi = pending(c, next.whenMs, next.day, next.finalScan);
            am.cancel(pi);
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.whenMs, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.whenMs, pi);
            }
            AuditDb db = new AuditDb(c);
            db.saveState("day_control_next_ms", String.valueOf(next.whenMs));
            db.saveState("day_control_next_day", next.day);
            db.saveState("day_control_next_final", next.finalScan ? "1" : "0");
            return true;
        } catch (Throwable e) {
            DiagnosticLog.error(c, "DAY_CONTROL_SCHEDULE", e);
            return false;
        }
    }
}
