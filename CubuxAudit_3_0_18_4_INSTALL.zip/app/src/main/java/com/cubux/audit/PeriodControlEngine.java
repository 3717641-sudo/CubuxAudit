package com.cubux.audit;

import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Builds a day-by-day control plan without mutating the database.
 * Changes are applied only after the transaction scan has been proven stable.
 */
public class PeriodControlEngine {
    private final AuditDb db;
    public PeriodControlEngine(AuditDb db) { this.db = db; }

    public Result analyze(List<JSONObject> items) throws Exception {
        return analyze(items, false, null, TimeUtil.yesterday());
    }

    public Result analyze(List<JSONObject> items, boolean partial) throws Exception {
        return analyze(items, partial, null, TimeUtil.yesterday());
    }

    public Result analyze(List<JSONObject> items, boolean partial, String fromDate) throws Exception {
        return analyze(items, partial, fromDate, TimeUtil.yesterday());
    }

    public Result analyze(List<JSONObject> items, boolean partial, String fromDate, String toDate) throws Exception {
        String cutoff = TimeUtil.yesterday();
        if (toDate == null || toDate.compareTo(cutoff) > 0) toDate = cutoff;

        Map<String, List<JSONObject>> byDate = new HashMap<>();
        String minSeen = null;
        for (JSONObject item : items) {
            String date = date(item);
            if (date == null || date.compareTo(cutoff) > 0) continue;
            byDate.computeIfAbsent(date, k -> new ArrayList<>()).add(item);
            if (minSeen == null || date.compareTo(minSeen) < 0) minSeen = date;
        }

        String start = fromDate != null ? fromDate : minSeen;
        if (start == null || toDate == null || start.compareTo(toDate) > 0) {
            return new Result(new HashSet<>(), 0, new HashSet<>(), new LinkedHashMap<>());
        }

        Set<String> detailed = new HashSet<>();
        Set<String> baselineDates = new HashSet<>();
        Map<String, SnapData> closureUpdates = new LinkedHashMap<>();
        int changed = 0;

        LocalDate day = LocalDate.parse(start);
        LocalDate end = LocalDate.parse(toDate);
        while (!day.isAfter(end)) {
            String date = day.toString();
            List<JSONObject> rows = byDate.get(date);
            if (rows == null) rows = Collections.emptyList();
            SnapData snap = snap(rows);
            AuditDb.Closure old = db.closure(date);
            if (old == null) {
                // A day that has never been protected before becomes a silent baseline.
                // This is critical after the phone has been off for several days.
                baselineDates.add(date);
                closureUpdates.put(date, snap.withStatus("CLOSED"));
            } else if (!old.hash.equals(snap.hash)) {
                detailed.add(date);
                changed++;
                closureUpdates.put(date, snap.withStatus("CHANGED"));
            }
            day = day.plusDays(1);
        }

        return new Result(detailed, changed, baselineDates, closureUpdates);
    }

    private SnapData snap(List<JSONObject> items) throws Exception {
        List<String> normalized = new ArrayList<>();
        JSONArray baseline = new JSONArray();
        double income = 0;
        double expense = 0;
        Map<String, Double> currencies = new HashMap<>();

        for (JSONObject item : items) {
            JSONObject x = AuditEngine.normalizeRecord(item);
            normalized.add(x.toString());
            baseline.put(x);
            double amount = x.optDouble("amount", 0);
            int direction = OperationTypeResolver.sign(x, db);
            if (direction > 0) income += Math.abs(amount);
            else if (direction < 0) expense += Math.abs(amount);
            String currency = x.optString("currency_code", "");
            double signedAmount = direction < 0 ? -Math.abs(amount) : direction > 0 ? Math.abs(amount) : 0.0;
            currencies.put(currency, currencies.getOrDefault(currency, 0.0) + signedAmount);
        }

        Collections.sort(normalized);
        StringBuilder source = new StringBuilder();
        for (String row : normalized) source.append(row).append('\n');

        JSONObject cur = new JSONObject();
        for (Map.Entry<String, Double> e : currencies.entrySet()) cur.put(e.getKey(), e.getValue());
        return new SnapData(items.size(), income, expense, cur.toString(),
                HashUtil.sha256(source.toString()), baseline.toString(), "CLOSED");
    }

    private String date(JSONObject o) {
        String d = o.optString("date", "");
        return d.length() >= 10 ? d.substring(0, 10) : null;
    }

    public static class SnapData {
        public final int count;
        public final double income, expense;
        public final String currencies, hash, baseline, status;
        SnapData(int count, double income, double expense, String currencies,
                 String hash, String baseline, String status) {
            this.count=count; this.income=income; this.expense=expense;
            this.currencies=currencies; this.hash=hash; this.baseline=baseline; this.status=status;
        }
        SnapData withStatus(String x) {
            return new SnapData(count,income,expense,currencies,hash,baseline,x);
        }
    }

    public static class Result {
        public final Set<String> detailedDates;
        public final int closedChangedCount;
        /** Dates never protected before this scan; events on them are absorbed into the baseline. */
        public final Set<String> baselineDates;
        /** Closure rows to write atomically together with transaction changes. */
        public final Map<String, SnapData> closureUpdates;
        Result(Set<String> detailedDates, int closedChangedCount, Set<String> baselineDates,
               Map<String, SnapData> closureUpdates) {
            this.detailedDates=detailedDates;
            this.closedChangedCount=closedChangedCount;
            this.baselineDates=baselineDates;
            this.closureUpdates=closureUpdates;
        }
    }
}
