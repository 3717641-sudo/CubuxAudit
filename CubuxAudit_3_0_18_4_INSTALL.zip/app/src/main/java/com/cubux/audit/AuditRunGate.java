package com.cubux.audit;

import java.util.concurrent.atomic.AtomicBoolean;

/** Prevents manual and background audits from running at the same time. */
public final class AuditRunGate {
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    private AuditRunGate() {}

    public static boolean tryAcquire() {
        return RUNNING.compareAndSet(false, true);
    }

    public static void release() {
        RUNNING.set(false);
    }

    public static boolean isRunning() {
        return RUNNING.get();
    }
}
