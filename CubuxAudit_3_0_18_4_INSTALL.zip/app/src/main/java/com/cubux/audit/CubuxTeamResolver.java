package com.cubux.audit;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Iterator;

/** Resolves the team id instead of hard-coding it into API requests. */
public final class CubuxTeamResolver {
    private final AuditDb db;
    private final CubuxClient client;
    public CubuxTeamResolver(Context c, CubuxClient client) {
        this.db = new AuditDb(c.getApplicationContext());
        this.client = client;
    }

    public String resolve() throws Exception {
        String saved = db.getState("cubux_team_id");
        if (saved != null && !saved.trim().isEmpty()) return saved.trim();
        String body = client.get("https://app.cubux.net/api/v1/team");
        String id = parse(body);
        if (id == null) throw new Exception("Cubux: не удалось определить команду");
        db.saveState("cubux_team_id", id);
        return id;
    }

    private String parse(String body) {
        try {
            String t=body==null?"":body.trim();
            Object root=t.startsWith("[")?new JSONArray(t):new JSONObject(t);
            return findTeamId(root,0);
        } catch (Exception ignored) { return null; }
    }

    private String findTeamId(Object node,int depth){
        if(node==null||node==JSONObject.NULL||depth>5)return null;
        if(node instanceof JSONArray){
            JSONArray a=(JSONArray)node;
            for(int i=0;i<a.length();i++){String id=findTeamId(a.opt(i),depth+1);if(id!=null)return id;}
            return null;
        }
        if(node instanceof JSONObject){
            JSONObject o=(JSONObject)node;
            // Team payloads normally expose id together with team-like fields.
            Object v=o.opt("id");
            if(v!=null&&v!=JSONObject.NULL && (o.has("title")||o.has("name")||o.has("currency")||o.has("currency_code")||depth>0)){
                String s=String.valueOf(v).trim();if(!s.isEmpty())return s;
            }
            String[] preferred={"items","teams","data","result"};
            for(String k:preferred){if(o.has(k)){String id=findTeamId(o.opt(k),depth+1);if(id!=null)return id;}}
            Iterator<String> it=o.keys();
            while(it.hasNext()){String k=it.next();String id=findTeamId(o.opt(k),depth+1);if(id!=null)return id;}
        }
        return null;
    }
}
