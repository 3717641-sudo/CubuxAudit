package com.cubux.audit;

/** Thread-safe manual audit controller used by UI, HTTP client and loader. */
public final class AuditControl {
    private final Object lock = new Object();
    private volatile boolean paused;
    private volatile boolean stopped;
    private volatile Runnable cancelAction;
    private long pauseStartedAtMs;
    private long pausedAccumulatedMs;

    public void pause() {
        synchronized (lock) {
            if (!stopped && !paused) {
                paused = true;
                pauseStartedAtMs = System.currentTimeMillis();
            }
        }
    }

    public void resume() {
        synchronized (lock) {
            if (stopped) return;
            if (paused && pauseStartedAtMs > 0L) {
                pausedAccumulatedMs += Math.max(0L, System.currentTimeMillis() - pauseStartedAtMs);
            }
            pauseStartedAtMs = 0L;
            paused = false;
            lock.notifyAll();
        }
    }

    public void stop() {
        Runnable action;
        synchronized (lock) {
            if (paused && pauseStartedAtMs > 0L) {
                pausedAccumulatedMs += Math.max(0L, System.currentTimeMillis() - pauseStartedAtMs);
            }
            pauseStartedAtMs = 0L;
            stopped = true;
            paused = false;
            action = cancelAction;
            lock.notifyAll();
        }
        if (action != null) try { action.run(); } catch (Throwable ignored) {}
    }

    public boolean isPaused() { return paused; }
    public boolean isStopped() { return stopped; }

    /** Elapsed check time excluding only a manual user pause. */
    public long activeElapsedMs(long startedWallMs) {
        synchronized (lock) {
            long pausedNow = paused && pauseStartedAtMs > 0L
                    ? Math.max(0L, System.currentTimeMillis() - pauseStartedAtMs) : 0L;
            return Math.max(0L, System.currentTimeMillis() - startedWallMs - pausedAccumulatedMs - pausedNow);
        }
    }

    public void setCancelAction(Runnable action) {
        cancelAction = action;
        if (stopped && action != null) try { action.run(); } catch (Throwable ignored) {}
    }
    public void clearCancelAction(Runnable action) { if (cancelAction == action) cancelAction = null; }

    public void checkpoint() throws AuditStoppedException {
        if (stopped) throw new AuditStoppedException();
        synchronized (lock) {
            while (paused && !stopped) {
                try { lock.wait(); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new AuditStoppedException(); }
            }
        }
        if (stopped) throw new AuditStoppedException();
    }

    public static final class AuditStoppedException extends Exception {
        public AuditStoppedException() { super("Проверка остановлена пользователем"); }
    }
}
