package com.cubux.audit;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CubuxAuthClient {

    private final Context context;
    private final long requestDelayMs;

    public CubuxAuthClient() { this(null, 5000L); }
    public CubuxAuthClient(Context context, long requestDelayMs) {
        this.context = context == null ? null : context.getApplicationContext();
        this.requestDelayMs = DelayProfile.clamp(requestDelayMs);
    }

    private void requireInternet() throws CubuxClient.NoInternetException {
        if (context != null && !NetworkUtil.hasInternet(context)) {
            throw new CubuxClient.NoInternetException("NO_INTERNET: нет подключения к интернету");
        }
    }

    private static final String BASE =
            "https://new.cubux.net";

    private static final String LOGIN_URL =
            BASE + "/login";

    private static final String USER_AGENT =
            "Mozilla/5.0 (Linux; Android 12) " +
            "AppleWebKit/537.36 Chrome/153.0 Mobile Safari/537.36";

    public String login(
            String username,
            String password
    ) throws Exception {

        requireInternet();
        String cookie = initialCookie();
        HttpURLConnection c = null;

        GentleServerGate.begin(null, null);
        long started = System.nanoTime();
        try {
            c = (HttpURLConnection)
                    new URL(LOGIN_URL).openConnection();

            c.setRequestMethod("POST");
            c.setConnectTimeout(30000);
            c.setReadTimeout(60000);
            c.setInstanceFollowRedirects(true);
            c.setDoOutput(true);

            c.setRequestProperty("User-Agent", USER_AGENT);
            c.setRequestProperty("Referer", LOGIN_URL);
            c.setRequestProperty(
                    "Content-Type",
                    "application/x-www-form-urlencoded; charset=UTF-8"
            );

            if (cookie != null && !cookie.isEmpty()) {
                c.setRequestProperty("Cookie", cookie);
            }

            String body =
                    "LoginForm%5Busername%5D=" +
                    URLEncoder.encode(username, "UTF-8") +
                    "&LoginForm%5Bpassword%5D=" +
                    URLEncoder.encode(password, "UTF-8");

            byte[] bytes = body.getBytes("UTF-8");
            c.setFixedLengthStreamingMode(bytes.length);

            OutputStream out = c.getOutputStream();
            out.write(bytes);
            out.flush();
            out.close();

            int code = c.getResponseCode();
            GentleServerGate.response(code, c.getHeaderField("Retry-After"));
            InputStream in =
                    code >= 200 && code < 400
                            ? c.getInputStream()
                            : c.getErrorStream();

            String response = readAll(in);

            if (code < 200 || code >= 400) {
                throw new Exception(
                        "Авторизация Cubux: HTTP " + code
                );
            }

            Pattern escaped =
                    Pattern.compile(
                            "\\\\\"accessToken\\\\\":\\\\\"([^\\\\\"]+)"
                    );

            Matcher m = escaped.matcher(response);

            if (m.find()) {
                return m.group(1);
            }

            Pattern normal =
                    Pattern.compile(
                            "\"accessToken\"\\s*:\\s*\"([^\"]+)\""
                    );

            Matcher m2 = normal.matcher(response);

            if (m2.find()) {
                return m2.group(1);
            }

            throw new Exception(
                    "Cubux: токен не найден. Проверьте логин и пароль."
            );

        } finally {
            if (c != null) {
                c.disconnect();
            }
            GentleServerGate.end(started, requestDelayMs);
        }
    }

    private String initialCookie()
            throws Exception {

        requireInternet();
        HttpURLConnection c = null;

        GentleServerGate.begin(null, null);
        long started = System.nanoTime();
        try {
            c = (HttpURLConnection)
                    new URL(LOGIN_URL).openConnection();

            c.setRequestMethod("GET");
            c.setConnectTimeout(30000);
            c.setReadTimeout(60000);
            c.setRequestProperty("User-Agent", USER_AGENT);
            c.setRequestProperty("Referer", LOGIN_URL);

            int code = c.getResponseCode();
            GentleServerGate.response(code, c.getHeaderField("Retry-After"));
            if (code >= 400) throw new java.io.IOException("Авторизация Cubux: HTTP " + code);

            Map<String, List<String>> headers =
                    c.getHeaderFields();

            List<String> cookies =
                    headers.get("Set-Cookie");

            if (cookies == null) {
                cookies = headers.get("set-cookie");
            }

            if (cookies == null || cookies.isEmpty()) {
                return "";
            }

            StringBuilder result = new StringBuilder();

            for (String item : cookies) {
                if (item == null) {
                    continue;
                }

                String first = item.split(";", 2)[0];

                if (result.length() > 0) {
                    result.append("; ");
                }

                result.append(first);
            }

            return result.toString();

        } finally {
            if (c != null) {
                c.disconnect();
            }
            GentleServerGate.end(started, requestDelayMs);
        }
    }

    private String readAll(
            InputStream in
    ) throws Exception {

        if (in == null) {
            return "";
        }

        ByteArrayOutputStream out =
                new ByteArrayOutputStream();

        byte[] buffer = new byte[8192];
        int n;

        while ((n = in.read(buffer)) != -1) {
            out.write(buffer, 0, n);
        }

        in.close();
        return out.toString("UTF-8");
    }
}
