package com.cubux.audit;

import org.json.JSONObject;

import java.util.Locale;

/** Single operation-direction resolver used by Journal, reports and closure totals. */
public final class OperationTypeResolver {
    private OperationTypeResolver() {}

    public static String resolve(JSONObject o, AuditDb db) {
        if (o == null) return "";

        // 1) Explicit semantic fields from the transaction itself.
        String[] explicitKeys = {"operation_type", "payment_type", "direction", "flow_type"};
        for (String k : explicitKeys) {
            String t = CategoryDirectory.typeFromText(text(o, k));
            if (!t.isEmpty()) return t;
        }

        if (truthy(o, "is_expense", "isExpense")) return "Расход";
        if (truthy(o, "is_income", "isIncome")) return "Доход";

        // 2) Dedicated amount channels are more trustworthy than the generic amount sign.
        Double expense = number(o, "expense");
        Double income = number(o, "income");
        if (expense != null && expense > 0 && (income == null || income <= 0)) return "Расход";
        if (income != null && income > 0 && (expense == null || expense <= 0)) return "Доход";

        // 3) Cubux categories are explicitly separated into income/expense categories.
        //    Resolve by cached category metadata loaded from /api/v1/category-read/team/{team}.
        if (db != null) {
            String[] ids = {text(o, "category_id"), text(o, "category_uuid")};
            for (String id : ids) {
                if (id.isEmpty()) continue;
                String v = db.getState("category_type:" + id);
                if (isResolved(v)) return v;
            }
            String category = text(o, "category");
            if (!category.isEmpty()) {
                String v = db.getState("category_type_name:" + norm(category));
                if (isResolved(v)) return v;
                // Cubux can return a breadcrumb such as "Бизнес → Материалы" while
                // the category directory stores only the leaf/parent names.  Try every
                // breadcrumb segment from the most specific (right) to the root.
                String[] parts = category.split("\\s*(?:→|>|/|\\\\)\\s*");
                for (int i = parts.length - 1; i >= 0; i--) {
                    String part = norm(parts[i]);
                    if (part.isEmpty()) continue;
                    v = db.getState("category_type_name:" + part);
                    if (isResolved(v)) return v;
                }
            }
        }

        // 4) A textual generic type can be useful, but a bare number MUST NOT be treated
        //    as income/expense: Cubux numeric type fields are not a reliable direction flag.
        String generic = CategoryDirectory.typeFromText(text(o, "type"));
        if (!generic.isEmpty()) return generic;

        // 5) A negative amount is unambiguously an outgoing value in old snapshots.
        //    A positive amount is NOT enough to call it income because Cubux commonly stores
        //    expense amounts as positive values too.
        Double amount = number(o, "amount");
        if (amount != null && amount < 0) return "Расход";

        return "Не определён";
    }

    public static int sign(JSONObject o, AuditDb db) {
        String t = resolve(o, db);
        if ("Доход".equals(t)) return 1;
        if ("Расход".equals(t)) return -1;
        return 0;
    }

    private static boolean isResolved(String v) {
        return "Доход".equals(v) || "Расход".equals(v) || "Перевод".equals(v);
    }

    private static String text(JSONObject o, String k) {
        Object v = o.opt(k);
        if (v == null || v == JSONObject.NULL) return "";
        String s = String.valueOf(v).trim();
        return "null".equalsIgnoreCase(s) ? "" : s;
    }

    private static Double number(JSONObject o, String k) {
        try {
            String s = text(o, k).replace(" ", "").replace(',', '.');
            return s.isEmpty() ? null : Double.parseDouble(s);
        } catch (Exception e) { return null; }
    }

    private static boolean truthy(JSONObject o, String... keys) {
        for (String k : keys) {
            String s = text(o, k).toLowerCase(Locale.ROOT);
            if (s.equals("true") || s.equals("1") || s.equals("yes")) return true;
        }
        return false;
    }

    private static String norm(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }
}
