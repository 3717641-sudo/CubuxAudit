package com.cubux.audit;

public final class AuditControlRegistry {
    private static volatile AuditControl control;
    private static volatile String mode = "QUICK";
    private AuditControlRegistry(){}
    public static synchronized void attach(AuditControl c, String auditMode) { control=c; mode=auditMode==null?"QUICK":auditMode; }
    public static synchronized void clear(AuditControl c) { if(control==c)control=null; }
    public static AuditControl current(){return control;}
    public static String mode(){return mode;}
    public static long activeElapsedMs(long startedWallMs){
        AuditControl c=control;
        return c==null?Math.max(0L,System.currentTimeMillis()-startedWallMs):c.activeElapsedMs(startedWallMs);
    }
}
