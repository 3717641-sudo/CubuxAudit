package com.cubux.audit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class DayControlAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String day = intent == null ? null : intent.getStringExtra("scan_day");
        boolean finalScan = intent != null && intent.getBooleanExtra("final_scan", false);
        long scheduledFor = intent == null ? 0L : intent.getLongExtra("scheduled_for", 0L);
        DayControlService.startScheduled(context, day, finalScan, scheduledFor);
    }
}
