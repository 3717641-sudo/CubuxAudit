package com.cubux.audit;

import android.content.Context;
import java.util.Calendar;

/** Central settings for scheduled checks and gentle Cubux access. */
public final class CheckSettings {
    public static final String TYPE_LIGHT = "LIGHT";
    public static final String TYPE_FULL = "FULL";

    private static final String K_LIGHT_DAYS = "schedule_light_days";
    private static final String K_FULL_DAYS = "schedule_full_days";
    private static final String K_LIGHT_TIME = "schedule_light_time";
    private static final String K_FULL_TIME = "schedule_full_time";
    private static final String K_RETRIES = "request_retry_limit";
    private static final String K_DELAY_MS = "request_delay_ms";

    private final AuditDb db;

    public CheckSettings(Context c) { db = new AuditDb(c.getApplicationContext()); }

    /** Bit 0=Mon ... bit 6=Sun. Defaults preserve old behavior: light Mon-Sat, full Sun. */
    public int lightDays() { return intState(K_LIGHT_DAYS, 0b0111111); }
    public int fullDays() { return intState(K_FULL_DAYS, 0b1000000); }
    public String lightTime() { return strState(K_LIGHT_TIME, "00:01"); }
    public String fullTime() { return strState(K_FULL_TIME, "00:01"); }
    public int retries() { return clamp(intState(K_RETRIES, 5), 1, 10); }
    public long requestDelayMs() { return DelayProfile.clamp(longState(K_DELAY_MS, DelayProfile.DEFAULT_MS)); }

    public void setLightDays(int mask) { db.saveState(K_LIGHT_DAYS, String.valueOf(mask & 0x7F)); }
    public void setFullDays(int mask) { db.saveState(K_FULL_DAYS, String.valueOf(mask & 0x7F)); }
    public void setLightTime(String hhmm) { db.saveState(K_LIGHT_TIME, normalizeTime(hhmm, "00:01")); }
    public void setFullTime(String hhmm) { db.saveState(K_FULL_TIME, normalizeTime(hhmm, "00:01")); }
    public void setRetries(int value) { db.saveState(K_RETRIES, String.valueOf(clamp(value, 1, 10))); }
    public void setRequestDelayMs(long value) { db.saveState(K_DELAY_MS, String.valueOf(DelayProfile.clamp(value))); }

    public boolean enabled(String type, int calendarDayOfWeek) {
        int bit = dayBit(calendarDayOfWeek);
        int mask = TYPE_FULL.equals(type) ? fullDays() : lightDays();
        return (mask & (1 << bit)) != 0;
    }

    public static int dayBit(int calendarDayOfWeek) {
        switch (calendarDayOfWeek) {
            case Calendar.MONDAY: return 0;
            case Calendar.TUESDAY: return 1;
            case Calendar.WEDNESDAY: return 2;
            case Calendar.THURSDAY: return 3;
            case Calendar.FRIDAY: return 4;
            case Calendar.SATURDAY: return 5;
            case Calendar.SUNDAY: return 6;
            default: return 0;
        }
    }

    public static String[] dayNames() {
        return new String[]{"Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"};
    }

    public static int[] parseTime(String hhmm) {
        try {
            String[] p = hhmm.split(":");
            int h = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            if (h >= 0 && h <= 23 && m >= 0 && m <= 59) return new int[]{h,m};
        } catch (Exception ignored) {}
        return new int[]{0,1};
    }

    public static long[] retryBackoffSeconds() {
        return new long[]{60L, 300L, 900L, 1800L, 3600L, 3600L, 3600L, 3600L, 3600L, 3600L};
    }

    private String strState(String key, String def) {
        String v = db.getState(key);
        return v == null || v.trim().isEmpty() ? def : v.trim();
    }
    private int intState(String key, int def) {
        try { return Integer.parseInt(strState(key, String.valueOf(def))); } catch (Exception e) { return def; }
    }
    private long longState(String key, long def) {
        try { return Long.parseLong(strState(key, String.valueOf(def))); } catch (Exception e) { return def; }
    }
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private static long clampLong(long v, long lo, long hi) { return Math.max(lo, Math.min(hi, v)); }
    private static String normalizeTime(String value, String def) {
        int[] t = parseTime(value == null ? def : value);
        return String.format(java.util.Locale.US, "%02d:%02d", t[0], t[1]);
    }
}
