package com.cubux.audit;
import android.content.*;

public class AuditActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        AuditControl c=AuditControlRegistry.current();
        if(c==null)return;
        String a=intent.getAction();
        if("com.cubux.audit.PAUSE".equals(a)){
            c.pause();
            DiagnosticLog.write(context,"CONTROL","Пауза из уведомления");
            AuditForegroundService.update(context,"Проверка на паузе",AuditForegroundService.percent,
                    AuditForegroundService.page,AuditForegroundService.pages,
                    AuditForegroundService.loaded,AuditForegroundService.total);
        } else if("com.cubux.audit.RESUME".equals(a)){
            c.resume();
            DiagnosticLog.write(context,"CONTROL","Продолжить из уведомления");
            AuditForegroundService.update(context,"Проверка продолжается",AuditForegroundService.percent,AuditForegroundService.page,AuditForegroundService.pages,AuditForegroundService.loaded,AuditForegroundService.total);
        } else if("com.cubux.audit.STOP".equals(a)){
            c.stop();
            DiagnosticLog.write(context,"CONTROL","Стоп из уведомления");
            AuditForegroundService.update(context,"Останавливаю проверку…",AuditForegroundService.percent,AuditForegroundService.page,AuditForegroundService.pages,AuditForegroundService.loaded,AuditForegroundService.total);
        }
    }
}
