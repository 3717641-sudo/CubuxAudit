package com.cubux.audit;

import java.util.Locale;

/** User-facing request delay scale for Cubux access. */
public final class DelayProfile {
    public static final long MIN_MS = 500L;
    public static final long MAX_MS = 10000L;
    public static final long DEFAULT_MS = 2000L;
    public static final long STEP_MS = 500L;

    private DelayProfile() {}

    public static long clamp(long value) {
        return Math.max(MIN_MS, Math.min(MAX_MS, value));
    }

    public static int indexFor(long millis) {
        long v = clamp(millis);
        return (int) Math.round((v - MIN_MS) / (double) STEP_MS);
    }

    public static long millisForIndex(int index) {
        int max = (int) ((MAX_MS - MIN_MS) / STEP_MS);
        int i = Math.max(0, Math.min(max, index));
        return MIN_MS + i * STEP_MS;
    }

    public static int count() {
        return (int) ((MAX_MS - MIN_MS) / STEP_MS) + 1;
    }

    public static String name(long millis) {
        double sec = clamp(millis) / 1000.0;
        if (sec <= 0.5) return "Хард";
        if (sec <= 1.0) return "Быстрый";
        if (sec <= 2.0) return "Оптимальный";
        if (sec <= 3.5) return "Щадящий";
        if (sec <= 5.5) return "Медленный";
        if (sec <= 8.5) return "Очень медленный";
        return "Максимально щадящий";
    }

    public static String seconds(long millis) {
        double sec = clamp(millis) / 1000.0;
        if (Math.abs(sec - Math.rint(sec)) < 0.0001) {
            return String.format(Locale.US, "%.0f", sec);
        }
        return String.format(Locale.US, "%.1f", sec).replace('.', ',');
    }

    public static String label(long millis) {
        return seconds(millis) + " сек — " + name(millis);
    }

    public static String[] labels() {
        String[] out = new String[count()];
        for (int i = 0; i < out.length; i++) out[i] = label(millisForIndex(i));
        return out;
    }
}
