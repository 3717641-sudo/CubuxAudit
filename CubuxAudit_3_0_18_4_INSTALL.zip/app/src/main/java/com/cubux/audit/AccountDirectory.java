package com.cubux.audit;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;

/** Read-only account ID -> human name cache. Failure never blocks an audit. */
public final class AccountDirectory {
    private final AuditDb db;
    private final CubuxClient client;
    private final String teamId;
    public AccountDirectory(AuditDb db,CubuxClient client,String teamId){this.db=db;this.client=client;this.teamId=teamId;}
    public void refresh(){
        try{
            String url="https://app.cubux.net/api/v1/account/team/"+enc(teamId);
            String body=client.get(url); int n=parseAndSave(body); if(n>0)db.saveState("account_directory_updated",TimeUtil.now());
        }catch(Throwable ignored){}
    }
    private int parseAndSave(String body)throws Exception{
        String t=body==null?"":body.trim();int[] n={0};
        if(t.startsWith("["))walk(new JSONArray(t),n); else if(t.startsWith("{"))walk(new JSONObject(t),n); return n[0];
    }
    private void walk(Object node,int[] n){
        if(node instanceof JSONObject){JSONObject o=(JSONObject)node;String id=first(o,"id","uuid","account_id","account_uuid");String name=first(o,"name","title","label");if(!id.isEmpty()&&!name.isEmpty()){db.saveState("account_name:"+id,name);n[0]++;}java.util.Iterator<String> it=o.keys();while(it.hasNext()){Object v=o.opt(it.next());if(v instanceof JSONObject||v instanceof JSONArray)walk(v,n);}}
        else if(node instanceof JSONArray){JSONArray a=(JSONArray)node;for(int i=0;i<a.length();i++){Object v=a.opt(i);if(v instanceof JSONObject||v instanceof JSONArray)walk(v,n);}}
    }
    private String first(JSONObject o,String...keys){for(String k:keys){Object v=o.opt(k);if(v!=null&&v!=JSONObject.NULL){String x=String.valueOf(v).trim();if(!x.isEmpty())return x;}}return "";}
    private String enc(String s){try{return URLEncoder.encode(s==null?"":s,"UTF-8");}catch(Exception e){return s==null?"":s;}}
}
