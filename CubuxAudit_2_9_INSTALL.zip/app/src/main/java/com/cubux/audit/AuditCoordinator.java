package com.cubux.audit;

import android.content.Context;

/** Coordinates light/full checks. Cubux access is strictly read-only. */
public class AuditCoordinator {
    public static final String MODE_QUICK="QUICK";   // UI/API compatibility; means LIGHT from 2.8
    public static final String MODE_FULL="FULL";

    private final Context context;
    private final AuditDb db;
    private final SecureCredentialsStore credentials;

    public AuditCoordinator(Context context){
        this.context=context.getApplicationContext();
        db=new AuditDb(this.context);
        credentials=new SecureCredentialsStore(this.context);
    }

    public AuditEngine.Result run(String login,String password,boolean recovery,
                                  AuditProgressListener listener)throws Exception{
        return run(login,password,recovery,listener,null);
    }

    public AuditEngine.Result run(String login,String password,boolean recovery,
                                  AuditProgressListener listener,AuditControl control)throws Exception{
        return runMode(login,password,recovery,listener,control,MODE_FULL);
    }

    public AuditEngine.Result runMode(String login,String password,boolean recovery,
                                      AuditProgressListener listener,AuditControl control,
                                      String mode)throws Exception{
        if(!AuditRunGate.tryAcquire())throw new Exception("Другая проверка уже выполняется");
        AuditControlRegistry.attach(control,mode);
        DiagnosticLog.write(context,"CHECK","Старт проверки. Режим="+mode+", recovery="+recovery);

        long runId=-1L;
        try{
            credentials.saveCredentials(login,password);
            long startedMs=System.currentTimeMillis();
            runId=db.createRun(recovery);
            final long activeRunId=runId;
            int[] retries={0};
            CheckSettings settings=new CheckSettings(context);
            // User setting controls whole-check retries. Inside one scan keep only a very small
            // request retry budget so failures cannot multiply into aggressive server traffic.
            int requestAttempts=Math.max(1, Math.min(2, settings.retries()));

            GentleServerGate.configure(settings.requestDelayMs(),
                    db.getState("cubux_server_not_before"),
                    deadline -> db.saveState("cubux_server_not_before", String.valueOf(deadline)));
            try{
                String token=credentials.getToken();
                if(token.isEmpty()){
                    stage(listener,"AUTHENTICATING","Подключаюсь к Cubux...");
                    token=new CubuxAuthClient().login(login,password);
                    credentials.saveToken(token);
                }

                CubuxClient client=new CubuxClient(token,()->{
                    stage(listener,"REAUTHENTICATING","Сеанс Cubux истёк. Обновляю подключение...");
                    String fresh=new CubuxAuthClient().login(credentials.getLogin(),credentials.getPassword());
                    credentials.saveToken(fresh);
                    return fresh;
                },control,settings.requestDelayMs());

                client.setStatusListener(listener);
                stage(listener,"TEAM","Получаю данные команды Cubux...");
                String teamId=new CubuxTeamResolver(context,client).resolve();
                String to=TimeUtil.today();
                HistoryRange range=new HistoryRange(db);
                String firstDate=range.startDate();

                AuditProgressListener wrapped=new AuditProgressListener(){
                    @Override public void onStage(String st,String msg){
                        db.updateRunStage(activeRunId,st);
                        DiagnosticLog.write(context,"STAGE",st+" — "+msg);
                        CheckStatusStore.activity(context,msg);
                        if(listener!=null)listener.onStage(st,msg);
                    }
                    @Override public void onMeta(int total,int pages){
                        DiagnosticLog.write(context,"META","Операций="+total+", страниц="+pages);
                        if(listener!=null)listener.onMeta(total,pages);
                    }
                    @Override public void onPage(int page,int pages,int loaded,int total){
                        double elapsed=Math.max(1,(System.currentTimeMillis()-startedMs)/1000.0);
                        db.updateRunProgress(activeRunId,"READING_DATA",page,pages,loaded,total,loaded/elapsed,retries[0]);
                        DiagnosticLog.write(context,"PAGE",page+"/"+pages+"; "+loaded+"/"+total);
                        if(listener!=null)listener.onPage(page,pages,loaded,total);
                    }
                    @Override public void onRetry(int page,int attempt,int retrySeconds,String error){
                        retries[0]++;
                        DiagnosticLog.write(context,"RETRY","Страница="+page+", попытка="+attempt+", ожидание="+retrySeconds+"с, ошибка="+error);
                        if(listener!=null)listener.onRetry(page,attempt,retrySeconds,error);
                    }
                };

                client.setStatusListener(wrapped);
                String effectiveMode=mode;
                if(MODE_QUICK.equals(mode)){
                    if(firstDate==null || db.transactions().isEmpty()){
                        stage(wrapped,"BASELINE_REQUIRED","Первый эталон ещё не создан. Выполняю полную первоначальную проверку...");
                        effectiveMode=MODE_FULL;
                    } else {
                        stage(wrapped,"LIGHT","Лёгкая проверка всей истории с "+firstDate+"...");
                        LightCheckEngine light=new LightCheckEngine(context,db,client,teamId,wrapped,control,requestAttempts);
                        LightCheckEngine.Outcome out=light.run(firstDate,to,runId,startedMs);
                        if(!out.needFull){
                            db.saveState("last_successful_audit_ms",String.valueOf(System.currentTimeMillis()));
                            db.saveState("last_audit_mode",MODE_QUICK);
                            stage(wrapped,"COMPLETED","Лёгкая проверка завершена успешно");
                            return out.result;
                        }
                        effectiveMode=MODE_FULL;
                        stage(wrapped,"AUTO_FULL","Лёгкая проверка обнаружила причину для полного просмотра: "+out.reason+". Запускаю полную проверку автоматически...");
                    }
                }

                // Full mode. On the very first check no dateSince is sent: Cubux itself defines
                // the beginning of the available history. That earliest returned date becomes
                // the single lower boundary used everywhere in the app.
                String from=range.startDate();
                stage(wrapped,"RANGE",from==null
                        ? "Первая полная проверка: получаю всю доступную историю Cubux..."
                        : "Полная проверка всей истории с "+from+"...");

                CubuxLoader loader=new CubuxLoader(client,teamId,from,to,wrapped,control,requestAttempts);
                CubuxLoader.Result loaded=loader.loadAll();

                String learned=range.learnFrom(loaded.items);
                if(learned==null && loaded.totalCount>0)throw new Exception("Cubux: не удалось определить дату первой операции");
                if(learned!=null)db.saveState("history_range_label",learned+" .. "+to);

                stage(wrapped,"PROCESSING","Проверяю целостность полученных данных...");
                PeriodControlEngine.Result period=new PeriodControlEngine(db).analyze(loaded.items,false,null,null);
                stage(wrapped,"COMPARING","Сравниваю все записи с локальным эталоном...");

                boolean restoreSync="1".equals(db.getState("restore_sync_pending"));
                AuditEngine.Result result=new AuditEngine(context).audit(
                        loaded.items,loaded.totalCount,runId,period.detailedDates,
                        period.closedChangedCount,startedMs,false,null,null,restoreSync
                );

                stage(wrapped,"CONTROL_BASELINE","Обновляю лёгкие контрольные данные...");
                if(learned!=null){
                    new LightCheckEngine(context,db,client,teamId,wrapped,control,requestAttempts)
                            .refreshBaseline(learned,to,result.total);
                }

                stage(wrapped,"SAVING","Сохраняю результат проверки...");
                db.saveState("last_successful_audit_ms",String.valueOf(System.currentTimeMillis()));
                db.saveState("last_audit_mode",MODE_FULL.equals(mode)?MODE_FULL:"FULL_AFTER_LIGHT");
                stage(wrapped,"COMPLETED","Проверка завершена успешно");
                DiagnosticLog.write(context,"CHECK","Успешно. Всего="+result.total+
                        ", новые="+result.newCount+", изменено="+result.changedCount+
                        ", удалено="+result.deletedCount+", режим="+effectiveMode);
                return result;

            }catch(AuditControl.AuditStoppedException e){
                if(runId>=0)db.stopRun(runId);
                DiagnosticLog.write(context,"CHECK","Проверка остановлена пользователем");
                throw e;
            }catch(Exception e){
                if(runId>=0)db.failRun(runId,e.getMessage()==null?e.toString():e.getMessage());
                DiagnosticLog.error(context,"CHECK_ERROR",e);
                throw e;
            }
        }finally{
            AuditControlRegistry.clear(control);
            AuditRunGate.release();
        }
    }

    public AuditEngine.Result runStored(boolean recovery,AuditProgressListener listener)throws Exception{
        return runStoredMode(recovery,listener,MODE_QUICK);
    }

    public AuditEngine.Result runStoredMode(boolean recovery,AuditProgressListener listener,String mode)throws Exception{
        String login=credentials.getLogin(),password=credentials.getPassword();
        if(login.isEmpty()||password.isEmpty())throw new Exception("Логин/пароль Cubux не сохранены");
        return runMode(login,password,recovery,listener,null,mode);
    }

    private void stage(AuditProgressListener listener,String st,String msg){
        CheckStatusStore.activity(context,msg);
        if(listener!=null)listener.onStage(st,msg);
    }

    public boolean isRecovery(){
        String value=db.getState("last_successful_audit_ms");
        if(value==null)return false;
        try{
            long last=Long.parseLong(value);
            return System.currentTimeMillis()-last>45L*60L*1000L;
        }catch(Exception e){return false;}
    }
}
