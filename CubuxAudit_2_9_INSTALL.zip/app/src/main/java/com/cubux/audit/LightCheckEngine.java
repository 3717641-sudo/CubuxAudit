package com.cubux.audit;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Lightweight whole-history control. It never silently trusts an incomplete control signal:
 * if aggregate control is unavailable or ambiguous, caller must run a full check.
 */
public final class LightCheckEngine {
    public static final class Outcome {
        public final boolean needFull;
        public final AuditEngine.Result result;
        public final String reason;
        Outcome(boolean needFull, AuditEngine.Result result, String reason) {
            this.needFull=needFull; this.result=result; this.reason=reason;
        }
        static Outcome full(String reason){ return new Outcome(true,null,reason); }
        static Outcome done(AuditEngine.Result r){ return new Outcome(false,r,null); }
    }

    private final Context context;
    private final AuditDb db;
    private final CubuxClient client;
    private final String teamId;
    private final AuditProgressListener listener;
    private final AuditControl control;
    private final int maxAttempts;

    public LightCheckEngine(Context context, AuditDb db, CubuxClient client, String teamId,
                            AuditProgressListener listener, AuditControl control, int maxAttempts) {
        this.context=context.getApplicationContext();
        this.db=db; this.client=client; this.teamId=teamId;
        this.listener=listener; this.control=control;
        this.maxAttempts=Math.max(1,Math.min(10,maxAttempts));
    }

    public Outcome run(String from, String to, long runId, long startedMs) throws Exception {
        if (from == null || from.isEmpty()) return Outcome.full("Первая проверка должна создать полный эталон истории Cubux");
        if (db.transactions().isEmpty()) return Outcome.full("Локальный эталон ещё не создан");

        stage("LIGHT_META", "Лёгкая проверка: сверяю количество операций по всей истории...");
        CubuxLoader metaLoader = new CubuxLoader(client,teamId,from,to,listener,control,maxAttempts);
        CubuxLoader.Meta meta = metaLoader.loadMetaOnly();
        int localTotal = db.transactions().size();

        stage("LIGHT_SUMMARY", "Лёгкая проверка: получаю контрольные суммы Cubux...");
        Summary current = fetchSummary(from,to);
        if (current == null) {
            DiagnosticLog.write(context,"LIGHT","Контрольный API недоступен — безопасный переход к полной проверке");
            return Outcome.full("Cubux не отдал надёжные контрольные суммы");
        }

        String oldHash=db.getState("light_summary_hash");
        String oldTotal=db.getState("light_summary_total");
        if (oldHash==null || oldHash.isEmpty() || oldTotal==null) {
            return Outcome.full("Нет контрольного эталона лёгкой проверки");
        }

        boolean countChanged = meta.totalCount != parseInt(oldTotal, localTotal) || meta.totalCount != localTotal;
        boolean summaryChanged = !oldHash.equals(current.wholeHash);

        if (!countChanged && !summaryChanged) {
            long dur=System.currentTimeMillis()-startedMs;
            db.finishRun(runId,dur,localTotal,0,0,0,0,0);
            db.saveState("last_light_check_ms",String.valueOf(System.currentTimeMillis()));
            stage("COMPLETED","Лёгкая проверка завершена: расхождений нет");
            return Outcome.done(new AuditEngine.Result(localTotal,0,0,0,0,0,runId,dur));
        }

        stage("LIGHT_MISMATCH", "Найдено расхождение. Определяю проблемный период...");
        Set<String> months = changedMonths(current);
        if (months.isEmpty()) {
            DiagnosticLog.write(context,"LIGHT_MISMATCH","Изменился общий контрольный отпечаток, месяц не локализован");
            return Outcome.full("Расхождение найдено, но период нельзя надёжно локализовать");
        }

        String first = Collections.min(months) + "-01";
        String lastMonth = Collections.max(months);
        String last = monthEnd(lastMonth);
        if (last.compareTo(to)>0) last=to;
        stage("LIGHT_DEEP", "Расхождение найдено в периоде " + first + " — " + last + ". Проверяю его подробно...");

        CubuxLoader loader = new CubuxLoader(client,teamId,first,last,listener,control,maxAttempts);
        CubuxLoader.Result loaded = loader.loadAll();
        PeriodControlEngine.Result period = new PeriodControlEngine(db).analyze(loaded.items,true,first,last);
        AuditEngine.Result result = new AuditEngine(context).audit(
                loaded.items,loaded.totalCount,runId,period.detailedDates,
                period.closedChangedCount,startedMs,true,first,last,
                "1".equals(db.getState("restore_sync_pending"))
        );
        saveBaseline(current, meta.totalCount);
        db.saveState("last_light_check_ms",String.valueOf(System.currentTimeMillis()));
        return Outcome.done(result);
    }

    /** Refreshes the lightweight control baseline after a successful full check. */
    public void refreshBaseline(String from, String to, int knownTotal) {
        try {
            Summary s=fetchSummary(from,to);
            if(s!=null){ saveBaseline(s,knownTotal); db.saveState("light_summary_supported","1"); }
            else db.saveState("light_summary_supported","0");
        } catch(Exception e){
            db.saveState("light_summary_supported","0");
            DiagnosticLog.error(context,"LIGHT_BASELINE",e);
        }
    }

    private void saveBaseline(Summary s,int total){
        db.saveState("light_summary_hash",s.wholeHash);
        db.saveState("light_summary_total",String.valueOf(total));
        db.saveState("light_summary_months",new JSONObject(s.monthHashes).toString());
        db.saveState("light_summary_endpoint",s.endpoint);
        db.saveState("light_summary_at",TimeUtil.now());
    }

    private Set<String> changedMonths(Summary current){
        Set<String> out=new HashSet<>();
        Map<String,String> old=new HashMap<>();
        try{
            JSONObject o=new JSONObject(value(db.getState("light_summary_months"),"{}"));
            Iterator<String> it=o.keys(); while(it.hasNext()){String k=it.next();old.put(k,o.optString(k,""));}
        }catch(Exception ignored){}
        if(old.isEmpty() || current.monthHashes.isEmpty()) return out;
        Set<String> keys=new HashSet<>(old.keySet()); keys.addAll(current.monthHashes.keySet());
        for(String k:keys) if(!value(old.get(k),"").equals(value(current.monthHashes.get(k),""))) out.add(k);
        return out;
    }

    private Summary fetchSummary(String from,String to) throws Exception {
        String saved=db.getState("light_summary_endpoint");
        List<String> candidates=new ArrayList<>();
        if(saved!=null&&!saved.isEmpty())candidates.add(saved);
        candidates.add("/api/v2/stats-daily/team/{team}");
        candidates.add("/api/v2/stats-monthly/team/{team}");
        candidates.add("/api/v2/turnover/sums-by-dates/{team}");
        candidates.add("/api/v2/turnover/sums-by-dates/team/{team}");

        Set<String> tried=new HashSet<>();
        for(String pattern:candidates){
            if(!tried.add(pattern))continue;
            checkpoint();
            String path=pattern.replace("{team}",enc(teamId));
            String url="https://app.cubux.net"+path+"?dateSince="+enc(from)+"&dateUntil="+enc(to);
            try{
                Object root=fetchCandidateRoot(url);
                if(root==null)continue;
                String canonical=canonical(root);
                if(canonical.length()<3)continue;
                Map<String,String> months=monthHashes(root);
                return new Summary(HashUtil.sha256(canonical),months,pattern);
            }catch(IOException e){
                String m=value(e.getMessage(),"");
                if(m.contains("HTTP 401")||m.contains("HTTP 403"))throw e;
                // 400/404 can mean that this candidate does not exist. Try next known aggregate endpoint.
                if(!(m.contains("HTTP 400")||m.contains("HTTP 404"))) DiagnosticLog.write(context,"LIGHT_SUMMARY",pattern+" -> "+m);
            }
        }
        return null;
    }


    private Object fetchCandidateRoot(String baseUrl) throws Exception {
        String body=getRetry(baseUrl);
        Object first=parseRoot(body);
        if(first==null)return null;
        if(!(first instanceof JSONObject))return first;
        JSONObject obj=(JSONObject)first;
        JSONObject meta=obj.optJSONObject("_meta");
        if(meta==null)return first;
        int pages=meta.optInt("pageCount",1);
        if(pages<=1)return first;
        // A "summary" endpoint that needs hundreds of pages is not lightweight.
        if(pages>100)return null;
        JSONArray allPages=new JSONArray();
        allPages.put(first);
        for(int p=2;p<=pages;p++){
            checkpoint();
            stage("LIGHT_SUMMARY","Получаю контрольные данные: страница "+p+" из "+pages+"...");
            String sep=baseUrl.contains("?")?"&":"?";
            Object next=parseRoot(getRetry(baseUrl+sep+"page="+p));
            if(next==null)throw new IOException("Cubux: неполные контрольные данные");
            allPages.put(next);
        }
        return allPages;
    }

    private String getRetry(String url) throws Exception {
        int attempt=0;
        while(true){
            checkpoint(); attempt++;
            try{return client.get(url);}catch(IOException e){
                String m=value(e.getMessage(),"");
                if(m.contains("HTTP 400")||m.contains("HTTP 401")||m.contains("HTTP 403")||m.contains("HTTP 404")||attempt>=maxAttempts)throw e;
                long[] waits=CheckSettings.retryBackoffSeconds(); int sec=(int)waits[Math.min(attempt-1,waits.length-1)];
                if(listener!=null)listener.onRetry(1,attempt,sec,m);
                for(int left=sec;left>0;left--){checkpoint();if(left==sec||left<=5||left%5==0)stage("RETRY_WAIT","Cubux временно не отвечает. Повтор через "+left+" сек...");Thread.sleep(1000L);}
            }
        }
    }

    private Object parseRoot(String body){
        try{String t=body==null?"":body.trim();if(t.startsWith("["))return new JSONArray(t);if(t.startsWith("{"))return new JSONObject(t);}catch(Exception ignored){}return null;
    }

    private Map<String,String> monthHashes(Object root){
        Map<String,List<String>> bucket=new TreeMap<>();
        collectMonths(root,null,bucket);
        Map<String,String> out=new TreeMap<>();
        for(Map.Entry<String,List<String>>e:bucket.entrySet()){
            Collections.sort(e.getValue()); StringBuilder b=new StringBuilder(); for(String x:e.getValue())b.append(x).append('\n');
            out.put(e.getKey(),HashUtil.sha256(b.toString()));
        }
        return out;
    }

    private void collectMonths(Object node,String keyHint,Map<String,List<String>> out){
        if(node instanceof JSONObject){
            JSONObject o=(JSONObject)node;
            String month=monthOf(o,keyHint);
            if(month!=null)out.computeIfAbsent(month,k->new ArrayList<>()).add(canonical(o));
            Iterator<String> it=o.keys();while(it.hasNext()){String k=it.next();Object v=o.opt(k);if(v!=null&&v!=JSONObject.NULL)collectMonths(v,k,out);}
        } else if(node instanceof JSONArray){
            JSONArray a=(JSONArray)node;for(int i=0;i<a.length();i++){Object v=a.opt(i);if(v!=null&&v!=JSONObject.NULL)collectMonths(v,keyHint,out);}
        } else if(keyHint!=null && keyHint.matches("\\d{4}-\\d{2}(-\\d{2})?")) {
            String m=keyHint.substring(0,7);out.computeIfAbsent(m,k->new ArrayList<>()).add(String.valueOf(node));
        }
    }

    private String monthOf(JSONObject o,String hint){
        String[] keys={"date","date_key","day","period","monthDate","startDate"};
        for(String k:keys){String d=o.optString(k,"");if(d.matches("\\d{4}-\\d{2}.*"))return d.substring(0,7);}
        int y=o.optInt("year",-1);Object mv=o.opt("month");
        if(y>1900&&mv!=null&&mv!=JSONObject.NULL){try{int m=Integer.parseInt(String.valueOf(mv));if(m>=1&&m<=12)return String.format(Locale.US,"%04d-%02d",y,m);}catch(Exception ignored){}}
        if(hint!=null&&hint.matches("\\d{4}-\\d{2}.*"))return hint.substring(0,7);
        return null;
    }

    private String canonical(Object v){
        if(v==null||v==JSONObject.NULL)return "null";
        if(v instanceof JSONObject){
            JSONObject o=(JSONObject)v;List<String>keys=new ArrayList<>();Iterator<String>it=o.keys();while(it.hasNext())keys.add(it.next());Collections.sort(keys);
            StringBuilder b=new StringBuilder("{");boolean first=true;for(String k:keys){if(isVolatileKey(k))continue;if(!first)b.append(',');first=false;b.append(JSONObject.quote(k)).append(':').append(canonical(o.opt(k)));}return b.append('}').toString();
        }
        if(v instanceof JSONArray){JSONArray a=(JSONArray)v;List<String>parts=new ArrayList<>();for(int i=0;i<a.length();i++)parts.add(canonical(a.opt(i)));Collections.sort(parts);return "["+join(parts)+"]";}
        if(v instanceof Number||v instanceof Boolean)return String.valueOf(v);
        return JSONObject.quote(String.valueOf(v));
    }
    private boolean isVolatileKey(String k){String x=k.toLowerCase(Locale.US);return x.equals("_links")||x.equals("links")||x.contains("generatedat")||x.contains("updatedat")||x.contains("requestid");}
    private String join(List<String>a){StringBuilder b=new StringBuilder();for(int i=0;i<a.size();i++){if(i>0)b.append(',');b.append(a.get(i));}return b.toString();}
    private String monthEnd(String yyyyMm){try{Calendar c=Calendar.getInstance();Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(yyyyMm+"-01");c.setTime(d);c.set(Calendar.DAY_OF_MONTH,c.getActualMaximum(Calendar.DAY_OF_MONTH));return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}catch(Exception e){return yyyyMm+"-31";}}
    private void stage(String s,String m){CheckStatusStore.activity(context,m);if(listener!=null)listener.onStage(s,m);}
    private void checkpoint() throws AuditControl.AuditStoppedException {if(control!=null)control.checkpoint();}
    private static String enc(String s){try{return URLEncoder.encode(s==null?"":s,"UTF-8");}catch(Exception e){return s==null?"":s;}}
    private static String value(String s,String d){return s==null?d:s;}
    private static int parseInt(String s,int d){try{return Integer.parseInt(s);}catch(Exception e){return d;}}

    private static final class Summary{
        final String wholeHash,endpoint;final Map<String,String>monthHashes;
        Summary(String h,Map<String,String>m,String e){wholeHash=h;monthHashes=m;endpoint=e;}
    }
}
