package com.cubux.audit;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;

public class CubuxClient {

    public interface TokenRefresher {
        String refreshToken()
                throws Exception;
    }

    private String token;
    private final TokenRefresher refresher;
    private final AuditControl control;
    private final long requestDelayMs;
    private AuditProgressListener statusListener;
    public void setStatusListener(AuditProgressListener listener) { statusListener = listener; }

    public CubuxClient(
            String token,
            TokenRefresher refresher
    ) {
        this(token, refresher, null, 5000L);
    }

    public CubuxClient(
            String token,
            TokenRefresher refresher,
            AuditControl control
    ) {
        this(token, refresher, control, 5000L);
    }

    public CubuxClient(
            String token,
            TokenRefresher refresher,
            AuditControl control,
            long requestDelayMs
    ) {
        this.token = token;
        this.refresher = refresher;
        this.control = control;
        this.requestDelayMs = Math.max(5000L, Math.min(30000L, requestDelayMs));
    }

    public CubuxClient(
            String token
    ) {
        this(token, null, null, 5000L);
    }

    public String get(
            String urlString
    ) throws IOException {
        return getInternal(
                urlString,
                true
        );
    }

    private String getInternal(
            String urlString,
            boolean allowRefresh
    ) throws IOException {

        HttpURLConnection connection =
                null;

        boolean acquired = false;
        long started = 0L;
        boolean receivedResponse = false;
        try {
            GentleServerGate.begin(control, statusListener);
            acquired = true;
            started = System.nanoTime();
            connection =
                    (HttpURLConnection)
                            new URL(
                                    urlString
                            ).openConnection();

            final HttpURLConnection activeConnection = connection;
            final Runnable cancelAction = () -> {
                try {
                    activeConnection.disconnect();
                } catch (Throwable ignored) {
                }
            };

            if (control != null) {
                control.setCancelAction(cancelAction);
                try {
                    control.checkpoint();
                } catch (AuditControl.AuditStoppedException e) {
                    cancelAction.run();
                    throw new IOException(e.getMessage());
                }
            }

            connection.setRequestMethod("GET");
            connection.setRequestProperty(
                    "Authorization",
                    "Bearer " + token
            );
            connection.setRequestProperty(
                    "Accept",
                    "application/json"
            );
            connection.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/153.0 Mobile Safari/537.36"
            );

            connection.setConnectTimeout(30000);
            connection.setReadTimeout(60000);
            connection.setInstanceFollowRedirects(true);

            int code =
                    connection.getResponseCode();

            receivedResponse = true;
            GentleServerGate.response(code, connection.getHeaderField("Retry-After"));

            if (code == 401 &&
                    allowRefresh &&
                    refresher != null) {

                connection.disconnect();
                connection = null;
                GentleServerGate.end(started, requestDelayMs);
                acquired = false;
                try {
                    String fresh =
                            refresher.refreshToken();

                    if (fresh == null ||
                            fresh.trim().isEmpty()) {
                        throw new IOException(
                                "Cubux HTTP 401: токен не обновлён"
                        );
                    }

                    token = fresh.trim();
                    return getInternal(
                            urlString,
                            false
                    );

                } catch (IOException e) {
                    throw e;

                } catch (Exception e) {
                    throw new IOException(
                            "Cubux HTTP 401: повторная авторизация не удалась. " +
                                    e.getMessage()
                    );
                }
            }

            if (code != 200) {
                throw new IOException(
                        "Cubux HTTP " + code
                );
            }

            InputStream input =
                    connection.getInputStream();

            ByteArrayOutputStream output =
                    new ByteArrayOutputStream();

            byte[] buffer =
                    new byte[8192];

            int length;

            while ((length =
                    input.read(buffer)) != -1) {
                output.write(
                        buffer,
                        0,
                        length
                );
            }

            input.close();
            return output.toString("UTF-8");

        } catch (UnknownHostException e) {
            GentleServerGate.failure();
            throw new IOException(
                    "DNS: не найден app.cubux.net"
            );

        } catch (SocketTimeoutException e) {
            GentleServerGate.failure();
            throw new IOException(
                    "TIMEOUT: Cubux не отвечает"
            );

        } catch (IOException e) {
            if (acquired && !receivedResponse && (control == null || !control.isStopped())) GentleServerGate.failure();
            throw e;
        } finally {
            if (connection != null) {
                final HttpURLConnection finishedConnection = connection;
                // Clear only the hook belonging to this request.
                // A newer request may already have installed another hook.
                if (control != null) {
                    // This is safe even if the active hook has already changed.
                    // We use a compatible disconnect action solely to avoid keeping
                    // a stale reference alive; stop is also guarded by checkpoints.
                    control.setCancelAction(null);
                }
                finishedConnection.disconnect();
            }
            if (acquired) GentleServerGate.end(started, requestDelayMs);
        }
    }
}
