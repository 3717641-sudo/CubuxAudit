package com.cubux.audit;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/** One shared gate for authentication, metadata and transaction requests. */
public final class GentleServerGate {
    public interface DeadlineStore { void save(long value); }
    private static final ReentrantLock LOCK = new ReentrantLock(true);
    private static volatile long notBefore;
    private static volatile long delayMs = 5000L;
    private static long adaptiveMs = 5000L;
    private static int failures;
    private static DeadlineStore store;
    private GentleServerGate() {}

    public static synchronized void configure(long delay, String saved, DeadlineStore target) {
        delayMs = Math.max(5000L, Math.min(30000L, delay));
        store = target;
        try { notBefore = Math.max(notBefore, Long.parseLong(saved)); }
        catch (Exception ignored) {}
    }

    public static void begin(AuditControl control, AuditProgressListener listener) throws IOException {
        boolean acquired = false;
        try {
            while (!(acquired = LOCK.tryLock(250, TimeUnit.MILLISECONDS))) checkpoint(control);
            long previousSeconds = -1;
            while (true) {
                checkpoint(control);
                long left = notBefore - System.currentTimeMillis();
                if (left <= 0) break;
                long seconds = (left + 999) / 1000;
                if (listener != null && seconds != previousSeconds) {
                    previousSeconds = seconds;
                    listener.onStage("GENTLE_WAIT", "Щадящий режим: следующий запрос через " + seconds + " сек.");
                }
                Thread.sleep(Math.min(250L, left));
            }
        } catch (Exception e) {
            if (acquired) LOCK.unlock();
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            throw new IOException(e.getMessage() == null ? "Запрос прерван" : e.getMessage(), e);
        }
    }

    private static void checkpoint(AuditControl control) throws Exception {
        if (control != null) control.checkpoint();
        if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
    }

    public static synchronized long retryAfterMs(String value, long now) {
        if (value == null) return 0;
        try {
            long seconds = Long.parseLong(value.trim());
            return Math.max(0, Math.multiplyExact(seconds, 1000L));
        } catch (Exception ignored) {}
        try { return Math.max(0, ZonedDateTime.parse(value.trim(), DateTimeFormatter.RFC_1123_DATE_TIME)
                .toInstant().toEpochMilli() - now); }
        catch (Exception ignored) { return 0; }
    }

    public static synchronized void response(int code, String retryAfter) {
        if (code == 429 || code >= 500) failure();
        else if (code >= 200 && code < 300) failures = 0;
        long now = System.currentTimeMillis();
        long wait = retryAfterMs(retryAfter, now);
        if (wait > 0) defer(wait);
    }

    public static synchronized void failure() {
        long[] waits = {60000L, 300000L, 900000L, 1800000L, 3600000L};
        defer(waits[Math.min(failures++, waits.length - 1)]);
    }

    private static void defer(long millis) {
        long now = System.currentTimeMillis();
        long deadline = millis > Long.MAX_VALUE - now ? Long.MAX_VALUE : now + millis;
        notBefore = Math.max(notBefore, deadline);
        if (store != null) store.save(notBefore);
    }

    public static void end(long startedNanos, long requestedDelay) {
        try {
            synchronized (GentleServerGate.class) {
                long elapsed = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startedNanos);
                long base = Math.max(delayMs, Math.max(5000L, Math.min(30000L, requestedDelay)));
                adaptiveMs = elapsed >= 10000L ? Math.min(30000L, Math.max(base, adaptiveMs * 2))
                        : Math.max(base, adaptiveMs - 1000L);
                defer(adaptiveMs);
            }
        } finally { LOCK.unlock(); }
    }
}
