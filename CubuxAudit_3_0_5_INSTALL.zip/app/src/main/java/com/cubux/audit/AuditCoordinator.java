package com.cubux.audit;

import android.content.Context;

/** Coordinates light/full checks. Cubux access is strictly read-only. */
public class AuditCoordinator {
    public static final String MODE_QUICK="QUICK";   // UI/API compatibility; means LIGHT from 2.8
    public static final String MODE_FULL="FULL";

    private final Context context;
    private final AuditDb db;
    private final SecureCredentialsStore credentials;

    public AuditCoordinator(Context context){
        this.context=context.getApplicationContext();
        db=new AuditDb(this.context);
        credentials=new SecureCredentialsStore(this.context);
    }

    public AuditEngine.Result run(String login,String password,boolean recovery,
                                  AuditProgressListener listener)throws Exception{
        return run(login,password,recovery,listener,null);
    }

    public AuditEngine.Result run(String login,String password,boolean recovery,
                                  AuditProgressListener listener,AuditControl control)throws Exception{
        return runMode(login,password,recovery,listener,control,MODE_FULL);
    }

    public AuditEngine.Result runMode(String login,String password,boolean recovery,
                                      AuditProgressListener listener,AuditControl control,
                                      String mode)throws Exception{
        if(!AuditRunGate.tryAcquire())throw new Exception("Другая проверка уже выполняется");
        AuditControlRegistry.attach(control,mode);
        DiagnosticLog.write(context,"CHECK","Старт проверки. Режим="+mode+", recovery="+recovery);

        long runId=-1L;
        try{
            credentials.saveCredentials(login,password);
            long startedMs=System.currentTimeMillis();
            runId=db.createRun(recovery);
            final long activeRunId=runId;
            int[] retries={0};
            CheckSettings settings=new CheckSettings(context);
            // User setting controls whole-check retries. Inside one scan keep only a very small
            // request retry budget so failures cannot multiply into aggressive server traffic.
            int requestAttempts=Math.max(1, Math.min(2, settings.retries()));

            GentleServerGate.configure(settings.requestDelayMs(),
                    db.getState("cubux_server_not_before"),
                    deadline -> db.saveState("cubux_server_not_before", String.valueOf(deadline)),
                    settings::requestDelayMs);
            try{
                String token=credentials.getToken();
                if(token.isEmpty()){
                    stage(listener,"AUTHENTICATING","Подключаюсь к Cubux...");
                    token=loginResilient(login,password,settings,listener,control);
                    credentials.saveToken(token);
                }

                CubuxClient client=new CubuxClient(context,token,()->{
                    stage(listener,"REAUTHENTICATING","Сеанс Cubux истёк. Обновляю подключение...");
                    String fresh=loginResilient(credentials.getLogin(),credentials.getPassword(),settings,listener,control);
                    credentials.saveToken(fresh);
                    return fresh;
                },control,settings.requestDelayMs());

                client.setStatusListener(listener);
                stage(listener,"TEAM","Получаю данные команды Cubux...");
                String teamId=new CubuxTeamResolver(context,client).resolve();
                String to=TimeUtil.yesterday();
                int purged=db.purgeTransactionsAfter(to);
                db.purgeClosuresAfter(to);
                if(purged>0) DiagnosticLog.write(context,"MIGRATION","Исключены незакрытые операции после "+to+": "+purged);
                HistoryRange range=new HistoryRange(db);
                String firstDate=range.startDate();

                AuditProgressListener wrapped=new AuditProgressListener(){
                    @Override public void onStage(String st,String msg){
                        db.updateRunStage(activeRunId,st);
                        DiagnosticLog.write(context,"STAGE",st+" — "+msg);
                        CheckStatusStore.activity(context,msg);
                        if(listener!=null)listener.onStage(st,msg);
                    }
                    @Override public void onMeta(int total,int pages){
                        DiagnosticLog.write(context,"META","Операций="+total+", страниц="+pages);
                        if(listener!=null)listener.onMeta(total,pages);
                    }
                    @Override public void onPage(int page,int pages,int loaded,int total){
                        double elapsed=Math.max(1,AuditControlRegistry.activeElapsedMs(startedMs)/1000.0);
                        db.updateRunProgress(activeRunId,"READING_DATA",page,pages,loaded,total,loaded/elapsed,retries[0]);
                        DiagnosticLog.write(context,"PAGE",page+"/"+pages+"; "+loaded+"/"+total);
                        if(listener!=null)listener.onPage(page,pages,loaded,total);
                    }
                    @Override public void onRetry(int page,int attempt,int retrySeconds,String error){
                        retries[0]++;
                        DiagnosticLog.write(context,"RETRY","Страница="+page+", попытка="+attempt+", ожидание="+retrySeconds+"с, ошибка="+error);
                        if(listener!=null)listener.onRetry(page,attempt,retrySeconds,error);
                    }
                };

                client.setStatusListener(wrapped);
                String effectiveMode=mode;
                if(MODE_QUICK.equals(mode)){
                    if(firstDate==null || db.transactions().isEmpty()){
                        stage(wrapped,"BASELINE_REQUIRED","Первый эталон ещё не создан. Выполняю полную первоначальную проверку...");
                        effectiveMode=MODE_FULL;
                    } else {
                        stage(wrapped,"LIGHT","Лёгкая проверка закрытой истории с "+firstDate+" по "+to+"...");
                        LightCheckEngine light=new LightCheckEngine(context,db,client,teamId,wrapped,control,requestAttempts);
                        LightCheckEngine.Outcome out=light.run(firstDate,to,runId,startedMs);
                        if(!out.needFull){
                            db.saveState("last_successful_audit_ms",String.valueOf(System.currentTimeMillis()));
                            db.saveState("last_audit_mode",MODE_QUICK);
                            stage(wrapped,"BACKUP","Создаю резервную копию базы Cubux Security...");
                            try{AutoBackupManager.backupNowBlocking(context);stage(wrapped,"BACKUP_OK","Резервная копия базы сохранена.");}
                            catch(Throwable e){DiagnosticLog.error(context,"AUTO_BACKUP",e);stage(wrapped,"BACKUP_WARNING","Лёгкая проверка завершена, но резервную копию обновить не удалось.");}
                            long finalDuration=AuditControlRegistry.activeElapsedMs(startedMs);
                            db.updateRunDuration(out.result.runId,finalDuration);
                            AuditEngine.Result finalResult=new AuditEngine.Result(out.result.total,out.result.newCount,out.result.changedCount,out.result.deletedCount,out.result.closedChangedCount,out.result.multiChangedCount,out.result.runId,finalDuration);
                            stage(wrapped,"COMPLETED","Лёгкая проверка завершена успешно");
                            return finalResult;
                        }
                        effectiveMode=MODE_FULL;
                        stage(wrapped,"AUTO_FULL","Лёгкая проверка обнаружила причину для полного просмотра: "+out.reason+". Запускаю полную проверку автоматически...");
                    }
                }

                // Full mode. On the very first check no dateSince is sent: Cubux itself defines
                // the beginning of the available history. That earliest returned date becomes
                // the single lower boundary used everywhere in the app.
                String from=range.startDate();
                stage(wrapped,"RANGE",from==null
                        ? "Первая полная проверка: получаю закрытую историю Cubux по "+to+" включительно..."
                        : "Полная проверка закрытой истории с "+from+" по "+to+"...");

                StableHistoryLoader stableLoader=new StableHistoryLoader(context,db,client,teamId,wrapped,control,requestAttempts);
                CubuxLoader.Result loaded=stableLoader.load(from,to);

                String learned=range.learnFrom(loaded.items);
                if(learned==null && loaded.totalCount>0)throw new Exception("Cubux: не удалось определить дату первой операции");
                if(learned!=null)db.saveState("history_range_label",learned+" .. "+to);

                stage(wrapped,"PROCESSING","Проверяю целостность закрытых дней...");
                String analysisStart=learned!=null?learned:from;
                PeriodControlEngine.Result period=new PeriodControlEngine(db).analyze(loaded.items,false,analysisStart,to);
                stage(wrapped,"COMPARING","Сравниваю закрытые дни с локальным эталоном...");

                boolean restoreSync="1".equals(db.getState("restore_sync_pending"));
                AuditEngine.Result result=new AuditEngine(context).audit(
                        loaded.items,loaded.totalCount,runId,period,startedMs,false,analysisStart,to,restoreSync
                );

                stage(wrapped,"CONTROL_BASELINE","Готовлю контрольный эталон для будущей лёгкой проверки...");
                if(analysisStart!=null){
                    LightCheckEngine lightBaseline=new LightCheckEngine(context,db,client,teamId,wrapped,control,requestAttempts);
                    if(stableLoader.getStableControl()!=null){
                        lightBaseline.saveControlBaseline(stableLoader.getStableControl());
                        stage(wrapped,"LIGHT_BASELINE_READY","Контрольный эталон лёгкой проверки сохранён из уже выполненного контроля. Дополнительный проход не нужен.");
                    } else if(stableLoader.getStableMonthlyControl()!=null){
                        db.saveState("light_month_probe",stableLoader.getStableMonthlyControl().toJson());
                        db.saveState("light_month_probe_at",TimeUtil.now());
                        db.saveState("light_summary_supported","0");
                        stage(wrapped,"LIGHT_BASELINE_READY","Месячный контрольный эталон сохранён из текущей полной проверки. Историю повторно не загружаю.");
                    } else {
                        // Emergency path only: no reusable stability snapshot was available.
                        lightBaseline.refreshBaseline(analysisStart,to,result.total);
                    }
                }

                stage(wrapped,"SAVING","Сохраняю итог проверки и историю запусков...");
                db.saveState("last_successful_audit_ms",String.valueOf(System.currentTimeMillis()));
                db.saveState("last_audit_mode",MODE_FULL.equals(mode)?MODE_FULL:"FULL_AFTER_LIGHT");
                stage(wrapped,"BACKUP","Создаю резервную копию базы Cubux Security...");
                try{AutoBackupManager.backupNowBlocking(context);stage(wrapped,"BACKUP_OK","Резервная копия базы сохранена.");}
                catch(Throwable e){DiagnosticLog.error(context,"AUTO_BACKUP",e);stage(wrapped,"BACKUP_WARNING","Проверка завершена, но резервную копию обновить не удалось.");}
                long finalDuration=AuditControlRegistry.activeElapsedMs(startedMs);
                db.updateRunDuration(result.runId,finalDuration);
                result=new AuditEngine.Result(result.total,result.newCount,result.changedCount,result.deletedCount,result.closedChangedCount,result.multiChangedCount,result.runId,finalDuration);
                stage(wrapped,"COMPLETED","Проверка завершена успешно");
                DiagnosticLog.write(context,"CHECK","Успешно. Всего="+result.total+
                        ", новые="+result.newCount+", изменено="+result.changedCount+
                        ", удалено="+result.deletedCount+", режим="+effectiveMode);
                return result;

            }catch(AuditControl.AuditStoppedException e){
                if(runId>=0)db.stopRun(runId);
                DiagnosticLog.write(context,"CHECK","Проверка остановлена пользователем");
                throw e;
            }catch(Exception e){
                if(runId>=0)db.failRun(runId,e.getMessage()==null?e.toString():e.getMessage());
                DiagnosticLog.error(context,"CHECK_ERROR",e);
                throw e;
            }
        }finally{
            AuditControlRegistry.clear(control);
            AuditRunGate.release();
        }
    }

    public AuditEngine.Result runStored(boolean recovery,AuditProgressListener listener)throws Exception{
        return runStoredMode(recovery,listener,MODE_QUICK);
    }

    public AuditEngine.Result runStoredMode(boolean recovery,AuditProgressListener listener,String mode)throws Exception{
        String login=credentials.getLogin(),password=credentials.getPassword();
        if(login.isEmpty()||password.isEmpty())throw new Exception("Логин/пароль Cubux не сохранены");
        return runMode(login,password,recovery,listener,null,mode);
    }

    private String loginResilient(String login,String password,CheckSettings settings,
                                  AuditProgressListener listener,AuditControl control)throws Exception{
        while(true){
            waitForInternet(listener,control);
            try{
                return new CubuxAuthClient(context,settings.requestDelayMs()).login(login,password);
            }catch(Exception e){
                if(NetworkUtil.hasInternet(context))throw e;
                waitForInternet(listener,control);
            }
        }
    }

    private void waitForInternet(AuditProgressListener listener,AuditControl control)throws Exception{
        if(NetworkUtil.hasInternet(context))return;
        long started=System.currentTimeMillis();
        stage(listener,"NO_INTERNET","Нет подключения к интернету. Проверка приостановлена.");
        while(!NetworkUtil.hasInternet(context)){
            if(control!=null)control.checkpoint();
            long sec=Math.max(1L,(System.currentTimeMillis()-started)/1000L);
            if(sec<=5||sec%5==0)stage(listener,"NO_INTERNET","Нет подключения к интернету. Жду восстановления сети… "+sec+" сек.");
            Thread.sleep(1000L);
        }
        stage(listener,"INTERNET_RESTORED","Интернет восстановлен. Продолжаю проверку...");
    }

    private void stage(AuditProgressListener listener,String st,String msg){
        CheckStatusStore.activity(context,msg);
        if(listener!=null)listener.onStage(st,msg);
    }

    public boolean isRecovery(){
        String value=db.getState("last_successful_audit_ms");
        if(value==null)return false;
        try{
            long last=Long.parseLong(value);
            return System.currentTimeMillis()-last>45L*60L*1000L;
        }catch(Exception e){return false;}
    }
}
