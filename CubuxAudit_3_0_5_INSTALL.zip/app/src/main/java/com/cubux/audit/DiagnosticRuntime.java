package com.cubux.audit;

/** Volatile request details for the in-app advanced diagnostics screen. */
public final class DiagnosticRuntime {
    private static volatile int lastHttpCode = 0;
    private static volatile String lastEndpoint = "";
    private static volatile String lastHttpAt = "";
    private DiagnosticRuntime() {}

    public static void http(int code,String url){
        lastHttpCode=code;
        lastEndpoint=sanitize(url);
        lastHttpAt=TimeUtil.now();
    }

    public static String text(){
        if(lastHttpCode<=0) return "Последний HTTP-ответ: ещё нет данных";
        return "Последний HTTP-ответ: "+lastHttpCode+"\n"+
                "Время: "+lastHttpAt+"\n"+
                "Endpoint: "+lastEndpoint;
    }

    private static String sanitize(String url){
        if(url==null)return "";
        String x=url.replaceFirst("^https?://[^/]+","");
        int q=x.indexOf('?');
        if(q<0)return x;
        String path=x.substring(0,q), query=x.substring(q+1);
        StringBuilder out=new StringBuilder(path);
        if(!query.isEmpty()){
            out.append('?');
            String[] parts=query.split("&");
            for(int i=0;i<parts.length;i++){
                if(i>0)out.append('&');
                int eq=parts[i].indexOf('=');
                out.append(eq<0?parts[i]:parts[i].substring(0,eq)+"=<…>");
            }
        }
        return out.toString();
    }
}
