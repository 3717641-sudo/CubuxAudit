package com.cubux.audit;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class DiagnosticsActivity extends Activity {
    private final int TEXT=Color.rgb(26,34,48);
    private final int MUTED=Color.rgb(95,110,135);
    private TextView content;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(14),dp(16),dp(20));
        root.setBackgroundColor(Color.rgb(245,248,252));

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        Button back=new Button(this);back.setText("← Назад");back.setAllCaps(false);back.setOnClickListener(v->finish());
        TextView title=text("Расширенная диагностика",21,true,TEXT);
        LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);tlp.setMargins(dp(8),0,0,0);
        top.addView(back,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(46)));
        top.addView(title,tlp);root.addView(top);

        TextView note=text("Технические данные для поиска ошибок. ID операций скрыт в обычном журнале и показывается только здесь.",13,false,MUTED);
        note.setPadding(0,dp(8),0,dp(10));root.addView(note);

        Button refresh=new Button(this);refresh.setText("Обновить данные");refresh.setAllCaps(false);refresh.setOnClickListener(v->refresh());
        root.addView(refresh,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46)));

        ScrollView scroll=new ScrollView(this);
        content=text("",13,false,TEXT);content.setTextIsSelectable(true);content.setPadding(0,dp(12),0,dp(24));
        scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        setContentView(root);refresh();
    }

    private void refresh(){
        AuditDb db=new AuditDb(this);
        StringBuilder s=new StringBuilder();
        s.append("ТЕКУЩАЯ / ПОСЛЕДНЯЯ ПРОВЕРКА\n\n");
        s.append(db.diagnosticsSummaryText()).append("\n\n");
        s.append("СЕТЕВАЯ ДИАГНОСТИКА\n\n");
        s.append(DiagnosticRuntime.text()).append("\n\n");
        s.append("ПОСЛЕДНИЕ ИЗМЕНЕНИЯ — ТЕХНИЧЕСКИЕ ДАННЫЕ\n\n");
        s.append(db.diagnosticChangesText(100)).append("\n\n");
        s.append("ДИАГНОСТИЧЕСКИЙ ЛОГ\n\n");
        s.append(DiagnosticLog.read(this));
        content.setText(s.toString());
    }

    private TextView text(String value,int size,boolean bold,int color){
        TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
