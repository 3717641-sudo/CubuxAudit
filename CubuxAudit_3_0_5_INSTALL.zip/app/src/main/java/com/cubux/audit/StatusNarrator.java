package com.cubux.audit;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Builds concise, six-line user-facing explanations for every audit stage. */
public final class StatusNarrator {
    private static final Pattern MONTH = Pattern.compile("(\\d+)\\s+из\\s+(\\d+).*?(\\d{4}-\\d{2})");
    private StatusNarrator() {}

    public static String action(String stage, String message) {
        String s = safe(stage);
        if ("START".equals(s)) return "Подготавливаю проверку";
        if ("AUTHENTICATING".equals(s)) return "Подключаюсь к Cubux";
        if ("REAUTHENTICATING".equals(s)) return "Обновляю авторизацию Cubux";
        if ("TEAM".equals(s)) return "Получаю данные команды Cubux";
        if ("BASELINE_REQUIRED".equals(s)) return "Создаю первоначальный эталон";
        if ("LIGHT".equals(s)) return "Запускаю лёгкую проверку";
        if ("LIGHT_META".equals(s)) return "Сверяю количество операций";
        if ("LIGHT_SUMMARY".equals(s)) return "Получаю контрольные данные истории";
        if ("LIGHT_MONTHLY".equals(s) || "MONTHLY_CONTROL".equals(s)) return "Сверяю историю по месяцам";
        if ("LIGHT_BASELINE_MIGRATION".equals(s) || "LIGHT_BASELINE_MONTHLY".equals(s)) return "Создаю контрольный эталон лёгкой проверки";
        if ("LIGHT_MISMATCH".equals(s)) return "Определяю проблемный период";
        if ("LIGHT_DEEP".equals(s)) return "Подробно проверяю изменившийся период";
        if ("AUTO_FULL".equals(s)) return "Перехожу к полной проверке";
        if ("RANGE".equals(s)) return "Определяю диапазон полной проверки";
        if ("STABILITY_START".equals(s)) return "Подготавливаю контроль стабильности";
        if ("MONTHLY_CONTROL_START".equals(s)) return "Подготавливаю контроль истории по месяцам";
        if ("LOADING_META".equals(s)) return "Определяю объём данных Cubux";
        if ("READING_DATA".equals(s)) return "Читаю операции из Cubux";
        if ("WAITING_CUBUX".equals(s)) return "Жду ответ Cubux";
        if ("SERVER_COOLDOWN".equals(s)) return "Соблюдаю защитную паузу Cubux";
        if ("NO_INTERNET".equals(s)) return "Жду восстановления интернета";
        if ("INTERNET_RESTORED".equals(s)) return "Интернет восстановлен — продолжаю проверку";
        if ("RETRY_WAIT".equals(s)) return "Жду перед повторной попыткой";
        if ("RECONNECTING".equals(s)) return "Повторно подключаюсь к Cubux";
        if ("AUTH_ERROR".equals(s)) return "Ошибка авторизации Cubux";
        if ("PERMANENT_ERROR".equals(s)) return "Cubux вернул постоянную ошибку";
        if ("READ_COMPLETE".equals(s)) return "Основная загрузка завершена";
        if ("STABILITY_VERIFY".equals(s)) return "Проверяю стабильность истории";
        if ("MONTHLY_CONTROL_VERIFY".equals(s)) return "Сверяю месячные контрольные отпечатки";
        if ("MONTHLY_CONTROL_SWITCH".equals(s)) return "Перехожу на контроль истории по месяцам";
        if ("HISTORY_MOVED".equals(s)) return "Обнаружено изменение закрытой истории";
        if ("HISTORY_RESCAN".equals(s)) return "Перечитываю только изменившийся период";
        if ("STABILITY_WAIT".equals(s)) return "Жду стабилизации изменившегося периода";
        if ("STABILITY_FALLBACK".equals(s) || "STABILITY_FALLBACK_SCAN".equals(s) || "STABILITY_EMERGENCY".equals(s)) return "Выполняю аварийный контроль стабильности";
        if ("STABILITY_OK".equals(s)) return "История подтверждена как стабильная";
        if ("PROCESSING".equals(s)) return "Проверяю целостность закрытых дней";
        if ("CLOSE_EMPTY_DAYS".equals(s)) return "Фиксирую новые закрытые дни без операций";
        if ("COMPARING".equals(s) || "CHECKING_HISTORY".equals(s)) return "Сравниваю операции с локальным эталоном";
        if ("CONTROL_BASELINE".equals(s) || "LIGHT_BASELINE_REFRESH".equals(s) || "LIGHT_BASELINE_READY".equals(s)) return "Обновляю контрольный эталон";
        if ("SAVING".equals(s)) return "Сохраняю результаты проверки";
        if ("BACKUP".equals(s)) return "Создаю резервную копию базы";
        if ("BACKUP_OK".equals(s)) return "Резервная копия сохранена";
        if ("BACKUP_WARNING".equals(s)) return "Проверка завершена, но backup требует внимания";
        if ("CREATING_REPORT".equals(s)) return "Формирую итог проверки";
        if ("LIGHT_NO_CHANGES".equals(s)) return "Лёгкая проверка не нашла расхождений";
        if ("COMPLETED".equals(s)) return "Проверка завершена успешно";
        if ("STOPPING".equals(s)) return "Останавливаю проверку";
        if ("STOPPED".equals(s)) return "Проверка остановлена";
        return !safe(message).isEmpty() ? compact(message, 68) : "Проверка выполняется";
    }

    public static String stageLabel(String stage) {
        String s=safe(stage);
        if (s.startsWith("AUTH") || "TEAM".equals(s) || "REAUTHENTICATING".equals(s)) return "Подключение к Cubux";
        if (s.startsWith("LIGHT")) return "Лёгкая проверка";
        if (s.contains("MONTHLY")) return "Контроль по месяцам";
        if (s.contains("STABILITY") || s.contains("HISTORY")) return "Контроль стабильности";
        if (s.contains("READ") || s.contains("LOAD") || "WAITING_CUBUX".equals(s)) return "Чтение данных";
        if (s.contains("PROCESS") || s.contains("COMPAR") || s.contains("CLOSE_EMPTY")) return "Сравнение с эталоном";
        if (s.contains("BASELINE")) return "Контрольный эталон";
        if (s.contains("BACKUP")) return "Резервная копия";
        if ("SAVING".equals(s)) return "Сохранение";
        if ("NO_INTERNET".equals(s) || "INTERNET_RESTORED".equals(s) || "RETRY_WAIT".equals(s) || "RECONNECTING".equals(s) || "SERVER_COOLDOWN".equals(s)) return "Соединение";
        if ("COMPLETED".equals(s)) return "Готово";
        if ("STOPPING".equals(s) || "STOPPED".equals(s)) return "Остановка";
        return "Проверка";
    }

    public static String progress(String stage, String message, int page, int pages, int loaded, int total) {
        String s=safe(stage);
        Matcher m=MONTH.matcher(safe(message));
        if(m.find()) return "месяц "+m.group(1)+" из "+m.group(2)+" • "+m.group(3);
        if (pages>0 || total>0) {
            if (total>0 && pages>0) return loaded+" из "+total+" операций • страница "+page+" из "+pages;
            if (pages>0) return "страница "+page+" из "+pages;
            return loaded+" из "+total+" операций";
        }
        if ("LIGHT_NO_CHANGES".equals(s)) return "подробная загрузка не требуется";
        if ("COMPLETED".equals(s)) return "100%";
        if ("NO_INTERNET".equals(s)) return "прогресс сохранён";
        if ("SAVING".equals(s)) return "защищённая запись в локальную базу";
        if ("BACKUP".equals(s)) return "копирование локальной базы";
        return "текущий этап выполняется";
    }

    public static String sixLines(String stage, String message, String auxiliary,
                                  int page, int pages, int loaded, int total,
                                  String delayLabel, String elapsed, String lastActivity,
                                  boolean paused) {
        if (paused) {
            return "Сейчас: проверка поставлена на паузу\n"+
                    "Этап: "+stageLabel(stage)+"\n"+
                    "Прогресс: "+progress(stage,message,page,pages,loaded,total)+"\n"+
                    "Скорость: "+safeOr(delayLabel,"—")+"\n"+
                    "Прошло: "+safeOr(elapsed,"00:00")+" • таймер остановлен\n"+
                    "Состояние: нажмите «Продолжить» для возобновления";
        }
        String state = !safe(auxiliary).isEmpty() ? auxiliary : message;
        if (safe(state).isEmpty()) state="работа продолжается";
        return "Сейчас: "+action(stage,message)+"\n"+
                "Этап: "+stageLabel(stage)+"\n"+
                "Прогресс: "+progress(stage,message,page,pages,loaded,total)+"\n"+
                "Скорость: "+safeOr(delayLabel,"—")+"\n"+
                "Прошло: "+safeOr(elapsed,"00:00")+"\n"+
                "Состояние: "+compact(state,82)+(safe(lastActivity).isEmpty()?"":" • "+lastActivity);
    }

    public static String notification(String stage,String message,String auxiliary,
                                      int page,int pages,int loaded,int total,String elapsed){
        String state=!safe(auxiliary).isEmpty()?auxiliary:message;
        return action(stage,message)+"\n"+
                "Прогресс: "+progress(stage,message,page,pages,loaded,total)+"\n"+
                "Прошло: "+safeOr(elapsed,"00:00")+
                (safe(state).isEmpty()?"":"\n"+compact(state,95));
    }

    public static boolean isAuxiliaryStage(String stage){
        return "GENTLE_WAIT".equals(stage);
    }

    private static String safe(String x){return x==null?"":x.trim();}
    private static String safeOr(String x,String d){return safe(x).isEmpty()?d:x.trim();}
    private static String compact(String x,int max){
        String s=safe(x).replace('\n',' ').replaceAll("\\s+"," ");
        return s.length()<=max?s:s.substring(0,Math.max(1,max-1))+"…";
    }
}
