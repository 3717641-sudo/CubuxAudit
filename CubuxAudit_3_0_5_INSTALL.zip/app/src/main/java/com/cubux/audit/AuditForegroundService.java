package com.cubux.audit;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.os.IBinder;

public class AuditForegroundService extends Service {
    public static final String CHANNEL="cubux_audit_running";
    public static final int ID=2601;
    public static volatile int percent=0, page=0, pages=0, loaded=0, total=0;
    public static volatile String state="Подготовка проверки";
    private static volatile long updatedAt=0L;
    private static volatile long startedAtMs=0L;

    public static final class Snapshot {
        public final int percent,page,pages,loaded,total;
        public final String state;
        public final long updatedAt,elapsedMs;
        Snapshot(int percent,int page,int pages,int loaded,int total,String state,long updatedAt,long elapsedMs){
            this.percent=percent;this.page=page;this.pages=pages;this.loaded=loaded;this.total=total;
            this.state=state;this.updatedAt=updatedAt;this.elapsedMs=elapsedMs;
        }
    }

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(ID, buildNotification());
        return START_STICKY;
    }

    public static void start(Context c) {
        Intent i=new Intent(c, AuditForegroundService.class);
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i); else c.startService(i);
    }

    public static void stop(Context c) {
        try { c.stopService(new Intent(c, AuditForegroundService.class)); } catch(Throwable ignored){}
    }

    public static synchronized void update(Context c,String st,int pct,int pg,int pgs,int ld,int ttl) {
        state=st==null?state:st;
        percent=Math.max(percent,pct);
        if(pg>=0) page=pg;
        if(pgs>=0) pages=pgs;
        if(ld>=0) loaded=ld;
        if(ttl>=0) total=ttl;
        updatedAt=System.currentTimeMillis();
        try {
            NotificationManager m=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            if(m!=null)m.notify(ID, buildStatic(c));
        } catch(Throwable ignored){}
    }

    public static synchronized Snapshot snapshot() {
        long elapsed = startedAtMs <= 0L ? 0L : AuditControlRegistry.activeElapsedMs(startedAtMs);
        return new Snapshot(percent,page,pages,loaded,total,state,updatedAt,elapsed);
    }

    public static synchronized void reset() { reset(System.currentTimeMillis()); }

    public static synchronized void reset(long startedAt) {
        percent=page=pages=loaded=total=0;
        state="Подготовка проверки";
        startedAtMs=startedAt > 0L ? startedAt : System.currentTimeMillis();
        updatedAt=System.currentTimeMillis();
    }

    /** Reset per-pass page counters without moving the global percent backwards. */
    public static synchronized void resetPageProgress() {
        page=0; pages=0; loaded=0; total=0;
        updatedAt=System.currentTimeMillis();
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager m=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            if(m!=null){
                NotificationChannel ch=new NotificationChannel(CHANNEL,"Текущая проверка",NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Прогресс выполняющейся проверки Cubux");
                m.createNotificationChannel(ch);
            }
        }
    }

    private Notification buildNotification(){ return buildStatic(this); }

    private static Notification buildStatic(Context c){
        Snapshot s=snapshot();
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent content=PendingIntent.getActivity(c,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent pause=action(c,"PAUSE",2);
        PendingIntent resume=action(c,"RESUME",3);
        PendingIntent stop=action(c,"STOP",4);

        Notification.Builder b=Build.VERSION.SDK_INT>=26?
                new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
        String progress= s.total>0 ? s.loaded+" из "+s.total+" • страница "+s.page+" из "+s.pages : "Этап выполняется";
        String elapsed="Прошло: "+TimeUtil.formatDuration(s.elapsedMs);
        b.setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("Cubux Security — "+s.percent+"%")
                .setContentText(progress+" • "+elapsed)
                .setStyle(new Notification.BigTextStyle().bigText(s.state+"\n"+progress+"\n"+elapsed))
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(content)
                .setProgress(100,Math.min(100,s.percent),false)
                .addAction(new Notification.Action.Builder(null,"Пауза",pause).build())
                .addAction(new Notification.Action.Builder(null,"Продолжить",resume).build())
                .addAction(new Notification.Action.Builder(null,"Стоп",stop).build());
        return b.build();
    }

    private static PendingIntent action(Context c,String a,int code){
        Intent i=new Intent(c,AuditActionReceiver.class).setAction("com.cubux.audit."+a);
        return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }

    @Override public IBinder onBind(Intent intent){return null;}
}
