package com.cubux.audit;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;

/** Read-only Cubux HTTP client with explicit network/server error classification. */
public class CubuxClient {

    public static class NoInternetException extends IOException {
        public NoInternetException(String message, Throwable cause) { super(message, cause); }
        public NoInternetException(String message) { super(message); }
    }

    public interface TokenRefresher {
        String refreshToken() throws Exception;
    }

    private final Context context;
    private String token;
    private final TokenRefresher refresher;
    private final AuditControl control;
    private final long requestDelayMs;
    private AuditProgressListener statusListener;

    private long currentRequestDelayMs() {
        if (context == null) return requestDelayMs;
        try { return new CheckSettings(context).requestDelayMs(); }
        catch (Throwable ignored) { return requestDelayMs; }
    }

    public void setStatusListener(AuditProgressListener listener) { statusListener = listener; }

    public CubuxClient(String token, TokenRefresher refresher) {
        this(null, token, refresher, null, 5000L);
    }

    public CubuxClient(String token, TokenRefresher refresher, AuditControl control) {
        this(null, token, refresher, control, 5000L);
    }

    public CubuxClient(String token, TokenRefresher refresher, AuditControl control, long requestDelayMs) {
        this(null, token, refresher, control, requestDelayMs);
    }

    public CubuxClient(Context context, String token, TokenRefresher refresher,
                       AuditControl control, long requestDelayMs) {
        this.context = context == null ? null : context.getApplicationContext();
        this.token = token;
        this.refresher = refresher;
        this.control = control;
        this.requestDelayMs = DelayProfile.clamp(requestDelayMs);
    }

    public CubuxClient(String token) {
        this(null, token, null, null, 5000L);
    }

    public boolean hasInternet() {
        return context == null || NetworkUtil.hasInternet(context);
    }

    public String get(String urlString) throws IOException {
        while (true) {
            try {
                return getInternal(urlString, true);
            } catch (NoInternetException e) {
                waitForInternet();
            }
        }
    }

    private void waitForInternet() throws IOException {
        long started = System.currentTimeMillis();
        stage("NO_INTERNET", "Нет подключения к интернету. Проверка приостановлена.");
        while (!hasInternet()) {
            try {
                if (control != null) control.checkpoint();
                long sec = Math.max(1L, (System.currentTimeMillis() - started) / 1000L);
                if (sec <= 5 || sec % 5 == 0) {
                    stage("NO_INTERNET", "Нет подключения к интернету. Жду восстановления сети… " + sec + " сек.");
                }
                Thread.sleep(1000L);
            } catch (AuditControl.AuditStoppedException e) {
                throw new IOException(e.getMessage(), e);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("Проверка прервана", e);
            }
        }
        stage("INTERNET_RESTORED", "Интернет восстановлен. Продолжаю проверку...");
    }

    private void stage(String stage, String message) {
        if (statusListener != null) statusListener.onStage(stage, message);
    }

    private String getInternal(String urlString, boolean allowRefresh) throws IOException {
        HttpURLConnection connection = null;
        boolean acquired = false;
        long started = 0L;
        boolean receivedResponse = false;
        try {
            if (!hasInternet()) throw new NoInternetException("NO_INTERNET: нет подключения к интернету");

            GentleServerGate.begin(control, statusListener);
            acquired = true;
            started = System.nanoTime();

            // Network could disappear while waiting in the request gate.
            if (!hasInternet()) throw new NoInternetException("NO_INTERNET: нет подключения к интернету");

            connection = (HttpURLConnection) new URL(urlString).openConnection();
            final HttpURLConnection activeConnection = connection;
            final Runnable cancelAction = () -> {
                try { activeConnection.disconnect(); } catch (Throwable ignored) {}
            };

            if (control != null) {
                control.setCancelAction(cancelAction);
                try {
                    control.checkpoint();
                } catch (AuditControl.AuditStoppedException e) {
                    cancelAction.run();
                    throw new IOException(e.getMessage());
                }
            }

            connection.setRequestMethod("GET");
            connection.setRequestProperty("Authorization", "Bearer " + token);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/153.0 Mobile Safari/537.36");
            connection.setConnectTimeout(30000);
            connection.setReadTimeout(60000);
            connection.setInstanceFollowRedirects(true);

            int code = connection.getResponseCode();
            DiagnosticRuntime.http(code, urlString);
            receivedResponse = true;
            GentleServerGate.response(code, connection.getHeaderField("Retry-After"));

            if (code == 401 && allowRefresh && refresher != null) {
                connection.disconnect();
                connection = null;
                GentleServerGate.end(started, currentRequestDelayMs());
                acquired = false;
                try {
                    String fresh = refresher.refreshToken();
                    if (fresh == null || fresh.trim().isEmpty()) {
                        throw new IOException("Cubux HTTP 401: токен не обновлён");
                    }
                    token = fresh.trim();
                    return getInternal(urlString, false);
                } catch (IOException e) {
                    throw e;
                } catch (Exception e) {
                    throw new IOException("Cubux HTTP 401: повторная авторизация не удалась. " + e.getMessage());
                }
            }

            if (code == 401) throw new IOException("Cubux HTTP 401: ошибка авторизации");
            if (code == 403) throw new IOException("Cubux HTTP 403: доступ запрещён");
            if (code == 429) throw new IOException("Cubux HTTP 429: временное ограничение частоты запросов");
            if (code != 200) throw new IOException("Cubux HTTP " + code);

            InputStream input = connection.getInputStream();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int length;
            while ((length = input.read(buffer)) != -1) output.write(buffer, 0, length);
            input.close();
            return output.toString("UTF-8");

        } catch (NoInternetException e) {
            throw e;
        } catch (UnknownHostException e) {
            if (!hasInternet()) throw new NoInternetException("NO_INTERNET: нет подключения к интернету", e);
            GentleServerGate.failure();
            throw new IOException("DNS: интернет есть, но имя app.cubux.net не разрешается", e);
        } catch (SocketTimeoutException e) {
            if (!hasInternet()) throw new NoInternetException("NO_INTERNET: нет подключения к интернету", e);
            GentleServerGate.failure();
            throw new IOException("TIMEOUT: Cubux не отвечает", e);
        } catch (IOException e) {
            if (!hasInternet() && (control == null || !control.isStopped())) {
                throw new NoInternetException("NO_INTERNET: нет подключения к интернету", e);
            }
            if (acquired && !receivedResponse && (control == null || !control.isStopped())) {
                GentleServerGate.failure();
            }
            throw e;
        } finally {
            if (connection != null) {
                if (control != null) control.setCancelAction(null);
                connection.disconnect();
            }
            if (acquired) GentleServerGate.end(started, currentRequestDelayMs());
        }
    }
}
