Cubux Audit 2.1.2 SAFE START

Purpose:
- launch reliably without Termux;
- remove WorkManager and AndroidX startup initialization from this build;
- keep Cubux login/password automatic token flow;
- keep audit, database, reports, journal, bank reconciliation, backups and UI;
- background automatic audit is temporarily disabled until startup stability is confirmed.

After successful launch we can restore background audit using a separate Android-native scheduling layer.
