package com.cubux.audit;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PeriodControlEngine {
    private final AuditDb db;
    public PeriodControlEngine(AuditDb db) { this.db = db; }

    public Result analyze(List<JSONObject> items) throws Exception {
        Map<String, List<JSONObject>> byDate = new HashMap<>();
        for (JSONObject item : items) {
            String date = date(item);
            if (date != null) byDate.computeIfAbsent(date, k -> new ArrayList<>()).add(item);
        }

        Set<String> detailed = new HashSet<>();
        detailed.add(TimeUtil.today());
        int changed = 0;

        for (Map.Entry<String, List<JSONObject>> entry : byDate.entrySet()) {
            String date = entry.getKey();
            if (date.equals(TimeUtil.today())) continue;
            Snap snap = snap(entry.getValue());
            AuditDb.Closure old = db.closure(date);
            if (old == null) {
                db.createClosure(date, snap.count, snap.income, snap.expense,
                        snap.currencies, snap.hash, snap.baseline);
                detailed.add(date);
            } else if (!old.hash.equals(snap.hash)) {
                db.markClosureChanged(date);
                detailed.add(date);
                changed++;
            }
        }

        // Important: a closed day can disappear completely. It must still be
        // compared so DELETED transactions are never silently discarded.
        for (String oldDate : db.closureDates()) {
            if (!oldDate.equals(TimeUtil.today()) && !byDate.containsKey(oldDate)) {
                db.markClosureChanged(oldDate);
                detailed.add(oldDate);
                changed++;
            }
        }

        return new Result(detailed, changed);
    }

    private Snap snap(List<JSONObject> items) throws Exception {
        List<String> normalized = new ArrayList<>();
        JSONArray baseline = new JSONArray();
        double income = 0;
        double expense = 0;
        Map<String, Double> currencies = new HashMap<>();

        for (JSONObject item : items) {
            JSONObject x = AuditEngine.normalizeRecord(item);
            normalized.add(x.toString());
            baseline.put(x);
            double amount = x.optDouble("amount", 0);
            if (amount >= 0) income += amount; else expense += Math.abs(amount);
            String currency = x.optString("currency_code", "");
            currencies.put(currency, currencies.getOrDefault(currency, 0.0) + amount);
        }

        Collections.sort(normalized);
        StringBuilder source = new StringBuilder();
        for (String row : normalized) source.append(row).append('\n');

        JSONObject cur = new JSONObject();
        for (Map.Entry<String, Double> e : currencies.entrySet()) cur.put(e.getKey(), e.getValue());
        return new Snap(items.size(), income, expense, cur.toString(),
                HashUtil.sha256(source.toString()), baseline.toString());
    }

    private String date(JSONObject o) {
        String d = o.optString("date", "");
        return d.length() >= 10 ? d.substring(0, 10) : null;
    }

    static class Snap {
        int count; double income, expense; String currencies, hash, baseline;
        Snap(int count, double income, double expense, String currencies, String hash, String baseline) {
            this.count=count; this.income=income; this.expense=expense;
            this.currencies=currencies; this.hash=hash; this.baseline=baseline;
        }
    }

    public static class Result {
        public final Set<String> detailedDates;
        public final int closedChangedCount;
        Result(Set<String> detailedDates, int closedChangedCount) {
            this.detailedDates=detailedDates; this.closedChangedCount=closedChangedCount;
        }
    }
}
