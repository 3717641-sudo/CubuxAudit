package com.cubux.audit;
import java.io.*; import java.net.*;
public class CubuxClient {
 private final String token; public CubuxClient(String t){token=t;}
 public String get(String u)throws IOException{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("GET");c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/json");c.setConnectTimeout(30000);c.setReadTimeout(60000);int code=c.getResponseCode();if(code!=200)throw new IOException("Cubux HTTP "+code);InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}catch(UnknownHostException e){throw new IOException("DNS: нет соединения с app.cubux.net");}catch(SocketTimeoutException e){throw new IOException("TIMEOUT: Cubux не отвечает");}finally{if(c!=null)c.disconnect();}}
}
