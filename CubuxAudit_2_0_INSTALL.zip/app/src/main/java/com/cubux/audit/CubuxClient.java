package com.cubux.audit;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;

public class CubuxClient {

    public interface TokenRefresher {
        String refreshToken()
                throws Exception;
    }

    private String token;
    private final TokenRefresher refresher;

    public CubuxClient(
            String token,
            TokenRefresher refresher
    ) {
        this.token = token;
        this.refresher = refresher;
    }

    public CubuxClient(
            String token
    ) {
        this(token, null);
    }

    public String get(
            String urlString
    ) throws IOException {
        return getInternal(
                urlString,
                true
        );
    }

    private String getInternal(
            String urlString,
            boolean allowRefresh
    ) throws IOException {

        HttpURLConnection connection =
                null;

        try {
            connection =
                    (HttpURLConnection)
                            new URL(
                                    urlString
                            ).openConnection();

            connection.setRequestMethod("GET");
            connection.setRequestProperty(
                    "Authorization",
                    "Bearer " + token
            );
            connection.setRequestProperty(
                    "Accept",
                    "application/json"
            );
            connection.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/153.0 Mobile Safari/537.36"
            );

            connection.setConnectTimeout(30000);
            connection.setReadTimeout(60000);
            connection.setInstanceFollowRedirects(true);

            int code =
                    connection.getResponseCode();

            if (code == 401 &&
                    allowRefresh &&
                    refresher != null) {

                try {
                    String fresh =
                            refresher.refreshToken();

                    if (fresh == null ||
                            fresh.trim().isEmpty()) {
                        throw new IOException(
                                "Cubux HTTP 401: токен не обновлён"
                        );
                    }

                    token = fresh.trim();
                    connection.disconnect();

                    return getInternal(
                            urlString,
                            false
                    );

                } catch (IOException e) {
                    throw e;

                } catch (Exception e) {
                    throw new IOException(
                            "Cubux HTTP 401: повторная авторизация не удалась. " +
                                    e.getMessage()
                    );
                }
            }

            if (code != 200) {
                throw new IOException(
                        "Cubux HTTP " + code
                );
            }

            InputStream input =
                    connection.getInputStream();

            ByteArrayOutputStream output =
                    new ByteArrayOutputStream();

            byte[] buffer =
                    new byte[8192];

            int length;

            while ((length =
                    input.read(buffer)) != -1) {
                output.write(
                        buffer,
                        0,
                        length
                );
            }

            input.close();
            return output.toString("UTF-8");

        } catch (UnknownHostException e) {
            throw new IOException(
                    "DNS: не найден app.cubux.net"
            );

        } catch (SocketTimeoutException e) {
            throw new IOException(
                    "TIMEOUT: Cubux не отвечает"
            );

        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
