package com.cubux.audit;

/** Thread-safe manual audit controller used by UI and loader. */
public final class AuditControl {
    private final Object lock = new Object();
    private volatile boolean paused;
    private volatile boolean stopped;

    public void pause() {
        paused = true;
    }

    public void resume() {
        synchronized (lock) {
            paused = false;
            lock.notifyAll();
        }
    }

    public void stop() {
        synchronized (lock) {
            stopped = true;
            paused = false;
            lock.notifyAll();
        }
    }

    public boolean isPaused() { return paused; }
    public boolean isStopped() { return stopped; }

    public void checkpoint() throws AuditStoppedException {
        if (stopped) throw new AuditStoppedException();
        synchronized (lock) {
            while (paused && !stopped) {
                try {
                    lock.wait(500L);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new AuditStoppedException();
                }
            }
        }
        if (stopped) throw new AuditStoppedException();
    }

    public static final class AuditStoppedException extends Exception {
        public AuditStoppedException() {
            super("Аудит остановлен пользователем");
        }
    }
}
