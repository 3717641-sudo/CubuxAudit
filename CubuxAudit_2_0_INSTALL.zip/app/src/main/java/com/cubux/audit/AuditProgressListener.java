package com.cubux.audit;
public interface AuditProgressListener {
 void onStage(String stage,String message);
 void onMeta(int total,int pages);
 void onPage(int page,int pages,int loaded,int total);
 void onRetry(int page,int attempt,int retrySeconds,String error);
}
