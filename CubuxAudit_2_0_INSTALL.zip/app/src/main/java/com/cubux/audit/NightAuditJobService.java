package com.cubux.audit;

import android.app.job.JobParameters;
import android.app.job.JobService;

public class NightAuditJobService extends JobService {
    private volatile boolean cancelled;

    @Override public boolean onStartJob(JobParameters params){
        new Thread(()->{
            boolean retry=false;
            try{
                DiagnosticLog.write(getApplicationContext(),"NIGHT","Ночной аудит 00:01 запущен");
                AuditCoordinator c=new AuditCoordinator(getApplicationContext());
                c.runStoredMode(c.isRecovery(),null,AuditCoordinator.MODE_FULL);
                new AuditDb(getApplicationContext()).saveState("last_night_audit_date",TimeUtil.today());
                NotificationHelper.showAuditResult(getApplicationContext(),true,
                        "Ночной аудит завершён. Вчерашний день зафиксирован.");
            }catch(Exception e){
                String msg=e.getMessage()==null?e.toString():e.getMessage();
                retry=!msg.contains("Логин/пароль Cubux не сохранены");
                DiagnosticLog.error(getApplicationContext(),"NIGHT_ERROR",e);
                if(!msg.contains("Другой аудит уже выполняется"))
                    NotificationHelper.showAuditResult(getApplicationContext(),false,"Ночной аудит отложен: "+msg);
            }finally{
                NightAuditScheduler.schedule(getApplicationContext());
                if(!cancelled)jobFinished(params,retry);
            }
        }).start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params){
        cancelled=true;
        return true;
    }
}
