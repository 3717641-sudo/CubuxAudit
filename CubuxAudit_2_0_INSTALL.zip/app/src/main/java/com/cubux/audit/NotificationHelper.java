package com.cubux.audit;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

public final class NotificationHelper {

    private static final String CHANNEL = "cubux_audit_status";

    private NotificationHelper() {}

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            NotificationChannel channel = new NotificationChannel(
                    CHANNEL,
                    "Cubux Audit",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Результаты автоматического аудита Cubux");
            manager.createNotificationChannel(channel);
        }
    }

    public static void showAuditResult(
            Context context,
            boolean success,
            String text
    ) {
        try {
            ensureChannel(context);

            if (Build.VERSION.SDK_INT >= 33 &&
                    context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            NotificationManager manager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            android.app.Notification.Builder builder =
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                            ? new android.app.Notification.Builder(context, CHANNEL)
                            : new android.app.Notification.Builder(context);

            builder.setSmallIcon(android.R.drawable.ic_popup_sync)
                    .setContentTitle(success
                            ? "Cubux Audit — проверка завершена"
                            : "Cubux Audit — проверка отложена")
                    .setContentText(text)
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(text))
                    .setAutoCancel(true);

            manager.notify(2202, builder.build());

        } catch (Throwable ignored) {
        }
    }
}
