package com.cubux.audit;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import java.util.Calendar;

public final class NightAuditScheduler {
    private static final int JOB_ID=2604;
    private NightAuditScheduler(){}

    public static long next001Ms(){
        Calendar now=Calendar.getInstance();
        Calendar next=(Calendar)now.clone();
        next.set(Calendar.HOUR_OF_DAY,0);
        next.set(Calendar.MINUTE,1);
        next.set(Calendar.SECOND,0);
        next.set(Calendar.MILLISECOND,0);
        if(!next.after(now))next.add(Calendar.DAY_OF_YEAR,1);
        return next.getTimeInMillis();
    }

    public static boolean schedule(Context context){
        try{
            long target=next001Ms();
            long delay=Math.max(1000L,target-System.currentTimeMillis());
            JobInfo job=new JobInfo.Builder(JOB_ID,new ComponentName(context,NightAuditJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setMinimumLatency(delay)
                    .setOverrideDeadline(delay+15L*60L*1000L)
                    .setPersisted(true)
                    .build();
            JobScheduler js=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if(js==null)return false;
            js.cancel(JOB_ID);
            int r=js.schedule(job);
            if(r==JobScheduler.RESULT_SUCCESS){
                new AuditDb(context).saveState("next_night_audit_ms",String.valueOf(target));
                return true;
            }
        }catch(Throwable e){
            DiagnosticLog.error(context,"NIGHT_SCHEDULE",e);
        }
        return false;
    }
}
