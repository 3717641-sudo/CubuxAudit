package com.cubux.audit;
import android.content.Context;import androidx.annotation.NonNull;import androidx.work.*;
public class AuditWorker extends Worker{
 public AuditWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull public Result doWork(){try{String token=new SecureTokenStore(getApplicationContext()).load();if(token.isEmpty())return Result.success();AuditCoordinator a=new AuditCoordinator(getApplicationContext());a.run(token,a.isRecovery(),null);return Result.success();}catch(Exception e){return Result.retry();}}
}
