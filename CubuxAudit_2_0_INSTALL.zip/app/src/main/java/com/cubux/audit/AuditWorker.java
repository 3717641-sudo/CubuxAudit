package com.cubux.audit;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class AuditWorker
        extends Worker {

    public AuditWorker(
            @NonNull Context context,
            @NonNull WorkerParameters params
    ) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            AuditCoordinator coordinator =
                    new AuditCoordinator(
                            getApplicationContext()
                    );

            coordinator.runStored(
                    coordinator.isRecovery(),
                    null
            );

            return Result.success();

        } catch (Exception e) {
            String message =
                    e.getMessage() == null
                            ? ""
                            : e.getMessage();

            if (message.contains(
                    "Логин/пароль Cubux не сохранены"
            )) {
                return Result.success();
            }

            return Result.retry();
        }
    }
}
