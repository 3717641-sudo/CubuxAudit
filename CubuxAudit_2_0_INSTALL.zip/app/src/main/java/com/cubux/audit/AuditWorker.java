package com.cubux.audit;

/**
 * Background scheduling is temporarily disabled in the safe-start build.
 * The application remains fully standalone and does not require Termux.
 */
public final class AuditWorker {
    private AuditWorker() {}
}
