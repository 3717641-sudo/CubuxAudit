package com.cubux.audit;
import android.content.*; import android.security.keystore.*; import android.util.Base64; import java.nio.charset.StandardCharsets; import java.security.KeyStore; import javax.crypto.*; import javax.crypto.spec.GCMParameterSpec;
public class SecureTokenStore {
 private static final String A="cubux_audit_token_key",P="cubux_secure"; private final SharedPreferences prefs;
 public SecureTokenStore(Context c){prefs=c.getSharedPreferences(P,Context.MODE_PRIVATE);}
 private SecretKey key()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias(A)){KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder(A,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}return ((KeyStore.SecretKeyEntry)ks.getEntry(A,null)).getSecretKey();}
 public void save(String t)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[] e=c.doFinal(t.getBytes(StandardCharsets.UTF_8));prefs.edit().putString("iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).putString("data",Base64.encodeToString(e,Base64.NO_WRAP)).apply();}
 public String load(){try{String i=prefs.getString("iv",null),d=prefs.getString("data",null);if(i==null||d==null)return "";Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(i,Base64.NO_WRAP)));return new String(c.doFinal(Base64.decode(d,Base64.NO_WRAP)),StandardCharsets.UTF_8);}catch(Exception e){return "";}}
 public void clear(){prefs.edit().clear().apply();}
}
