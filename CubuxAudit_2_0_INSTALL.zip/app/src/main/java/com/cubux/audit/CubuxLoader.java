package com.cubux.audit;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CubuxLoader {
    private final CubuxClient client;
    private final String from;
    private final String to;
    private final AuditProgressListener listener;
    private final AuditControl control;
    private static final int WAIT_SECONDS = 30;

    public CubuxLoader(CubuxClient client, String from, String to,
                       AuditProgressListener listener) {
        this(client, from, to, listener, null);
    }

    public CubuxLoader(CubuxClient client, String from, String to,
                       AuditProgressListener listener, AuditControl control) {
        this.client = client;
        this.from = from;
        this.to = to;
        this.listener = listener;
        this.control = control;
    }

    public Result loadAll() throws Exception {
        List<JSONObject> all = new ArrayList<>();
        checkpoint();
        stage("LOADING_META", "Получаю информацию о количестве операций...");
        JSONObject first = pageRetry(1);
        JSONObject meta = first.optJSONObject("_meta");
        if (meta == null) throw new IOException("Cubux: отсутствует _meta");
        int total = meta.optInt("totalCount", -1);
        int pages = meta.optInt("pageCount", -1);
        if (total < 0 || pages < 1) throw new IOException("Cubux: некорректный _meta");
        if (listener != null) listener.onMeta(total, pages);
        add(first, all);
        progress(1, pages, all.size(), total);

        for (int p = 2; p <= pages; p++) {
            checkpoint();
            stage("READING_DATA", "Читаю страницу " + p + " из " + pages + "...");
            JSONObject data = pageRetry(p);
            JSONObject pm = data.optJSONObject("_meta");
            if (pm == null || pm.optInt("totalCount", -1) != total ||
                    pm.optInt("pageCount", -1) != pages) {
                throw new IOException("Cubux изменил _meta во время загрузки");
            }
            add(data, all);
            progress(p, pages, all.size(), total);
        }

        checkpoint();
        if (all.size() != total) {
            throw new IOException("НЕПОЛНАЯ ЗАГРУЗКА: " + all.size() + " из " + total);
        }
        return new Result(total, pages, all);
    }

    private JSONObject pageRetry(int page) throws Exception {
        int attempt = 0;
        while (true) {
            checkpoint();
            attempt++;
            try {
                stage("WAITING_CUBUX", "Ожидаю ответа Cubux...");
                return page(page);
            } catch (IOException e) {
                String message = e.getMessage() == null ? "" : e.getMessage();
                if (message.contains("401") || message.contains("403") || message.contains("404")) {
                    throw e;
                }
                if (listener != null) listener.onRetry(page, attempt, WAIT_SECONDS, message);
                for (int i = 0; i < WAIT_SECONDS; i++) {
                    checkpoint();
                    Thread.sleep(1000L);
                }
                stage("RECONNECTING", "Подключение восстановлено. Продолжаю проверку...");
            }
        }
    }

    private JSONObject page(int page) throws Exception {
        return new JSONObject(client.get(
                "https://app.cubux.net/api/v1/transaction/team/250574?dateSince=" +
                        from + "&dateUntil=" + to + "&mn=1&page=" + page));
    }

    private void add(JSONObject data, List<JSONObject> out) throws Exception {
        JSONArray items = data.optJSONArray("items");
        if (items == null) throw new IOException("Cubux: отсутствует items");
        for (int i = 0; i < items.length(); i++) {
            checkpoint();
            JSONObject item = items.optJSONObject(i);
            if (item != null) out.add(item);
        }
    }

    private void checkpoint() throws AuditControl.AuditStoppedException {
        if (control != null) control.checkpoint();
    }

    private void stage(String stage, String message) {
        if (listener != null) listener.onStage(stage, message);
    }

    private void progress(int page, int pages, int loaded, int total) {
        if (listener != null) listener.onPage(page, pages, loaded, total);
    }

    public static class Result {
        public final int totalCount;
        public final int pageCount;
        public final List<JSONObject> items;
        Result(int totalCount, int pageCount, List<JSONObject> items) {
            this.totalCount = totalCount;
            this.pageCount = pageCount;
            this.items = items;
        }
    }
}
