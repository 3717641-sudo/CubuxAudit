package com.cubux.audit;
import java.nio.charset.StandardCharsets; import java.security.MessageDigest; import java.util.Locale;
public final class HashUtil {
 private HashUtil(){}
 public static String sha256(String s)throws Exception{return sha256(s.getBytes(StandardCharsets.UTF_8));}
 public static String sha256(byte[] b)throws Exception{byte[] d=MessageDigest.getInstance("SHA-256").digest(b);StringBuilder r=new StringBuilder();for(byte x:d)r.append(String.format(Locale.US,"%02x",x));return r.toString();}
}
