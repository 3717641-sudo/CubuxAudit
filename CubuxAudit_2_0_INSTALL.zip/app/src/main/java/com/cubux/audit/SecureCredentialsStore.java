package com.cubux.audit;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class SecureCredentialsStore {

    private static final String ALIAS =
            "cubux_credentials_key";

    private static final String PREF =
            "cubux_credentials";

    private final SharedPreferences prefs;

    public SecureCredentialsStore(
            Context context
    ) {
        prefs = context.getSharedPreferences(
                PREF,
                Context.MODE_PRIVATE
        );
    }

    private SecretKey key() throws Exception {

        KeyStore ks =
                KeyStore.getInstance(
                        "AndroidKeyStore"
                );

        ks.load(null);

        if (!ks.containsAlias(ALIAS)) {

            KeyGenerator generator =
                    KeyGenerator.getInstance(
                            KeyProperties.KEY_ALGORITHM_AES,
                            "AndroidKeyStore"
                    );

            generator.init(
                    new KeyGenParameterSpec.Builder(
                            ALIAS,
                            KeyProperties.PURPOSE_ENCRYPT |
                                    KeyProperties.PURPOSE_DECRYPT
                    )
                            .setBlockModes(
                                    KeyProperties.BLOCK_MODE_GCM
                            )
                            .setEncryptionPaddings(
                                    KeyProperties.ENCRYPTION_PADDING_NONE
                            )
                            .build()
            );

            generator.generateKey();
        }

        KeyStore.SecretKeyEntry entry =
                (KeyStore.SecretKeyEntry)
                        ks.getEntry(
                                ALIAS,
                                null
                        );

        return entry.getSecretKey();
    }

    private void saveValue(
            String name,
            String value
    ) throws Exception {

        Cipher cipher =
                Cipher.getInstance(
                        "AES/GCM/NoPadding"
                );

        cipher.init(
                Cipher.ENCRYPT_MODE,
                key()
        );

        byte[] encrypted =
                cipher.doFinal(
                        value.getBytes(
                                StandardCharsets.UTF_8
                        )
                );

        prefs.edit()
                .putString(
                        name + "_iv",
                        Base64.encodeToString(
                                cipher.getIV(),
                                Base64.NO_WRAP
                        )
                )
                .putString(
                        name + "_data",
                        Base64.encodeToString(
                                encrypted,
                                Base64.NO_WRAP
                        )
                )
                .apply();
    }

    private String loadValue(
            String name
    ) {

        try {
            String ivText =
                    prefs.getString(
                            name + "_iv",
                            null
                    );

            String dataText =
                    prefs.getString(
                            name + "_data",
                            null
                    );

            if (ivText == null ||
                    dataText == null) {
                return "";
            }

            Cipher cipher =
                    Cipher.getInstance(
                            "AES/GCM/NoPadding"
                    );

            cipher.init(
                    Cipher.DECRYPT_MODE,
                    key(),
                    new GCMParameterSpec(
                            128,
                            Base64.decode(
                                    ivText,
                                    Base64.NO_WRAP
                            )
                    )
            );

            byte[] plain =
                    cipher.doFinal(
                            Base64.decode(
                                    dataText,
                                    Base64.NO_WRAP
                            )
                    );

            return new String(
                    plain,
                    StandardCharsets.UTF_8
            );

        } catch (Exception e) {
            return "";
        }
    }

    public void saveCredentials(
            String login,
            String password
    ) throws Exception {
        saveValue("login", login);
        saveValue("password", password);
    }

    public void saveToken(
            String token
    ) throws Exception {
        saveValue("token", token);
    }

    public String getLogin() {
        return loadValue("login");
    }

    public String getPassword() {
        return loadValue("password");
    }

    public String getToken() {
        return loadValue("token");
    }

    public void clearToken() {
        prefs.edit()
                .remove("token_iv")
                .remove("token_data")
                .apply();
    }

    public void clearAll() {
        prefs.edit().clear().apply();
    }
}
