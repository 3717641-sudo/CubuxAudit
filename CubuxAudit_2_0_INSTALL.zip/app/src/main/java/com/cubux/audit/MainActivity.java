package com.cubux.audit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_BANK = 1001;
    private static final int REQ_BACKUP = 1002;
    private static final int REQ_RESTORE = 1003;

    private final int GREEN = Color.rgb(0, 190, 92);
    private final int DARK = Color.rgb(28, 37, 52);
    private final int TEXT = Color.rgb(26, 34, 48);
    private final int MUTED = Color.rgb(105, 119, 144);
    private final int RED = Color.rgb(255, 75, 88);
    private final int YELLOW = Color.rgb(255, 184, 31);
    private final int PURPLE = Color.rgb(126, 79, 255);
    private final int BLUE = Color.rgb(51, 151, 245);

    private AuditDb db;
    private SecureCredentialsStore credentials;

    private EditText loginInput;
    private EditText passwordInput;

    private ProgressBar progressBar;
    private TextView percentText;
    private TextView statusText;
    private TextView detailsText;
    private TextView resultText;

    private TextView totalTop;
    private TextView newTop;
    private TextView changedTop;
    private TextView deletedTop;

    private TextView newCard;
    private TextView changedCard;
    private TextView deletedCard;
    private TextView closedCard;
    private TextView multiCard;

    private Button auditButton;

    private long startedMs;
    private int retries;

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);

        db = new AuditDb(this);

        credentials =
                new SecureCredentialsStore(
                        this
                );

        createUi();

        try {
            // Credentials are loaded only after the UI is already created.
        } catch (Throwable ignored) {
        }

        // Автоаудит включается после успешной первой авторизации.
        // Ошибка фонового планировщика не должна мешать запуску приложения.
    }

    private void createUi() {

        ScrollView scroll =
                new ScrollView(this);

        scroll.setFillViewport(true);
        scroll.setBackgroundColor(
                Color.rgb(245, 248, 252)
        );

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL
        );

        root.setBackgroundColor(
                Color.rgb(245, 248, 252)
        );

        root.addView(
                buildHeader()
        );

        LinearLayout body =
                new LinearLayout(this);

        body.setOrientation(
                LinearLayout.VERTICAL
        );

        body.setPadding(
                dp(16),
                dp(14),
                dp(16),
                dp(28)
        );

        body.addView(
                buildAuditPanel()
        );

        body.addView(
                buildStatsRow()
        );

        body.addView(
                buildNavigationGrid()
        );

        resultText =
                label(
                        "",
                        15,
                        false,
                        TEXT
                );

        resultText.setPadding(
                dp(4),
                dp(16),
                dp(4),
                dp(16)
        );

        body.addView(resultText);

        root.addView(body);

        scroll.addView(root);

        setContentView(scroll);
    }

    private View buildHeader() {

        LinearLayout header =
                new LinearLayout(this);

        header.setOrientation(
                LinearLayout.VERTICAL
        );

        header.setPadding(
                dp(18),
                dp(18),
                dp(18),
                dp(18)
        );

        GradientDrawable bg =
                new GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        new int[]{
                                Color.rgb(0, 177, 94),
                                Color.rgb(0, 205, 116)
                        }
                );

        header.setBackground(bg);

        LinearLayout top =
                new LinearLayout(this);

        top.setGravity(
                Gravity.CENTER_VERTICAL
        );

        TextView menu =
                iconText("☰", 32);

        TextView title =
                label(
                        "Cubux Audit 2.0",
                        24,
                        true,
                        Color.WHITE
                );

        title.setGravity(
                Gravity.CENTER
        );

        LinearLayout.LayoutParams titleLp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        TextView settings =
                iconText("⚙", 28);

        settings.setOnClickListener(
                v -> showSettingsDialog()
        );

        top.addView(menu);
        top.addView(title, titleLp);
        top.addView(settings);

        header.addView(top);

        TextView sub =
                label(
                        "Финансовый аудит • READ-ONLY",
                        14,
                        false,
                        Color.argb(
                                220,
                                255,
                                255,
                                255
                        )
                );

        sub.setGravity(
                Gravity.CENTER
        );

        header.addView(sub);

        LinearLayout stats =
                new LinearLayout(this);

        stats.setOrientation(
                LinearLayout.HORIZONTAL
        );

        stats.setPadding(
                0,
                dp(26),
                0,
                0
        );

        totalTop =
                topStat(
                        "▤",
                        "0",
                        "Всего операций",
                        Color.rgb(0, 221, 128)
                );

        newTop =
                topStat(
                        "+",
                        "0",
                        "Новые",
                        Color.rgb(0, 221, 128)
                );

        changedTop =
                topStat(
                        "✎",
                        "0",
                        "Изменённые",
                        YELLOW
                );

        deletedTop =
                topStat(
                        "▥",
                        "0",
                        "Удалённые",
                        RED
                );

        stats.addView(
                totalTop,
                weight()
        );

        stats.addView(
                newTop,
                weight()
        );

        stats.addView(
                changedTop,
                weight()
        );

        stats.addView(
                deletedTop,
                weight()
        );

        header.addView(stats);

        return header;
    }

    private TextView topStat(
            String icon,
            String value,
            String caption,
            int accent
    ) {
        TextView v =
                label(
                        icon +
                                "   " +
                                value +
                                "\n" +
                                caption,
                        13,
                        false,
                        Color.WHITE
                );

        v.setGravity(
                Gravity.CENTER
        );

        v.setPadding(
                dp(4),
                dp(10),
                dp(4),
                dp(10)
        );

        GradientDrawable bg =
                rounded(
                        Color.argb(
                                30,
                                255,
                                255,
                                255
                        ),
                        16
                );

        bg.setStroke(
                dp(1),
                Color.argb(
                        90,
                        255,
                        255,
                        255
                )
        );

        v.setBackground(bg);

        return v;
    }

    private View buildAuditPanel() {

        LinearLayout card =
                card();

        LinearLayout first =
                new LinearLayout(this);

        first.setGravity(
                Gravity.CENTER_VERTICAL
        );

        auditButton =
                new Button(this);

        auditButton.setText(
                "▶  ЗАПУСТИТЬ АУДИТ"
        );

        auditButton.setTextColor(
                Color.WHITE
        );

        auditButton.setTextSize(17);

        auditButton.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        auditButton.setAllCaps(false);

        auditButton.setBackground(
                rounded(
                        GREEN,
                        18
                )
        );

        LinearLayout.LayoutParams bp =
                new LinearLayout.LayoutParams(
                        0,
                        dp(64),
                        1
                );

        bp.setMargins(
                0,
                0,
                dp(14),
                0
        );

        first.addView(
                auditButton,
                bp
        );

        LinearLayout progressBlock =
                new LinearLayout(this);

        progressBlock.setOrientation(
                LinearLayout.VERTICAL
        );

        percentText =
                label(
                        "Проверка 0%",
                        18,
                        true,
                        TEXT
                );

        progressBar =
                new ProgressBar(
                        this,
                        null,
                        android.R.attr.progressBarStyleHorizontal
                );

        progressBar.setMax(100);
        progressBar.setProgress(0);

        progressBlock.addView(
                percentText
        );

        progressBlock.addView(
                progressBar,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(14)
                )
        );

        first.addView(
                progressBlock,
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                )
        );

        card.addView(first);

        statusText =
                label(
                        "Готов к проверке",
                        16,
                        true,
                        TEXT
                );

        statusText.setPadding(
                0,
                dp(16),
                0,
                dp(4)
        );

        card.addView(statusText);

        detailsText =
                label(
                        "Автоаудит включён • каждые 30 минут",
                        14,
                        false,
                        MUTED
                );

        card.addView(detailsText);

        LinearLayout steps =
                new LinearLayout(this);

        steps.setPadding(
                0,
                dp(16),
                0,
                0
        );

        steps.addView(
                step("✓", "Подключаюсь\nк Cubux"),
                weight()
        );

        steps.addView(
                step("✓", "Читаю\nданные"),
                weight()
        );

        steps.addView(
                step("○", "Сравниваю"),
                weight()
        );

        steps.addView(
                step("○", "Формирую\nотчёт"),
                weight()
        );

        card.addView(steps);

        auditButton.setOnClickListener(
                v -> runAudit()
        );

        return card;
    }

    private TextView step(
            String icon,
            String caption
    ) {
        TextView v =
                label(
                        icon +
                                "\n" +
                                caption,
                        13,
                        false,
                        MUTED
                );

        v.setGravity(
                Gravity.CENTER
        );

        return v;
    }

    private View buildStatsRow() {

        LinearLayout row =
                new LinearLayout(this);

        row.setOrientation(
                LinearLayout.HORIZONTAL
        );

        row.setPadding(
                0,
                dp(14),
                0,
                dp(4)
        );

        newCard =
                statCard(
                        "▤",
                        "0",
                        "Новые",
                        Color.rgb(
                                0,
                                197,
                                111
                        )
                );

        changedCard =
                statCard(
                        "✎",
                        "0",
                        "Изменённые",
                        YELLOW
                );

        deletedCard =
                statCard(
                        "▥",
                        "0",
                        "Удалённые",
                        RED
                );

        closedCard =
                statCard(
                        "▣",
                        "0",
                        "Закрытые\nпериоды",
                        PURPLE
                );

        multiCard =
                statCard(
                        "↻",
                        "0",
                        "Повторные\nизменения",
                        BLUE
                );

        row.addView(
                newCard,
                weight()
        );

        row.addView(
                changedCard,
                weight()
        );

        row.addView(
                deletedCard,
                weight()
        );

        row.addView(
                closedCard,
                weight()
        );

        row.addView(
                multiCard,
                weight()
        );

        return row;
    }

    private TextView statCard(
            String icon,
            String value,
            String caption,
            int accent
    ) {
        TextView v =
                label(
                        icon +
                                "\n" +
                                value +
                                "\n" +
                                caption,
                        13,
                        true,
                        TEXT
                );

        v.setGravity(
                Gravity.CENTER
        );

        v.setPadding(
                dp(4),
                dp(12),
                dp(4),
                dp(12)
        );

        GradientDrawable bg =
                rounded(
                        Color.WHITE,
                        16
                );

        bg.setStroke(
                dp(1),
                Color.argb(
                        35,
                        Color.red(accent),
                        Color.green(accent),
                        Color.blue(accent)
                )
        );

        v.setBackground(bg);

        return v;
    }

    private View buildNavigationGrid() {

        LinearLayout wrap =
                new LinearLayout(this);

        wrap.setOrientation(
                LinearLayout.VERTICAL
        );

        wrap.setPadding(
                0,
                dp(12),
                0,
                0
        );

        wrap.addView(
                navRow(
                        navCard(
                                "↺",
                                "История аудитов",
                                "Просмотр прошлых проверок",
                                Color.rgb(0, 202, 116),
                                v -> resultText.setText(
                                        "ИСТОРИЯ АУДИТОВ\n\n" +
                                                db.recentRunsText()
                                )
                        ),
                        navCard(
                                "▤",
                                "Журнал изменений",
                                "Подробный список изменений",
                                YELLOW,
                                v -> showJournalDialog()
                        )
                )
        );

        wrap.addView(
                navRow(
                        navCard(
                                "◔",
                                "Отчёты",
                                "День, неделя, месяц, год",
                                BLUE,
                                v -> showReportsDialog()
                        ),
                        navCard(
                                "▦",
                                "Банковская сверка",
                                "Сравнение с выпиской банка",
                                PURPLE,
                                v -> showBankDialog()
                        )
                )
        );

        wrap.addView(
                navRow(
                        navCard(
                                "▣",
                                "Закрытые периоды",
                                "Контроль истории Cubux",
                                Color.rgb(
                                        245,
                                        65,
                                        122
                                ),
                                v -> resultText.setText(
                                        "Закрытые периоды контролируются автоматически по SHA-256.\n" +
                                                "Baseline прошлых дней не перезаписывается."
                                )
                        ),
                        navCard(
                                "⚙",
                                "Настройки",
                                "Авторизация и автоаудит",
                                Color.rgb(
                                        108,
                                        78,
                                        244
                                ),
                                v -> showSettingsDialog()
                        )
                )
        );

        return wrap;
    }

    private View navRow(
            View left,
            View right
    ) {
        LinearLayout row =
                new LinearLayout(this);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        lp.setMargins(
                0,
                0,
                dp(7),
                dp(12)
        );

        LinearLayout.LayoutParams rp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        rp.setMargins(
                dp(7),
                0,
                0,
                dp(12)
        );

        row.addView(
                left,
                lp
        );

        row.addView(
                right,
                rp
        );

        return row;
    }

    private TextView navCard(
            String icon,
            String title,
            String subtitle,
            int accent,
            View.OnClickListener listener
    ) {
        TextView v =
                label(
                        icon +
                                "    " +
                                title +
                                "\n\n" +
                                subtitle +
                                "     ›",
                        15,
                        false,
                        TEXT
                );

        v.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        v.setPadding(
                dp(16),
                dp(20),
                dp(16),
                dp(20)
        );

        v.setMinHeight(
                dp(120)
        );

        v.setGravity(
                Gravity.CENTER_VERTICAL
        );

        GradientDrawable bg =
                rounded(
                        Color.WHITE,
                        18
                );

        bg.setStroke(
                dp(1),
                Color.rgb(
                        232,
                        237,
                        244
                )
        );

        v.setBackground(bg);
        v.setOnClickListener(
                listener
        );

        return v;
    }

    private LinearLayout card() {

        LinearLayout c =
                new LinearLayout(this);

        c.setOrientation(
                LinearLayout.VERTICAL
        );

        c.setPadding(
                dp(16),
                dp(16),
                dp(16),
                dp(16)
        );

        c.setBackground(
                rounded(
                        Color.WHITE,
                        22
                )
        );

        return c;
    }

    private LinearLayout.LayoutParams weight() {

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        p.setMargins(
                dp(3),
                0,
                dp(3),
                0
        );

        return p;
    }

    private TextView iconText(
            String value,
            int size
    ) {
        TextView v =
                label(
                        value,
                        size,
                        true,
                        Color.WHITE
                );

        v.setGravity(
                Gravity.CENTER
        );

        v.setPadding(
                dp(6),
                dp(6),
                dp(6),
                dp(6)
        );

        return v;
    }

    private TextView label(
            String value,
            int size,
            boolean bold,
            int color
    ) {
        TextView v =
                new TextView(this);

        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setFontFeatureSettings(
                "kern"
        );

        if (bold) {
            v.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD
            );
        }

        return v;
    }

    private GradientDrawable rounded(
            int color,
            int radiusDp
    ) {
        GradientDrawable d =
                new GradientDrawable();

        d.setColor(color);

        d.setCornerRadius(
                dp(radiusDp)
        );

        return d;
    }

    private int dp(
            int value
    ) {
        return (int) (
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density +
                        0.5f
        );
    }

    private void runAudit() {

        String login =
                credentials.getLogin();

        String password =
                credentials.getPassword();

        if (login.isEmpty() ||
                password.isEmpty()) {
            showLoginDialog(true);
            return;
        }

        auditButton.setEnabled(false);

        progressBar.setProgress(0);
        percentText.setText(
                "Проверка 0%"
        );

        resultText.setText("");

        startedMs =
                System.currentTimeMillis();

        retries = 0;

        AuditCoordinator coordinator =
                new AuditCoordinator(this);

        boolean recovery =
                coordinator.isRecovery();

        new Thread(
                () -> {
                    try {
                        AuditEngine.Result r =
                                coordinator.run(
                                        login,
                                        password,
                                        recovery,
                                        progressListener()
                                );

                        runOnUiThread(
                                () -> showResult(r)
                        );

                    } catch (Exception e) {
                        String msg =
                                e.getMessage() == null
                                        ? e.toString()
                                        : e.getMessage();

                        runOnUiThread(
                                () -> {
                                    statusText.setText(
                                            "АУДИТ ОСТАНОВЛЕН"
                                    );

                                    resultText.setText(
                                            "Причина:\n" +
                                                    msg
                                    );
                                }
                        );

                    } finally {
                        runOnUiThread(
                                () ->
                                        auditButton
                                                .setEnabled(
                                                        true
                                                )
                        );
                    }
                }
        ).start();
    }

    private AuditProgressListener progressListener() {
        return new AuditProgressListener() {

            @Override
            public void onStage(
                    String stage,
                    String message
            ) {
                runOnUiThread(
                        () ->
                                statusText.setText(
                                        message
                                )
                );
            }

            @Override
            public void onMeta(
                    int total,
                    int pages
            ) {
                runOnUiThread(
                        () ->
                                detailsText.setText(
                                        "Найдено " +
                                                total +
                                                " операций • " +
                                                pages +
                                                " страниц"
                                )
                );
            }

            @Override
            public void onPage(
                    int page,
                    int pages,
                    int loaded,
                    int total
            ) {
                updateProgress(
                        page,
                        pages,
                        loaded,
                        total
                );
            }

            @Override
            public void onRetry(
                    int page,
                    int attempt,
                    int retrySeconds,
                    String error
            ) {
                retries++;

                runOnUiThread(
                        () -> {
                            statusText.setText(
                                    "Соединение прервано. Жду восстановления..."
                            );

                            detailsText.setText(
                                    "Страница " +
                                            page +
                                            " • прогресс сохранён" +
                                            "\nПовтор через " +
                                            retrySeconds +
                                            " сек." +
                                            "\nПопытка " +
                                            attempt
                            );
                        }
                );
            }
        };
    }

    private void updateProgress(
            int page,
            int pages,
            int loaded,
            int total
    ) {
        long elapsed =
                System.currentTimeMillis() -
                        startedMs;

        int percent =
                total <= 0
                        ? 0
                        : (int) (
                                loaded *
                                        100.0 /
                                        total
                        );

        double speed =
                loaded /
                        Math.max(
                                1,
                                elapsed /
                                        1000.0
                        );

        runOnUiThread(
                () -> {
                    progressBar.setProgress(
                            Math.min(
                                    100,
                                    percent
                            )
                    );

                    percentText.setText(
                            "Проверка " +
                                    percent +
                                    "%"
                    );

                    statusText.setText(
                            "Читаю данные Cubux..."
                    );

                    detailsText.setText(
                            loaded +
                                    " из " +
                                    total +
                                    " операций • страница " +
                                    page +
                                    " из " +
                                    pages +
                                    "\nСкорость: " +
                                    String.format(
                                            Locale.US,
                                            "%.1f",
                                            speed
                                    ) +
                                    " операций/сек • прошло " +
                                    TimeUtil.formatDuration(
                                            elapsed
                                    ) +
                                    "\nПоследняя активность: " +
                                    TimeUtil.clock()
                    );
                }
        );
    }

    private void showResult(
            AuditEngine.Result r
    ) {
        try {
            String savedInterval =
                    db.getState("audit_interval_minutes");

            long interval = 30;

            if (savedInterval != null) {
                try {
                    interval =
                            Long.parseLong(savedInterval);
                } catch (Exception ignored) {
                }
            }

            AutoAuditScheduler.schedule(
                    this,
                    interval
            );

        } catch (Throwable ignored) {
            // Фоновый планировщик никогда не должен ронять UI.
        }

        progressBar.setProgress(100);

        percentText.setText(
                "Проверка 100%"
        );

        statusText.setText(
                "Проверка завершена успешно"
        );

        detailsText.setText(
                "Последняя проверка: " +
                        TimeUtil.now() +
                        " • " +
                        TimeUtil.formatDuration(
                                r.durationMs
                        )
        );

        setStat(
                totalTop,
                "▤",
                r.total,
                "Всего операций"
        );

        setStat(
                newTop,
                "+",
                r.newCount,
                "Новые"
        );

        setStat(
                changedTop,
                "✎",
                r.changedCount,
                "Изменённые"
        );

        setStat(
                deletedTop,
                "▥",
                r.deletedCount,
                "Удалённые"
        );

        setMiniStat(
                newCard,
                "▤",
                r.newCount,
                "Новые"
        );

        setMiniStat(
                changedCard,
                "✎",
                r.changedCount,
                "Изменённые"
        );

        setMiniStat(
                deletedCard,
                "▥",
                r.deletedCount,
                "Удалённые"
        );

        setMiniStat(
                closedCard,
                "▣",
                r.closedChangedCount,
                "Закрытые\nпериоды"
        );

        setMiniStat(
                multiCard,
                "↻",
                r.multiChangedCount,
                "Повторные\nизменения"
        );

        resultText.setText(
                "Целостность: OK • Cubux: READ-ONLY"
        );
    }

    private void setStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        view.setText(
                icon +
                        "   " +
                        value +
                        "\n" +
                        caption
        );
    }

    private void setMiniStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        view.setText(
                icon +
                        "\n" +
                        value +
                        "\n" +
                        caption
        );
    }

    private void showLoginDialog(
            boolean runAfterSave
    ) {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        int pad = dp(18);

        box.setPadding(
                pad,
                0,
                pad,
                0
        );

        EditText login =
                new EditText(this);

        login.setHint(
                "Логин Cubux"
        );

        login.setSingleLine(true);

        login.setText(
                credentials.getLogin()
        );

        EditText password =
                new EditText(this);

        password.setHint(
                "Пароль Cubux"
        );

        password.setSingleLine(true);

        password.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        box.addView(login);
        box.addView(password);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Авторизация Cubux"
                )
                .setMessage(
                        "Приложение само получит и будет обновлять API-токен."
                )
                .setView(box)
                .setPositiveButton(
                        "Сохранить",
                        (d, w) -> {
                            try {
                                credentials.saveCredentials(
                                        login.getText()
                                                .toString()
                                                .trim(),
                                        password.getText()
                                                .toString()
                                );

                                credentials.clearToken();

                                Toast.makeText(
                                        this,
                                        "Данные сохранены",
                                        Toast.LENGTH_SHORT
                                ).show();

                                if (runAfterSave) {
                                    runAudit();
                                }

                            } catch (Exception e) {
                                Toast.makeText(
                                        this,
                                        "Ошибка сохранения",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void showSettingsDialog() {
        String[] items = {
                "Логин и пароль Cubux",
                "Интервал автоаудита",
                "Удалить данные авторизации"
        };

        new AlertDialog.Builder(this)
                .setTitle(
                        "Настройки"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                showLoginDialog(false);
                            } else if (which == 1) {
                                intervalDialog();
                            } else {
                                credentials.clearAll();

                                Toast.makeText(
                                        this,
                                        "Логин, пароль и токен удалены",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                )
                .show();
    }

    private void intervalDialog() {
        final String[] labels = {
                "15 минут",
                "30 минут",
                "1 час",
                "2 часа",
                "6 часов",
                "12 часов",
                "24 часа"
        };

        final long[] values = {
                15,
                30,
                60,
                120,
                360,
                720,
                1440
        };

        new AlertDialog.Builder(this)
                .setTitle(
                        "Интервал автоаудита"
                )
                .setItems(
                        labels,
                        (d, which) -> {
                            AutoAuditScheduler
                                    .schedule(
                                            this,
                                            values[which]
                                    );

                            db.saveState(
                                    "audit_interval_minutes",
                                    String.valueOf(
                                            values[which]
                                    )
                            );

                            Toast.makeText(
                                    this,
                                    "Автоаудит: " +
                                            labels[which],
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                )
                .show();
    }

    private void showReportsDialog() {
        String[] items = {
                "День",
                "Неделя",
                "Месяц",
                "Год",
                "Произвольный период"
        };

        ReportEngine r =
                new ReportEngine(db);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Отчёты"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                resultText.setText(
                                        r.today()
                                );
                            } else if (
                                    which == 1
                            ) {
                                resultText.setText(
                                        r.week()
                                );
                            } else if (
                                    which == 2
                            ) {
                                resultText.setText(
                                        r.month()
                                );
                            } else if (
                                    which == 3
                            ) {
                                resultText.setText(
                                        r.year()
                                );
                            } else {
                                customReportDialog();
                            }
                        }
                )
                .show();
    }

    private void showBankDialog() {
        String[] items = {
                "Импорт CSV / XLSX",
                "Сверить банк с Cubux"
        };

        new AlertDialog.Builder(this)
                .setTitle(
                        "Банковская сверка"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                pickBankFile();
                            } else {
                                new Thread(
                                        () -> {
                                            String text =
                                                    new BankReconcileEngine(
                                                            db
                                                    ).reconcile();

                                            runOnUiThread(
                                                    () ->
                                                            resultText
                                                                    .setText(
                                                                            text
                                                                    )
                                            );
                                        }
                                ).start();
                            }
                        }
                )
                .show();
    }

    private void showJournalDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText search =
                new EditText(this);

        search.setHint(
                "Поиск: дата, сумма, категория, счёт, описание, ID"
        );

        Spinner filter =
                new Spinner(this);

        String[] values = {
                "ALL",
                "NEW",
                "CHANGED",
                "DELETED",
                "CLOSED"
        };

        filter.setAdapter(
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        values
                )
        );

        box.addView(search);
        box.addView(filter);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Журнал изменений"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        db.journalText(
                                                String.valueOf(
                                                        filter.getSelectedItem()
                                                ),
                                                search.getText()
                                                        .toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void customReportDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText from =
                new EditText(this);

        from.setHint(
                "От YYYY-MM-DD"
        );

        EditText to =
                new EditText(this);

        to.setHint(
                "До YYYY-MM-DD"
        );

        box.addView(from);
        box.addView(to);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Произвольный период"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        new ReportEngine(
                                                db
                                        ).report(
                                                from.getText()
                                                        .toString(),
                                                to.getText()
                                                        .toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void pickBankFile() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType("*/*");

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_BANK
        );
    }

    private void createBackup() {
        Intent i =
                new Intent(
                        Intent.ACTION_CREATE_DOCUMENT
                );

        i.setType(
                "application/zip"
        );

        i.putExtra(
                Intent.EXTRA_TITLE,
                "CubuxAudit-backup.zip"
        );

        startActivityForResult(
                i,
                REQ_BACKUP
        );
    }

    private void pickRestore() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType(
                "application/zip"
        );

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_RESTORE
        );
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (resultCode != RESULT_OK ||
                data == null ||
                data.getData() == null) {
            return;
        }

        Uri uri = data.getData();

        if (requestCode == REQ_BANK) {
            new Thread(
                    () -> {
                        try {
                            int imported =
                                    new BankImportEngine(
                                            db
                                    ).importFile(
                                            getContentResolver(),
                                            uri,
                                            uri.toString()
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Импортировано банковских операций: " +
                                                            imported
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка импорта: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (
                requestCode ==
                        REQ_BACKUP
        ) {
            new Thread(
                    () -> {
                        try {
                            String hash =
                                    new BackupManager(
                                            this,
                                            db
                                    ).exportTo(
                                            getContentResolver(),
                                            uri
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Backup создан\nSHA-256:\n" +
                                                            hash
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка backup: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (
                requestCode ==
                        REQ_RESTORE
        ) {
            new Thread(
                    () -> {
                        try {
                            new BackupManager(
                                    this,
                                    db
                            ).restoreFrom(
                                    getContentResolver(),
                                    uri
                            );

                            db =
                                    new AuditDb(this);

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Backup восстановлен. Запустите аудит для сравнения с текущим Cubux."
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка восстановления: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();
        }
    }
}
