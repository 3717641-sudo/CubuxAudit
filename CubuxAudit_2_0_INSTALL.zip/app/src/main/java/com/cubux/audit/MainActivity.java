package com.cubux.audit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_BANK = 1001;
    private static final int REQ_BACKUP = 1002;
    private static final int REQ_RESTORE = 1003;

    private final int GREEN = Color.rgb(0, 190, 92);
    private final int DARK = Color.rgb(28, 37, 52);
    private final int TEXT = Color.rgb(26, 34, 48);
    private final int MUTED = Color.rgb(105, 119, 144);
    private final int RED = Color.rgb(255, 75, 88);
    private final int YELLOW = Color.rgb(255, 184, 31);
    private final int PURPLE = Color.rgb(126, 79, 255);
    private final int BLUE = Color.rgb(51, 151, 245);

    private AuditDb db;
    private SecureCredentialsStore credentials;

    private EditText loginInput;
    private EditText passwordInput;

    private ProgressBar progressBar;
    private TextView percentText;
    private TextView statusText;
    private TextView detailsText;
    private TextView resultText;

    private TextView totalTop;
    private TextView newTop;
    private TextView changedTop;
    private TextView deletedTop;

    private TextView newCard;
    private TextView changedCard;
    private TextView deletedCard;
    private TextView closedCard;
    private TextView multiCard;

    private Button auditButton;
    private Button pauseButton;
    private Button stopButton;
    private AuditControl auditControl;
    private long auditSessionCounter = 0L;
    private volatile long activeAuditSession = 0L;
    private volatile int maxPageShown = 0;
    private volatile int maxLoadedShown = 0;
    private volatile int maxPercentShown = 0;
    private volatile boolean auditRunning;

    private long startedMs;
    private int retries;

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);

        db = new AuditDb(this);

        credentials =
                new SecureCredentialsStore(
                        this
                );

        createUi();

        try {
            NotificationHelper.ensureChannel(this);
            refreshAutoAuditStatus();
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            refreshAutoAuditStatus();
        } catch (Throwable ignored) {
        }
    }

    private void createUi() {

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(Color.rgb(245, 248, 252));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(245, 248, 252));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 248, 252));

        root.addView(buildHeader());

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(28));

        body.addView(buildAuditPanel());
        body.addView(buildStatsRow());
        body.addView(buildNavigationGrid());

        resultText = label("", 15, false, TEXT);
        resultText.setPadding(dp(4), dp(16), dp(4), dp(16));
        body.addView(resultText);

        root.addView(body);
        scroll.addView(root);

        screen.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1
        ));
        screen.addView(buildBottomNavigation());
        setContentView(screen);
    }

    private View buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(7), dp(8), dp(7));
        nav.setBackgroundColor(Color.rgb(28, 39, 53));

        nav.addView(bottomItem("⌂", "Главная", GREEN, v -> scrollToTop()), weight());
        nav.addView(bottomItem("▶", "Аудит", Color.rgb(225, 232, 240), v -> onAuditNavigationPressed()), weight());
        nav.addView(bottomItem("▥", "Отчёты", Color.rgb(225, 232, 240), v -> showReportsDialog()), weight());
        nav.addView(bottomItem("▤", "Журнал", Color.rgb(225, 232, 240), v -> showJournalDialog()), weight());
        nav.addView(bottomItem("⚙", "Настройки", Color.rgb(225, 232, 240), v -> showSettingsDialog()), weight());
        return nav;
    }

    private TextView bottomItem(String icon, String caption, int color, View.OnClickListener listener) {
        TextView v = label(icon + "\n" + caption, 11, true, color);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(1), dp(5), dp(1), dp(5));
        v.setMinHeight(dp(54));
        v.setOnClickListener(listener);
        return v;
    }

    private void onAuditNavigationPressed() {
        if (auditRunning) {
            statusText.setText(
                    auditControl != null && auditControl.isPaused()
                            ? "Аудит на паузе"
                            : "Аудит уже выполняется"
            );
            Toast.makeText(
                    this,
                    auditControl != null && auditControl.isPaused()
                            ? "Аудит на паузе — используйте «Продолжить» или «Остановить»"
                            : "Аудит уже запущен",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }
        runAudit();
    }

    private void scrollToTop() {
        View content = findViewById(android.R.id.content);
        if (content != null) content.requestFocus();
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(16), dp(14), dp(16), dp(18));

        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{ Color.rgb(0, 174, 93), Color.rgb(0, 207, 112) }
        );
        header.setBackground(bg);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView menu = iconText("☰", 30);
        menu.setContentDescription("Меню");

        TextView title = label("Cubux Audit 2.5", 24, true, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);

        TextView settings = iconText("⚙", 27);
        settings.setContentDescription("Настройки");
        settings.setOnClickListener(v -> showSettingsDialog());

        TextView bell = iconText("●", 14);
        bell.setContentDescription("Уведомления");
        bell.setPadding(dp(8), dp(6), dp(2), dp(6));
        bell.setOnClickListener(v -> Toast.makeText(this,
                "Уведомления об аудите настраиваются в разделе «Настройки»",
                Toast.LENGTH_SHORT).show());

        top.addView(menu);
        top.addView(title, titleLp);
        top.addView(settings);
        top.addView(bell);
        header.addView(top);

        TextView sub = label("Финансовый аудит  •  Только чтение", 13, false,
                Color.argb(225,255,255,255));
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(3), 0, 0);
        header.addView(sub);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, dp(20), 0, 0);

        totalTop = topStat("▤", "0", "Всего\nопераций", GREEN);
        newTop = topStat("+", "0", "Новые", GREEN);
        changedTop = topStat("✎", "0", "Изменённые", YELLOW);
        deletedTop = topStat("▥", "0", "Удалённые", RED);

        stats.addView(totalTop, weight());
        stats.addView(newTop, weight());
        stats.addView(changedTop, weight());
        stats.addView(deletedTop, weight());
        header.addView(stats);
        return header;
    }

    private TextView topStat(
            String icon,
            String value,
            String caption,
            int accent
    ) {
        TextView v = label(icon + "  " + value + "\n" + caption, 11, false, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(74));
        v.setPadding(dp(2), dp(8), dp(2), dp(8));
        GradientDrawable bg = rounded(Color.argb(28,255,255,255), 18);
        bg.setStroke(dp(1), Color.argb(95,255,255,255));
        v.setBackground(bg);
        return v;
    }

    private View buildAuditPanel() {
        LinearLayout card = card();

        LinearLayout first = new LinearLayout(this);
        first.setOrientation(LinearLayout.HORIZONTAL);
        first.setGravity(Gravity.CENTER_VERTICAL);

        auditButton = new Button(this);
        auditButton.setText("▶  ЗАПУСТИТЬ АУДИТ");
        auditButton.setTextColor(Color.WHITE);
        auditButton.setTextSize(16);
        auditButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        auditButton.setAllCaps(false);
        auditButton.setPadding(dp(8), 0, dp(8), 0);
        auditButton.setBackground(rounded(GREEN, 18));
        auditButton.setOnClickListener(v -> runAudit());

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(64), 11);
        bp.setMargins(0,0,dp(14),0);
        first.addView(auditButton, bp);

        LinearLayout progressBlock = new LinearLayout(this);
        progressBlock.setOrientation(LinearLayout.VERTICAL);
        progressBlock.setGravity(Gravity.CENTER_VERTICAL);

        percentText = label("Проверка 0%", 18, true, TEXT);
        percentText.setPadding(0, 0, 0, dp(7));
        progressBlock.addView(percentText);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setProgressTintList(ColorStateList.valueOf(GREEN));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(226,232,239)));
        progressBlock.addView(progressBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(9)));

        first.addView(progressBlock, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 10));
        card.addView(first);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(0, dp(12), 0, 0);

        pauseButton = new Button(this);
        pauseButton.setText("⏸  Пауза");
        pauseButton.setTextColor(TEXT);
        pauseButton.setTextSize(14);
        pauseButton.setAllCaps(false);
        pauseButton.setEnabled(false);
        pauseButton.setBackground(rounded(Color.rgb(238,243,248), 15));
        pauseButton.setOnClickListener(v -> togglePause());

        stopButton = new Button(this);
        stopButton.setText("■  Остановить");
        stopButton.setTextColor(RED);
        stopButton.setTextSize(14);
        stopButton.setAllCaps(false);
        stopButton.setEnabled(false);
        stopButton.setBackground(rounded(Color.rgb(255,242,244), 15));
        stopButton.setOnClickListener(v -> stopAudit());

        LinearLayout.LayoutParams cp1 = new LinearLayout.LayoutParams(0, dp(48), 1);
        cp1.setMargins(0,0,dp(6),0);
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(0, dp(48), 1);
        cp2.setMargins(dp(6),0,0,0);
        controls.addView(pauseButton, cp1);
        controls.addView(stopButton, cp2);
        card.addView(controls);

        statusText = label("Готов к проверке", 16, true, TEXT);
        statusText.setPadding(0, dp(16), 0, dp(4));
        card.addView(statusText);

        detailsText = label("Автоаудит выключен", 13, false, MUTED);
        card.addView(detailsText);

        LinearLayout steps = new LinearLayout(this);
        steps.setPadding(0, dp(17), 0, 0);
        steps.addView(step("✓", "Подключение\nк Cubux"), weight());
        steps.addView(step("✓", "Чтение\nданных"), weight());
        steps.addView(step("○", "Сравнение"), weight());
        steps.addView(step("○", "Отчёт"), weight());
        card.addView(steps);
        return card;
    }

    private TextView step(
            String icon,
            String caption
    ) {
        TextView v = label(icon + "\n" + caption, 11, false, MUTED);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(58));
        return v;
    }

    private View buildStatsRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(14), 0, dp(4));

        newCard = statCard("▤", "0", "Новые", Color.rgb(0,197,111));
        changedCard = statCard("✎", "0", "Изменено", YELLOW);
        deletedCard = statCard("▥", "0", "Удалено", RED);
        closedCard = statCard("▣", "0", "Закрытые", PURPLE);
        multiCard = statCard("↻", "0", "Повторные", BLUE);

        row.addView(newCard, weight());
        row.addView(changedCard, weight());
        row.addView(deletedCard, weight());
        row.addView(closedCard, weight());
        row.addView(multiCard, weight());
        return row;
    }

    private TextView statCard(
            String icon,
            String value,
            String caption,
            int accent
    ) {
        TextView v = label(icon + "\n" + value + "\n" + caption, 11, true, TEXT);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(102));
        v.setPadding(dp(2), dp(10), dp(2), dp(10));
        int r = Color.red(accent), g = Color.green(accent), b = Color.blue(accent);
        GradientDrawable bg = rounded(Color.rgb(
                Math.min(255, 245 + r / 40),
                Math.min(255, 246 + g / 45),
                Math.min(255, 248 + b / 55)), 17);
        bg.setStroke(dp(1), Color.argb(95,r,g,b));
        v.setBackground(bg);
        return v;
    }

    private View buildNavigationGrid() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(14), 0, 0);

        wrap.addView(navRow(
                navCard("↺", "История аудитов", "Просмотр результатов прошлых проверок", Color.rgb(0,202,116),
                        v -> resultText.setText("ИСТОРИЯ АУДИТОВ\n\n" + db.recentRunsText())),
                navCard("▤", "Журнал изменений", "Все найденные изменения операций", YELLOW,
                        v -> showJournalDialog())
        ));

        wrap.addView(navRow(
                navCard("◔", "Отчёты", "Аналитика за день, неделю, месяц и год", BLUE,
                        v -> showReportsDialog()),
                navCard("▦", "Банковская сверка", "Сравнение Cubux с выпиской банка", PURPLE,
                        v -> showBankDialog())
        ));

        wrap.addView(navCardWide("▣", "Закрытые периоды",
                "Контроль изменений в уже завершённых периодах", Color.rgb(245,65,122),
                v -> resultText.setText("Закрытые периоды контролируются автоматически по SHA-256.\n" +
                        "Контрольная база прошлых дней не перезаписывается.")));

        wrap.addView(navRow(
                navCard("⬆", "Резервная копия", "Экспорт базы с проверкой SHA-256", Color.rgb(0,160,180),
                        v -> createBackup()),
                navCard("⬇", "Восстановление", "Восстановление базы из резервной копии", Color.rgb(90,110,140),
                        v -> pickRestore())
        ));
        return wrap;
    }

    private View navRow(
            View left,
            View right
    ) {
        LinearLayout row =
                new LinearLayout(this);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        lp.setMargins(
                0,
                0,
                dp(7),
                dp(12)
        );

        LinearLayout.LayoutParams rp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        rp.setMargins(
                dp(7),
                0,
                0,
                dp(12)
        );

        row.addView(
                left,
                lp
        );

        row.addView(
                right,
                rp
        );

        return row;
    }

    private View navCard(
            String icon,
            String title,
            String subtitle,
            int accent,
            View.OnClickListener listener
    ) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(13), dp(15), dp(11), dp(15));
        box.setMinimumHeight(dp(112));
        GradientDrawable bg = rounded(Color.WHITE, 20);
        bg.setStroke(dp(1), Color.rgb(232,237,244));
        box.setBackground(bg);
        box.setOnClickListener(listener);

        TextView bubble = label(icon, 23, true, Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable ibg = rounded(accent, 18);
        bubble.setBackground(ibg);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(54), dp(54));
        ip.setMargins(0,0,dp(12),0);
        box.addView(bubble, ip);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = label(title, 15, true, TEXT);
        TextView st = label(subtitle, 12, false, MUTED);
        st.setPadding(0,dp(4),0,0);
        texts.addView(t);
        texts.addView(st);
        box.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView arrow = label("›", 28, false, MUTED);
        arrow.setGravity(Gravity.CENTER);
        box.addView(arrow, new LinearLayout.LayoutParams(dp(22), dp(50)));
        return box;
    }


    private View navCardWide(String icon, String title, String subtitle, int accent, View.OnClickListener listener) {
        View v = navCard(icon, title, subtitle, accent, listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout card() {

        LinearLayout c =
                new LinearLayout(this);

        c.setOrientation(
                LinearLayout.VERTICAL
        );

        c.setPadding(
                dp(16),
                dp(16),
                dp(16),
                dp(16)
        );

        c.setBackground(
                rounded(
                        Color.WHITE,
                        22
                )
        );

        return c;
    }

    private LinearLayout.LayoutParams weight() {

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        p.setMargins(
                dp(3),
                0,
                dp(3),
                0
        );

        return p;
    }

    private TextView iconText(
            String value,
            int size
    ) {
        TextView v =
                label(
                        value,
                        size,
                        true,
                        Color.WHITE
                );

        v.setGravity(
                Gravity.CENTER
        );

        v.setPadding(
                dp(6),
                dp(6),
                dp(6),
                dp(6)
        );

        return v;
    }

    private TextView label(
            String value,
            int size,
            boolean bold,
            int color
    ) {
        TextView v =
                new TextView(this);

        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setFontFeatureSettings(
                "kern"
        );

        if (bold) {
            v.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD
            );
        }

        return v;
    }

    private GradientDrawable rounded(
            int color,
            int radiusDp
    ) {
        GradientDrawable d =
                new GradientDrawable();

        d.setColor(color);

        d.setCornerRadius(
                dp(radiusDp)
        );

        return d;
    }

    private int dp(
            int value
    ) {
        return (int) (
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density +
                        0.5f
        );
    }

    private void runAudit() {

        if (auditRunning) {
            onAuditNavigationPressed();
            return;
        }

        String login =
                credentials.getLogin();

        String password =
                credentials.getPassword();

        if (login.isEmpty() ||
                password.isEmpty()) {
            showLoginDialog(true);
            return;
        }

        auditButton.setEnabled(false);
        auditRunning = true;
        final long sessionId = ++auditSessionCounter;
        activeAuditSession = sessionId;
        maxPageShown = 0;
        maxLoadedShown = 0;
        maxPercentShown = 0;
        final AuditControl sessionControl = new AuditControl();
        auditControl = sessionControl;
        pauseButton.setEnabled(true);
        pauseButton.setText("⏸  ПАУЗА");
        stopButton.setEnabled(true);

        progressBar.setProgress(0);
        percentText.setText(
                "Проверка 0%"
        );

        resultText.setText("");

        startedMs =
                System.currentTimeMillis();

        retries = 0;

        AuditCoordinator coordinator =
                new AuditCoordinator(this);

        boolean recovery =
                coordinator.isRecovery();

        new Thread(
                () -> {
                    try {
                        AuditEngine.Result r =
                                coordinator.run(
                                        login,
                                        password,
                                        recovery,
                                        progressListener(sessionId, sessionControl),
                                        sessionControl
                                );

                        runOnUiThread(
                                () -> {
                                    if (sessionId == activeAuditSession) {
                                        showResult(r);
                                    }
                                }
                        );

                    } catch (Exception e) {
                        String msg =
                                e.getMessage() == null
                                        ? e.toString()
                                        : e.getMessage();

                        runOnUiThread(
                                () -> {
                                    if (sessionId != activeAuditSession) return;
                                    if (msg.contains("остановлен пользователем")) {
                                        statusText.setText("Аудит остановлен");
                                        resultText.setText("Проверка остановлена пользователем. Данные Cubux не изменялись.");
                                    } else {
                                        statusText.setText("АУДИТ ОСТАНОВЛЕН");
                                        resultText.setText("Причина:\n" + msg);
                                    }
                                }
                        );

                    } finally {
                        if (sessionId == activeAuditSession && auditControl == sessionControl) {
                            auditRunning = false;
                        }
                        runOnUiThread(
                                () -> {
                                    if (sessionId != activeAuditSession || auditControl != sessionControl) return;
                                    auditButton.setEnabled(true);
                                    pauseButton.setEnabled(false);
                                    pauseButton.setText("⏸  ПАУЗА");
                                    stopButton.setEnabled(false);
                                }
                        );
                    }
                }
        ).start();
    }

    private void togglePause() {
        final AuditControl control = auditControl;
        if (!auditRunning || control == null || control.isStopped()) return;
        if (control.isPaused()) {
            control.resume();
            pauseButton.setText("⏸  ПАУЗА");
            statusText.setText("Продолжаю аудит...");
        } else {
            control.pause();
            pauseButton.setText("▶  ПРОДОЛЖИТЬ");
            statusText.setText("Аудит на паузе");
            detailsText.setText(
                    maxLoadedShown + " операций • страница " + maxPageShown +
                    "\nПрогресс зафиксирован • нажмите «Продолжить»"
            );
        }
    }

    private void stopAudit() {
        final AuditControl control = auditControl;
        if (!auditRunning || control == null || control.isStopped()) return;
        control.stop();
        pauseButton.setEnabled(false);
        stopButton.setEnabled(false);
        statusText.setText("Останавливаю аудит...");
        detailsText.setText(
                maxLoadedShown + " операций • страница " + maxPageShown +
                "\nТекущий запрос Cubux отменяется..."
        );
    }

    private AuditProgressListener progressListener(
            final long sessionId,
            final AuditControl sessionControl
    ) {
        return new AuditProgressListener() {

            private boolean isCurrent() {
                return sessionId == activeAuditSession
                        && auditRunning
                        && auditControl == sessionControl
                        && !sessionControl.isStopped();
            }

            @Override
            public void onStage(
                    String stage,
                    String message
            ) {
                if (!isCurrent() || sessionControl.isPaused()) return;
                runOnUiThread(
                        () ->
                                statusText.setText(
                                        message
                                )
                );
            }

            @Override
            public void onMeta(
                    int total,
                    int pages
            ) {
                if (!isCurrent()) return;
                runOnUiThread(
                        () ->
                                detailsText.setText(
                                        "Найдено " +
                                                total +
                                                " операций • " +
                                                pages +
                                                " страниц"
                                )
                );
            }

            @Override
            public void onPage(
                    int page,
                    int pages,
                    int loaded,
                    int total
            ) {
                if (!isCurrent() || sessionControl.isPaused()) return;
                updateProgress(
                        sessionId,
                        sessionControl,
                        page,
                        pages,
                        loaded,
                        total
                );
            }

            @Override
            public void onRetry(
                    int page,
                    int attempt,
                    int retrySeconds,
                    String error
            ) {
                if (!isCurrent()) return;
                retries++;

                runOnUiThread(
                        () -> {
                            statusText.setText(
                                    "Соединение прервано. Жду восстановления..."
                            );

                            detailsText.setText(
                                    "Страница " +
                                            page +
                                            " • прогресс сохранён" +
                                            "\nПовтор через " +
                                            retrySeconds +
                                            " сек." +
                                            "\nПопытка " +
                                            attempt
                            );
                        }
                );
            }
        };
    }

    private void updateProgress(
            long sessionId,
            AuditControl sessionControl,
            int page,
            int pages,
            int loaded,
            int total
    ) {
        if (sessionId != activeAuditSession || !auditRunning) return;

        // Never allow stale/retried callbacks to move UI backwards.
        if (page < maxPageShown || loaded < maxLoadedShown) return;

        maxPageShown = Math.max(maxPageShown, page);
        maxLoadedShown = Math.max(maxLoadedShown, loaded);
        long elapsed =
                System.currentTimeMillis() -
                        startedMs;

        int rawPercent =
                total <= 0
                        ? 0
                        : (int) (
                                loaded *
                                        90.0 /
                                        total
                        );

        final int percent =
                Math.max(
                        maxPercentShown,
                        Math.min(90, rawPercent)
                );

        maxPercentShown = percent;

        double speed =
                loaded /
                        Math.max(
                                1,
                                elapsed /
                                        1000.0
                        );

        runOnUiThread(
                () -> {
                    if (sessionId != activeAuditSession || !auditRunning) return;
                    if (auditControl != sessionControl || sessionControl.isPaused() || sessionControl.isStopped()) return;
                    progressBar.setProgress(
                            Math.min(
                                    100,
                                    percent
                            )
                    );

                    percentText.setText(
                            "Проверка " +
                                    percent +
                                    "%"
                    );

                    statusText.setText(
                            "Читаю данные Cubux..."
                    );

                    detailsText.setText(
                            maxLoadedShown +
                                    " из " +
                                    total +
                                    " операций • страница " +
                                    maxPageShown +
                                    " из " +
                                    pages +
                                    "\nСкорость: " +
                                    String.format(
                                            Locale.US,
                                            "%.1f",
                                            speed
                                    ) +
                                    " операций/сек • прошло " +
                                    TimeUtil.formatDuration(
                                            elapsed
                                    ) +
                                    "\nПоследняя активность: " +
                                    TimeUtil.clock()
                    );
                }
        );
    }

    private void showResult(
            AuditEngine.Result r
    ) {
        try {
            if (db.getState("auto_audit_enabled") == null) {
                AutoAuditScheduler.enable(this, 30);
            } else if (AutoAuditScheduler.isEnabled(this)) {
                AutoAuditScheduler.scheduleNext(
                        this,
                        AutoAuditScheduler.getIntervalMinutes(this)
                );
            }
            refreshAutoAuditStatus();
            requestNotificationPermissionIfNeeded();
        } catch (Throwable ignored) {
        }

        progressBar.setProgress(100);

        percentText.setText(
                "Проверка 100%"
        );

        statusText.setText(
                "Проверка завершена успешно"
        );

        long nextAuto = AutoAuditScheduler.getNextAuditMs(this);
        String nextAutoText = AutoAuditScheduler.isEnabled(this) && nextAuto > 0
                ? new java.text.SimpleDateFormat(
                        "dd.MM HH:mm",
                        Locale.getDefault()
                ).format(new java.util.Date(nextAuto))
                : "выключен";

        detailsText.setText(
                "Последняя проверка: " +
                        TimeUtil.now() +
                        " • " +
                        TimeUtil.formatDuration(r.durationMs) +
                        "\nСледующий автоаудит: " +
                        nextAutoText
        );

        setStat(
                totalTop,
                "▤",
                r.total,
                "Всего операций"
        );

        setStat(
                newTop,
                "+",
                r.newCount,
                "Новые"
        );

        setStat(
                changedTop,
                "✎",
                r.changedCount,
                "Изменённые"
        );

        setStat(
                deletedTop,
                "▥",
                r.deletedCount,
                "Удалённые"
        );

        setMiniStat(
                newCard,
                "▤",
                r.newCount,
                "Новые"
        );

        setMiniStat(
                changedCard,
                "✎",
                r.changedCount,
                "Изменённые"
        );

        setMiniStat(
                deletedCard,
                "▥",
                r.deletedCount,
                "Удалённые"
        );

        setMiniStat(
                closedCard,
                "▣",
                r.closedChangedCount,
                "Закрытые"
        );

        setMiniStat(
                multiCard,
                "↻",
                r.multiChangedCount,
                "Повторные"
        );

        resultText.setText(
                "Целостность: ОК • Cubux: только чтение"
        );
    }

    private void setStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        view.setText(
                icon +
                        "   " +
                        value +
                        "\n" +
                        caption
        );
    }

    private void setMiniStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        view.setText(
                icon +
                        "\n" +
                        value +
                        "\n" +
                        caption
        );
    }

    private void showLoginDialog(
            boolean runAfterSave
    ) {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        int pad = dp(18);

        box.setPadding(
                pad,
                0,
                pad,
                0
        );

        EditText login =
                new EditText(this);

        login.setHint(
                "Логин Cubux"
        );

        login.setSingleLine(true);

        login.setText(
                credentials.getLogin()
        );

        EditText password =
                new EditText(this);

        password.setHint(
                "Пароль Cubux"
        );

        password.setSingleLine(true);

        password.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        box.addView(login);
        box.addView(password);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Авторизация Cubux"
                )
                .setMessage(
                        "Приложение само получит и будет обновлять API-токен."
                )
                .setView(box)
                .setPositiveButton(
                        "Сохранить",
                        (d, w) -> {
                            try {
                                credentials.saveCredentials(
                                        login.getText()
                                                .toString()
                                                .trim(),
                                        password.getText()
                                                .toString()
                                );

                                credentials.clearToken();

                                Toast.makeText(
                                        this,
                                        "Данные сохранены",
                                        Toast.LENGTH_SHORT
                                ).show();

                                if (runAfterSave) {
                                    runAudit();
                                }

                            } catch (Exception e) {
                                Toast.makeText(
                                        this,
                                        "Ошибка сохранения",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void showSettingsDialog() {
        String autoText = AutoAuditScheduler.isEnabled(this)
                ? "Автоаудит: выключить"
                : "Автоаудит: включить";

        String[] items = {
                "Логин и пароль Cubux",
                autoText,
                "Интервал автоаудита",
                "Удалить данные авторизации"
        };

        new AlertDialog.Builder(this)
                .setTitle(
                        "Настройки"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                showLoginDialog(false);
                            } else if (which == 1) {
                                if (AutoAuditScheduler.isEnabled(this)) {
                                    AutoAuditScheduler.disable(this);
                                    Toast.makeText(this, "Автоаудит выключен", Toast.LENGTH_SHORT).show();
                                } else {
                                    AutoAuditScheduler.enable(
                                            this,
                                            AutoAuditScheduler.getIntervalMinutes(this)
                                    );
                                    Toast.makeText(this, "Автоаудит включён", Toast.LENGTH_SHORT).show();
                                }
                                refreshAutoAuditStatus();
                            } else if (which == 2) {
                                intervalDialog();
                            } else {
                                credentials.clearAll();
                                AutoAuditScheduler.disable(this);
                                refreshAutoAuditStatus();

                                Toast.makeText(
                                        this,
                                        "Логин, пароль и токен удалены",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                )
                .show();
    }

    private void intervalDialog() {
        final String[] labels = {
                "15 минут",
                "30 минут",
                "1 час",
                "2 часа",
                "6 часов",
                "12 часов",
                "24 часа"
        };

        final long[] values = {
                15,
                30,
                60,
                120,
                360,
                720,
                1440
        };

        new AlertDialog.Builder(this)
                .setTitle(
                        "Интервал автоаудита"
                )
                .setItems(
                        labels,
                        (d, which) -> {
                            db.saveState(
                                    "audit_interval_minutes",
                                    String.valueOf(values[which])
                            );

                            if (AutoAuditScheduler.isEnabled(this)) {
                                AutoAuditScheduler.enable(
                                        this,
                                        values[which]
                                );
                            }

                            refreshAutoAuditStatus();

                            Toast.makeText(
                                    this,
                                    "Автоаудит: " +
                                            labels[which],
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                )
                .show();
    }

    private void refreshAutoAuditStatus() {
        if (detailsText == null) return;

        if (!AutoAuditScheduler.isEnabled(this)) {
            detailsText.setText("Автоаудит выключен");
            return;
        }

        long interval = AutoAuditScheduler.getIntervalMinutes(this);
        long next = AutoAuditScheduler.getNextAuditMs(this);

        String nextText = next > 0
                ? new java.text.SimpleDateFormat(
                        "dd.MM HH:mm",
                        Locale.getDefault()
                ).format(new java.util.Date(next))
                : "после первой успешной проверки";

        detailsText.setText(
                "Автоаудит: каждые " + interval +
                        " мин. • следующая: " + nextText
        );
    }

    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                        android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    2203
            );
        }
    }

    private void showReportsDialog() {
        String[] items = {
                "День",
                "Неделя",
                "Месяц",
                "Год",
                "Произвольный период"
        };

        ReportEngine r =
                new ReportEngine(db);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Отчёты"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                resultText.setText(
                                        r.today()
                                );
                            } else if (
                                    which == 1
                            ) {
                                resultText.setText(
                                        r.week()
                                );
                            } else if (
                                    which == 2
                            ) {
                                resultText.setText(
                                        r.month()
                                );
                            } else if (
                                    which == 3
                            ) {
                                resultText.setText(
                                        r.year()
                                );
                            } else {
                                customReportDialog();
                            }
                        }
                )
                .show();
    }

    private void showBankDialog() {
        String[] items = {
                "Импорт CSV / XLSX",
                "Сверить банк с Cubux"
        };

        new AlertDialog.Builder(this)
                .setTitle(
                        "Банковская сверка"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                pickBankFile();
                            } else {
                                new Thread(
                                        () -> {
                                            String text =
                                                    new BankReconcileEngine(
                                                            db
                                                    ).reconcile();

                                            runOnUiThread(
                                                    () ->
                                                            resultText
                                                                    .setText(
                                                                            text
                                                                    )
                                            );
                                        }
                                ).start();
                            }
                        }
                )
                .show();
    }

    private void showJournalDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText search =
                new EditText(this);

        search.setHint(
                "Поиск: дата, сумма, категория, счёт, описание, ID"
        );

        Spinner filter =
                new Spinner(this);

        String[] values = {
                "Все",
                "Новые",
                "Изменённые",
                "Удалённые",
                "Закрытые периоды",
                "Повторные изменения"
        };

        filter.setAdapter(
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        values
                )
        );

        box.addView(search);
        box.addView(filter);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Журнал изменений"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        db.journalText(
                                                journalFilterKey(filter.getSelectedItemPosition()),
                                                search.getText().toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private String journalFilterKey(int position) {
        switch (position) {
            case 1: return "NEW";
            case 2: return "CHANGED";
            case 3: return "DELETED";
            case 4: return "CLOSED";
            case 5: return "MULTI";
            default: return "ALL";
        }
    }

    private void customReportDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText from =
                new EditText(this);

        from.setHint(
                "От YYYY-MM-DD"
        );

        EditText to =
                new EditText(this);

        to.setHint(
                "До YYYY-MM-DD"
        );

        box.addView(from);
        box.addView(to);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Произвольный период"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        new ReportEngine(
                                                db
                                        ).report(
                                                from.getText()
                                                        .toString(),
                                                to.getText()
                                                        .toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void pickBankFile() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType("*/*");

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_BANK
        );
    }

    private void createBackup() {
        Intent i =
                new Intent(
                        Intent.ACTION_CREATE_DOCUMENT
                );

        i.setType(
                "application/zip"
        );

        i.putExtra(
                Intent.EXTRA_TITLE,
                "CubuxAudit-backup.zip"
        );

        startActivityForResult(
                i,
                REQ_BACKUP
        );
    }

    private void pickRestore() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType(
                "application/zip"
        );

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_RESTORE
        );
    }

    private String getDisplayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {
        }
        return uri.toString();
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (resultCode != RESULT_OK ||
                data == null ||
                data.getData() == null) {
            return;
        }

        Uri uri = data.getData();

        if (requestCode == REQ_BANK) {
            new Thread(
                    () -> {
                        try {
                            int imported =
                                    new BankImportEngine(
                                            db
                                    ).importFile(
                                            getContentResolver(),
                                            uri,
                                            getDisplayName(uri)
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Импортировано банковских операций: " +
                                                            imported
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка импорта: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (
                requestCode ==
                        REQ_BACKUP
        ) {
            new Thread(
                    () -> {
                        try {
                            String hash =
                                    new BackupManager(
                                            this,
                                            db
                                    ).exportTo(
                                            getContentResolver(),
                                            uri
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Backup создан\nSHA-256:\n" +
                                                            hash
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка backup: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (
                requestCode ==
                        REQ_RESTORE
        ) {
            new Thread(
                    () -> {
                        try {
                            new BackupManager(
                                    this,
                                    db
                            ).restoreFrom(
                                    getContentResolver(),
                                    uri
                            );

                            db =
                                    new AuditDb(this);

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Backup восстановлен. Запустите аудит для сравнения с текущим Cubux."
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка восстановления: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();
        }
    }
}
