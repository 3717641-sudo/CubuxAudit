package com.cubux.audit;

import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AuditCoordinator {
    public static final String MODE_QUICK="QUICK";
    public static final String MODE_FULL="FULL";

    private final Context context;
    private final AuditDb db;
    private final SecureCredentialsStore credentials;

    public AuditCoordinator(Context context){
        this.context=context.getApplicationContext();
        db=new AuditDb(this.context);
        credentials=new SecureCredentialsStore(this.context);
    }

    public AuditEngine.Result run(String login,String password,boolean recovery,
                                  AuditProgressListener listener)throws Exception{
        return run(login,password,recovery,listener,null);
    }

    public AuditEngine.Result run(String login,String password,boolean recovery,
                                  AuditProgressListener listener,AuditControl control)throws Exception{
        return runMode(login,password,recovery,listener,control,MODE_FULL);
    }

    public AuditEngine.Result runMode(String login,String password,boolean recovery,
                                      AuditProgressListener listener,AuditControl control,
                                      String mode)throws Exception{
        if(!AuditRunGate.tryAcquire())throw new Exception("Другой аудит уже выполняется");
        AuditControlRegistry.attach(control,mode);
        DiagnosticLog.write(context,"AUDIT","Старт. Режим="+mode+", recovery="+recovery);

        try{
            credentials.saveCredentials(login,password);
            long startedMs=System.currentTimeMillis();
            long runId=db.createRun(recovery);
            int[] retries={0};

            try{
                String token=credentials.getToken();
                if(token.isEmpty()){
                    stage(listener,"AUTHENTICATING","Авторизуюсь в Cubux...");
                    token=new CubuxAuthClient().login(login,password);
                    credentials.saveToken(token);
                }

                CubuxClient client=new CubuxClient(token,()->{
                    stage(listener,"REAUTHENTICATING","Токен истёк. Получаю новый...");
                    String fresh=new CubuxAuthClient().login(credentials.getLogin(),credentials.getPassword());
                    credentials.saveToken(fresh);
                    return fresh;
                },control);

                boolean partial=MODE_QUICK.equals(mode);
                String from=partial?quickFromDate():"2021-07-04";
                String to=TimeUtil.today();
                DiagnosticLog.write(context,"AUDIT","Диапазон "+from+" .. "+to);

                CubuxLoader loader=new CubuxLoader(client,from,to,new AuditProgressListener(){
                    @Override public void onStage(String st,String msg){
                        db.updateRunStage(runId,st);
                        DiagnosticLog.write(context,"STAGE",st+" — "+msg);
                        if(listener!=null)listener.onStage(st,msg);
                    }
                    @Override public void onMeta(int total,int pages){
                        DiagnosticLog.write(context,"META","Операций="+total+", страниц="+pages);
                        if(listener!=null)listener.onMeta(total,pages);
                    }
                    @Override public void onPage(int page,int pages,int loaded,int total){
                        double elapsed=Math.max(1,(System.currentTimeMillis()-startedMs)/1000.0);
                        db.updateRunProgress(runId,"READING_DATA",page,pages,loaded,total,loaded/elapsed,retries[0]);
                        DiagnosticLog.write(context,"PAGE",page+"/"+pages+"; "+loaded+"/"+total);
                        if(listener!=null)listener.onPage(page,pages,loaded,total);
                    }
                    @Override public void onRetry(int page,int attempt,int retrySeconds,String error){
                        retries[0]++;
                        DiagnosticLog.write(context,"RETRY","Страница="+page+", попытка="+attempt+", ошибка="+error);
                        if(listener!=null)listener.onRetry(page,attempt,retrySeconds,error);
                    }
                },control);

                CubuxLoader.Result loaded=loader.loadAll();
                stage(listener,"PROCESSING","Проверяю полученные данные...");

                PeriodControlEngine.Result period=new PeriodControlEngine(db).analyze(loaded.items,partial);
                stage(listener,"COMPARING","Сравниваю с предыдущей проверкой...");

                boolean restoreSync="1".equals(db.getState("restore_sync_pending"));
                AuditEngine.Result result=new AuditEngine(context).audit(
                        loaded.items,loaded.totalCount,runId,period.detailedDates,
                        period.closedChangedCount,startedMs,partial,from,restoreSync
                );

                db.saveState("last_successful_audit_ms",String.valueOf(System.currentTimeMillis()));
                db.saveState("last_audit_mode",mode);
                DiagnosticLog.write(context,"AUDIT","Успешно. Всего="+result.total+
                        ", новые="+result.newCount+", изменено="+result.changedCount+
                        ", удалено="+result.deletedCount);
                return result;

            }catch(AuditControl.AuditStoppedException e){
                db.stopRun(runId);
                DiagnosticLog.write(context,"AUDIT","Остановлен пользователем");
                throw e;
            }catch(Exception e){
                db.failRun(runId,e.getMessage()==null?e.toString():e.getMessage());
                DiagnosticLog.error(context,"AUDIT_ERROR",e);
                throw e;
            }
        }finally{
            AuditControlRegistry.clear(control);
            AuditRunGate.release();
        }
    }

    public AuditEngine.Result runStored(boolean recovery,AuditProgressListener listener)throws Exception{
        return runStoredMode(recovery,listener,MODE_QUICK);
    }

    public AuditEngine.Result runStoredMode(boolean recovery,AuditProgressListener listener,String mode)throws Exception{
        String login=credentials.getLogin(),password=credentials.getPassword();
        if(login.isEmpty()||password.isEmpty())throw new Exception("Логин/пароль Cubux не сохранены");
        return runMode(login,password,recovery,listener,null,mode);
    }

    private void stage(AuditProgressListener listener,String st,String msg){
        if(listener!=null)listener.onStage(st,msg);
    }

    private String quickFromDate(){
        Calendar c=Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR,-7);
        return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
    }

    public boolean isRecovery(){
        String value=db.getState("last_successful_audit_ms");
        if(value==null)return false;
        try{
            long last=Long.parseLong(value);
            return System.currentTimeMillis()-last>45L*60L*1000L;
        }catch(Exception e){return false;}
    }
}
