package com.cubux.audit;

import android.content.Context;

public class AuditCoordinator {

    private final Context context;
    private final AuditDb db;
    private final SecureCredentialsStore credentials;

    public AuditCoordinator(
            Context context
    ) {
        this.context =
                context.getApplicationContext();

        db = new AuditDb(
                this.context
        );

        credentials =
                new SecureCredentialsStore(
                        this.context
                );
    }

    public AuditEngine.Result run(
            String login,
            String password,
            boolean recovery,
            AuditProgressListener listener
    ) throws Exception {

        credentials.saveCredentials(
                login,
                password
        );

        long startedMs =
                System.currentTimeMillis();

        long runId =
                db.createRun(recovery);

        int[] retries =
                new int[]{0};

        try {
            String token =
                    credentials.getToken();

            if (token.isEmpty()) {
                if (listener != null) {
                    listener.onStage(
                            "AUTHENTICATING",
                            "Авторизуюсь в Cubux..."
                    );
                }

                token =
                        new CubuxAuthClient()
                                .login(
                                        login,
                                        password
                                );

                credentials.saveToken(token);
            }

            CubuxClient client =
                    new CubuxClient(
                            token,
                            () -> {
                                if (listener != null) {
                                    listener.onStage(
                                            "REAUTHENTICATING",
                                            "Токен истёк. Получаю новый..."
                                    );
                                }

                                String fresh =
                                        new CubuxAuthClient()
                                                .login(
                                                        credentials.getLogin(),
                                                        credentials.getPassword()
                                                );

                                credentials.saveToken(
                                        fresh
                                );

                                return fresh;
                            }
                    );

            CubuxLoader loader =
                    new CubuxLoader(
                            client,
                            "2021-07-04",
                            TimeUtil.today(),
                            new AuditProgressListener() {

                                @Override
                                public void onStage(
                                        String stage,
                                        String message
                                ) {
                                    db.updateRunStage(
                                            runId,
                                            stage
                                    );

                                    if (listener != null) {
                                        listener.onStage(
                                                stage,
                                                message
                                        );
                                    }
                                }

                                @Override
                                public void onMeta(
                                        int totalCount,
                                        int pageCount
                                ) {
                                    if (listener != null) {
                                        listener.onMeta(
                                                totalCount,
                                                pageCount
                                        );
                                    }
                                }

                                @Override
                                public void onPage(
                                        int currentPage,
                                        int pageCount,
                                        int loadedCount,
                                        int totalCount
                                ) {
                                    double elapsed =
                                            Math.max(
                                                    1,
                                                    (
                                                            System.currentTimeMillis() -
                                                                    startedMs
                                                    ) /
                                                            1000.0
                                            );

                                    db.updateRunProgress(
                                            runId,
                                            "READING_DATA",
                                            currentPage,
                                            pageCount,
                                            loadedCount,
                                            totalCount,
                                            loadedCount / elapsed,
                                            retries[0]
                                    );

                                    if (listener != null) {
                                        listener.onPage(
                                                currentPage,
                                                pageCount,
                                                loadedCount,
                                                totalCount
                                        );
                                    }
                                }

                                @Override
                                public void onRetry(
                                        int page,
                                        int attempt,
                                        int retrySeconds,
                                        String error
                                ) {
                                    retries[0]++;

                                    if (listener != null) {
                                        listener.onRetry(
                                                page,
                                                attempt,
                                                retrySeconds,
                                                error
                                        );
                                    }
                                }
                            }
                    );

            CubuxLoader.Result loaded =
                    loader.loadAll();

            PeriodControlEngine.Result period =
                    new PeriodControlEngine(
                            db
                    ).analyze(
                            loaded.items
                    );

            AuditEngine.Result result =
                    new AuditEngine(
                            context
                    ).audit(
                            loaded.items,
                            loaded.totalCount,
                            runId,
                            period.detailedDates,
                            period.closedChangedCount,
                            startedMs
                    );

            db.saveState(
                    "last_successful_audit_ms",
                    String.valueOf(
                            System.currentTimeMillis()
                    )
            );

            return result;

        } catch (Exception e) {
            db.failRun(
                    runId,
                    e.getMessage() == null
                            ? e.toString()
                            : e.getMessage()
            );
            throw e;
        }
    }

    public AuditEngine.Result runStored(
            boolean recovery,
            AuditProgressListener listener
    ) throws Exception {

        String login =
                credentials.getLogin();

        String password =
                credentials.getPassword();

        if (login.isEmpty() ||
                password.isEmpty()) {
            throw new Exception(
                    "Логин/пароль Cubux не сохранены"
            );
        }

        return run(
                login,
                password,
                recovery,
                listener
        );
    }

    public boolean isRecovery() {
        String value =
                db.getState(
                        "last_successful_audit_ms"
                );

        if (value == null) {
            return false;
        }

        try {
            long last =
                    Long.parseLong(value);

            return System.currentTimeMillis() -
                    last >
                    45L * 60L * 1000L;

        } catch (Exception e) {
            return false;
        }
    }
}
