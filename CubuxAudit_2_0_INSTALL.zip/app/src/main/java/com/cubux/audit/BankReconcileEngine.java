package com.cubux.audit;
import org.json.JSONObject;import java.util.*;
public class BankReconcileEngine{
 private final AuditDb db;public BankReconcileEngine(AuditDb d){db=d;}
 public String reconcile(){for(AuditDb.BankRow b:db.bankRows()){String best=null;double bs=0;for(JSONObject c:db.currentJson()){double a=c.optDouble("amount",0);if(a<=0)continue;double s=0;String d=c.optString("date","");if(d.length()>=10)d=d.substring(0,10);if(b.date!=null&&b.date.equals(d))s+=.45;if(Math.abs(b.amount-a)<.01)s+=.45;if(b.currency!=null&&!b.currency.isEmpty()&&b.currency.equalsIgnoreCase(c.optString("currency_code","")))s+=.05;String cd=c.optString("description","");if(b.description!=null&&!b.description.isEmpty()&&!cd.isEmpty()&&cd.toLowerCase().contains(b.description.toLowerCase()))s+=.05;if(s>bs){bs=s;best=String.valueOf(c.opt("id"));}}String st=bs>=.9?"EXACT":bs>=.6?"PROBABLE":bs>=.4?"MANUAL":"MISSING_CUBUX";if("MISSING_CUBUX".equals(st))best=null;db.bankMatch(b.id,best,st,bs,"date="+b.date+", amount="+b.amount);}return db.bankSummary();}
}
