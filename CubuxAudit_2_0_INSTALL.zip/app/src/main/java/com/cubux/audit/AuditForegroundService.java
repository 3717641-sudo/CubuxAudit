package com.cubux.audit;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.os.IBinder;

public class AuditForegroundService extends Service {
    public static final String CHANNEL="cubux_audit_running";
    public static final int ID=2601;
    public static volatile int percent=0, page=0, pages=0, loaded=0, total=0;
    public static volatile String state="Подготовка аудита";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(ID, buildNotification());
        return START_STICKY;
    }

    public static void start(Context c) {
        Intent i=new Intent(c, AuditForegroundService.class);
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i); else c.startService(i);
    }

    public static void stop(Context c) {
        try { c.stopService(new Intent(c, AuditForegroundService.class)); } catch(Throwable ignored){}
    }

    public static void update(Context c,String st,int pct,int pg,int pgs,int ld,int ttl) {
        state=st==null?state:st; percent=Math.max(percent,pct); page=Math.max(page,pg);
        pages=Math.max(pages,pgs); loaded=Math.max(loaded,ld); total=Math.max(total,ttl);
        try {
            NotificationManager m=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            if(m!=null)m.notify(ID, buildStatic(c));
        } catch(Throwable ignored){}
    }

    public static void reset() {
        percent=page=pages=loaded=total=0; state="Подготовка аудита";
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager m=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            if(m!=null){
                NotificationChannel ch=new NotificationChannel(CHANNEL,"Текущий аудит",NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Прогресс выполняющегося аудита Cubux");
                m.createNotificationChannel(ch);
            }
        }
    }

    private Notification buildNotification(){ return buildStatic(this); }

    private static Notification buildStatic(Context c){
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent content=PendingIntent.getActivity(c,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent pause=action(c,"PAUSE",2);
        PendingIntent resume=action(c,"RESUME",3);
        PendingIntent stop=action(c,"STOP",4);

        Notification.Builder b=Build.VERSION.SDK_INT>=26?
                new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
        String progress= total>0 ? loaded+" из "+total+" • страница "+page+" из "+pages : state;
        b.setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("Cubux Audit — "+percent+"%")
                .setContentText(progress)
                .setStyle(new Notification.BigTextStyle().bigText(state+"\n"+progress))
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(content)
                .setProgress(100,Math.min(100,percent),false)
                .addAction(new Notification.Action.Builder(null,"Пауза",pause).build())
                .addAction(new Notification.Action.Builder(null,"Продолжить",resume).build())
                .addAction(new Notification.Action.Builder(null,"Стоп",stop).build());
        return b.build();
    }

    private static PendingIntent action(Context c,String a,int code){
        Intent i=new Intent(c,AuditActionReceiver.class).setAction("com.cubux.audit."+a);
        return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }

    @Override public IBinder onBind(Intent intent){return null;}
}
