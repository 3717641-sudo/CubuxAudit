package com.cubux.audit;
import org.json.JSONObject; import java.util.*;
public class ReportEngine {
 private final AuditDb db; public ReportEngine(AuditDb d){db=d;}
 public String report(String from,String to){int c=0;double in=0,out=0;for(JSONObject o:db.currentJson()){String d=o.optString("date","");if(d.length()<10)continue;d=d.substring(0,10);if(d.compareTo(from)<0||d.compareTo(to)>0)continue;c++;double a=o.optDouble("amount",0);if(a>=0)in+=a;else out+=Math.abs(a);}return "ОТЧЁТ\n"+from+" — "+to+"\n\nОпераций: "+c+"\nДоходы: "+String.format(Locale.US,"%.2f",in)+"\nРасходы: "+String.format(Locale.US,"%.2f",out)+"\nБаланс: "+String.format(Locale.US,"%.2f",in-out);}
 public String day(){String d=TimeUtil.today();return report(d,d);} public String month(){String t=TimeUtil.today();return report(t.substring(0,8)+"01",t);} public String year(){String t=TimeUtil.today();return report(t.substring(0,4)+"-01-01",t);} public String week(){Calendar cal=Calendar.getInstance();cal.setFirstDayOfWeek(Calendar.MONDAY);cal.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);String f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(cal.getTime());return report(f,TimeUtil.today());}
}
