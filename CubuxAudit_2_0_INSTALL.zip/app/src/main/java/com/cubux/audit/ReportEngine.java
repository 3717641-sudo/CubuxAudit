package com.cubux.audit;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReportEngine {

    private final AuditDb db;

    public ReportEngine(
            AuditDb db
    ) {
        this.db = db;
    }

    public String report(
            String from,
            String to
    ) {
        List<JSONObject> items =
                db.getCurrentTransactionsJson();

        int count = 0;
        double income = 0;
        double expense = 0;

        for (JSONObject item : items) {
            String date =
                    item.optString(
                            "date",
                            ""
                    );

            if (date.length() < 10) {
                continue;
            }

            date = date.substring(0, 10);

            if (date.compareTo(from) < 0 ||
                    date.compareTo(to) > 0) {
                continue;
            }

            count++;

            double amount =
                    item.optDouble(
                            "amount",
                            0
                    );

            if (amount >= 0) {
                income += amount;
            } else {
                expense += Math.abs(amount);
            }
        }

        return "ОТЧЁТ\n" +
                from + " — " + to +
                "\n\nОпераций: " +
                count +
                "\nДоходы: " +
                String.format(
                        Locale.US,
                        "%.2f",
                        income
                ) +
                "\nРасходы: " +
                String.format(
                        Locale.US,
                        "%.2f",
                        expense
                ) +
                "\nБаланс: " +
                String.format(
                        Locale.US,
                        "%.2f",
                        income - expense
                );
    }

    public String today() {
        String d = TimeUtil.today();
        return report(d, d);
    }

    public String week() {
        try {
            SimpleDateFormat f =
                    new SimpleDateFormat(
                            "yyyy-MM-dd",
                            Locale.US
                    );

            Date today =
                    f.parse(
                            TimeUtil.today()
                    );

            Calendar c =
                    Calendar.getInstance();

            c.setTime(today);

            int day =
                    c.get(
                            Calendar.DAY_OF_WEEK
                    );

            int delta =
                    day == Calendar.SUNDAY
                            ? -6
                            : Calendar.MONDAY - day;

            c.add(
                    Calendar.DAY_OF_MONTH,
                    delta
            );

            return report(
                    f.format(c.getTime()),
                    TimeUtil.today()
            );

        } catch (Exception e) {
            return "Не удалось сформировать отчёт за неделю";
        }
    }

    public String month() {
        String today =
                TimeUtil.today();

        return report(
                today.substring(0, 8) +
                        "01",
                today
        );
    }

    public String year() {
        String today =
                TimeUtil.today();

        return report(
                today.substring(0, 4) +
                        "-01-01",
                today
        );
    }
}
