package com.cubux.audit;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public final class AutoAuditScheduler {

    private static final String NAME =
            "cubux_auto_audit";

    private AutoAuditScheduler() {}

    public static boolean schedule(
            Context context,
            long minutes
    ) {

        try {

            long safe =
                    Math.max(
                            15,
                            minutes
                    );

            Constraints constraints =
                    new Constraints.Builder()
                            .setRequiredNetworkType(
                                    NetworkType.CONNECTED
                            )
                            .build();

            PeriodicWorkRequest request =
                    new PeriodicWorkRequest.Builder(
                            AuditWorker.class,
                            safe,
                            TimeUnit.MINUTES
                    )
                            .setConstraints(
                                    constraints
                            )
                            .build();

            WorkManager
                    .getInstance(
                            context.getApplicationContext()
                    )
                    .enqueueUniquePeriodicWork(
                            NAME,
                            ExistingPeriodicWorkPolicy.UPDATE,
                            request
                    );

            return true;

        } catch (Throwable error) {

            return false;
        }
    }

    public static void cancel(
            Context context
    ) {

        try {

            WorkManager
                    .getInstance(
                            context.getApplicationContext()
                    )
                    .cancelUniqueWork(NAME);

        } catch (Throwable ignored) {
        }
    }
}
