package com.cubux.audit;
import android.content.Context;import androidx.work.*;import java.util.concurrent.TimeUnit;
public final class AutoAuditScheduler{
 private AutoAuditScheduler(){} public static void schedule(Context c,long min){long m=Math.max(15,min);Constraints k=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest r=new PeriodicWorkRequest.Builder(AuditWorker.class,m,TimeUnit.MINUTES).setConstraints(k).build();WorkManager.getInstance(c).enqueueUniquePeriodicWork("cubux_auto_audit",ExistingPeriodicWorkPolicy.UPDATE,r);}public static void cancel(Context c){WorkManager.getInstance(c).cancelUniqueWork("cubux_auto_audit");}
}
