package com.cubux.audit;

import android.content.Context;

/**
 * Safe-start scheduler.
 * Background audit will be re-enabled after startup stability is confirmed.
 */
public final class AutoAuditScheduler {

    private AutoAuditScheduler() {}

    public static boolean schedule(
            Context context,
            long minutes
    ) {
        return true;
    }

    public static void cancel(
            Context context
    ) {
    }
}
