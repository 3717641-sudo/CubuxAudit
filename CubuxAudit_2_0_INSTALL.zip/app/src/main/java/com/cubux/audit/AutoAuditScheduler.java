package com.cubux.audit;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

public final class AutoAuditScheduler {

    private static final int JOB_ID = 2201;
    private static final long MIN_INTERVAL = 15L;

    private AutoAuditScheduler() {}

    public static boolean isEnabled(Context context) {
        return "1".equals(
                new AuditDb(context).getState("auto_audit_enabled")
        );
    }

    public static long getIntervalMinutes(Context context) {
        String value = new AuditDb(context).getState("audit_interval_minutes");
        if (value == null) return 30L;
        try {
            return Math.max(MIN_INTERVAL, Long.parseLong(value));
        } catch (Exception e) {
            return 30L;
        }
    }

    public static long getNextAuditMs(Context context) {
        String value = new AuditDb(context).getState("next_auto_audit_ms");
        if (value == null) return 0L;
        try {
            return Long.parseLong(value);
        } catch (Exception e) {
            return 0L;
        }
    }

    public static boolean enable(Context context, long minutes) {
        AuditDb db = new AuditDb(context);
        long safe = Math.max(MIN_INTERVAL, minutes);
        db.saveState("auto_audit_enabled", "1");
        db.saveState("audit_interval_minutes", String.valueOf(safe));
        return scheduleNext(context, safe);
    }

    public static void disable(Context context) {
        AuditDb db = new AuditDb(context);
        db.saveState("auto_audit_enabled", "0");
        db.saveState("next_auto_audit_ms", "0");

        try {
            JobScheduler scheduler =
                    (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (scheduler != null) {
                scheduler.cancel(JOB_ID);
            }
        } catch (Throwable ignored) {
        }
    }

    public static boolean scheduleNext(Context context, long minutes) {
        try {
            if (!isEnabled(context)) return false;

            long safe = Math.max(MIN_INTERVAL, minutes);
            long delayMs = safe * 60L * 1000L;
            long nextMs = System.currentTimeMillis() + delayMs;

            ComponentName component =
                    new ComponentName(context, AutoAuditJobService.class);

            JobInfo job = new JobInfo.Builder(JOB_ID, component)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setMinimumLatency(delayMs)
                    .setOverrideDeadline(delayMs + 10L * 60L * 1000L)
                    .setBackoffCriteria(
                            15L * 60L * 1000L,
                            JobInfo.BACKOFF_POLICY_EXPONENTIAL
                    )
                    .setPersisted(true)
                    .build();

            JobScheduler scheduler =
                    (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);

            if (scheduler == null) return false;

            scheduler.cancel(JOB_ID);
            int result = scheduler.schedule(job);

            if (result == JobScheduler.RESULT_SUCCESS) {
                new AuditDb(context).saveState(
                        "next_auto_audit_ms",
                        String.valueOf(nextMs)
                );
                return true;
            }

        } catch (Throwable ignored) {
        }

        return false;
    }

    public static void scheduleAfterRun(Context context) {
        if (!isEnabled(context)) return;
        scheduleNext(context, getIntervalMinutes(context));
    }
}
