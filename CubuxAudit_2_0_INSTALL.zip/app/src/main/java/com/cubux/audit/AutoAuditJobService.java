package com.cubux.audit;

import android.app.job.JobParameters;
import android.app.job.JobService;

public class AutoAuditJobService extends JobService {

    private volatile boolean cancelled = false;

    @Override
    public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            boolean needsRetry = false;

            try {
                AuditCoordinator coordinator =
                        new AuditCoordinator(getApplicationContext());

                coordinator.runStored(
                        coordinator.isRecovery(),
                        null
                );

                NotificationHelper.showAuditResult(
                        getApplicationContext(),
                        true,
                        "Автоаудит завершён успешно"
                );

            } catch (Exception e) {
                String message = e.getMessage() == null
                        ? e.toString()
                        : e.getMessage();

                if (message.contains("Логин/пароль Cubux не сохранены")) {
                    needsRetry = false;
                } else {
                    needsRetry = true;
                    NotificationHelper.showAuditResult(
                            getApplicationContext(),
                            false,
                            "Автоаудит отложен: " + message
                    );
                }
            } finally {
                if (!cancelled) {
                    if (!needsRetry) {
                        AutoAuditScheduler.scheduleAfterRun(
                                getApplicationContext()
                        );
                    }
                    jobFinished(params, needsRetry);
                }
            }
        }).start();

        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        cancelled = true;
        return true;
    }
}
