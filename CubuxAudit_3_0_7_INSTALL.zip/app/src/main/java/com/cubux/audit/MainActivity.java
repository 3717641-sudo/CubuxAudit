package com.cubux.audit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.os.Bundle;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_BANK = 1001;
    private static final int REQ_BACKUP = 1002;
    private static final int REQ_RESTORE = 1003;
    private static final int REQ_LOG = 1004;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_CHECK = 1;
    private static final int PAGE_BANK = 2;
    private static final int PAGE_REPORTS = 3;
    private static final int PAGE_JOURNAL = 4;
    private static final int PAGE_SETTINGS = 5;
    private static final int PAGE_COUNT = 6;

    private final int GREEN = Color.rgb(0, 190, 92);
    private final int DARK = Color.rgb(28, 37, 52);
    private final int TEXT = Color.rgb(26, 34, 48);
    private final int MUTED = Color.rgb(105, 119, 144);
    private final int RED = Color.rgb(255, 75, 88);
    private final int YELLOW = Color.rgb(255, 184, 31);
    private final int PURPLE = Color.rgb(126, 79, 255);
    private final int BLUE = Color.rgb(51, 151, 245);

    private AuditDb db;
    private SecureCredentialsStore credentials;

    private LinearLayout pageHost;
    private LinearLayout bottomNav;
    private TextView informerText;
    private int currentPage = PAGE_HOME;
    private float swipeDownX;
    private float swipeDownY;

    private EditText loginInput;
    private EditText passwordInput;

    private ProgressBar progressBar;
    private TextView percentText;
    private TextView statusText;
    private TextView detailsText;
    private TextView resultText;
    private TextView lastCheckText;

    private TextView connectStep;
    private TextView readStep;
    private TextView compareStep;
    private TextView reportStep;

    private TextView totalTop;
    private TextView newTop;
    private TextView changedTop;
    private TextView deletedTop;

    private TextView newCard;
    private TextView changedCard;
    private TextView deletedCard;
    private TextView closedCard;
    private TextView multiCard;

    private Button auditButton;
    private Button fullAuditButton;
    private Button pauseButton;
    private Button stopButton;
    private AuditControl auditControl;
    private long auditSessionCounter = 0L;
    private volatile long activeAuditSession = 0L;
    private volatile int maxPageShown = 0;
    private volatile int maxLoadedShown = 0;
    private volatile int maxPercentShown = 0;
    private volatile boolean auditRunning;
    private String activeCheckMode = AuditCoordinator.MODE_QUICK;
    private volatile String scanContext = "";
    private volatile String currentStageForUi = "IDLE";
    private volatile String currentWaitForUi = "";

    private long startedMs;
    private int retries;

    private final Handler progressSyncHandler = new Handler(Looper.getMainLooper());
    private boolean progressSyncActive = false;
    private final Runnable progressSyncTick = new Runnable() {
        @Override public void run() {
            if (!progressSyncActive) return;
            try { syncProgressFromService(); } catch (Throwable ignored) {}
            progressSyncHandler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);

        db = new AuditDb(this);
        if (!"1".equals(db.getState("legacy_baseline_noise_cleaned"))) {
            db.cleanupLegacyBaselineNoise();
        }
        String autoBackupTime = db.getState("auto_backup_time");
        String lastSuccessfulCheck = db.getState("last_successful_audit_ms");
        // Do not create an empty automatic backup on a fresh reinstall: an older
        // Downloads backup must remain easy to identify and restore first.
        if ((autoBackupTime == null || autoBackupTime.trim().isEmpty())
                && lastSuccessfulCheck != null && !lastSuccessfulCheck.trim().isEmpty()) {
            AutoBackupManager.backupAsync(this);
        }

        credentials =
                new SecureCredentialsStore(
                        this
                );

        createUi();

        try {
            NotificationHelper.ensureChannel(this);
            CheckScheduler.scheduleStartup(this);
            DiagnosticLog.write(this, "APP", "Приложение запущено");
            db.appEvent("INFO", "ПРИЛОЖЕНИЕ", "Cubux Security 3.0.7 запущен");
            refreshAutoAuditStatus();
            refreshLastCheckStatus();
        } catch (Throwable e) {
            DiagnosticLog.error(this, "APP_START", e);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startProgressSync();
        try {
            refreshAutoAuditStatus();
            refreshLastCheckStatus();
            refreshDashboardInformer();
            AuditControl running = AuditControlRegistry.current();
            if (running != null && AuditRunGate.isRunning()) {
                auditControl = running;
                auditRunning = true;
                if (currentPage != PAGE_CHECK) { refreshDashboardInformer(); return; }
                pauseButton.setEnabled(true);
                stopButton.setEnabled(true);
                auditButton.setEnabled(false);
                if (fullAuditButton != null) fullAuditButton.setEnabled(false);
                pauseButton.setVisibility(View.VISIBLE);
                stopButton.setVisibility(View.VISIBLE);
                AuditForegroundService.Snapshot snap = AuditForegroundService.snapshot();
                currentStageForUi = snap.stage == null ? currentStageForUi : snap.stage;
                currentWaitForUi = snap.note == null ? "" : snap.note;
                progressBar.setProgress(snap.percent);
                percentText.setText("Проверка " + snap.percent + "%");
                statusText.setText(running.isPaused() ? "Проверка на паузе" : snap.state);
                updateStageIndicators(currentStageForUi);
                detailsText.setText(runningDetails(snap));
            }
        } catch (Throwable e) {
            DiagnosticLog.error(this, "RESUME", e);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev != null) {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                swipeDownX = ev.getX();
                swipeDownY = ev.getY();
            } else if (ev.getAction() == MotionEvent.ACTION_UP) {
                float dx = ev.getX() - swipeDownX;
                float dy = ev.getY() - swipeDownY;
                if (Math.abs(dx) > dp(85) && Math.abs(dx) > Math.abs(dy) * 1.35f) {
                    if (dx < 0 && currentPage < PAGE_COUNT - 1) switchPage(currentPage + 1);
                    else if (dx > 0 && currentPage > 0) switchPage(currentPage - 1);
                    return true;
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopProgressSync();
    }

    private void startProgressSync() {
        if (progressSyncActive) return;
        progressSyncActive = true;
        progressSyncHandler.removeCallbacks(progressSyncTick);
        progressSyncHandler.post(progressSyncTick);
    }

    private void stopProgressSync() {
        progressSyncActive = false;
        progressSyncHandler.removeCallbacks(progressSyncTick);
    }

    /** Notification and the visible screen read the same foreground-service snapshot. */
    private void syncProgressFromService() {
        if (!AuditRunGate.isRunning()) { refreshDashboardInformer(); return; }
        if (currentPage != PAGE_CHECK) { refreshDashboardInformer(); return; }
        AuditForegroundService.Snapshot s = AuditForegroundService.snapshot();
        AuditControl running = AuditControlRegistry.current();
        auditRunning = true;
        if (running != null) auditControl = running;
        maxPercentShown = Math.max(maxPercentShown, s.percent);
        maxPageShown = Math.max(maxPageShown, s.page);
        maxLoadedShown = Math.max(maxLoadedShown, s.loaded);
        currentStageForUi = s.stage == null ? currentStageForUi : s.stage;
        currentWaitForUi = s.note == null ? "" : s.note;
        if (progressBar != null) progressBar.setProgress(Math.min(100, s.percent));
        if (percentText != null) percentText.setText("Проверка " + s.percent + "%");
        if (statusText != null) statusText.setText(running != null && running.isPaused() ? "Проверка на паузе" : s.state);
        updateStageIndicators(currentStageForUi);
        if (detailsText != null) detailsText.setText(runningDetails(s));
        if (pauseButton != null) { pauseButton.setEnabled(running != null); pauseButton.setVisibility(View.VISIBLE); }
        if (stopButton != null) { stopButton.setEnabled(running != null); stopButton.setVisibility(View.VISIBLE); }
        if (auditButton != null) auditButton.setEnabled(false);
        if (fullAuditButton != null) fullAuditButton.setEnabled(false);
    }

    private void createUi() {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(Color.rgb(245, 248, 252));

        screen.addView(buildHeader());

        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        pageHost.setBackgroundColor(Color.rgb(245, 248, 252));
        screen.addView(pageHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        bottomNav = buildBottomNavigation();
        screen.addView(bottomNav);
        setContentView(screen);
        switchPage(PAGE_HOME);
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(3), dp(5), dp(3), dp(5));
        nav.setBackgroundColor(Color.rgb(28, 39, 53));
        return nav;
    }

    private void rebuildBottomNavigation() {
        if (bottomNav == null) return;
        bottomNav.removeAllViews();
        int inactive = Color.rgb(225, 232, 240);
        String[] icons = {"⌂", "▶", "▣", "▥", "▤", "⚙"};
        String[] names = {"Главная", "Проверка", "Банк", "Отчёты", "Журнал", "Настройки"};
        for (int i = 0; i < PAGE_COUNT; i++) {
            final int page = i;
            int color = currentPage == i ? GREEN : inactive;
            TextView item = bottomItem(icons[i], names[i], color, v -> switchPage(page));
            if (currentPage == i) {
                GradientDrawable active = rounded(Color.argb(28, 0, 190, 92), 10);
                item.setBackground(active);
            }
            bottomNav.addView(item, weight());
        }
    }

    private void switchPage(int page) {
        if (page < 0 || page >= PAGE_COUNT || pageHost == null) return;
        currentPage = page;
        pageHost.removeAllViews();

        View content;
        if (page == PAGE_HOME) content = buildHomePage();
        else if (page == PAGE_CHECK) content = buildCheckPage();
        else if (page == PAGE_BANK) content = buildBankPage();
        else if (page == PAGE_REPORTS) content = buildReportsPage();
        else if (page == PAGE_JOURNAL) content = buildJournalPage();
        else content = buildSettingsPage();

        pageHost.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rebuildBottomNavigation();
        if (page == PAGE_HOME) refreshDashboardInformer();
        if (page == PAGE_CHECK && AuditRunGate.isRunning()) {
            try { syncProgressFromService(); } catch (Throwable ignored) {}
        }
    }

    private ScrollView pageScroll(LinearLayout body) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(245, 248, 252));
        scroll.addView(body);
        return scroll;
    }

    private LinearLayout pageBody() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(28));
        body.setBackgroundColor(Color.rgb(245, 248, 252));
        return body;
    }

    private TextView pageTitle(String title, String subtitle) {
        TextView v = label(title + (subtitle == null || subtitle.isEmpty() ? "" : "\n" + subtitle),
                20, true, TEXT);
        v.setPadding(dp(2), dp(2), dp(2), dp(14));
        return v;
    }

    private View buildHomePage() {
        LinearLayout body = pageBody();
        informerText = label("Проверяю состояние...", 16, true, Color.WHITE);
        informerText.setGravity(Gravity.CENTER_VERTICAL);
        informerText.setPadding(dp(16), dp(15), dp(16), dp(15));
        informerText.setMinHeight(dp(74));
        informerText.setOnClickListener(v -> showEventCenterDialog());
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ip.setMargins(0, 0, 0, dp(14));
        body.addView(informerText, ip);

        body.addView(buildHomeStatsRow());
        body.addView(buildHomeCheckActions());
        body.addView(buildLastCheckCard());

        TextView events = label("История событий  ›\nВсе сообщения приложения с датой и временем", 14, true, TEXT);
        events.setPadding(dp(16), dp(15), dp(16), dp(15));
        events.setBackground(rounded(Color.WHITE, 18));
        events.setOnClickListener(v -> showEventCenterDialog());
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ep.setMargins(0, dp(14), 0, 0);
        body.addView(events, ep);
        refreshDashboardInformer();
        return pageScroll(body);
    }

    private View buildHomeStatsRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 0, 0, dp(14));
        newTop = statCard("+", String.valueOf(parseIntState("last_check_new")), "Новые", GREEN);
        changedTop = statCard("✎", String.valueOf(parseIntState("last_check_changed")), "Изменённые", YELLOW);
        deletedTop = statCard("▥", String.valueOf(parseIntState("last_check_deleted")), "Удалённые", RED);
        row.addView(newTop, weight());
        row.addView(changedTop, weight());
        row.addView(deletedTop, weight());
        return row;
    }

    private View buildHomeCheckActions() {
        LinearLayout card = card();
        TextView title = label("Запустить проверку", 16, true, TEXT);
        title.setPadding(0, 0, 0, dp(12));
        card.addView(title);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button quick = new Button(this);
        quick.setText("Быстрая проверка");
        quick.setAllCaps(false);
        quick.setTextColor(Color.WHITE);
        quick.setTextSize(14);
        quick.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        quick.setBackground(rounded(GREEN, 15));
        quick.setOnClickListener(v -> {
            switchPage(PAGE_CHECK);
            runAudit(AuditCoordinator.MODE_QUICK);
        });

        Button full = new Button(this);
        full.setText("Полная проверка");
        full.setAllCaps(false);
        full.setTextColor(TEXT);
        full.setTextSize(14);
        full.setBackground(rounded(Color.rgb(238, 243, 248), 15));
        full.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Полная проверка")
                .setMessage("Будут заново прочитаны все страницы Cubux. Используйте её для глубокого контроля истории.")
                .setPositiveButton("Запустить", (d,w) -> {
                    switchPage(PAGE_CHECK);
                    runAudit(AuditCoordinator.MODE_FULL);
                })
                .setNegativeButton("Отмена", null).show());

        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, dp(52), 1);
        l.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams r = new LinearLayout.LayoutParams(0, dp(52), 1);
        r.setMargins(dp(6), 0, 0, 0);
        row.addView(quick, l);
        row.addView(full, r);
        card.addView(row);
        return card;
    }

    private View buildCheckPage() {
        LinearLayout body = pageBody();
        body.addView(pageTitle("Проверка", "Прогресс, управление и история проверок"));
        body.addView(buildAuditPanel());
        body.addView(buildStatsRow());

        Button history = new Button(this);
        history.setText("История проверок");
        history.setAllCaps(false);
        history.setTextColor(TEXT);
        history.setBackground(rounded(Color.WHITE, 16));
        history.setOnClickListener(v -> showCheckHistoryDialog());
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        hp.setMargins(0, dp(12), 0, 0);
        body.addView(history, hp);

        resultText = label(db.getState("last_check_message") == null ? "" : db.getState("last_check_message"),
                14, false, TEXT);
        resultText.setPadding(dp(4), dp(16), dp(4), dp(16));
        body.addView(resultText);
        return pageScroll(body);
    }

    private View buildBankPage() {
        LinearLayout body = pageBody();
        body.addView(pageTitle("Банк", "Сверка банковской выписки с Cubux"));
        LinearLayout c = card();
        TextView t = label("1  Загрузите файл из банка\n2  Программа распознает операции\n3  Сравнит их с Cubux", 15, false, TEXT);
        t.setPadding(0, 0, 0, dp(14));
        c.addView(t);
        Button choose = new Button(this);
        choose.setText("Выбрать файл");
        choose.setAllCaps(false);
        choose.setTextColor(Color.WHITE);
        choose.setBackground(rounded(BLUE, 15));
        choose.setOnClickListener(v -> showBankDialog());
        c.addView(choose, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        body.addView(c);
        TextView summary = label(db.bankSummary(), 14, false, TEXT);
        summary.setPadding(dp(4), dp(16), dp(4), dp(16));
        body.addView(summary);
        return pageScroll(body);
    }

    private View buildReportsPage() {
        LinearLayout body = pageBody();
        body.addView(pageTitle("Отчёты", "Статистика изменений за день, неделю, месяц и год"));
        body.addView(buildHomeStatsRow());
        Button open = new Button(this);
        open.setText("Открыть отчёт за период");
        open.setAllCaps(false);
        open.setTextColor(Color.WHITE);
        open.setBackground(rounded(BLUE, 15));
        open.setOnClickListener(v -> showReportsDialog());
        body.addView(open, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        return pageScroll(body);
    }

    private View buildJournalPage() {
        LinearLayout body = pageBody();
        body.addView(pageTitle("Журнал", "Новые, изменённые и удалённые операции"));
        final TextView journal = label(db.journalText("ALL", ""), 13, false, TEXT);
        journal.setTextIsSelectable(true);
        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Все", "Новые", "Изменённые", "Удалённые"};
        String[] values = {"ALL", "NEW", "CHANGED", "DELETED"};
        for (int i=0;i<names.length;i++) {
            final String f=values[i];
            Button b=new Button(this); b.setText(names[i]); b.setAllCaps(false); b.setTextSize(11);
            b.setOnClickListener(v -> journal.setText(db.journalText(f, "")));
            filters.addView(b, weight());
        }
        body.addView(filters);
        journal.setPadding(dp(2), dp(14), dp(2), dp(14));
        body.addView(journal);
        return pageScroll(body);
    }

    private View buildSettingsPage() {
        LinearLayout body = pageBody();
        body.addView(pageTitle("Настройки", "Проверки, уведомления, данные и диагностика"));
        LinearLayout c = card();
        TextView state = label("Автоматическая проверка\nВремя запуска и дни недели\nИнтервал между запросами\nУведомления\nРезервные копии и восстановление", 14, false, TEXT);
        state.setPadding(0, 0, 0, dp(14));
        c.addView(state);
        Button open = new Button(this);
        open.setText("Открыть параметры");
        open.setAllCaps(false);
        open.setTextColor(Color.WHITE);
        open.setBackground(rounded(GREEN, 15));
        open.setOnClickListener(v -> showSettingsDialog());
        c.addView(open, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        body.addView(c);
        return pageScroll(body);
    }

    private void showEventCenterDialog() {
        ScrollView scroll = new ScrollView(this);
        TextView text = label(db.eventsText(), 13, false, TEXT);
        text.setPadding(dp(16), dp(10), dp(16), dp(18));
        text.setTextIsSelectable(true);
        scroll.addView(text);
        new AlertDialog.Builder(this)
                .setTitle("История событий")
                .setView(scroll)
                .setPositiveButton("Закрыть", null)
                .show();
    }

    private void showCheckHistoryDialog() {
        int n=parseIntState("last_check_new"), c=parseIntState("last_check_changed"), d=parseIntState("last_check_deleted");
        String head="Новые: "+n+"    Изменённые: "+c+"    Удалённые: "+d+"\n\n";
        ScrollView scroll = new ScrollView(this);
        TextView text = label(head + db.recentRunsText(), 13, false, TEXT);
        text.setPadding(dp(16), dp(10), dp(16), dp(18));
        text.setTextIsSelectable(true);
        scroll.addView(text);
        new AlertDialog.Builder(this)
                .setTitle("История проверок")
                .setView(scroll)
                .setPositiveButton("Закрыть", null)
                .show();
    }

    private void refreshDashboardInformer() {
        if (informerText == null) return;
        String state=db.getState("last_check_state");
        int n=parseIntState("last_check_new"), c=parseIntState("last_check_changed"), d=parseIntState("last_check_deleted");
        String text; int color;
        if (AuditRunGate.isRunning()) {
            text="Идёт проверка — нажмите, чтобы открыть историю событий"; color=BLUE;
        } else if (!isNetworkAvailable()) {
            text="Нет интернета — проверка продолжится после восстановления сети"; color=YELLOW;
        } else if ("ERROR".equals(state)) {
            text="Есть проблемы — последняя проверка завершилась ошибкой"; color=RED;
        } else if ("1".equals(db.getState("missed_check_pending"))) {
            text="Требуется внимание — была пропущена автоматическая проверка"; color=YELLOW;
        } else if ("1".equals(db.getState("yesterday_changed_during_scan"))) {
            text="Внимание — данные за вчерашний день менялись. Проверьте вчерашний день в Cubux"; color=RED;
        } else if (c>0 || d>0) {
            text="Есть изменения — изменённые: "+c+", удалённые: "+d; color=RED;
        } else if (n>0) {
            text="Найдены новые записи: "+n+" — изменённых и удалённых нет"; color=YELLOW;
        } else if ("OK".equals(state)) {
            text="Всё отлично — данные не изменились"; color=GREEN;
        } else {
            text="Система готова — выполните первую проверку"; color=BLUE;
        }
        informerText.setText(text + "\nИстория событий  ›");
        GradientDrawable bg=rounded(color,18);
        informerText.setBackground(bg);
        informerText.setTextColor(color==YELLOW?TEXT:Color.WHITE);
    }

    private TextView bottomItem(String icon, String caption, int color, View.OnClickListener listener) {
        TextView v = label(icon + "\n" + caption, 11, true, color);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(1), dp(5), dp(1), dp(5));
        v.setMinHeight(dp(54));
        v.setOnClickListener(listener);
        return v;
    }

    private void onAuditNavigationPressed() {
        switchPage(PAGE_CHECK);
    }

    private void scrollToTop() {
        View content = findViewById(android.R.id.content);
        if (content != null) content.requestFocus();
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(16), dp(12), dp(16), dp(12));

        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{ Color.rgb(0, 174, 93), Color.rgb(0, 207, 112) }
        );
        header.setBackground(bg);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView menu = iconText("☰", 27);
        menu.setContentDescription("Меню");
        menu.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Разделы")
                .setItems(new String[]{"Главная","Проверка","Банк","Отчёты","Журнал","Настройки"},
                        (d,which) -> switchPage(which))
                .show());

        TextView title = label("Cubux Security 3.0.7", 23, true, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);

        TextView settings = iconText("⚙", 25);
        settings.setContentDescription("Настройки");
        settings.setOnClickListener(v -> switchPage(PAGE_SETTINGS));

        TextView bell = iconText("●", 14);
        bell.setContentDescription("История событий");
        bell.setPadding(dp(8), dp(6), dp(2), dp(6));
        bell.setOnClickListener(v -> showEventCenterDialog());

        top.addView(menu);
        top.addView(title, titleLp);
        top.addView(settings);
        top.addView(bell);
        header.addView(top);

        TextView sub = label("Финансовая проверка  •  Только чтение", 12, false,
                Color.argb(225,255,255,255));
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(2), 0, 0);
        header.addView(sub);
        return header;
    }

    private TextView topStat(
            String icon,
            String value,
            String caption,
            int accent
    ) {
        TextView v = label(icon + "  " + value + "\n" + caption, 11, false, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(74));
        v.setPadding(dp(2), dp(8), dp(2), dp(8));
        GradientDrawable bg = rounded(Color.argb(28,255,255,255), 18);
        bg.setStroke(dp(1), Color.argb(95,255,255,255));
        v.setBackground(bg);
        return v;
    }

    private View buildAuditPanel() {
        LinearLayout card = card();

        LinearLayout first = new LinearLayout(this);
        first.setOrientation(LinearLayout.HORIZONTAL);
        first.setGravity(Gravity.CENTER_VERTICAL);

        auditButton = new Button(this);
        auditButton.setText("Быстрая проверка");
        auditButton.setTextColor(Color.WHITE);
        auditButton.setTextSize(16);
        auditButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        auditButton.setAllCaps(false);
        auditButton.setPadding(dp(8), 0, dp(8), 0);
        auditButton.setBackground(rounded(GREEN, 18));
        auditButton.setOnClickListener(v -> runAudit(AuditCoordinator.MODE_QUICK));

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(64), 11);
        bp.setMargins(0,0,dp(14),0);
        first.addView(auditButton, bp);

        LinearLayout progressBlock = new LinearLayout(this);
        progressBlock.setOrientation(LinearLayout.VERTICAL);
        progressBlock.setGravity(Gravity.CENTER_VERTICAL);

        percentText = label("Проверка 0%", 18, true, TEXT);
        percentText.setPadding(0, 0, 0, dp(7));
        progressBlock.addView(percentText);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setProgressTintList(ColorStateList.valueOf(GREEN));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(226,232,239)));
        progressBlock.addView(progressBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(9)));

        first.addView(progressBlock, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 10));
        card.addView(first);

        fullAuditButton = new Button(this);
        fullAuditButton.setText("Полная проверка");
        fullAuditButton.setTextColor(GREEN);
        fullAuditButton.setTextSize(13);
        fullAuditButton.setAllCaps(false);
        fullAuditButton.setBackground(rounded(Color.rgb(238, 249, 244), 14));
        fullAuditButton.setOnClickListener(v -> {
            if (auditRunning) {
                Toast.makeText(this, "Сначала завершите текущую проверку", Toast.LENGTH_SHORT).show();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Полная проверка")
                        .setMessage("Будут заново прочитаны все страницы Cubux. Используйте её для глубокого контроля истории.")
                        .setPositiveButton("Запустить", (d,w) -> runAudit(AuditCoordinator.MODE_FULL))
                        .setNegativeButton("Отмена", null)
                        .show();
            }
        });
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        fp.setMargins(0, dp(10), 0, 0);
        card.addView(fullAuditButton, fp);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(0, dp(12), 0, 0);

        pauseButton = new Button(this);
        pauseButton.setText("⏸  Пауза");
        pauseButton.setTextColor(TEXT);
        pauseButton.setTextSize(14);
        pauseButton.setAllCaps(false);
        pauseButton.setEnabled(false);
        pauseButton.setVisibility(View.GONE);
        pauseButton.setBackground(rounded(Color.rgb(238,243,248), 15));
        pauseButton.setOnClickListener(v -> togglePause());

        stopButton = new Button(this);
        stopButton.setText("■  Стоп");
        stopButton.setTextColor(RED);
        stopButton.setTextSize(14);
        stopButton.setAllCaps(false);
        stopButton.setEnabled(false);
        stopButton.setVisibility(View.GONE);
        stopButton.setBackground(rounded(Color.rgb(255,242,244), 15));
        stopButton.setOnClickListener(v -> stopAudit());

        LinearLayout.LayoutParams cp1 = new LinearLayout.LayoutParams(0, dp(48), 1);
        cp1.setMargins(0,0,dp(6),0);
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(0, dp(48), 1);
        cp2.setMargins(dp(6),0,0,0);
        controls.addView(pauseButton, cp1);
        controls.addView(stopButton, cp2);
        card.addView(controls);

        statusText = label("Готов к проверке", 16, true, TEXT);
        statusText.setPadding(0, dp(16), 0, dp(4));
        statusText.setMinLines(2);
        statusText.setMaxLines(2);
        statusText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        statusText.setVisibility(View.GONE);
        card.addView(statusText);

        detailsText = label("Расписание проверок загружается...", 13, false, MUTED);
        // Fixed four-line details area: status changes no longer move the controls below it.
        detailsText.setMinLines(8);
        detailsText.setMaxLines(8);
        detailsText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(detailsText);

        LinearLayout steps = new LinearLayout(this);
        steps.setPadding(0, dp(17), 0, 0);
        connectStep = step("○", "Подключение\nк Cubux");
        readStep = step("○", "Чтение\nданных");
        compareStep = step("○", "Сравнение");
        reportStep = step("○", "Отчёт");
        steps.addView(connectStep, weight());
        steps.addView(readStep, weight());
        steps.addView(compareStep, weight());
        steps.addView(reportStep, weight());
        card.addView(steps);
        return card;
    }

    private TextView step(
            String icon,
            String caption
    ) {
        TextView v = label(icon + "\n" + caption, 11, false, MUTED);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(58));
        return v;
    }


private View buildLastCheckCard() {
    LinearLayout card = card();
    TextView title = label("Последняя проверка", 16, true, TEXT);
    card.addView(title);
    lastCheckText = label("Проверок ещё не было", 14, false, MUTED);
    lastCheckText.setPadding(0, dp(8), 0, 0);
    lastCheckText.setOnClickListener(v -> showJournalDialog());
    card.addView(lastCheckText);
    refreshLastCheckStatus();
    return card;
}

private void refreshLastCheckStatus() {
    if (lastCheckText == null || db == null) return;
    String state = db.getState("last_check_state");
    String type = db.getState("last_check_type");
    String time = db.getState("last_check_time");
    String msg = db.getState("last_check_message");
    String activity = db.getState("last_check_activity");
    if (state == null) {
        lastCheckText.setText("Проверок ещё не было. Расписание задаётся в настройках.");
        return;
    }
    StringBuilder x = new StringBuilder();
    if (type != null && !type.isEmpty()) x.append(type);
    if (time != null && !time.isEmpty()) x.append(" • ").append(time);
    if (x.length() > 0) x.append("\n");
    x.append(msg == null ? "Состояние проверки неизвестно" : msg);
    if ("OK".equals(state)) {
        int n=parseIntState("last_check_new"), c=parseIntState("last_check_changed"), d=parseIntState("last_check_deleted");
        x.append("\nНовые: ").append(n).append(" • Изменённые: ").append(c).append(" • Удалённые: ").append(d);
    }
    if (activity != null && !activity.isEmpty()) x.append("\nПоследняя активность: ").append(activity);
    try {
        String lastMs=db.getState("last_successful_audit_ms");
        if(lastMs!=null && System.currentTimeMillis()-Long.parseLong(lastMs)>36L*60L*60L*1000L)
            x.append("\n⚠ Давно не было успешной проверки. Рекомендуется запустить проверку вручную.");
    } catch(Exception ignored) {}
    lastCheckText.setTextColor("ERROR".equals(state)?RED:"RUNNING".equals(state)?BLUE:"OK".equals(state)?GREEN:MUTED);
    lastCheckText.setText(x.toString());
}

private int parseIntState(String key) {
    try { return Integer.parseInt(db.getState(key)); } catch (Exception e) { return 0; }
}

private long parseLongState(String key) {
    try { return Long.parseLong(db.getState(key)); } catch (Exception e) { return 0L; }
}

    private View buildStatsRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(14), 0, dp(4));

        newCard = statCard("+", String.valueOf(parseIntState("last_check_new")), "Новые", GREEN);
        changedCard = statCard("✎", String.valueOf(parseIntState("last_check_changed")), "Изменённые", YELLOW);
        deletedCard = statCard("▥", String.valueOf(parseIntState("last_check_deleted")), "Удалённые", RED);

        row.addView(newCard, weight());
        row.addView(changedCard, weight());
        row.addView(deletedCard, weight());
        return row;
    }

    private TextView statCard(
            String icon,
            String value,
            String caption,
            int accent
    ) {
        TextView v = label(icon + "\n" + value + "\n" + caption, 11, true, TEXT);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(102));
        v.setPadding(dp(2), dp(10), dp(2), dp(10));
        int r = Color.red(accent), g = Color.green(accent), b = Color.blue(accent);
        GradientDrawable bg = rounded(Color.rgb(
                Math.min(255, 245 + r / 40),
                Math.min(255, 246 + g / 45),
                Math.min(255, 248 + b / 55)), 17);
        bg.setStroke(dp(1), Color.argb(95,r,g,b));
        v.setBackground(bg);
        return v;
    }

    private View buildNavigationGrid() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(14), 0, 0);

        wrap.addView(navRow(
                navCard("↺", "История проверкаов", "Просмотр результатов прошлых проверок", Color.rgb(0,202,116),
                        v -> resultText.setText("ИСТОРИЯ ПРОВЕРКАОВ\n\n" + db.recentRunsText())),
                navCard("▤", "Журнал изменений", "Все найденные изменения операций", YELLOW,
                        v -> showJournalDialog())
        ));

        wrap.addView(navRow(
                navCard("◔", "Отчёты", "Аналитика за день, неделю, месяц и год", BLUE,
                        v -> showReportsDialog()),
                navCard("▦", "Банковская сверка", "Сравнение Cubux с выпиской банка", PURPLE,
                        v -> showBankDialog())
        ));

        wrap.addView(navCardWide("▣", "Закрытые периоды",
                "Контроль изменений в уже завершённых периодах", Color.rgb(245,65,122),
                v -> resultText.setText("Закрытые периоды контролируются автоматически по SHA-256.\n" +
                        "Контрольная база прошлых дней не перезаписывается.")));

        wrap.addView(navRow(
                navCard("⬆", "Резервная копия", "Экспорт базы с проверкой SHA-256", Color.rgb(0,160,180),
                        v -> createBackup()),
                navCard("⬇", "Восстановление", "Восстановление базы из резервной копии", Color.rgb(90,110,140),
                        v -> pickRestore())
        ));
        return wrap;
    }

    private View navRow(
            View left,
            View right
    ) {
        LinearLayout row =
                new LinearLayout(this);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        lp.setMargins(
                0,
                0,
                dp(7),
                dp(12)
        );

        LinearLayout.LayoutParams rp =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        rp.setMargins(
                dp(7),
                0,
                0,
                dp(12)
        );

        row.addView(
                left,
                lp
        );

        row.addView(
                right,
                rp
        );

        return row;
    }

    private View navCard(
            String icon,
            String title,
            String subtitle,
            int accent,
            View.OnClickListener listener
    ) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(13), dp(15), dp(11), dp(15));
        box.setMinimumHeight(dp(112));
        GradientDrawable bg = rounded(Color.WHITE, 20);
        bg.setStroke(dp(1), Color.rgb(232,237,244));
        box.setBackground(bg);
        box.setOnClickListener(listener);

        TextView bubble = label(icon, 23, true, Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable ibg = rounded(accent, 18);
        bubble.setBackground(ibg);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(54), dp(54));
        ip.setMargins(0,0,dp(12),0);
        box.addView(bubble, ip);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = label(title, 15, true, TEXT);
        TextView st = label(subtitle, 12, false, MUTED);
        st.setPadding(0,dp(4),0,0);
        texts.addView(t);
        texts.addView(st);
        box.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView arrow = label("›", 28, false, MUTED);
        arrow.setGravity(Gravity.CENTER);
        box.addView(arrow, new LinearLayout.LayoutParams(dp(22), dp(50)));
        return box;
    }


    private View navCardWide(String icon, String title, String subtitle, int accent, View.OnClickListener listener) {
        View v = navCard(icon, title, subtitle, accent, listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout card() {

        LinearLayout c =
                new LinearLayout(this);

        c.setOrientation(
                LinearLayout.VERTICAL
        );

        c.setPadding(
                dp(16),
                dp(16),
                dp(16),
                dp(16)
        );

        c.setBackground(
                rounded(
                        Color.WHITE,
                        22
                )
        );

        return c;
    }

    private LinearLayout.LayoutParams weight() {

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1
                );

        p.setMargins(
                dp(3),
                0,
                dp(3),
                0
        );

        return p;
    }

    private TextView iconText(
            String value,
            int size
    ) {
        TextView v =
                label(
                        value,
                        size,
                        true,
                        Color.WHITE
                );

        v.setGravity(
                Gravity.CENTER
        );

        v.setPadding(
                dp(6),
                dp(6),
                dp(6),
                dp(6)
        );

        return v;
    }

    private TextView label(
            String value,
            int size,
            boolean bold,
            int color
    ) {
        TextView v =
                new TextView(this);

        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setFontFeatureSettings(
                "kern"
        );

        if (bold) {
            v.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD
            );
        }

        return v;
    }

    private GradientDrawable rounded(
            int color,
            int radiusDp
    ) {
        GradientDrawable d =
                new GradientDrawable();

        d.setColor(color);

        d.setCornerRadius(
                dp(radiusDp)
        );

        return d;
    }

    private int dp(
            int value
    ) {
        return (int) (
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density +
                        0.5f
        );
    }

    private void runAudit() { runAudit(AuditCoordinator.MODE_QUICK); }

    private void runAudit(String mode) {

        if (auditRunning) {
            onAuditNavigationPressed();
            return;
        }

        String login =
                credentials.getLogin();

        String password =
                credentials.getPassword();

        if (login.isEmpty() ||
                password.isEmpty()) {
            showLoginDialog(true);
            return;
        }

        auditButton.setEnabled(false);
        auditRunning = true;
        activeCheckMode = mode;
        final long sessionId = ++auditSessionCounter;
        activeAuditSession = sessionId;
        maxPageShown = 0;
        maxLoadedShown = 0;
        maxPercentShown = 0;
        final AuditControl sessionControl = new AuditControl();
        auditControl = sessionControl;
        AuditControlRegistry.attach(sessionControl, mode);
        startedMs = System.currentTimeMillis();
        AuditForegroundService.reset(startedMs);
        AuditForegroundService.start(this);
        scanContext = AuditCoordinator.MODE_FULL.equals(mode) ? "Основное чтение полной проверки" : "Быстрая проверка";
        currentStageForUi = "PREPARING";
        currentWaitForUi = "";
        updateStageIndicators("START");
        DiagnosticLog.write(this, "CONTROL", "Ручная проверка запущена. Режим=" + mode);
        CheckStatusStore.running(this, AuditCoordinator.MODE_FULL.equals(mode) ? "Полная проверка" : "Быстрая проверка");
        pauseButton.setEnabled(true);
        pauseButton.setVisibility(View.VISIBLE);
        pauseButton.setText("⏸  ПАУЗА");
        stopButton.setEnabled(true);
        stopButton.setVisibility(View.VISIBLE);
        if (fullAuditButton != null) fullAuditButton.setEnabled(false);

        progressBar.setProgress(0);
        percentText.setText(
                "Проверка 0%"
        );

        resultText.setText("");

        retries = 0;

        AuditCoordinator coordinator =
                new AuditCoordinator(this);

        boolean recovery =
                coordinator.isRecovery();

        new Thread(
                () -> {
                    try {
                        AuditEngine.Result r =
                                coordinator.runMode(
                                        login,
                                        password,
                                        recovery,
                                        progressListener(sessionId, sessionControl),
                                        sessionControl,
                                        mode
                                );

                        runOnUiThread(
                                () -> {
                                    if (sessionId == activeAuditSession) {
                                        showResult(r);
                                    }
                                }
                        );

                    } catch (Exception e) {
                        String msg =
                                e.getMessage() == null
                                        ? e.toString()
                                        : e.getMessage();

                        runOnUiThread(
                                () -> {
                                    if (sessionId != activeAuditSession) return;
                                    if (msg.contains("остановлен пользователем")) {
                                        statusText.setText("Проверка остановлена");
                                        resultText.setText("Проверка остановлена пользователем. Данные Cubux не изменялись.");
                                        db.saveState("last_check_state","STOPPED");
                                        db.saveState("last_check_message","Проверка остановлена пользователем.");
                                        refreshLastCheckStatus();
                                    } else {
                                        statusText.setText("ПРОВЕРКА ОСТАНОВЛЕНА");
                                        resultText.setText("Причина:\n" + msg);
                                        CheckStatusStore.failure(MainActivity.this, AuditCoordinator.MODE_FULL.equals(activeCheckMode) ? "Полная проверка" : "Быстрая проверка", Math.max(1,retries), msg);
                                        refreshLastCheckStatus();
                                    }
                                }
                        );

                    } finally {
                        AuditControlRegistry.clear(sessionControl);
                        AuditForegroundService.stop(MainActivity.this);
                        if (sessionId == activeAuditSession && auditControl == sessionControl) {
                            auditRunning = false;
                        }
                        runOnUiThread(
                                () -> {
                                    if (sessionId != activeAuditSession || auditControl != sessionControl) return;
                                    auditButton.setEnabled(true);
                                    if (fullAuditButton != null) fullAuditButton.setEnabled(true);
                                    pauseButton.setEnabled(false);
                                    pauseButton.setText("⏸  ПАУЗА");
                                    pauseButton.setVisibility(View.GONE);
                                    stopButton.setEnabled(false);
                                    stopButton.setVisibility(View.GONE);
                                }
                        );
                    }
                }
        ).start();
    }

    private void togglePause() {
        final AuditControl control = auditControl;
        if (!auditRunning || control == null || control.isStopped()) return;
        if (control.isPaused()) {
            control.resume();
            DiagnosticLog.write(this, "CONTROL", "Продолжить проверку");
            CheckStatusStore.event(this, "INFO", "ПРОВЕРКА", "Проверка продолжена пользователем");
            pauseButton.setText("⏸  ПАУЗА");
            statusText.setText("Продолжаю проверку...");
        } else {
            control.pause();
            DiagnosticLog.write(this, "CONTROL", "Пауза проверки");
            CheckStatusStore.event(this, "INFO", "ПРОВЕРКА", "Проверка поставлена на паузу пользователем");
            pauseButton.setText("▶  ПРОДОЛЖИТЬ");
            statusText.setText("Проверка на паузе");
            AuditForegroundService.Snapshot snap = AuditForegroundService.snapshot();
            detailsText.setText(
                    "Сейчас: проверка поставлена на паузу" +
                    "\nЭтап: " + stageName(currentStageForUi) +
                    "\nПрогресс: " + maxLoadedShown + " операций • страница " + maxPageShown +
                    "\nЗапросы: приостановлены пользователем" +
                    "\nПрошло: " + TimeUtil.formatDuration(snap.elapsedMs) + " • таймер на паузе" +
                    "\nСостояние: нажмите «Продолжить», чтобы продолжить с этого места"
            );
        }
    }

    private void stopAudit() {
        final AuditControl control = auditControl;
        if (!auditRunning || control == null || control.isStopped()) return;
        control.stop();
        DiagnosticLog.write(this, "CONTROL", "Остановить проверку");
        CheckStatusStore.event(this, "WARNING", "ПРОВЕРКА", "Проверка остановлена пользователем");
        pauseButton.setEnabled(false);
        stopButton.setEnabled(false);
        statusText.setText("Останавливаю проверку...");
        detailsText.setText(
                "Сейчас: останавливаю проверку" +
                "\nЭтап: отмена текущего запроса Cubux" +
                "\nПрогресс: " + maxLoadedShown + " операций • страница " + maxPageShown +
                "\nЗапросы: новые запросы не отправляются" +
                "\nПрошло: " + TimeUtil.formatDuration(AuditForegroundService.snapshot().elapsedMs) +
                "\nСостояние: незавершённые данные не будут записаны в эталон"
        );
    }

    private AuditProgressListener progressListener(
            final long sessionId,
            final AuditControl sessionControl
    ) {
        return new AuditProgressListener() {

            private boolean isCurrent() {
                return sessionId == activeAuditSession
                        && auditRunning
                        && auditControl == sessionControl
                        && !sessionControl.isStopped();
            }

            @Override
            public void onStage(
                    String stage,
                    String message
            ) {
                if (!isCurrent() || sessionControl.isPaused()) return;

                // A normal inter-request delay is only auxiliary information. It must never
                // replace the explanation of what the scan itself is doing.
                if ("GENTLE_WAIT".equals(stage) || "SERVER_COOLDOWN".equals(stage)) {
                    currentWaitForUi = message == null ? "" : message;
                    AuditForegroundService.updateNote(MainActivity.this, currentWaitForUi);
                    runOnUiThread(() -> detailsText.setText(runningDetails(AuditForegroundService.snapshot())));
                    return;
                }

                currentWaitForUi = "";
                if ("AUTO_FULL".equals(stage)) {
                    maxPageShown = 0;
                    maxLoadedShown = 0;
                    scanContext = "Полная проверка после лёгкой";
                    AuditForegroundService.resetPageProgress();
                } else if ("STABILITY_FALLBACK_SCAN".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0;
                    scanContext = "Контроль стабильности — аварийный полный проход";
                    AuditForegroundService.resetPageProgress();
                } else if ("HISTORY_RESCAN".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0;
                    scanContext = "Повторная проверка изменённого периода";
                    AuditForegroundService.resetPageProgress();
                } else if ("LIGHT_DEEP".equals(stage)) {
                    maxPageShown = 0; maxLoadedShown = 0;
                    scanContext = "Подробная проверка изменённого периода";
                    AuditForegroundService.resetPageProgress();
                } else if ("READ_COMPLETE".equals(stage)) {
                    scanContext = "Основное чтение завершено";
                }
                currentStageForUi = stage == null ? "" : stage;
                int stagePercent = stagePercent(stage, maxPercentShown);
                maxPercentShown = Math.max(maxPercentShown, stagePercent);
                AuditForegroundService.updateStage(MainActivity.this, currentStageForUi, message, maxPercentShown,
                        maxPageShown, AuditForegroundService.pages, maxLoadedShown, AuditForegroundService.total);
                CheckStatusStore.activity(MainActivity.this, message);
                runOnUiThread(() -> {
                    if (sessionId != activeAuditSession) return;
                    progressBar.setProgress(maxPercentShown);
                    percentText.setText("Проверка " + maxPercentShown + "%");
                    statusText.setText(message);
                    updateStageIndicators(stage);
                    detailsText.setText(runningDetails(AuditForegroundService.snapshot()));
                });
            }

            @Override
            public void onMeta(
                    int total,
                    int pages
            ) {
                if (!isCurrent()) return;
                AuditForegroundService.update(MainActivity.this, "Получены параметры проверки", maxPercentShown,
                        maxPageShown, pages, maxLoadedShown, total);
                runOnUiThread(() -> detailsText.setText(runningDetails(AuditForegroundService.snapshot())));
            }

            @Override
            public void onPage(
                    int page,
                    int pages,
                    int loaded,
                    int total
            ) {
                if (!isCurrent() || sessionControl.isPaused()) return;
                updateProgress(
                        sessionId,
                        sessionControl,
                        page,
                        pages,
                        loaded,
                        total
                );
            }

            @Override
            public void onRetry(
                    int page,
                    int attempt,
                    int retrySeconds,
                    String error
            ) {
                if (!isCurrent()) return;
                retries++;

                boolean online = isNetworkAvailable();
                String retryStatus;
                if (!online) retryStatus = "Нет подключения к интернету. Проверка приостановлена.";
                else if (error != null && error.contains("HTTP 429")) retryStatus = "Cubux временно ограничил частоту запросов.";
                else if (error != null && error.matches(".*HTTP 5\\d\\d.*")) retryStatus = "Сервер Cubux временно недоступен.";
                else retryStatus = "Интернет есть, но Cubux временно не отвечает.";
                currentWaitForUi = retryStatus + " Повтор через " + retrySeconds + " сек. • попытка " + attempt;
                AuditForegroundService.updateNote(MainActivity.this, currentWaitForUi);
                CheckStatusStore.event(MainActivity.this, "WARNING", "СЕТЬ/CUBUX", currentWaitForUi);

                runOnUiThread(
                        () -> {
                            statusText.setText(retryStatus);
                            detailsText.setText(runningDetails(AuditForegroundService.snapshot()));
                        }
                );
            }
        };
    }


private int stagePercent(String stage, int current) {
    if (stage == null) return current;
    if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return Math.max(current, 1);
    if ("TEAM".equals(stage) || "RANGE".equals(stage) || "LOADING_META".equals(stage)) return Math.max(current, 3);
    if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return Math.max(current, 8);
    if ("LIGHT_SUMMARY".equals(stage)) return Math.max(current, 18);
    if ("LIGHT_MONTHLY".equals(stage) || "LIGHT_BASELINE_MIGRATION".equals(stage)) return Math.max(current, 20);
    if ("LIGHT_NO_CHANGES".equals(stage)) return Math.max(current, 94);
    if ("LIGHT_MISMATCH".equals(stage)) return Math.max(current, 28);
    if ("LIGHT_DEEP".equals(stage)) return Math.max(current, 32);
    if ("READ_COMPLETE".equals(stage)) return Math.max(current, 86);
    if ("STABILITY_START".equals(stage)) return Math.max(current, 3);
    if ("MONTHLY_CONTROL_START".equals(stage) || "MONTHLY_CONTROL".equals(stage)) return Math.max(current, 4);
    if ("STABILITY_VERIFY".equals(stage) || "MONTHLY_CONTROL_VERIFY".equals(stage) || "MONTHLY_CONTROL_SWITCH".equals(stage) || "STABILITY_FALLBACK".equals(stage)) return Math.max(current, 88);
    if ("STABILITY_FALLBACK_SCAN".equals(stage) || "STABILITY_EMERGENCY".equals(stage) || "HISTORY_RESCAN".equals(stage) || "HISTORY_MOVED".equals(stage)) return Math.max(current, 89);
    if ("STABILITY_OK".equals(stage)) return Math.max(current, 90);
    if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return Math.max(current, 92);
    if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return Math.max(current, 95);
    if ("CONTROL_BASELINE".equals(stage) || "LIGHT_BASELINE_REFRESH".equals(stage) || "LIGHT_BASELINE_READY".equals(stage)) return Math.max(current, 96);
    if ("SAVING".equals(stage)) return Math.max(current, 98);
    if ("BACKUP".equals(stage) || "BACKUP_OK".equals(stage) || "BACKUP_WARNING".equals(stage) || "CREATING_REPORT".equals(stage)) return Math.max(current, 99);
    if ("COMPLETED".equals(stage)) return 100;
    return current;
}

private boolean isNetworkAvailable() {
    return NetworkUtil.hasInternet(this);
}

    private void updateProgress(
            long sessionId,
            AuditControl sessionControl,
            int page,
            int pages,
            int loaded,
            int total
    ) {
        if (sessionId != activeAuditSession || !auditRunning) return;

        // Never allow stale/retried callbacks to move UI backwards.
        if (page < maxPageShown || loaded < maxLoadedShown) return;

        maxPageShown = Math.max(maxPageShown, page);
        maxLoadedShown = Math.max(maxLoadedShown, loaded);
        long elapsed = sessionControl.activeElapsedMs(startedMs);

        int rawPercent =
                total <= 0
                        ? 0
                        : (int) (
                                5.0 + loaded *
                                        80.0 /
                                        total
                        );

        final int percent =
                Math.max(
                        maxPercentShown,
                        Math.min(85, rawPercent)
                );

        maxPercentShown = percent;

        double speed =
                loaded /
                        Math.max(
                                1,
                                elapsed /
                                        1000.0
                        );

        String readStatus = scanContext == null || scanContext.isEmpty()
                ? "Читаю операции из Cubux"
                : scanContext + ": читаю операции из Cubux";
        currentStageForUi = "READING_DATA";
        currentWaitForUi = "";
        AuditForegroundService.updateStage(this, "READING_DATA", readStatus, percent,
                maxPageShown, pages, maxLoadedShown, total);

        runOnUiThread(
                () -> {
                    if (sessionId != activeAuditSession || !auditRunning) return;
                    if (auditControl != sessionControl || sessionControl.isPaused() || sessionControl.isStopped()) return;
                    progressBar.setProgress(
                            Math.min(
                                    100,
                                    percent
                            )
                    );

                    percentText.setText(
                            "Проверка " +
                                    percent +
                                    "%"
                    );

                    statusText.setText(readStatus);
                    updateStageIndicators("READING_DATA");
                    detailsText.setText(runningDetails(AuditForegroundService.snapshot()));
                }
        );
    }

    private CharSequence runningDetails(AuditForegroundService.Snapshot s) {
        if (s == null) s = AuditForegroundService.snapshot();
        String stage = (s.stage == null || s.stage.isEmpty()) ? currentStageForUi : s.stage;
        String rawAction = (s.state == null || s.state.trim().isEmpty()) ? "Выполняю проверку" : s.state.trim();
        String action = actionDescription(stage, rawAction);
        String progress = progressDescription(s, rawAction);
        String detail = actionDetailDescription(stage, rawAction, s);
        String speed = "Скорость: " + DelayProfile.label(new CheckSettings(this).requestDelayMs());
        String elapsed = "Прошло: " + TimeUtil.formatDuration(s.elapsedMs);
        String activity = "Последняя активность: " + (s.updatedAt > 0L ? new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new java.util.Date(s.updatedAt)) : "—");
        String note = (s.note != null && !s.note.trim().isEmpty()) ? s.note.trim() : currentWaitForUi;
        if (note == null || note.trim().isEmpty()) note = "этап выполняется, данные обновляются";
        if (note.startsWith("Состояние:")) note = note.substring("Состояние:".length()).trim();
        String text = "Сейчас: " + action +
                "\nЭтап: " + stageName(stage) +
                "\n" + progress +
                "\nДействие: " + detail +
                "\n" + speed +
                "\n" + elapsed +
                "\n" + activity +
                "\nСостояние: " + note;
        return boldCurrentAction(text);
    }

    private CharSequence boldCurrentAction(String text){
        SpannableStringBuilder out=new SpannableStringBuilder(text==null?"":text);
        int boldStart="Сейчас: ".length();
        int boldEnd=out.toString().indexOf('\n'); if(boldEnd<0)boldEnd=out.length();
        if(boldEnd>boldStart)out.setSpan(new StyleSpan(Typeface.BOLD),boldStart,boldEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return out;
    }

    private String actionDetailDescription(String stage,String raw,AuditForegroundService.Snapshot s){
        if(stage==null)return "выполняю текущий этап проверки";
        if("PREPARING".equals(stage)||"START".equals(stage))return "проверяю настройки, локальную базу и готовность к запуску";
        if("AUTHENTICATING".equals(stage)||"REAUTHENTICATING".equals(stage))return "проверяю доступ к Cubux и получаю рабочий токен";
        if("TEAM".equals(stage))return "получаю команду и идентификатор данных Cubux";
        if("RANGE".equals(stage))return "определяю границы закрытой истории для проверки";
        if("LOADING_META".equals(stage))return "получаю число операций и страниц перед чтением";
        if("READING_DATA".equals(stage))return "загружаю следующую страницу операций последовательно";
        if(stage.startsWith("LIGHT")||stage.startsWith("MONTHLY_CONTROL"))return "сравниваю контрольные данные с локальным эталоном без лишней полной загрузки";
        if(stage.startsWith("STABILITY")||"HISTORY_MOVED".equals(stage)||"HISTORY_RESCAN".equals(stage))return "убеждаюсь, что данные не менялись во время сканирования";
        if("PROCESSING".equals(stage)||"CLOSE_EMPTY_DAYS".equals(stage))return "проверяю закрытые дни и формирую безопасный эталон";
        if("COMPARING".equals(stage)||"CHECKING_HISTORY".equals(stage))return "ищу новые, изменённые и удалённые записи";
        if("SAVING".equals(stage))return "атомарно сохраняю только подтверждённый результат";
        if(stage.startsWith("BACKUP"))return "создаю резервную копию локальной базы";
        if("NO_INTERNET".equals(stage))return "жду сеть; незавершённые данные не сохраняются";
        if("RETRY_WAIT".equals(stage)||"WAITING_CUBUX".equals(stage))return "повторяю тот же запрос после защитной паузы";
        if("COMPLETED".equals(stage))return "все этапы завершены, результат сохранён";
        return raw==null||raw.trim().isEmpty()?"выполняю текущий этап проверки":raw.trim();
    }

    private String actionDescription(String stage, String raw) {
        if (stage == null) return raw;
        if ("PREPARING".equals(stage)) return "подготавливаю проверку";
        if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return "проверяю и обновляю авторизацию Cubux";
        if ("TEAM".equals(stage)) return "получаю данные команды Cubux";
        if ("RANGE".equals(stage)) return "определяю диапазон закрытой истории";
        if ("LOADING_META".equals(stage)) return "получаю количество операций и страниц";
        if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return "проверяю метаданные закрытой истории";
        if ("LIGHT_SUMMARY".equals(stage)) return "сверяю контрольные суммы без полной загрузки";
        if ("LIGHT_MONTHLY".equals(stage) || "MONTHLY_CONTROL".equals(stage) || "MONTHLY_CONTROL_START".equals(stage) || "MONTHLY_CONTROL_VERIFY".equals(stage)) return "сверяю контрольные данные истории по месяцам";
        if ("LIGHT_BASELINE_MIGRATION".equals(stage)) return "создаю лёгкий эталон из существующей локальной базы";
        if ("LIGHT_MISMATCH".equals(stage)) return "локализую период, в котором найдено расхождение";
        if ("LIGHT_DEEP".equals(stage)) return "подробно проверяю только изменившийся период";
        if ("LIGHT_NO_CHANGES".equals(stage)) return "контрольные данные совпали, изменений нет";
        if ("AUTO_FULL".equals(stage) || "BASELINE_REQUIRED".equals(stage)) return "готовлю переход к полной проверке";
        if ("WAITING_CUBUX".equals(stage)) return "жду ответ Cubux на текущий запрос";
        if ("READING_DATA".equals(stage)) return "читаю операции из Cubux";
        if ("READ_COMPLETE".equals(stage)) return "основная загрузка завершена, проверяю результат";
        if ("STABILITY_START".equals(stage) || "STABILITY_VERIFY".equals(stage)) return "проверяю, не менялась ли история во время сканирования";
        if ("HISTORY_MOVED".equals(stage)) return "обнаружено изменение истории, уточняю изменившийся период";
        if ("HISTORY_RESCAN".equals(stage)) return "повторно читаю только изменившийся период";
        if ("STABILITY_EMERGENCY".equals(stage) || "STABILITY_FALLBACK".equals(stage) || "STABILITY_FALLBACK_SCAN".equals(stage)) return "выполняю аварийный контроль стабильности";
        if ("STABILITY_OK".equals(stage)) return "стабильность истории подтверждена";
        if ("STABILITY_WAIT".equals(stage)) return "жду стабилизации изменившегося периода";
        if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return "проверяю целостность закрытых дней";
        if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return "сравниваю подтверждённые данные с локальным эталоном";
        if ("CONTROL_BASELINE".equals(stage) || "LIGHT_BASELINE_READY".equals(stage)) return "готовлю контрольный эталон для следующих проверок";
        if ("SAVING".equals(stage)) return "сохраняю подтверждённый результат в локальную базу";
        if (stage.startsWith("BACKUP")) return "создаю резервную копию базы Cubux Security";
        if ("NO_INTERNET".equals(stage)) return "жду восстановления подключения к интернету";
        if ("INTERNET_RESTORED".equals(stage) || "RECONNECTING".equals(stage)) return "восстанавливаю прерванное подключение и продолжаю";
        if ("RETRY_WAIT".equals(stage) || "WAITING_CUBUX".equals(stage)) return "жду повторного запроса к Cubux";
        if ("AUTH_ERROR".equals(stage) || "PERMANENT_ERROR".equals(stage)) return "проверка остановлена из-за ошибки Cubux";
        if ("COMPLETED".equals(stage)) return "проверка завершена успешно";
        return raw;
    }

    private String progressDescription(AuditForegroundService.Snapshot s, String action) {
        String st = (s.stage == null || s.stage.isEmpty()) ? currentStageForUi : s.stage;
        String marker = "Контроль по месяцам:";
        int i = action.indexOf(marker);
        if (i >= 0) {
            String x = action.substring(i + marker.length()).trim();
            int dot = x.indexOf(". Полная");
            if (dot > 0) x = x.substring(0, dot);
            return "Прогресс: месяц " + x;
        }
        if (action.contains("периоде ")) {
            int p = action.indexOf("периоде ");
            String x = action.substring(p + 8).replace(". Проверяю его подробно...", "").trim();
            return "Прогресс: период " + x;
        }
        if ("BACKUP".equals(st) || "BACKUP_OK".equals(st) || "BACKUP_WARNING".equals(st)) return "Прогресс: создаю и проверяю резервную копию базы";
        if ("SAVING".equals(st)) return "Прогресс: сохраняю подтверждённый результат";
        if ("COMPARING".equals(st) || "CHECKING_HISTORY".equals(st)) return "Прогресс: сравниваю данные с локальным эталоном";
        if ("PROCESSING".equals(st) || "CLOSE_EMPTY_DAYS".equals(st)) return "Прогресс: проверяю целостность закрытых дней";
        if ("CONTROL_BASELINE".equals(st) || "LIGHT_BASELINE_READY".equals(st) || "LIGHT_BASELINE_MIGRATION".equals(st)) return "Прогресс: готовлю контрольный эталон для следующих лёгких проверок";
        if ("LIGHT_NO_CHANGES".equals(st)) return "Прогресс: контроль завершён, подробная загрузка не требуется";
        if ("READ_COMPLETE".equals(st)) return "Прогресс: основная загрузка завершена полностью";
        if ("STABILITY_VERIFY".equals(st) || "MONTHLY_CONTROL_VERIFY".equals(st) || "STABILITY_START".equals(st)) return "Прогресс: проверяю, не менялась ли история во время чтения";
        if (s.total > 0 && ("READING_DATA".equals(st) || "WAITING_CUBUX".equals(st) || "RETRY_WAIT".equals(st) || "NO_INTERNET".equals(st) || "INTERNET_RESTORED".equals(st))) {
            return "Прогресс: " + s.loaded + " из " + s.total + " операций • страница " + s.page + " из " + s.pages;
        }
        if (s.total > 0) return "Прогресс: подтверждено " + s.loaded + " из " + s.total + " операций";
        return "Прогресс: выполняется текущий этап";
    }

    private String stageName(String stage) {
        if (stage == null || stage.isEmpty() || "IDLE".equals(stage) || "PREPARING".equals(stage) || "START".equals(stage)) return "подготовка";
        if ("AUTHENTICATING".equals(stage) || "REAUTHENTICATING".equals(stage)) return "авторизация Cubux";
        if ("TEAM".equals(stage)) return "получение данных команды";
        if ("RANGE".equals(stage) || "LOADING_META".equals(stage)) return "определение диапазона и объёма данных";
        if ("LIGHT".equals(stage) || "LIGHT_META".equals(stage)) return "лёгкая проверка — метаданные";
        if ("LIGHT_SUMMARY".equals(stage)) return "лёгкая проверка — контрольные суммы";
        if ("LIGHT_MONTHLY".equals(stage) || "MONTHLY_CONTROL".equals(stage) || "MONTHLY_CONTROL_START".equals(stage)) return "контроль истории по месяцам";
        if ("LIGHT_BASELINE_MIGRATION".equals(stage) || "LIGHT_BASELINE_READY".equals(stage) || "CONTROL_BASELINE".equals(stage)) return "контрольный эталон лёгкой проверки";
        if ("LIGHT_MISMATCH".equals(stage)) return "поиск проблемного периода";
        if ("LIGHT_DEEP".equals(stage)) return "подробная проверка изменённого периода";
        if ("LIGHT_NO_CHANGES".equals(stage)) return "лёгкая проверка — расхождений нет";
        if ("AUTO_FULL".equals(stage) || "BASELINE_REQUIRED".equals(stage)) return "переход к полной проверке";
        if ("READING_DATA".equals(stage)) return "чтение операций Cubux";
        if ("READ_COMPLETE".equals(stage)) return "основная загрузка завершена";
        if (stage.startsWith("STABILITY") || stage.startsWith("MONTHLY_CONTROL") || "HISTORY_MOVED".equals(stage) || "HISTORY_RESCAN".equals(stage)) return "контроль стабильности истории";
        if ("PROCESSING".equals(stage) || "CLOSE_EMPTY_DAYS".equals(stage)) return "проверка целостности закрытых дней";
        if ("COMPARING".equals(stage) || "CHECKING_HISTORY".equals(stage)) return "сравнение с локальным эталоном";
        if ("SAVING".equals(stage)) return "сохранение результата";
        if (stage.startsWith("BACKUP")) return "резервная копия";
        if ("NO_INTERNET".equals(stage)) return "ожидание интернета";
        if ("INTERNET_RESTORED".equals(stage) || "RECONNECTING".equals(stage)) return "восстановление соединения";
        if ("RETRY_WAIT".equals(stage) || "WAITING_CUBUX".equals(stage)) return "повтор запроса Cubux";
        if ("AUTH_ERROR".equals(stage) || "PERMANENT_ERROR".equals(stage)) return "ошибка проверки";
        if ("COMPLETED".equals(stage)) return "готово";
        return stage.replace('_', ' ').toLowerCase(Locale.getDefault());
    }

    private void updateStageIndicators(String stage) {
        if (connectStep == null) return;
        String st = stage == null ? "" : stage;
        boolean completed = "COMPLETED".equals(st);
        boolean reading = completed || st.contains("READ") || st.contains("LOAD") || st.contains("STABILITY") || st.contains("HISTORY") || st.contains("LIGHT_DEEP");
        boolean comparing = completed || st.contains("PROCESS") || st.contains("COMPAR") || st.contains("CONTROL") || st.contains("LIGHT_NO_CHANGES") || st.contains("CLOSE_EMPTY");
        boolean reporting = completed || st.contains("SAVING") || st.contains("BACKUP") || st.contains("REPORT");
        boolean connected = completed || reading || comparing || reporting || st.contains("TEAM") || st.contains("RANGE") || st.contains("LIGHT") || st.contains("AUTH");
        setStageStep(connectStep, connected ? "✓" : "○", "Подключение\nк Cubux", connected ? GREEN : MUTED);
        setStageStep(readStep, reading ? "✓" : "○", "Чтение\nданных", reading ? GREEN : MUTED);
        setStageStep(compareStep, comparing ? "✓" : "○", "Сравнение", comparing ? GREEN : MUTED);
        setStageStep(reportStep, reporting ? "✓" : "○", "Отчёт", reporting ? GREEN : MUTED);
    }

    private void setStageStep(TextView view, String icon, String caption, int color) {
        if (view == null) return;
        view.setText(icon + "\n" + caption);
        view.setTextColor(color);
    }

    private void showResult(
            AuditEngine.Result r
    ) {
        try {
            CheckScheduler.scheduleNext(this);
            refreshAutoAuditStatus();
            requestNotificationPermissionIfNeeded();
        } catch (Throwable ignored) {
        }

        AuditForegroundService.updateStage(this, "COMPLETED", "Проверка завершена успешно", 100,
                maxPageShown, AuditForegroundService.pages, maxLoadedShown, AuditForegroundService.total);
        progressBar.setProgress(100);

        percentText.setText(
                "Проверка 100%"
        );

        statusText.setText(
                "Проверка завершена успешно"
        );
        updateStageIndicators("COMPLETED");
        if (pauseButton != null) pauseButton.setVisibility(View.GONE);
        if (stopButton != null) stopButton.setVisibility(View.GONE);
        String actualMode = db.getState("last_audit_mode");
        String checkLabel = AuditCoordinator.MODE_FULL.equals(activeCheckMode) ? "Полная проверка" :
                ("FULL_AFTER_LIGHT".equals(actualMode) ? "Быстрая → полная проверка" : "Быстрая проверка");
        CheckStatusStore.success(this, checkLabel, r);
        refreshLastCheckStatus();
        refreshDashboardInformer();

        long nextMs = parseLongState("next_scheduled_check_ms");
        String nextType = db.getState("next_scheduled_check_type");
        String nextText = nextMs > 0
                ? ((CheckSettings.TYPE_FULL.equals(nextType) ? "Полная" : "Быстрая") + " • " +
                   new java.text.SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(new java.util.Date(nextMs)))
                : "не запланирована";

        detailsText.setText(
                "Сейчас: проверка завершена успешно" +
                        "\nЭтап: готово" +
                        "\nПроверено: " + r.total + " операций" +
                        "\nРезультат: новые " + r.newCount + " • изменённые " + r.changedCount + " • удалённые " + r.deletedCount +
                        "\nВремя проверки: " + TimeUtil.formatDuration(r.durationMs) +
                        "\nСледующая проверка: " + nextText
        );

        setStat(
                totalTop,
                "▤",
                r.total,
                "Всего операций"
        );

        setStat(
                newTop,
                "+",
                r.newCount,
                "Новые"
        );

        setStat(
                changedTop,
                "✎",
                r.changedCount,
                "Изменённые"
        );

        setStat(
                deletedTop,
                "▥",
                r.deletedCount,
                "Удалённые"
        );

        setMiniStat(
                newCard,
                "▤",
                r.newCount,
                "Новые"
        );

        setMiniStat(
                changedCard,
                "✎",
                r.changedCount,
                "Изменённые"
        );

        setMiniStat(
                deletedCard,
                "▥",
                r.deletedCount,
                "Удалённые"
        );

        setMiniStat(
                closedCard,
                "▣",
                r.closedChangedCount,
                "Закрытые"
        );

        setMiniStat(
                multiCard,
                "↻",
                r.multiChangedCount,
                "Повторные"
        );

        resultText.setText(
                "Целостность: ОК • Cubux: только чтение"
        );
    }

    private void setStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        if (view == null) return;
        view.setText(
                icon +
                        "   " +
                        value +
                        "\n" +
                        caption
        );
    }

    private void setMiniStat(
            TextView view,
            String icon,
            int value,
            String caption
    ) {
        if (view == null) return;
        view.setText(
                icon +
                        "\n" +
                        value +
                        "\n" +
                        caption
        );
    }

    private void showLoginDialog(
            boolean runAfterSave
    ) {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        int pad = dp(18);

        box.setPadding(
                pad,
                0,
                pad,
                0
        );

        EditText login =
                new EditText(this);

        login.setHint(
                "Логин Cubux"
        );

        login.setSingleLine(true);

        login.setText(
                credentials.getLogin()
        );

        EditText password =
                new EditText(this);

        password.setHint(
                "Пароль Cubux"
        );

        password.setSingleLine(true);

        password.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        box.addView(login);
        box.addView(password);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Авторизация Cubux"
                )
                .setMessage(
                        "Приложение само получит и будет обновлять API-токен."
                )
                .setView(box)
                .setPositiveButton(
                        "Сохранить",
                        (d, w) -> {
                            try {
                                credentials.saveCredentials(
                                        login.getText()
                                                .toString()
                                                .trim(),
                                        password.getText()
                                                .toString()
                                );

                                credentials.clearToken();

                                Toast.makeText(
                                        this,
                                        "Данные сохранены",
                                        Toast.LENGTH_SHORT
                                ).show();

                                if (runAfterSave) {
                                    runAudit();
                                }

                            } catch (Exception e) {
                                Toast.makeText(
                                        this,
                                        "Ошибка сохранения",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void showSettingsDialog() {
        CheckSettings cfg = new CheckSettings(this);
        String[] items = {
                "Логин и пароль Cubux",
                "Автопроверка и автозапуск",
                "Расписание лёгкой проверки",
                "Расписание полной проверки",
                "Повторных попыток: " + cfg.retries(),
                "Пауза между запросами: " + DelayProfile.label(cfg.requestDelayMs()),
                "Расширенная диагностика",
                "Удалить данные авторизации"
        };

        new AlertDialog.Builder(this)
                .setTitle("Настройки")
                .setItems(items, (d, which) -> {
                    if (which == 0) showLoginDialog(false);
                    else if (which == 1) showAutoStartSettings();
                    else if (which == 2) scheduleSettingsDialog(CheckSettings.TYPE_LIGHT);
                    else if (which == 3) scheduleSettingsDialog(CheckSettings.TYPE_FULL);
                    else if (which == 4) retrySettingsDialog();
                    else if (which == 5) delaySettingsDialog();
                    else if (which == 6) showAdvancedDiagnosticsDialog();
                    else {
                        credentials.clearAll();
                        CheckScheduler.cancel(this);
                        Toast.makeText(this, "Логин, пароль и токен удалены", Toast.LENGTH_SHORT).show();
                        refreshAutoAuditStatus();
                    }
                }).show();
    }

    private void showAutoStartSettings() {
        boolean exact=CheckScheduler.canScheduleExact(this);
        long next=parseLongState("next_scheduled_check_ms");
        long last=parseLongState("last_scheduled_start_ms");
        String nextText=next>0?new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new java.util.Date(next)):"не запланирована";
        String lastText=last>0?new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss",Locale.getDefault()).format(new java.util.Date(last)):"ещё не запускалась";
        String msg="Автопроверка: "+(next>0?"включена":"нет активного расписания")+
                "\nТочный запуск: "+(exact?"разрешён":"НЕ разрешён системой")+
                "\nЗапуск при закрытом приложении: включён"+
                "\nАвтозапуск после перезагрузки: включён"+
                "\nПропущенная проверка: выполнить после включения телефона"+
                "\nСледующая проверка: "+nextText+
                "\nПоследний запуск по расписанию: "+lastText;
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("Автопроверка и автозапуск").setMessage(msg).setPositiveButton("Готово",null);
        if(Build.VERSION.SDK_INT>=31&&!exact){b.setNeutralButton("Исправить",(d,w)->{try{Intent i=new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Throwable e){startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}});}
        b.setNegativeButton("Перепланировать",(d,w)->{CheckScheduler.scheduleNext(this);refreshAutoAuditStatus();Toast.makeText(this,"Расписание обновлено",Toast.LENGTH_SHORT).show();}).show();
    }

    private void showAdvancedDiagnosticsDialog() {
        String[] items = {
                "Технические данные изменений",
                "Служебный лог проверок и запросов",
                "Экспортировать служебный лог",
                "Очистить служебный лог"
        };
        new AlertDialog.Builder(this)
                .setTitle("Расширенная диагностика")
                .setMessage("Технический раздел. Здесь видны ID операций, старые/новые данные, причины NEW / CHANGED / DELETED, страницы проверки, HTTP-коды и служебные статусы.")
                .setItems(items, (d, which) -> {
                    if (which == 0) resultText.setText(db.diagnosticJournal());
                    else if (which == 1) resultText.setText("СЛУЖЕБНЫЙ ЛОГ ПРОВЕРОК И ЗАПРОСОВ\n\n" + DiagnosticLog.read(this));
                    else if (which == 2) exportDiagnosticLog();
                    else {
                        DiagnosticLog.clear(this);
                        Toast.makeText(this, "Служебный лог очищен", Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }

    private void scheduleSettingsDialog(String type) {
        CheckSettings cfg = new CheckSettings(this);
        boolean full = CheckSettings.TYPE_FULL.equals(type);
        int mask = full ? cfg.fullDays() : cfg.lightDays();
        String time = full ? cfg.fullTime() : cfg.lightTime();
        int[] hm = CheckSettings.parseTime(time);
        final int[] selectedTime = {hm[0], hm[1]};
        String[] days = CheckSettings.dayNames();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(4), dp(18), 0);
        final android.widget.CheckBox[] checks = new android.widget.CheckBox[7];
        for (int i=0;i<7;i++) {
            android.widget.CheckBox cb = new android.widget.CheckBox(this);
            cb.setText(days[i]);
            cb.setChecked((mask & (1 << i)) != 0);
            cb.setTextSize(16);
            cb.setPadding(0, dp(3), 0, dp(3));
            checks[i]=cb;
            box.addView(cb);
        }
        Button timeButton = new Button(this);
        timeButton.setAllCaps(false);
        timeButton.setText(String.format(Locale.US,"Время запуска: %02d:%02d",selectedTime[0],selectedTime[1]));
        timeButton.setOnClickListener(v -> new android.app.TimePickerDialog(this,(view,h,m)->{
            selectedTime[0]=h;selectedTime[1]=m;
            timeButton.setText(String.format(Locale.US,"Время запуска: %02d:%02d",h,m));
        },selectedTime[0],selectedTime[1],true).show());
        box.addView(timeButton);

        TextView note = label(full
                ? "Если на этот же день назначена лёгкая проверка, выполняется только полная."
                : "Если на этот же день назначена полная проверка, лёгкая отдельно не запускается.",
                12,false,MUTED);
        note.setPadding(0,dp(8),0,0); box.addView(note);

        new AlertDialog.Builder(this)
                .setTitle(full ? "Полная проверка" : "Быстрая проверка")
                .setView(box)
                .setPositiveButton("Сохранить",(d,w)->{
                    int newMask=0; for(int i=0;i<7;i++)if(checks[i].isChecked())newMask|=(1<<i);
                    String t=String.format(Locale.US,"%02d:%02d",selectedTime[0],selectedTime[1]);
                    if(full){cfg.setFullDays(newMask);cfg.setFullTime(t);}else{cfg.setLightDays(newMask);cfg.setLightTime(t);}
                    CheckScheduler.scheduleNext(this); refreshAutoAuditStatus();
                    Toast.makeText(this,"Расписание сохранено",Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Отмена",null).show();
    }

    private void retrySettingsDialog() {
        final int[] values={1,3,5,7,10};
        String[] labels={"1 попытка","3 попытки","5 попыток","7 попыток","10 попыток"};
        new AlertDialog.Builder(this).setTitle("Повторные попытки при ошибке")
                .setItems(labels,(d,which)->{
                    new CheckSettings(this).setRetries(values[which]);
                    Toast.makeText(this,"Повторных попыток: "+values[which],Toast.LENGTH_SHORT).show();
                    refreshAutoAuditStatus();
                }).show();
    }

    private void delaySettingsDialog() {
        CheckSettings cfg = new CheckSettings(this);
        long currentMs = cfg.requestDelayMs();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        TextView info = new TextView(this);
        info.setText("Пауза между последовательными запросами Cubux: 0,5–10 секунд. 0,5 сек — самый жёсткий режим; при 429, таймаутах и ошибках сервера защитные задержки увеличиваются автоматически.");
        info.setTextSize(16);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, 0, 0, dp(12));
        box.addView(info, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        String[] labels = DelayProfile.labels();
        NumberPicker picker = new NumberPicker(this);
        picker.setMinValue(0);
        picker.setMaxValue(labels.length - 1);
        picker.setDisplayedValues(labels);
        picker.setValue(DelayProfile.indexFor(currentMs));
        picker.setWrapSelectorWheel(false);
        picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        box.addView(picker, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView current = new TextView(this);
        current.setText("Выбрано: " + DelayProfile.label(currentMs) +
                (currentMs == DelayProfile.DEFAULT_MS ? " (по умолчанию)" : ""));
        current.setTextSize(14);
        current.setGravity(Gravity.CENTER);
        current.setPadding(0, dp(8), 0, 0);
        box.addView(current, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        picker.setOnValueChangedListener((p, oldVal, newVal) -> {
            long ms = DelayProfile.millisForIndex(newVal);
            current.setText("Выбрано: " + DelayProfile.label(ms) +
                    (ms == DelayProfile.DEFAULT_MS ? " (по умолчанию)" : ""));
        });

        new AlertDialog.Builder(this)
                .setTitle("Пауза между запросами Cubux")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (d, which) -> {
                    long ms = DelayProfile.millisForIndex(picker.getValue());
                    new CheckSettings(this).setRequestDelayMs(ms);
                    Toast.makeText(this, "Пауза: " + DelayProfile.label(ms), Toast.LENGTH_SHORT).show();
                    refreshAutoAuditStatus();
                })
                .show();
    }

    private String scheduleDaysText(int mask) {
        String[] n=CheckSettings.dayNames(); StringBuilder b=new StringBuilder();
        for(int i=0;i<7;i++)if((mask&(1<<i))!=0){if(b.length()>0)b.append(", ");b.append(n[i]);}
        return b.length()==0?"выключена":b.toString();
    }

    private void refreshAutoAuditStatus() {
        if (detailsText == null) return;
        CheckSettings cfg=new CheckSettings(this);
        long next=parseLongState("next_scheduled_check_ms");
        String type=db.getState("next_scheduled_check_type");
        String nextText=next>0
                ? (CheckSettings.TYPE_FULL.equals(type)?"Полная":"Лёгкая")+" • "+
                  new java.text.SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new java.util.Date(next))
                : "нет";
        String first=new HistoryRange(db).startDate();
        detailsText.setText(
                "Следующая: "+nextText+
                "\nЛёгкая: "+scheduleDaysText(cfg.lightDays())+" • "+cfg.lightTime()+
                "\nПолная: "+scheduleDaysText(cfg.fullDays())+" • "+cfg.fullTime()+
                "\nЗапросы: последовательно, пауза "+DelayProfile.label(cfg.requestDelayMs())+
                " • попыток "+cfg.retries()+
                "\nНачало истории: "+(first==null?"определится по первой полной загрузке":first)
        );
    }

    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                        android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    2203
            );
        }
    }

    private void showReportsDialog() {
        String[] items = {
                "День",
                "Неделя",
                "Месяц",
                "Год",
                "Произвольный период"
        };

        ReportEngine r =
                new ReportEngine(db);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Отчёты"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                resultText.setText(
                                        r.today()
                                );
                            } else if (
                                    which == 1
                            ) {
                                resultText.setText(
                                        r.week()
                                );
                            } else if (
                                    which == 2
                            ) {
                                resultText.setText(
                                        r.month()
                                );
                            } else if (
                                    which == 3
                            ) {
                                resultText.setText(
                                        r.year()
                                );
                            } else {
                                customReportDialog();
                            }
                        }
                )
                .show();
    }

    private void showBankDialog() {
        String[] items = {
                "Импорт CSV / XLSX",
                "Сверить банк с Cubux"
        };

        new AlertDialog.Builder(this)
                .setTitle(
                        "Банковская сверка"
                )
                .setItems(
                        items,
                        (d, which) -> {
                            if (which == 0) {
                                pickBankFile();
                            } else {
                                new Thread(
                                        () -> {
                                            String text =
                                                    new BankReconcileEngine(
                                                            db
                                                    ).reconcile();

                                            runOnUiThread(
                                                    () ->
                                                            resultText
                                                                    .setText(
                                                                            text
                                                                    )
                                            );
                                        }
                                ).start();
                            }
                        }
                )
                .show();
    }

    private void showJournalDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText search =
                new EditText(this);

        search.setHint(
                "Поиск: дата, сумма, категория, счёт, описание, ID"
        );

        Spinner filter =
                new Spinner(this);

        String[] values = {
                "Все",
                "Новые",
                "Изменённые",
                "Удалённые",
                "Закрытые периоды",
                "Повторные изменения"
        };

        filter.setAdapter(
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        values
                )
        );

        box.addView(search);
        box.addView(filter);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Журнал изменений"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        db.journalText(
                                                journalFilterKey(filter.getSelectedItemPosition()),
                                                search.getText().toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private String journalFilterKey(int position) {
        switch (position) {
            case 1: return "NEW";
            case 2: return "CHANGED";
            case 3: return "DELETED";
            case 4: return "CLOSED";
            case 5: return "MULTI";
            default: return "ALL";
        }
    }

    private void customReportDialog() {
        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        EditText from =
                new EditText(this);

        from.setHint(
                "От YYYY-MM-DD"
        );

        EditText to =
                new EditText(this);

        to.setHint(
                "До YYYY-MM-DD"
        );

        box.addView(from);
        box.addView(to);

        new AlertDialog.Builder(this)
                .setTitle(
                        "Произвольный период"
                )
                .setView(box)
                .setPositiveButton(
                        "Показать",
                        (d, w) ->
                                resultText.setText(
                                        new ReportEngine(
                                                db
                                        ).report(
                                                from.getText()
                                                        .toString(),
                                                to.getText()
                                                        .toString()
                                        )
                                )
                )
                .setNegativeButton(
                        "Отмена",
                        null
                )
                .show();
    }

    private void pickBankFile() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType("*/*");

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_BANK
        );
    }

    private void exportDiagnosticLog() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "CubuxAudit-diagnostic-log.txt");
        startActivityForResult(i, REQ_LOG);
    }

    private void createBackup() {
        Intent i =
                new Intent(
                        Intent.ACTION_CREATE_DOCUMENT
                );

        i.setType(
                "application/zip"
        );

        i.putExtra(
                Intent.EXTRA_TITLE,
                "CubuxAudit-backup.zip"
        );

        startActivityForResult(
                i,
                REQ_BACKUP
        );
    }

    private void pickRestore() {
        Intent i =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        i.setType(
                "application/zip"
        );

        i.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
                i,
                REQ_RESTORE
        );
    }

    private String getDisplayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {
        }
        return uri.toString();
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (resultCode != RESULT_OK ||
                data == null ||
                data.getData() == null) {
            return;
        }

        Uri uri = data.getData();

        if (requestCode == REQ_LOG) {
            try {
                DiagnosticLog.export(this, uri);
                resultText.setText("Диагностический лог экспортирован. Его можно отправить для анализа ошибок.");
            } catch (Exception e) {
                resultText.setText("Ошибка экспорта лога: " + e.getMessage());
            }
        } else if (requestCode == REQ_BANK) {
            new Thread(
                    () -> {
                        try {
                            int imported =
                                    new BankImportEngine(
                                            db
                                    ).importFile(
                                            getContentResolver(),
                                            uri,
                                            getDisplayName(uri)
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Импортировано банковских операций: " +
                                                            imported
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка импорта: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (
                requestCode ==
                        REQ_BACKUP
        ) {
            new Thread(
                    () -> {
                        try {
                            String hash =
                                    new BackupManager(
                                            this,
                                            db
                                    ).exportTo(
                                            getContentResolver(),
                                            uri
                                    );

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Backup создан\nSHA-256:\n" +
                                                            hash
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка backup: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();

        } else if (
                requestCode ==
                        REQ_RESTORE
        ) {
            new Thread(
                    () -> {
                        try {
                            new BackupManager(
                                    this,
                                    db
                            ).restoreFrom(
                                    getContentResolver(),
                                    uri
                            );

                            db =
                                    new AuditDb(this);

                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                     "Резервная копия восстановлена. Следующая проверка будет синхронизационной: пропущенные операции догрузятся без массовых ложных «Новых»."
                                            )
                            );

                        } catch (Exception e) {
                            runOnUiThread(
                                    () ->
                                            resultText.setText(
                                                    "Ошибка восстановления: " +
                                                            e.getMessage()
                                            )
                            );
                        }
                    }
            ).start();
        }
    }
}
