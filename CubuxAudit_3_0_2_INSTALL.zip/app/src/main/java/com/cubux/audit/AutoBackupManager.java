package com.cubux.audit;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

/**
 * Writes a rolling database backup to shared Downloads on Android 10+.
 * The file lives outside the app sandbox, so uninstalling Cubux Security does not delete it.
 * Restore remains explicit through the existing "Восстановить backup" action.
 */
public final class AutoBackupManager {
    private static final Object LOCK = new Object();
    private static volatile boolean running;
    private static volatile boolean pending;

    private AutoBackupManager() {}

    public static void backupAsync(Context context) {
        if (context == null) return;
        final Context app = context.getApplicationContext();
        synchronized (LOCK) {
            if (running) {
                pending = true;
                return;
            }
            running = true;
            pending = false;
        }
        new Thread(() -> {
            while (true) {
                try {
                    backupNow(app);
                } catch (Throwable e) {
                    DiagnosticLog.error(app, "AUTO_BACKUP", e);
                    try {
                        AuditDb db = new AuditDb(app);
                        db.saveState("auto_backup_status", "ERROR: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
                        db.close();
                    } catch (Throwable ignored) {}
                }
                synchronized (LOCK) {
                    if (pending) {
                        pending = false;
                        continue;
                    }
                    running = false;
                    break;
                }
            }
        }, "cubux-auto-backup").start();
    }

    private static void backupNow(Context context) throws Exception {
        AuditDb db = new AuditDb(context);
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                db.saveState("auto_backup_status", "На Android ниже 10 используйте ручной backup");
                return;
            }

            ContentResolver resolver = context.getContentResolver();
            Uri uri = null;
            String saved = db.getState("auto_backup_uri");
            if (saved != null && !saved.trim().isEmpty()) {
                try {
                    Uri candidate = Uri.parse(saved.trim());
                    // Test that the row still exists and can be opened by BackupManager later.
                    resolver.openFileDescriptor(candidate, "rw").close();
                    uri = candidate;
                } catch (Throwable ignored) {
                    uri = null;
                }
            }

            boolean created = false;
            if (uri == null) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, "CubuxSecurity-backup-latest.zip");
                values.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Cubux Security");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Не удалось создать файл автокопии в Downloads");
                created = true;
            }

            String hash = new BackupManager(context, db).exportTo(resolver, uri);

            if (created) {
                ContentValues ready = new ContentValues();
                ready.put(MediaStore.Downloads.IS_PENDING, 0);
                resolver.update(uri, ready, null, null);
            }
            db.saveState("auto_backup_uri", uri.toString());
            db.saveState("auto_backup_time", TimeUtil.now());
            db.saveState("auto_backup_sha256", hash);
            db.saveState("auto_backup_status", "OK");
            DiagnosticLog.write(context, "AUTO_BACKUP", "Автокопия базы обновлена в Downloads/Cubux Security");
        } finally {
            db.close();
        }
    }
}
