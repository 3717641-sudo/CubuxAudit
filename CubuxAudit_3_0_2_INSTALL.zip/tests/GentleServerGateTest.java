package com.cubux.audit;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicBoolean;
public class GentleServerGateTest {
    static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
    static long deadline()throws Exception{Field f=GentleServerGate.class.getDeclaredField("notBefore");f.setAccessible(true);return f.getLong(null);}
    static void clear()throws Exception{Field f=GentleServerGate.class.getDeclaredField("notBefore");f.setAccessible(true);f.setLong(null,0);}
    public static void main(String[] args)throws Exception{
        check(GentleServerGate.retryAfterMs("120",0)==120000,"numeric Retry-After");
        check(GentleServerGate.retryAfterMs("Thu, 01 Jan 1970 00:02:00 GMT",0)==120000,"date Retry-After");
        check(GentleServerGate.retryAfterMs("bad",0)==0,"invalid Retry-After");
        GentleServerGate.configure(500,null,x->{});
        GentleServerGate.begin(null,null);long started=System.nanoTime();
        AtomicBoolean entered=new AtomicBoolean();
        Thread t=new Thread(()->{try{GentleServerGate.begin(null,null);entered.set(true);GentleServerGate.end(System.nanoTime(),500);}catch(Exception e){throw new RuntimeException(e);}});
        t.start();Thread.sleep(100);check(!entered.get(),"parallel request blocked");
        GentleServerGate.end(started,500);long ended=System.nanoTime();
        t.join(3500);check(entered.get(),"waiting request continues");
        check((System.nanoTime()-ended)/1000000>=400,"0.5 second after completion");
        clear();GentleServerGate.response(429,"120");check(deadline()-System.currentTimeMillis()>119000,"server Retry-After respected");
        clear();GentleServerGate.response(503,null);check(deadline()-System.currentTimeMillis()>299000,"escalated cooldown");
        AuditControl c=new AuditControl();c.stop();try{GentleServerGate.begin(c,null);throw new AssertionError("stop ignored");}catch(java.io.IOException expected){}
        clear();GentleServerGate.begin(null,null);GentleServerGate.end(System.nanoTime()-11000000000L,500);check(deadline()-System.currentTimeMillis()>900,"slow response increases pause");
        clear();GentleServerGate.configure(1000,String.valueOf(System.currentTimeMillis()+60000),x->{});check(deadline()-System.currentTimeMillis()>59000,"persisted cooldown restored");
        System.out.println("PASS: 0.5s minimum; serialization; Retry-After; adaptive/backoff; stop; persisted cooldown");
    }
}
